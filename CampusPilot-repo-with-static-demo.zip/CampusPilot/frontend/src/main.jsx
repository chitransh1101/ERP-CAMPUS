import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// Installable app (PWA): register the service worker in production builds.
if ("serviceWorker" in navigator && !(import.meta.env && import.meta.env.DEV)) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js").catch(() => { /* not critical: the site works without it */ });
  });
}
