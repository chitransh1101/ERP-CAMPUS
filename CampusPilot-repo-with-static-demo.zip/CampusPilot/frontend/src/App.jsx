import React, { useState, useEffect, useRef, useMemo, useCallback, useId } from "react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  BarChart,
  Bar,
  CartesianGrid,
  LabelList,
} from "recharts";

class PortalErrorBoundary extends React.Component {
  constructor(props) { super(props); this.state = { error: null }; }
  static getDerivedStateFromError(error) { return { error }; }
  componentDidCatch(error, info) { console.error("CampusPilot crash:", error, info); }
  render() {
    if (this.state.error) {
      return (
        <div style={{ padding: 40, fontFamily: "monospace", color: "#eee", background: "#1a1a1a", minHeight: "100vh" }}>
          <h2 style={{ color: "#ff6b6b" }}>Something broke in the {this.props.label || "app"}</h2>
          <p>{String(this.state.error && this.state.error.message)}</p>
          <pre style={{ whiteSpace: "pre-wrap", opacity: 0.7 }}>{this.state.error && this.state.error.stack}</pre>
          <button onClick={() => this.setState({ error: null })} style={{ marginTop: 16, padding: "8px 16px" }}>Try again</button>
        </div>
      );
    }
    return this.props.children;
  }
}

const ICONS = {
  grid: "M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z",
  book: "M5 4h9a3 3 0 0 1 3 3v13H8a3 3 0 0 0-3 3V4Z",
  target: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm0-4a5 5 0 1 0 0-10 5 5 0 0 0 0 10Zm0-3.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z",
  briefcase: "M4 8h16v11H4zM9 8V6a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2M4 13h16",
  mail: "M4 6h16v12H4zM4 6l8 7 8-7",
  gear: "M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7ZM19.4 13.5a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V19.5a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H4.5a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.9l-.1-.1A2 2 0 1 1 8.5 4l.1.1a1.7 1.7 0 0 0 1.9.3H10.6a1.7 1.7 0 0 0 1-1.5V4.5a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9v.1a1.7 1.7 0 0 0 1.5 1H19.5a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z",
  search: "M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14Zm10 17-5.6-5.6",
  bell: "M6 9a6 6 0 1 1 12 0c0 4 1.5 5.5 1.5 5.5H4.5S6 13 6 9Zm4.5 9a1.5 1.5 0 0 0 3 0",
  chevronDown: "M6 9l6 6 6-6",
  arrowUpRight: "M7 17 17 7M9 7h8v8",
  check: "M5 13l4.5 4.5L19 8",
  clock: "M12 7v5l3.5 2M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z",
  calendar: "M4 5h16v16H4zM4 9h16M8 3v4M16 3v4M8 14h2M14 14h2M8 17h2M14 17h2",
  chat: "M4 5h16v11H8l-4 4Z",
  shield: "M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6Z M9 12l2 2 4-4",
  rupee: "M6 4h11M6 8h11M6 4c5 0 8 2 8 4.5S13 13 6 13l8 8",
  barchart: "M5 20V10M11 20V4M17 20v-7",
  inbox: "M4 5h16v14H4Z M4 12h5l2 3h2l2-3h5",
  forum: "M4 5h11v8H9l-3 3v-3H4zM13 9h7v7h-3v3l-3-3h-1z",
  clipboard: "M8 4h8v3H8zM6 6h12v15H6ZM9 12h6M9 16h6",
  upload: "M12 16V6M8 10l4-4 4 4M4 18h16",
  folder: "M4 6h6l2 2h8v11H4Z",
  chevronRight: "M9 6l6 6-6 6",
  home: "M4 11l8-7 8 7v9a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1Z",
  minus: "M5 12h14",
  close: "M6 6l12 12M18 6L6 18",
  sun: "M12 3v2.4M12 18.6V21M5 5l1.7 1.7M17.3 17.3 19 19M3 12h2.4M18.6 12H21M5 19l1.7-1.7M17.3 6.7 19 5M12 8.2a3.8 3.8 0 1 0 0 7.6 3.8 3.8 0 0 0 0-7.6Z",
  moon: "M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79Z",
  download: "M12 4v11M7.5 10.5 12 15l4.5-4.5M4 19h16",
  qr: "M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h2.5v2.5H14zM17.5 17.5H20V20h-2.5zM14 18h2v2h-2zM18 14h2v2h-2zM6.5 6.5h1v1h-1zM16.5 6.5h1v1h-1zM6.5 16.5h1v1h-1z",
  exam: "M6 3h9l3 3v15H6zM15 3v3h3M9 10h6M9 13.5h6M9 17h3.5",
  award: "M12 14.5a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11ZM8.6 13.4 7.5 21l4.5-2.6 4.5 2.6-1.1-7.6",
  send: "M21 3 10 14M21 3l-7 18-4-7-7-4Z",
  idcard: "M3 6h18v12H3zM8.5 12.5a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM5.5 16c.5-1.6 1.7-2.5 3-2.5s2.5.9 3 2.5M14 10h4.5M14 13.5h4.5",
  family: "M8 8.5a2.8 2.8 0 1 0 0-5.6 2.8 2.8 0 0 0 0 5.6ZM17 9.5a2.2 2.2 0 1 0 0-4.4 2.2 2.2 0 0 0 0 4.4ZM2.5 20c0-4 2.5-6.5 5.5-6.5s5.5 2.5 5.5 6.5M13.5 20c.2-3 1.6-5 3.5-5s3.3 2 3.5 5",
  pie: "M12 3v9h9A9 9 0 1 1 12 3ZM15 3.5A8 8 0 0 1 20.5 9H15Z",
  sparkle: "M12 3l1.6 4.9L18.5 9.5l-4.9 1.6L12 16l-1.6-4.9L5.5 9.5l4.9-1.6ZM18.5 15l.7 2 2 .7-2 .7-.7 2-.7-2-2-.7 2-.7Z",
  zoomIn: "M10.5 17a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13ZM20 20l-4.8-4.8M10.5 8v5M8 10.5h5",
  zoomOut: "M10.5 17a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13ZM20 20l-4.8-4.8M8 10.5h5",
  lock: "M6 10.5V8a6 6 0 0 1 12 0v2.5M5 10.5h14v10H5Z",
  user: "M12 12a4.5 4.5 0 1 0 0-9 4.5 4.5 0 0 0 0 9ZM4 21c1.5-4.5 5-6.5 8-6.5s6.5 2 8 6.5",
  users: "M9 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7ZM2 20c.6-3.4 3.4-5.5 7-5.5s6.4 2.1 7 5.5M17 8.5a3 3 0 1 0 0-6M22 20c-.4-2.3-1.7-4-3.7-4.8",
  logout: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9",
  cap: "M12 3 2 8l10 5 10-5-10-5Z M6 11.5V16c0 1.7 2.7 3 6 3s6-1.3 6-3v-4.5 M22 8v5",
  plus: "M12 5v14M5 12h14",
  camera: "M4 8h3l2-3h6l2 3h3v11H4Z M12 12a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7Z",
  wallet: "M3 7h15a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h11M16 13h3",
  activity: "M22 12h-4l-3 9L9 3l-3 9H2",
  building: "M6 21V5a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v16M3 21h18M9 9h1M14 9h1M9 13h1M14 13h1M9 17h1M14 17h1",
  alert: "M12 9v3m0 4h.01M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0Z",
  eye: "M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z",
  eyeOff: "M3 3l18 18 M10.6 5.2A10.8 10.8 0 0 1 12 5c6.5 0 10 7 10 7a17.9 17.9 0 0 1-3.5 4.4M6.6 6.6C4 8.3 2 12 2 12s3.5 7 10 7c1.6 0 3-.4 4.2-1M9.9 9.9a3 3 0 0 0 4.2 4.2",
  clipboardCheck: "M8 4h8v3H8zM6 6h12v15H6ZM9 13.5l2 2 4-4.5",
};
function Icon({ name, size = 18, strokeWidth = 1.9 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
      strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={ICONS[name] || ""} />
    </svg>
  );
}

function BrandMark({ size = 26 }) {
  return (
    <span className="cp-logo-mark" style={{ width: size, height: size }} aria-hidden="true">
      <svg width="100%" height="100%" viewBox="0 0 40 40" fill="none">
        <defs>
          <linearGradient id="cpLogoGrad" x1="2" y1="2" x2="38" y2="38" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#22D3C0" />
            <stop offset="52%" stopColor="#2C7FBE" />
            <stop offset="100%" stopColor="#233E68" />
          </linearGradient>
        </defs>
        <rect x="1" y="1" width="38" height="38" rx="11.5" fill="url(#cpLogoGrad)" />
        <path d="M20 9.5 L32.5 15 L20 20.5 L7.5 15 Z" fill="#fff" fillOpacity="0.96" />
        <path d="M13.2 17.3v6c0 1.9 3 3.4 6.8 3.4s6.8-1.5 6.8-3.4v-6" stroke="#fff" strokeOpacity="0.96" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M32.5 15v6.9" stroke="#fff" strokeOpacity="0.96" strokeWidth="2" strokeLinecap="round" />
        <circle cx="32.5" cy="23.6" r="1.5" fill="#fff" fillOpacity="0.96" />
      </svg>
    </span>
  );
}

function PortalLoading({ label = "your data" }) {
  return (
    <div className="cp-portal-loading">
      <div className="cp-portal-loading-spinner" />
      <div className="cp-portal-loading-text">Loading {label}…</div>
    </div>
  );
}

function SectionLoading({ label = "Loading…" }) {
  return <div className="cp-section-loading"><span className="cp-spinner cp-spinner--sm" />{label}</div>;
}

function uid(prefix) { return prefix + "_" + Math.random().toString(36).slice(2, 9); }
function nowMs() { return Date.now(); }
function timeAgo(ts) {
  const s = Math.max(1, Math.floor((Date.now() - ts) / 1000));
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}
function initialsOf(name) {
  const parts = (name || "").trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "—";
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

const realtimeBus = (() => {
  const listeners = {};
  return {
    on(channel, fn) {
      (listeners[channel] = listeners[channel] || []).push(fn);
      return () => { listeners[channel] = (listeners[channel] || []).filter((f) => f !== fn); };
    },
    emit(channel, payload) { (listeners[channel] || []).forEach((fn) => { try { fn(payload); } catch (e) { console.error(e); } }); },
  };
})();

// Live connection to the server. Every event the backend publishes
// (notifications, attendance, grades, grievances, placements, OCR drafts…)
// arrives here and is re-emitted on realtimeBus, so every open tab and
// device updates instantly. Reconnects with exponential backoff.
const liveState = { connected: false, lastEvent: Date.now() };
let liveSocket = null, liveRetry = 0, liveTimer = null, livePing = null, liveWanted = false;
function wsUrl() {
  const base = /^https?:/.test(API_BASE) ? API_BASE : window.location.origin + API_BASE;
  return base.replace(/^http/, "ws").replace(/\/$/, "") + "/ws";
}
function setLive(v) {
  const was = liveState.connected;
  liveState.connected = v;
  realtimeBus.emit("live:status", v);
  if (v && !was) realtimeBus.emit("live:reconnected", true);
}
function scheduleReconnect() {
  clearTimeout(liveTimer);
  const wait = Math.min(30000, 1000 * 2 ** liveRetry++);
  liveTimer = setTimeout(connectLive, wait);
}
function connectLive() {
  liveWanted = true;
  if (liveSocket && liveSocket.readyState <= 1) return;
  let ws;
  try { ws = new WebSocket(wsUrl()); } catch { scheduleReconnect(); return; }
  liveSocket = ws;
  ws.onopen = () => {
    liveRetry = 0; setLive(true);
    clearInterval(livePing);
    livePing = setInterval(() => { try { ws.send("ping"); } catch { /* reconnect handles it */ } }, 25000);
  };
  ws.onmessage = (ev) => {
    let msg;
    try { msg = JSON.parse(ev.data); } catch { return; }
    liveState.lastEvent = Date.now();
    if (msg.type === "session:revoked") { window.dispatchEvent(new CustomEvent("cp:session-expired")); return; }
    if (msg.type && msg.type !== "pong" && msg.type !== "hello") realtimeBus.emit(msg.type, msg.data);
  };
  ws.onclose = (ev) => {
    clearInterval(livePing);
    if (liveSocket === ws) liveSocket = null;
    setLive(false);
    if (ev.code === 4401) return;          // not signed in: don't hammer the server
    if (liveWanted) scheduleReconnect();
  };
  ws.onerror = () => { try { ws.close(); } catch { /* ignore */ } };
}
function disconnectLive() {
  liveWanted = false;
  clearTimeout(liveTimer); clearInterval(livePing);
  if (liveSocket) { try { liveSocket.close(); } catch { /* ignore */ } liveSocket = null; }
  setLive(false);
}
if (typeof document !== "undefined") {
  document.addEventListener("visibilitychange", () => { if (!document.hidden && liveWanted && !liveState.connected) { liveRetry = 0; connectLive(); } });
}

const WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const DAY_SLOTS = ["9:00 AM", "10:00 AM", "11:15 AM", "12:30 PM", "2:00 PM", "3:15 PM"];
const ROOMS = ["B-204", "Lab 3", "A-102", "B-118", "C-210", "Lab 1"];

function buildTimetable(courses) {
  const grid = Object.fromEntries(WEEKDAYS.map((d) => [d, []]));
  if (!courses.length) return grid;
  let slotCursor = 0;
  courses.forEach((course, ci) => {
    const sessionsPerWeek = 3;
    for (let s = 0; s < sessionsPerWeek; s++) {
      const dayIdx = (ci * 2 + s * 2 + 1) % WEEKDAYS.length;
      const day = WEEKDAYS[dayIdx];
      const slot = DAY_SLOTS[slotCursor % DAY_SLOTS.length];
      grid[day].push({ time: slot, course: course.name, code: course.code, room: ROOMS[(ci + s) % ROOMS.length] });
      slotCursor++;
    }
  });
  WEEKDAYS.forEach((d) => grid[d].sort((a, b) => DAY_SLOTS.indexOf(a.time) - DAY_SLOTS.indexOf(b.time)));
  return grid;
}

function gradeDistribution(entries) {
  const bands = [{ label: "A", min: 85 }, { label: "B", min: 70 }, { label: "C", min: 55 }, { label: "D", min: 40 }, { label: "F", min: 0 }];
  const counts = bands.map((b) => ({ label: b.label, value: 0 }));
  entries.forEach((e) => {
    const idx = bands.findIndex((b) => e.score >= b.min);
    if (idx >= 0) counts[idx].value += 1;
  });
  return counts;
}

const GRIEVANCE_CATEGORIES_STUDENT = ["Academic", "Hostel", "Fees & Finance", "Ragging / Harassment", "Infrastructure", "Other"];
const GRIEVANCE_CATEGORIES_TEACHER = ["Academic / Curriculum", "Timetable & Workload", "Payroll & HR", "Infrastructure & Labs", "Harassment / Workplace Conduct", "Administrative Support", "Other"];
const GRIEVANCE_CATEGORIES_ALL = Array.from(new Set([...GRIEVANCE_CATEGORIES_STUDENT, ...GRIEVANCE_CATEGORIES_TEACHER]));

function autoClassifyGrievance(text, role = "student") {
  const t = text.toLowerCase();
  const studentRules = [
    { category: "Ragging / Harassment", keywords: ["harass", "bully", "ragging", "misconduct", "discriminat", "abuse", "threat"] },
    { category: "Hostel", keywords: ["hostel", "warden", "roommate", "mess food", "dormitory"] },
    { category: "Fees & Finance", keywords: ["fee", "payment", "refund", "scholarship", "invoice", "overdue", "installment"] },
    { category: "Infrastructure", keywords: ["wifi", "wi-fi", "internet", "projector", "washroom", "toilet", "electricity", "ac ", "classroom", "lab equipment"] },
    { category: "Academic", keywords: ["exam", "marks", "grade", "attendance", "lecture", "syllabus", "assignment", "faculty", "professor"] },
  ];
  const teacherRules = [
    { category: "Harassment / Workplace Conduct", keywords: ["harass", "bully", "misconduct", "discriminat", "abuse", "threat"] },
    { category: "Payroll & HR", keywords: ["salary", "payroll", "payslip", "reimbursement", "provident fund", " pf ", "leave balance", "increment"] },
    { category: "Timetable & Workload", keywords: ["timetable", "schedule", "workload", "overloaded", "clash", "back-to-back", "substitution"] },
    { category: "Infrastructure & Labs", keywords: ["wifi", "wi-fi", "internet", "projector", "lab equipment", "staffroom", "electricity", "classroom", "ac "] },
    { category: "Academic / Curriculum", keywords: ["syllabus", "curriculum", "exam duty", "invigilation", "grading policy", "academic calendar"] },
    { category: "Administrative Support", keywords: ["admin", "paperwork", "approval", "hr department"] },
  ];
  const rules = role === "teacher" ? teacherRules : studentRules;
  for (const rule of rules) {
    if (rule.keywords.some((k) => t.includes(k))) return rule.category;
  }
  return "Other";
}

const RISK_WEIGHTS = { attendance: 0.45, score: 0.35, fee: 0.20 };
const RISK_THRESHOLDS = { low: 75, medium: 50 };

function feeComponentFor(feeStatus) {
  if (feeStatus === "paid") return 100;
  if (feeStatus === "partial") return 50;
  if (feeStatus === "overdue") return 0;
  return 75;
}

function computeRiskScore({ attendancePct = 0, avgScore = 0, feeStatus }) {
  const feeComponent = feeComponentFor(feeStatus);
  const healthScore = Math.round(
    RISK_WEIGHTS.attendance * attendancePct +
    RISK_WEIGHTS.score * avgScore +
    RISK_WEIGHTS.fee * feeComponent
  );
  const riskLevel = healthScore >= RISK_THRESHOLDS.low ? "low" : healthScore >= RISK_THRESHOLDS.medium ? "medium" : "high";

  const reasons = [];
  if (attendancePct < 75) reasons.push(`Attendance ${attendancePct}% (below 75%)`);
  if (avgScore < 50) reasons.push(`Avg. score ${avgScore}/100 (below 50)`);
  if (feeStatus === "overdue") reasons.push("Fee overdue");
  else if (feeStatus === "partial") reasons.push("Fee partially paid");
  if (!reasons.length) reasons.push("No risk factors flagged");

  return { healthScore, riskLevel, reasons, feeComponent };
}

function withRiskScores(records) {
  return records.map((r) => ({ ...r, ...computeRiskScore(r) }));
}

function riskSummaryCounts(scoredRecords) {
  return {
    total: scoredRecords.length,
    low: scoredRecords.filter((r) => r.riskLevel === "low").length,
    medium: scoredRecords.filter((r) => r.riskLevel === "medium").length,
    high: scoredRecords.filter((r) => r.riskLevel === "high").length,
  };
}

const RISK_FORMULA_TEXT =
  "Early-warning heuristic computed on the server from real records: health score = 45% attendance + 35% average score + 20% fee status " +
  "(paid=100, partial=50, overdue=0); components with no data yet are left out. Score ≥75 = Low, 50–74 = Medium, <50 = High.";

function passwordStrength(pw) {
  if (!pw) return { label: "", pct: 0, tone: "" };
  let score = 0;
  if (pw.length >= 8) score++;
  if (pw.length >= 12) score++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
  if (/\d/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  if (pw.length < 8) return { label: "Too short — use at least 8 characters", pct: 15, tone: "weak" };
  if (!/[A-Za-z]/.test(pw) || !/\d/.test(pw)) return { label: "Needs both letters and numbers", pct: 35, tone: "weak" };
  if (score <= 2) return { label: "Okay — longer or mixed case is stronger", pct: 60, tone: "mid" };
  if (score === 3) return { label: "Good", pct: 80, tone: "good" };
  return { label: "Strong", pct: 100, tone: "strong" };
}

function PasswordStrengthHint({ password }) {
  const s = passwordStrength(password);
  if (!password) {
    return <div className="a2-pw-hint a2-pw-hint--idle">At least 8 characters with letters and numbers — 12+ with symbols is stronger.</div>;
  }
  return (
    <div className="a2-pw-hint">
      <div className="a2-pw-bar"><div className={`a2-pw-bar-fill a2-pw-bar-fill--${s.tone}`} style={{ width: `${s.pct}%` }} /></div>
      <span className={`a2-pw-label a2-pw-label--${s.tone}`}>{s.label}</span>
    </div>
  );
}

// Same-origin by default: nginx proxies /api to the backend, which lets the
// session live in an httpOnly cookie. Override with window.__CAMPUSPILOT_API__.
const API_BASE = ((typeof window !== "undefined" && window.__CAMPUSPILOT_API__) || "/api").replace(/\/$/, "");
const DEMO_MODE = typeof window !== "undefined" && window.__CAMPUSPILOT_DEMO__ === true;

function readCookie(name) {
  const m = typeof document !== "undefined" && document.cookie.match(new RegExp("(?:^|; )" + name + "=([^;]*)"));
  return m ? decodeURIComponent(m[1]) : "";
}

// The session token is an httpOnly cookie the browser sends automatically —
// JavaScript never sees it, so an injected script can't steal it. Writes
// carry the CSRF double-submit header the server checks.
async function apiFetch(path, { method = "GET", body, qs, timeoutMs = 30000 } = {}) {
  let url = `${API_BASE}${path}`;
  if (qs) {
    const params = new URLSearchParams();
    Object.entries(qs).forEach(([k, v]) => { if (v !== undefined && v !== null && v !== "") params.set(k, v); });
    const q = params.toString();
    if (q) url += `?${q}`;
  }
  const isFormData = typeof FormData !== "undefined" && body instanceof FormData;
  const headers = {};
  if (body !== undefined && !isFormData) headers["Content-Type"] = "application/json";
  if (method !== "GET") headers["X-CSRF-Token"] = readCookie("cp_csrf");

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  let res;
  try {
    res = await fetch(url, {
      method, headers, credentials: "include", signal: ctrl.signal,
      body: body === undefined ? undefined : isFormData ? body : JSON.stringify(body),
    });
  } catch (e) {
    throw new Error(e.name === "AbortError" ? "The server took too long to respond — please try again." : "Can't reach the CampusPilot server. Check your connection.");
  } finally {
    clearTimeout(timer);
  }
  const text = await res.text();
  let data = null;
  if (text) { try { data = JSON.parse(text); } catch { data = text; } }
  if (!res.ok) {
    const detail = data && typeof data === "object" ? data.detail : null;
    const msg = (typeof detail === "string" && detail) || `Request failed (${res.status})`;
    if (res.status === 401 && path !== "/auth/login" && path !== "/auth/me") {
      window.dispatchEvent(new CustomEvent("cp:session-expired"));
    }
    const err = new Error(msg);
    err.status = res.status;
    throw err;
  }
  return data;
}

const api = {
  auth: {
    async login(email, password, role) {
      const data = await apiFetch("/auth/login", { method: "POST", body: { email, password, role } });
      return data.user;
    },
    async signup(record) {
      const data = await apiFetch("/auth/signup", {
        method: "POST",
        body: { name: record.name, email: record.email, password: record.password, role: record.role, idLabel: record.idLabel },
      });
      return data.user;
    },
    async me() {
      try { return await apiFetch("/auth/me"); } catch (e) { if (e.status === 401) return null; throw e; }
    },
    changePassword: (currentPassword, newPassword) => apiFetch("/auth/change-password", { method: "POST", body: { currentPassword, newPassword } }),
    async logout() { try { await apiFetch("/auth/logout", { method: "POST" }); } catch { /* already signed out */ } },
    logoutAll: () => apiFetch("/auth/logout-all", { method: "POST" }),
  },
  notifications: {
    list: () => apiFetch("/notifications/"),
    markRead: (id) => apiFetch(`/notifications/${id}/read`, { method: "PATCH" }),
    markAllRead: () => apiFetch("/notifications/read-all", { method: "POST" }),
  },
  admin: {
    listUsers: (qs) => apiFetch("/admin/users", { qs }),
    createUser: (u) => apiFetch("/admin/users", {
      method: "POST",
      body: { name: u.name, email: u.email, role: u.role, idLabel: u.idLabel || null, department: u.department || null, designation: u.designation || null, phone: u.phone || null },
    }),
    setUserStatus: (id, status) => apiFetch(`/admin/users/${id}/status`, { method: "PATCH", body: { status } }),
    resetPassword: (id) => apiFetch(`/admin/users/${id}/reset-password`, { method: "POST" }),
    listCourses: () => apiFetch("/admin/courses"),
    createCourse: (c) => apiFetch("/admin/courses", { method: "POST", body: { code: c.code, name: c.name, dept: c.dept, facultyId: c.facultyId || null } }),
    courseStudents: (id) => apiFetch(`/admin/courses/${id}/students`),
    enroll: (id, studentIds) => apiFetch(`/admin/courses/${id}/enroll`, { method: "POST", body: { studentIds } }),
    listSubjectRequests: () => apiFetch("/admin/subject-requests"),
    approveSubjectRequest: (id) => apiFetch(`/admin/subject-requests/${id}/approve`, { method: "POST" }),
    rejectSubjectRequest: (id, reason) => apiFetch(`/admin/subject-requests/${id}/reject`, { method: "POST", body: { reason: reason || "" } }),
    listFees: () => apiFetch("/admin/fees"),
    markFeePaid: (id, amount) => apiFetch(`/admin/fees/${id}/mark-paid`, { method: "POST", body: amount ? { amount } : {} }),
    reportsSummary: () => apiFetch("/admin/reports/summary"),
    listAuditLog: (qs) => apiFetch("/admin/audit-log", { qs }),
    listGrievances: () => apiFetch("/admin/grievances"),
    assignGrievance: (id, assignee) => apiFetch(`/admin/grievances/${id}/assign`, { method: "POST", body: { assignee } }),
    resolveGrievance: (id, resolution) => apiFetch(`/admin/grievances/${id}/resolve`, { method: "POST", body: { resolution: resolution || "" } }),
    listLeave: () => apiFetch("/admin/leave-requests"),
    decideLeave: (id, status) => apiFetch(`/admin/leave-requests/${id}/decide`, { method: "POST", body: { status } }),
    riskScores: () => apiFetch("/admin/risk-scores"),
    importTemplates: () => apiFetch("/admin/import/templates"),
    importCsv: (kind, file) => { const f = new FormData(); f.append("file", file, file.name); return apiFetch(`/admin/import/${kind}`, { method: "POST", body: f, timeoutMs: 120000 }); },
  },
  teacher: {
    myCourses: () => apiFetch("/teacher/courses"),
    roster: (courseId) => apiFetch("/teacher/roster", { qs: { courseId } }),
    activity: () => apiFetch("/teacher/activity"),

    // ---- live OCR attendance drafts
    createDraft: (courseId, date) => apiFetch("/teacher/attendance/drafts", { method: "POST", body: { courseId, date } }),
    listDrafts: () => apiFetch("/teacher/attendance/drafts"),
    getDraft: (id) => apiFetch(`/teacher/attendance/drafts/${id}`),
    addDraftPhotos(id, files) {
      const form = new FormData();
      files.forEach((f) => form.append("files", f, f.name || "photo.jpg"));
      return apiFetch(`/teacher/attendance/drafts/${id}/photos`, { method: "POST", body: form, timeoutMs: 180000 });
    },
    overrideDraft: (id, studentId, present) => apiFetch(`/teacher/attendance/drafts/${id}/students/${studentId}`, { method: "PATCH", body: { present } }),
    publishDraft: (id) => apiFetch(`/teacher/attendance/drafts/${id}/publish`, { method: "POST" }),
    discardDraft: (id) => apiFetch(`/teacher/attendance/drafts/${id}`, { method: "DELETE" }),
    attendanceSessions: (courseId) => apiFetch("/teacher/attendance/sessions", { qs: { courseId } }),

    markAttendance: (courseId, records, date) => apiFetch("/teacher/attendance", { method: "POST", body: { courseId, records, date } }),
    publishGrades: (courseId, assessment, entries) => apiFetch("/teacher/grades", { method: "POST", body: { courseId, assessment, entries } }),
    gradeHistory: (courseId) => apiFetch("/teacher/grades", { qs: { courseId } }),

    getProfile: () => apiFetch("/teacher/profile"),
    updateProfile: (_userId, patch) => apiFetch("/teacher/profile", {
      method: "PATCH",
      body: Object.fromEntries(["phone", "department", "designation", "qualification", "office", "bio"].filter((k) => k in patch).map((k) => [k, patch[k] ?? null])),
    }),
    subjects: () => apiFetch("/teacher/subjects"),
    requestSubject: (payload) => apiFetch("/teacher/subject-requests", {
      method: "POST",
      body: { code: payload.code.trim(), name: payload.name.trim(), dept: (payload.dept || "General").trim(), notes: payload.notes ? payload.notes.trim() : "" },
    }),
    mySubjectRequests: () => apiFetch("/teacher/subject-requests/mine"),
    studentsWithStats: (courseIds) => apiFetch("/teacher/students", { qs: { courseIds: (courseIds || []).join(",") } }),
    riskScores: (courseIds) => apiFetch("/teacher/risk-scores", { qs: { courseIds: (courseIds || []).join(",") } }),
    listAssignments: () => apiFetch("/teacher/assignments"),
    createAssignment: (payload) => apiFetch("/teacher/assignments", { method: "POST", body: { title: payload.title, courseId: payload.courseId, due: payload.due } }),
    listMaterial: () => apiFetch("/teacher/materials"),
    uploadMaterial: (payload) => apiFetch("/teacher/materials", { method: "POST", body: { title: payload.title, courseId: payload.courseId, type: payload.type, size: payload.size } }),
    timetable: () => apiFetch("/teacher/timetable"),
    listNotices: () => apiFetch("/teacher/notices"),
    sendNotice: (payload) => apiFetch("/teacher/notices", { method: "POST", body: { title: payload.title, courseId: payload.courseId } }),
    listMyLeave: () => apiFetch("/teacher/leave"),
    applyLeave: (payload) => apiFetch("/teacher/leave", { method: "POST", body: { type: payload.type, from: payload.from, to: payload.to, reason: payload.reason || "" } }),
    raiseGrievance: (payload) => apiFetch("/teacher/grievances", { method: "POST", body: { category: payload.category, description: payload.description, contactEmail: payload.contactEmail || null } }),
    myGrievances: () => apiFetch("/teacher/grievances/mine"),
    reportsSummary: () => apiFetch("/teacher/reports/summary"),
  },
  student: {
    summary: () => apiFetch("/student/summary"),
    courses: () => apiFetch("/student/courses"),
    attendance: () => apiFetch("/student/attendance"),
    grades: () => apiFetch("/student/grades"),
    fees: () => apiFetch("/student/fees"),
    notices: () => apiFetch("/student/notices"),
    assignments: () => apiFetch("/student/assignments"),
    submitAssignment: (id) => apiFetch(`/student/assignments/${id}/submit`, { method: "POST" }),
    raiseGrievance: (payload) => apiFetch("/student/grievances", { method: "POST", body: { category: payload.category, description: payload.description, contactEmail: payload.contactEmail || null } }),
    myGrievances: () => apiFetch("/student/grievances/mine"),
    libraryCatalog: () => apiFetch("/student/library/catalog"),
    myLibraryRequests: () => apiFetch("/student/library/requests/mine"),
    requestBook: (book) => apiFetch("/student/library/requests", { method: "POST", body: { bookId: book.id } }),
    timetable: () => apiFetch("/student/timetable"),
  },
  placements: {
    list: () => apiFetch("/placements/"),
    create: (payload) => apiFetch("/placements/", {
      method: "POST",
      body: { company: payload.company, role: payload.role, package: payload.package, location: payload.location, minCGPA: payload.minCGPA, minAttendance: payload.minAttendance, deadline: payload.deadline },
    }),
    setStatus: (id, status) => apiFetch(`/placements/${id}/status`, { method: "PATCH", body: { status } }),
    apply: (placementId) => apiFetch(`/placements/${placementId}/apply`, { method: "POST" }),
    myApplications: () => apiFetch("/placements/mine"),
    listApplicants: (placementId) => apiFetch(`/placements/${placementId}/applicants`),
    setApplicationStatus: (appId, status) => apiFetch(`/placements/applications/${appId}`, { method: "PATCH", body: { status } }),
  },
};

const ROLES = [
  { key: "student", label: "Student", sub: "Timetable, marks & fees", icon: "cap", idLabel: "Roll Number",
    accent: "#1FC3B4", accentDeep: "#12756B", accentSoft: "#DCF3EE",
    authDesc: "Check your timetable, assignments, fees and results — all in one place." },
  { key: "teacher", label: "Faculty", sub: "Attendance & gradebook", icon: "book", idLabel: "Staff ID",
    accent: "#C79A3E", accentDeep: "#8A6A22", accentSoft: "#F6ECD5",
    authDesc: "Mark attendance by photo, publish grades, and keep your classes on track." },
  { key: "admin", label: "Admin", sub: "Full campus console", icon: "shield", idLabel: "Admin ID",
    accent: "#3A5A8C", accentDeep: "#1B2C4A", accentSoft: "#E4EAF3",
    authDesc: "Users, courses, fees, reports and the campus-wide audit trail in one console." },
  { key: "parent", label: "Parent", sub: "Your child's progress", icon: "family", idLabel: "Parent",
    accent: "#8B5CF6", accentDeep: "#5B3AA8", accentSoft: "#EDE7FB",
    authDesc: "Follow your child's attendance, marks, exams and fees — with instant SMS / WhatsApp alerts." },
];
function roleInfo(key) { return ROLES.find((r) => r.key === key) || ROLES[0]; }

// ============================================================ new API calls
Object.assign(api, {
  parent: {
    children: () => apiFetch("/parent/children"),
    child: (id, part) => apiFetch(`/parent/children/${id}/${part}`),
    messages: () => apiFetch("/parent/messages"),
  },
  exams: {
    all: () => apiFetch("/exams/admin"),
    create: (e) => apiFetch("/exams", { method: "POST", body: e }),
    remove: (id) => apiFetch(`/exams/${id}`, { method: "DELETE" }),
    teacher: () => apiFetch("/exams/teacher"),
    results: (id) => apiFetch(`/exams/${id}/results`),
    saveResults: (id, entries) => apiFetch(`/exams/${id}/results`, { method: "PUT", body: { entries } }),
    publish: (id) => apiFetch(`/exams/${id}/publish`, { method: "POST" }),
    mine: () => apiFetch("/exams/mine"),
  },
  qr: {
    start: (courseId) => apiFetch("/teacher/qr-sessions", { method: "POST", body: { courseId } }),
    open: () => apiFetch("/teacher/qr-sessions"),
    live: (id) => apiFetch(`/teacher/qr-sessions/${id}`, { qs: { origin: window.location.origin } }),
    mark: (id, studentId, present) => apiFetch(`/teacher/qr-sessions/${id}/mark`, { method: "POST", body: { studentId, present } }),
    publish: (id) => apiFetch(`/teacher/qr-sessions/${id}/publish`, { method: "POST" }),
    cancel: (id) => apiFetch(`/teacher/qr-sessions/${id}`, { method: "DELETE" }),
    checkin: (body) => apiFetch("/student/qr-checkin", { method: "POST", body: { ...body, device: deviceId() } }),
  },
  insights: {
    access: () => apiFetch("/analytics/access"),
    analytics: (dept) => apiFetch("/analytics", { qs: { dept } }),
    heads: () => apiFetch("/admin/department-heads"),
    setHead: (dept, userId) => apiFetch("/admin/department-heads", { method: "PUT", body: { dept, userId: userId || null } }),
    accreditation: (target) => apiFetch("/admin/accreditation", { qs: { target } }),
  },
  calendar: {
    month: (month, studentId) => apiFetch("/calendar", { qs: { month, studentId } }),
    add: (ev) => apiFetch("/admin/calendar", { method: "POST", body: ev }),
    remove: (id) => apiFetch(`/admin/calendar/${id}`, { method: "DELETE" }),
  },
  docs: {
    mine: () => apiFetch("/documents/mine"),
    verify: (token) => apiFetch(`/verify/${encodeURIComponent(token)}`),
  },
  alerts: {
    parents: () => apiFetch("/admin/parents"),
    addParent: (p) => apiFetch("/admin/parents", { method: "POST", body: p }),
    unlink: (id) => apiFetch(`/admin/parents/links/${id}`, { method: "DELETE" }),
    messages: (qs) => apiFetch("/admin/messages", { qs }),
    feeReminders: () => apiFetch("/admin/messages/fee-reminders", { method: "POST" }),
    test: (phone) => apiFetch("/admin/messages/test", { method: "POST", body: { phone } }),
    retry: (id) => apiFetch(`/admin/messages/${id}/retry`, { method: "POST" }),
  },
});

// A random id kept on this device; the QR check-in uses it to flag one phone
// checking in several students (a common proxy-attendance trick).
function deviceId() {
  try {
    let d = localStorage.getItem("cp_device");
    if (!d) { d = (crypto.randomUUID ? crypto.randomUUID() : uid("dev") + Date.now()); localStorage.setItem("cp_device", d); }
    return d;
  } catch { return null; }
}

// Download a file (PDF) from the API with the session cookie + CSRF header.
async function downloadFile(path, { method = "GET", body, filename = "download.pdf" } = {}) {
  const headers = {};
  if (method !== "GET") headers["X-CSRF-Token"] = readCookie("cp_csrf");
  if (body !== undefined) headers["Content-Type"] = "application/json";
  let res;
  try {
    res = await fetch(`${API_BASE}${path}`, { method, headers, credentials: "include", body: body === undefined ? undefined : JSON.stringify(body) });
  } catch { throw new Error("Can't reach the CampusPilot server. Check your connection."); }
  if (!res.ok) {
    let msg = `Download failed (${res.status})`;
    try { const d = await res.json(); if (typeof d.detail === "string") msg = d.detail; } catch { /* not json */ }
    throw new Error(msg);
  }
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

function downloadCsv(filename, columns, rows) {
  const q = (v) => { const s = String(v ?? ""); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  const text = "﻿" + [columns.map(q).join(","), ...rows.map((r) => r.map(q).join(","))].join("\n");
  const url = URL.createObjectURL(new Blob([text], { type: "text/csv;charset=utf-8" }));
  const a = document.createElement("a"); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

function DownloadButton({ label, path, filename, method, body, tone = "solid", icon = "download", onError, onDone }) {
  const [busy, setBusy] = useState(false);
  async function go() {
    setBusy(true);
    try { await downloadFile(path, { method, body, filename }); onDone && onDone(); }
    catch (e) { onError ? onError(e.message) : alert(e.message); }
    setBusy(false);
  }
  return <Pill tone={tone} onClick={go} disabled={busy}><Icon name={icon} size={13} /> {busy ? t("Preparing…") : t(label)}</Pill>;
}

// =================================================================== Hindi
// Translation happens where labels are rendered (menus, card titles, table
// headers, stat labels, buttons that call t()), so any string in HI below is
// translated everywhere it appears. Data (names, course titles) stays as entered.
let CURRENT_LANG = (() => { try { return localStorage.getItem("cp_lang") === "hi" ? "hi" : "en"; } catch { return "en"; } })();
if (typeof document !== "undefined") document.documentElement.lang = CURRENT_LANG;
function t(s) { return CURRENT_LANG === "hi" && typeof s === "string" && HI[s] ? HI[s] : s; }
function useLang() {
  const [lang, setLangState] = useState(CURRENT_LANG);
  useEffect(() => {
    const on = () => setLangState(CURRENT_LANG);
    window.addEventListener("cp:lang", on);
    return () => window.removeEventListener("cp:lang", on);
  }, []);
  return lang;
}
function setLang(l) {
  CURRENT_LANG = l === "hi" ? "hi" : "en";
  try { localStorage.setItem("cp_lang", CURRENT_LANG); } catch { /* ignore */ }
  document.documentElement.lang = CURRENT_LANG;
  window.dispatchEvent(new Event("cp:lang"));
}
function LangToggle({ compact }) {
  const lang = useLang();
  return (
    <div className={"cp-lang" + (compact ? " cp-lang--compact" : "")} role="group" aria-label="Language / भाषा">
      <button type="button" className={lang === "en" ? "is-active" : ""} onClick={() => setLang("en")} aria-pressed={lang === "en"}>EN</button>
      <button type="button" className={lang === "hi" ? "is-active" : ""} onClick={() => setLang("hi")} aria-pressed={lang === "hi"} lang="hi">हिं</button>
    </div>
  );
}

// ============================================================ empty screens
const EMPTY_ART = {
  default: <><rect x="22" y="30" width="76" height="56" rx="10" className="es-fill" /><path d="M22 52h22l6 9h20l6-9h22" className="es-line" /><circle cx="86" cy="26" r="9" className="es-accent" /><path d="M83 26l2.2 2.2L90 23.5" className="es-check" /></>,
  calendar: <><rect x="24" y="28" width="72" height="60" rx="10" className="es-fill" /><path d="M24 44h72M42 22v12M78 22v12" className="es-line" /><circle cx="60" cy="66" r="9" className="es-accent" /></>,
  search: <><circle cx="54" cy="54" r="24" className="es-fill" /><path d="M72 72l18 18" className="es-line" /><circle cx="54" cy="54" r="8" className="es-accent" /></>,
  bell: <><path d="M40 70V52a20 20 0 0 1 40 0v18l6 8H34z" className="es-fill" /><circle cx="60" cy="86" r="6" className="es-accent" /></>,
};
function EmptyState({ text, hint, art = "default", action }) {
  return (
    <div className="cp-empty">
      <svg viewBox="0 0 120 110" width="120" height="110" aria-hidden="true">{EMPTY_ART[art] || EMPTY_ART.default}</svg>
      <div className="cp-empty-text">{t(text)}</div>
      {hint ? <div className="cp-empty-hint">{t(hint)}</div> : null}
      {action || null}
    </div>
  );
}

// ======================================================== install (PWA)
let deferredInstall = null;
if (typeof window !== "undefined") {
  window.addEventListener("beforeinstallprompt", (e) => { e.preventDefault(); deferredInstall = e; window.dispatchEvent(new Event("cp:installable")); });
  window.addEventListener("appinstalled", () => { deferredInstall = null; window.dispatchEvent(new Event("cp:installable")); });
}
function useInstallPrompt() {
  const standalone = typeof window !== "undefined" && (window.matchMedia?.("(display-mode: standalone)").matches || window.navigator.standalone);
  const isIOS = typeof navigator !== "undefined" && /iphone|ipad|ipod/i.test(navigator.userAgent);
  const [can, setCan] = useState(!!deferredInstall);
  useEffect(() => {
    const on = () => setCan(!!deferredInstall);
    window.addEventListener("cp:installable", on);
    return () => window.removeEventListener("cp:installable", on);
  }, []);
  async function install() {
    if (!deferredInstall) return false;
    deferredInstall.prompt();
    const choice = await deferredInstall.userChoice.catch(() => null);
    deferredInstall = null; setCan(false);
    return choice && choice.outcome === "accepted";
  }
  return { canInstall: can && !standalone, showIOSHint: isIOS && !standalone, install, standalone };
}
function InstallAppButton() {
  const { canInstall, showIOSHint, install } = useInstallPrompt();
  const [iosOpen, setIosOpen] = useState(false);
  if (!canInstall && !showIOSHint) return null;
  return (
    <>
      <button type="button" className="cp-install-btn" onClick={() => (canInstall ? install() : setIosOpen(true))}>
        <Icon name="download" size={15} /> {t("Install app")}
      </button>
      <Modal open={iosOpen} onClose={() => setIosOpen(false)} title={t("Install CampusPilot")}>
        <ol className="cp-steps-list">
          <li>Tap the <strong>Share</strong> button in Safari (the square with an arrow).</li>
          <li>Scroll down and tap <strong>Add to Home Screen</strong>.</li>
          <li>Tap <strong>Add</strong>. CampusPilot now opens like an app, full-screen.</li>
        </ol>
      </Modal>
    </>
  );
}

// ================================================================ guided tour
const TOUR_STEPS = {
  common: [
    { sel: ".cp-nav", title: "Your menu", body: "Everything for your role lives here. On a phone, open it with the ☰ button." },
    { sel: ".cp-zoom", title: "Zoom in or out", body: "Make pages bigger or smaller. Click the % to reset. Shortcuts: Alt + = and Alt + −." },
    { sel: ".cp-bell", title: "Live notifications", body: "Attendance, marks, fees and approvals appear here the moment they happen." },
    { sel: ".cp-lang", title: "हिंदी / English", body: "Switch the menus and main labels to Hindi at any time." },
  ],
  student: [{ sel: '[data-nav="exams"]', title: "Exams & hall ticket", body: "Your exam timetable, hall ticket, results and grade card." },
    { sel: '[data-nav="attendance"]', title: "QR check-in", body: "When your teacher shows a QR code in class, scan it with your phone camera or type the 6-digit code here." }],
  teacher: [{ sel: '[data-nav="qr"]', title: "QR attendance", body: "Show a QR code in class — students scan it and attendance fills itself in." },
    { sel: '[data-nav="attendance"]', title: "Attendance by photo", body: "Or snap the paper attendance sheet and let CampusPilot read it." }],
  admin: [{ sel: '[data-nav="reports"]', title: "Analytics", body: "Campus trends, attendance heat-maps and at-risk students — download as PDF." },
    { sel: '[data-nav="accreditation"]', title: "NAAC / NBA data", body: "Accreditation tables generated from live records, ready to export." }],
  parent: [{ sel: '[data-nav="alerts"]', title: "Alerts", body: "Every SMS/WhatsApp alert we send you is also listed here." }],
  end: [{ sel: ".cw-fab", title: "Ask the Copilot", body: "Ask questions in plain words — it answers from your own records." }],
};
function tourKey(role) { return `cp_tour_done_${role}`; }
function GuidedTour({ role, open, onClose }) {
  const steps = useMemo(() => [...TOUR_STEPS.common, ...(TOUR_STEPS[role] || []), ...(role === "parent" ? [] : TOUR_STEPS.end)], [role]);
  const [i, setI] = useState(0);
  const [rect, setRect] = useState(null);
  const visible = useCallback((s) => {
    const el = document.querySelector(s.sel);
    if (!el) return null;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0 ? r : null;
  }, []);
  useEffect(() => { if (open) setI(0); }, [open]);
  useEffect(() => {
    if (!open) return undefined;
    let idx = i;
    while (idx < steps.length && !visible(steps[idx])) idx++;
    if (idx !== i) { if (idx >= steps.length) { finish(); } else setI(idx); return undefined; }
    const el = document.querySelector(steps[i].sel);
    el && el.scrollIntoView({ block: "nearest", behavior: "smooth" });
    const update = () => setRect(visible(steps[i]));
    update();
    const tmr = setTimeout(update, 350);
    window.addEventListener("resize", update);
    return () => { clearTimeout(tmr); window.removeEventListener("resize", update); };
  }, [open, i, steps, visible]);
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => { if (e.key === "Escape") finish(); if (e.key === "ArrowRight") next(); if (e.key === "ArrowLeft") setI((x) => Math.max(0, x - 1)); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  });
  function finish() { try { localStorage.setItem(tourKey(role), "1"); } catch { /* ignore */ } onClose(); }
  function next() { if (i >= steps.length - 1) finish(); else setI(i + 1); }
  if (!open || !rect) return null;
  const s = steps[i];
  const pad = 6;
  const below = rect.bottom + 190 < window.innerHeight;
  const left = Math.max(12, Math.min(rect.left, window.innerWidth - 332));
  return (
    <div className="cp-tour" role="dialog" aria-modal="true" aria-label={t("Quick tour")}>
      <div className="cp-tour-hole" style={{ top: rect.top - pad, left: rect.left - pad, width: rect.width + pad * 2, height: rect.height + pad * 2 }} />
      <div className="cp-tour-card" style={{ top: below ? rect.bottom + 14 : Math.max(12, rect.top - 176), left }}>
        <div className="cp-tour-step">{t("Step")} {i + 1} / {steps.length}</div>
        <h4>{t(s.title)}</h4>
        <p>{t(s.body)}</p>
        <div className="cp-tour-actions">
          <button type="button" className="cp-tour-skip" onClick={finish}>{t("Skip tour")}</button>
          <div>
            {i > 0 && <button type="button" className="cp-tour-back" onClick={() => setI(i - 1)}>{t("Back")}</button>}
            <button type="button" className="cp-tour-next" onClick={next} autoFocus>{i === steps.length - 1 ? t("Finish") : t("Next")}</button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ================================================================= drawing
function QrSvg({ matrix, size = 240, label }) {
  if (!matrix || !matrix.length) return null;
  const n = matrix.length, b = 2;
  let d = "";
  matrix.forEach((row, r) => { for (let c = 0; c < row.length; c++) if (row[c] === "1") d += `M${c + b} ${r + b}h1v1h-1z`; });
  return (
    <svg className="cp-qr" viewBox={`0 0 ${n + b * 2} ${n + b * 2}`} width={size} height={size} role="img" aria-label={label || "QR code"} shapeRendering="crispEdges">
      <rect width="100%" height="100%" fill="#fff" /><path d={d} fill="#111" />
    </svg>
  );
}

function heatColor(v) {
  if (v === null || v === undefined) return "var(--heat-none)";
  if (v >= 85) return "var(--heat-4)";
  if (v >= 75) return "var(--heat-3)";
  if (v >= 65) return "var(--heat-2)";
  return "var(--heat-1)";
}
function Heatmap({ rows, cols, rowTitle = "" }) {
  return (
    <div className="cp-heat-wrap">
      <table className="cp-heat">
        <thead><tr><th>{t(rowTitle)}</th>{cols.map((c) => <th key={c}>{c}</th>)}</tr></thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.label}>
              <th title={r.name || r.label}>{r.label}</th>
              {r.values.map((v, j) => <td key={j} style={{ background: heatColor(v) }} title={`${r.name || r.label} · ${cols[j]}: ${v === null ? "no classes" : v + "%"}`}>{v === null ? "" : v}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
      <div className="cp-heat-legend">
        <span><i style={{ background: "var(--heat-1)" }} />&lt;65%</span><span><i style={{ background: "var(--heat-2)" }} />65–74%</span>
        <span><i style={{ background: "var(--heat-3)" }} />75–84%</span><span><i style={{ background: "var(--heat-4)" }} />85%+</span>
        <span><i style={{ background: "var(--heat-none)" }} />{t("no classes")}</span>
      </div>
    </div>
  );
}

const LINE_COLORS = ["#12756B", "#C2410C", "#3A5A8C", "#8A6A22", "#7C3AED", "#0E7490"];
function MultiLineChart({ labels, series, height = 220, min = 40, max = 100 }) {
  const box = useRef(null);
  const [W, setW] = useState(640);
  useEffect(() => {
    if (!box.current || typeof ResizeObserver === "undefined") return undefined;
    const ro = new ResizeObserver(([e]) => setW(Math.max(280, Math.round(e.contentRect.width))));
    ro.observe(box.current);
    return () => ro.disconnect();
  }, []);
  const H = height, L = 38, R = 14, T = 12, B = 26;
  const x = (i) => L + (labels.length <= 1 ? 0 : (i * (W - L - R)) / (labels.length - 1));
  const y = (v) => T + (1 - (Math.max(min, Math.min(max, v)) - min) / (max - min)) * (H - T - B);
  const ticks = [min, (min + max) / 2, max];
  return (
    <div className="cp-linechart" ref={box}>
      <svg viewBox={`0 0 ${W} ${H}`} width={W} height={H} role="img" aria-label="Attendance trend by department">
        {ticks.map((tk) => <g key={tk}><line x1={L} x2={W - R} y1={y(tk)} y2={y(tk)} className="cp-lc-grid" /><text x={L - 6} y={y(tk) + 4} textAnchor="end" className="cp-lc-axis">{tk}%</text></g>)}
        <line x1={L} x2={W - R} y1={y(75)} y2={y(75)} className="cp-lc-target" />
        {labels.map((lb, i) => <text key={lb} x={x(i)} y={H - 6} textAnchor="middle" className="cp-lc-axis">{lb}</text>)}
        {series.map((s, si) => {
          const pts = s.values.map((v, i) => (v === null ? null : [x(i), y(v)])).filter(Boolean);
          return (
            <g key={s.dept}>
              <polyline points={pts.map((p) => p.join(",")).join(" ")} fill="none" stroke={LINE_COLORS[si % LINE_COLORS.length]} strokeWidth="2.4" strokeLinejoin="round" />
              {pts.map((p, i) => <circle key={i} cx={p[0]} cy={p[1]} r="3" fill={LINE_COLORS[si % LINE_COLORS.length]} />)}
            </g>
          );
        })}
      </svg>
      <div className="cp-lc-legend">
        {series.map((s, si) => <span key={s.dept}><i style={{ background: LINE_COLORS[si % LINE_COLORS.length] }} />{s.dept}</span>)}
        <span><i className="cp-lc-legend-target" />{t("75% requirement")}</span>
      </div>
    </div>
  );
}


function useRipples() {
  const [ripples, setRipples] = useState([]);
  function addRipple(e) {
    const el = e.currentTarget;
    const rect = el.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height) * 2.2;
    const x = (e.clientX ?? rect.left + rect.width / 2) - rect.left - size / 2;
    const y = (e.clientY ?? rect.top + rect.height / 2) - rect.top - size / 2;
    const id = Math.random().toString(36).slice(2);
    setRipples((r) => [...r, { id, x, y, size }]);
    window.setTimeout(() => setRipples((r) => r.filter((rp) => rp.id !== id)), 620);
  }
  return [ripples, addRipple];
}
function RippleField({ ripples }) {
  return (
    <span className="cp-ripple-field" aria-hidden="true">
      {ripples.map((rp) => <span key={rp.id} className="cp-ripple" style={{ left: rp.x, top: rp.y, width: rp.size, height: rp.size }} />)}
    </span>
  );
}
function Pill({ tone = "outline", children, ...rest }) {
  const [ripples, addRipple] = useRipples();
  return (
    <button className={`cp-pill cp-pill--${tone}`} onPointerDown={(e) => { addRipple(e); rest.onPointerDown?.(e); }} {...rest}>
      <span className="cp-pill-label">{children}</span>
      <RippleField ripples={ripples} />
    </button>
  );
}
function RoundButton({ children, className = "", ...rest }) {
  const [ripples, addRipple] = useRipples();
  return (
    <button className={"cp-round-btn " + className} onPointerDown={(e) => { addRipple(e); rest.onPointerDown?.(e); }} {...rest}>
      {children}
      <RippleField ripples={ripples} />
    </button>
  );
}
function ThemeToggle({ theme, onToggle }) {
  const isDark = theme === "dark";
  return (
    <RoundButton className="cp-theme-toggle" aria-label="Toggle dark mode" title="Toggle dark mode" onPointerDown={onToggle}>
      <span className={"cp-theme-icon" + (isDark ? " is-dark" : "")}><Icon name={isDark ? "moon" : "sun"} size={17} /></span>
    </RoundButton>
  );
}
// ---- Page zoom: makes everything in the page area bigger/smaller (tables, charts,
// sheets). Remembered on this device. Shortcuts: Alt + =  /  Alt + -  /  Alt + 0.
const ZOOM_STEPS = [0.75, 0.85, 0.9, 1, 1.1, 1.25, 1.4, 1.5, 1.75, 2];
function useZoom() {
  const [zoom, setZoomRaw] = useState(() => {
    try { const z = parseFloat(localStorage.getItem("cp_zoom")); return ZOOM_STEPS.includes(z) ? z : 1; } catch { return 1; }
  });
  const setZoom = useCallback((z) => { setZoomRaw(z); try { localStorage.setItem("cp_zoom", String(z)); } catch { /* ignore */ } }, []);
  const step = useCallback((dir) => setZoomRaw((cur) => {
    const i = ZOOM_STEPS.indexOf(cur);
    const n = ZOOM_STEPS[Math.max(0, Math.min(ZOOM_STEPS.length - 1, (i < 0 ? 3 : i) + dir))];
    try { localStorage.setItem("cp_zoom", String(n)); } catch { /* ignore */ }
    return n;
  }), []);
  useEffect(() => {
    const onKey = (e) => {
      if (!e.altKey || e.ctrlKey || e.metaKey) return;
      if (e.code === "Equal" || e.code === "NumpadAdd") { e.preventDefault(); step(1); }
      else if (e.code === "Minus" || e.code === "NumpadSubtract") { e.preventDefault(); step(-1); }
      else if (e.code === "Digit0" || e.code === "Numpad0") { e.preventDefault(); setZoom(1); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [step, setZoom]);
  return { zoom, zoomIn: () => step(1), zoomOut: () => step(-1), reset: () => setZoom(1) };
}
function ZoomControl({ zoom, zoomIn, zoomOut, reset }) {
  const pct = Math.round(zoom * 100);
  return (
    <div className="cp-zoom" role="group" aria-label="Page zoom">
      <button type="button" className="cp-zoom-btn" onClick={zoomOut} disabled={zoom <= ZOOM_STEPS[0]} aria-label="Zoom out" title="Zoom out (Alt + −)"><Icon name="zoomOut" size={16} /></button>
      <button type="button" className="cp-zoom-pct" onClick={reset} aria-label={`Zoom ${pct}%, reset to 100%`} title="Reset to 100% (Alt + 0)">{pct}%</button>
      <button type="button" className="cp-zoom-btn" onClick={zoomIn} disabled={zoom >= ZOOM_STEPS[ZOOM_STEPS.length - 1]} aria-label="Zoom in" title="Zoom in (Alt + =)"><Icon name="zoomIn" size={16} /></button>
    </div>
  );
}
function CountUp({ to, decimals = 0, duration = 900 }) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    let raf; const startTime = performance.now();
    function tick(t) {
      const p = Math.min(1, (t - startTime) / duration);
      setVal(to * (1 - Math.pow(1 - p, 3)));
      if (p < 1) raf = requestAnimationFrame(tick);
    }
    raf = requestAnimationFrame(tick);
    return () => raf && cancelAnimationFrame(raf);
  }, [to, duration]);
  return <>{val.toFixed(decimals)}</>;
}
function AuroraBackground() {
  return (
    <div className="cp-aurora" aria-hidden="true">
      <span className="cp-blob cp-blob--a" /><span className="cp-blob cp-blob--b" /><span className="cp-blob cp-blob--c" /><span className="cp-grain" />
    </div>
  );
}
function HeroIllustration() {
  return (
    <svg viewBox="0 0 320 220" width="100%" aria-hidden="true" className="cp-float">
      <circle cx="272" cy="34" r="20" fill="#FFD976" /><path d="M264 34 l6 6 12-12" fill="none" stroke="#12756B" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="30" cy="150" r="16" fill="#FF8A70" /><path d="M23 150h14M30 143v14" stroke="#FFFFFF" strokeWidth="3" strokeLinecap="round" />
      <rect x="40" y="176" width="220" height="10" rx="5" fill="#0B5951" opacity="0.35" />
      <g transform="translate(96,120)">
        <rect x="0" y="0" width="108" height="66" rx="8" fill="#0E3B36" /><rect x="6" y="6" width="96" height="48" rx="4" fill="#DFF6F2" />
        <path d="M14 44 L38 24 L56 38 L96 12" stroke="#1FC3B4" strokeWidth="3" fill="none" strokeLinecap="round" strokeLinejoin="round" />
        <rect x="-10" y="64" width="128" height="10" rx="5" fill="#12756B" />
      </g>
      <g transform="translate(150,26)">
        <circle cx="30" cy="24" r="22" fill="#FFC7A8" /><path d="M8 22a22 22 0 0 1 44 0c0 4-4 4-4 4H12s-4 0-4-4Z" fill="#12756B" />
        <rect x="8" y="46" width="44" height="60" rx="16" fill="#1FC3B4" />
      </g>
      <ellipse cx="196" cy="200" rx="60" ry="8" fill="#0B5951" opacity="0.15" />
    </svg>
  );
}

function Card({ title, actions, children, wide }) {
  return (
    <div className={"cp-card" + (wide ? " cp-card--wide" : "")}>
      {title ? <div className="cp-card-head"><h3>{t(title)}</h3><div className="cp-card-actions">{actions}</div></div> : null}
      <div className="cp-card-body">{children}</div>
    </div>
  );
}

function StatCard({ icon, label, value, sub }) {
  return (
    <div className="cp-stat">
      <span className="cp-stat-ico"><Icon name={icon} size={17} /></span>
      <div><div className="cp-stat-value">{typeof value === "number" ? <CountUp to={value} /> : value}</div><div className="cp-stat-label">{t(label)}</div>{sub ? <div className="cp-stat-sub">{t(sub)}</div> : null}</div>
    </div>
  );
}
function Badge({ tone = "neutral", children }) { return <span className={`cp-badge2 cp-badge2--${tone}`}>{children}</span>; }
function GrievanceStatusBadge({ status }) {
  const tone = status === "resolved" ? "green" : status === "in-review" ? "amber" : "red";
  const pending = status !== "resolved";
  return (
    <Badge tone={tone}>
      {pending && <span className="cp-badge-pulse-dot" aria-hidden="true" />}
      {status.replace("-", " ")}
    </Badge>
  );
}
function PriorityBadge({ priority }) {
  const tone = priority === "high" ? "red" : priority === "medium" ? "amber" : "neutral";
  return <Badge tone={tone}>{priority || "—"}</Badge>;
}
function RiskBadge({ level }) {
  const tone = level === "high" ? "red" : level === "medium" ? "amber" : "green";
  const label = level === "high" ? "High risk" : level === "medium" ? "Medium risk" : "Low risk";
  return <Badge tone={tone}>{label}</Badge>;
}

function InfoTooltip({ text }) {
  const [open, setOpen] = useState(false);
  return (
    <span
      className="ri-tooltip-wrap"
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
      onFocus={() => setOpen(true)}
      onBlur={() => setOpen(false)}
      tabIndex={0}
      role="button"
      aria-label="How risk is calculated"
    >
      <span className="ri-tooltip-icon"><Icon name="alert" size={13} /></span>
      {open && <span className="ri-tooltip-bubble">{text}</span>}
    </span>
  );
}
function Tabs({ tabs, active, onChange }) {
  return <div className="cp-tabs2" role="tablist">{tabs.map((tb) => <button key={tb.key} role="tab" aria-selected={active === tb.key} className={"cp-tab2" + (active === tb.key ? " is-active" : "")} onClick={() => onChange(tb.key)}>{t(tb.label)}</button>)}</div>;
}
function Modal({ open, onClose, title, children }) {
  if (!open) return null;
  return (
    <div className="cp-modal-veil" onClick={onClose}>
      <div className="cp-modal" onClick={(e) => e.stopPropagation()}>
        <div className="cp-modal-head"><h3>{t(title)}</h3><button className="cp-icon-btn" onClick={onClose}><Icon name="close" size={15} /></button></div>
        <div className="cp-modal-body">{children}</div>
      </div>
    </div>
  );
}
function DataTable({ columns, rows, empty = "No records yet." }) {
  return (
    <div className="cp-table-wrap">
      <table className="cp-data-table">
        <thead><tr>{columns.map((c) => <th key={c.key}>{t(c.label)}</th>)}</tr></thead>
        <tbody>
          {rows.length ? rows.map((row, i) => <tr key={row.id || i}>{columns.map((c) => <td key={c.key}>{c.render ? c.render(row) : row[c.key]}</td>)}</tr>)
            : <tr><td colSpan={columns.length} className="cp-table-empty-cell"><EmptyState text={empty} /></td></tr>}
        </tbody>
      </table>
    </div>
  );
}
const SORT_ICO_UP = "M6 15l6-6 6 6"; const SORT_ICO_DOWN = "M6 9l6 6 6-6"; const SORT_ICO_UPDOWN = "M8 9l4-4 4 4M8 15l4 4 4-4";

function SortableTable({ columns, rows, empty = "No records yet.", defaultSortKey, defaultSortDir = "desc", rowClassName }) {
  const [sortKey, setSortKey] = useState(defaultSortKey || null);
  const [sortDir, setSortDir] = useState(defaultSortDir);

  const sortedRows = useMemo(() => {
    if (!sortKey) return rows;
    const col = columns.find((c) => c.key === sortKey);
    const getVal = col && col.sortValue ? col.sortValue : (r) => r[sortKey];
    const copy = [...rows];
    copy.sort((a, b) => {
      const av = getVal(a), bv = getVal(b);
      if (av === bv) return 0;
      const cmp = av > bv ? 1 : -1;
      return sortDir === "asc" ? cmp : -cmp;
    });
    return copy;
  }, [rows, sortKey, sortDir, columns]);

  function toggleSort(col) {
    if (!col.sortable) return;
    if (sortKey === col.key) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else { setSortKey(col.key); setSortDir("desc"); }
  }

  return (
    <div className="cp-table-wrap">
      <table className="cp-data-table">
        <thead>
          <tr>
            {columns.map((c) => (
              <th key={c.key} className={c.sortable ? "ri-th-sortable" : ""} onClick={() => toggleSort(c)}>
                <span className="ri-th-inner">
                  {t(c.label)}
                  {c.sortable && (
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d={sortKey === c.key ? (sortDir === "asc" ? SORT_ICO_UP : SORT_ICO_DOWN) : SORT_ICO_UPDOWN} />
                    </svg>
                  )}
                </span>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {sortedRows.length
            ? sortedRows.map((row, i) => <tr key={row.id || i} className={rowClassName ? rowClassName(row) : undefined}>{columns.map((c) => <td key={c.key}>{c.render ? c.render(row) : row[c.key]}</td>)}</tr>)
            : <tr><td colSpan={columns.length} className="cp-table-empty-cell"><EmptyState text={empty} /></td></tr>}
        </tbody>
      </table>
    </div>
  );
}
function useToast() {
  const [toast, setToast] = useState(null);
  const show = useCallback((msg, tone = "ok") => { setToast({ msg, tone, id: uid("t") }); window.setTimeout(() => setToast(null), 2600); }, []);
  return [toast, show];
}
function Toast({ toast }) {
  if (!toast) return null;
  return (
    <div className={`cp-toast cp-toast--${toast.tone}`}>
      <span className="cp-toast-ico"><Icon name={toast.tone === "warn" ? "alert" : "check"} size={14} /></span>
      {toast.msg}
    </div>
  );
}
function useLiveStatus() {
  const [connected, setConnected] = useState(liveState.connected);
  useEffect(() => realtimeBus.on("live:status", setConnected), []);
  return connected;
}

// Re-run `fn` whenever any of the given server events arrives (and after a
// reconnect, in case events were missed while offline).
function useLive(events, fn) {
  const ref = useRef(fn);
  ref.current = fn;
  const key = events.join("|");
  useEffect(() => {
    const offs = [...events, "live:reconnected"].map((e) => realtimeBus.on(e, (d) => ref.current(d, e)));
    return () => offs.forEach((off) => off());
  }, [key]);
}

function LiveBadge() {
  const connected = useLiveStatus();
  return (
    <span className="cp-live" title={connected ? "Connected — changes from other users and devices appear instantly" : "Reconnecting to live updates…"}>
      <span className={"cp-live-dot2" + (connected ? "" : " cp-live-dot2--local")} />
      {connected ? "Live" : "Reconnecting…"}
    </span>
  );
}

function NotificationBell({ onToast }) {
  const [items, setItems] = useState([]);
  const [open, setOpen] = useState(false);
  const refresh = useCallback(() => { api.notifications.list().then(setItems).catch(() => {}); }, []);
  useEffect(() => { refresh(); }, [refresh]);
  useLive(["notification:new"], (n, ev) => {
    if (ev === "notification:new" && n) { setItems((xs) => [n, ...xs.filter((x) => x.id !== n.id)].slice(0, 50)); onToast && onToast(n.title); }
    else refresh();
  });
  const unread = items.filter((n) => !n.read).length;
  async function markAll() { await api.notifications.markAllRead(); setItems((xs) => xs.map((x) => ({ ...x, read: true }))); }
  return (
    <div className="cp-bell-wrap">
      <button className="cp-bell" aria-label={`Notifications (${unread} unread)`} onClick={() => setOpen((o) => !o)}>
        <Icon name="bell" size={17} />
        {unread > 0 && <span className="cp-bell-count">{unread > 9 ? "9+" : unread}</span>}
      </button>
      {open && (
        <div className="cp-bell-panel" role="dialog" aria-label="Notifications">
          <div className="cp-bell-head"><strong>Notifications</strong>{unread > 0 && <button onClick={markAll}>Mark all read</button>}</div>
          <div className="cp-bell-list">
            {items.length ? items.map((n) => (
              <div key={n.id} className={"cp-bell-item" + (n.read ? "" : " is-unread")}
                onClick={() => { if (!n.read) { api.notifications.markRead(n.id).catch(() => {}); setItems((xs) => xs.map((x) => (x.id === n.id ? { ...x, read: true } : x))); } }}>
                <div className="cp-bell-title">{n.title}</div>
                <div className="cp-bell-body">{n.body}</div>
                <div className="cp-bell-time">{timeAgo(n.ts)}</div>
              </div>
            )) : <EmptyState art="bell" text="You're all caught up." />}
          </div>
        </div>
      )}
    </div>
  );
}

function Switch({ checked, onChange }) {
  return <label className="cp-switch"><input type="checkbox" checked={checked} onChange={onChange} /><span /></label>;
}
function AuditList({ entries }) {
  return (
    <div className="cp-audit-list">
      {entries.length ? entries.map((e) => (
        <div className="cp-audit-row" key={e.id}>
          <span className={"cp-audit-dot cp-audit-dot--" + e.actorRole} />
          <div className="cp-audit-body"><div className="cp-audit-line"><strong>{e.actor}</strong> · {e.action}</div>{e.detail ? <div className="cp-audit-detail">{e.detail}</div> : null}</div>
          <span className="cp-audit-time">{timeAgo(e.ts)}</span>
        </div>
      )) : <EmptyState art="default" text="No activity yet." />}
    </div>
  );
}

function GlassTooltip({ active, payload, label, suffix = "" }) {
  if (!active || !payload || !payload.length) return null;
  return (
    <div
      style={{
        background: "var(--panel)",
        border: "1px solid var(--panel-border)",
        borderRadius: 10,
        padding: "6px 10px",
        fontSize: 12,
        fontWeight: 600,
        color: "var(--ink)",
        boxShadow: "0 10px 24px rgba(18,60,55,0.18)",
        backdropFilter: "blur(10px)",
      }}
    >
      {label !== undefined && (
        <div style={{ color: "var(--ink-faint)", fontWeight: 700, marginBottom: 2 }}>{label}</div>
      )}
      {payload[0].value}{suffix}
    </div>
  );
}

function ChartSparkline({
  data,
  height = 84,
  stroke = "var(--accent-deep)",
  fillFrom,
  suffix = "%",
}) {
  const gradId = useId().replace(/[:]/g, "");
  const chartData = (data || []).map((v, i) => ({ i, value: v }));
  const from = fillFrom || stroke;

  return (
    <div style={{ width: "100%", height }}>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={chartData} margin={{ top: 6, right: 6, left: 6, bottom: 0 }}>
          <defs>
            <linearGradient id={`spark-fill-${gradId}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={from} stopOpacity={0.35} />
              <stop offset="100%" stopColor={from} stopOpacity={0} />
            </linearGradient>
          </defs>
          <XAxis dataKey="i" hide />
          <YAxis hide domain={["dataMin - 6", "dataMax + 6"]} />
          <Tooltip content={<GlassTooltip suffix={suffix} />} cursor={false} />
          <Area
            type="monotone"
            dataKey="value"
            stroke={stroke}
            strokeWidth={2.5}
            fill={`url(#spark-fill-${gradId})`}
            dot={{ r: 2.5, fill: stroke, strokeWidth: 0 }}
            activeDot={{ r: 4.5, fill: stroke, strokeWidth: 0 }}
            isAnimationActive={true}
            animationDuration={900}
            animationEasing="ease-out"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

function ChartBarRow({ data, height = 140, suffix = "%" }) {
  const gradId = useId().replace(/[:]/g, "");
  return (
    <div style={{ width: "100%", height }}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data || []} margin={{ top: 18, right: 8, left: 8, bottom: 0 }} barCategoryGap="28%">
          <defs>
            <linearGradient id={`bar-fill-${gradId}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--accent)" />
              <stop offset="100%" stopColor="var(--accent-deep)" />
            </linearGradient>
          </defs>
          <CartesianGrid vertical={false} stroke="var(--panel-border)" strokeDasharray="3 3" />
          <XAxis
            dataKey="label"
            tickLine={false}
            axisLine={false}
            tick={{ fill: "var(--ink-faint)", fontSize: 10.5 }}
          />
          <YAxis hide domain={[0, (max) => Math.max(max, 1)]} />
          <Tooltip content={<GlassTooltip suffix={suffix} />} cursor={{ fill: "var(--surface)" }} />
          <Bar
            dataKey="value"
            fill={`url(#bar-fill-${gradId})`}
            radius={[8, 8, 0, 0]}
            maxBarSize={34}
            isAnimationActive={true}
            animationDuration={700}
            animationEasing="ease-out"
          >
            <LabelList
              dataKey="value"
              position="top"
              formatter={(v) => `${v}${suffix}`}
              style={{ fill: "var(--ink)", fontSize: 11, fontWeight: 700 }}
            />
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

const RISK_COLUMNS = [
  { key: "name", label: "Student", sortable: true },
  { key: "idLabel", label: "ID", sortable: true },
  { key: "attendancePct", label: "Attendance", sortable: true, sortValue: (r) => r.attendancePct ?? -1, render: (r) => <span>{r.attendancePct == null ? "—" : `${r.attendancePct}%`}</span> },
  { key: "avgScore", label: "Avg. score", sortable: true, sortValue: (r) => r.avgScore ?? -1, render: (r) => <span>{r.avgScore == null ? "—" : `${r.avgScore}/100`}</span> },
  { key: "cgpa", label: "CGPA", sortable: true, sortValue: (r) => r.cgpa ?? -1, render: (r) => <span>{r.cgpa ?? "—"}</span> },
  { key: "feeStatus", label: "Fees", sortable: true, render: (r) => <span style={{ textTransform: "capitalize" }}>{r.feeStatus}</span> },
  { key: "healthScore", label: "Health score", sortable: true, render: (r) => <strong>{r.healthScore}</strong> },
  {
    key: "riskLevel", label: "Risk", sortable: true,
    sortValue: (r) => ({ low: 0, medium: 1, high: 2 }[r.riskLevel]),
    render: (r) => <RiskBadge level={r.riskLevel} />,
  },
  { key: "reasons", label: "Why", sortable: false, render: (r) => <span className="cp-muted">{r.reasons.join(" · ")}</span> },
];

function RiskSummaryStats({ counts }) {
  return (
    <div className="cp-stat-grid">
      <StatCard icon="users" label="Students scored" value={counts.total} />
      <StatCard icon="alert" label="High risk" value={counts.high} sub="needs attention" />
      <StatCard icon="target" label="Medium risk" value={counts.medium} />
      <StatCard icon="check" label="Low risk" value={counts.low} />
    </div>
  );
}

function TeacherRiskInsights({ courses }) {
  const [scored, setScored] = useState([]);
  const courseIds = useMemo(() => (courses || []).map((c) => c.id), [courses]);
  const refresh = useCallback(() => { if (courseIds.length) api.teacher.riskScores(courseIds).then(setScored); }, [courseIds.join(",")]);
  useEffect(() => { refresh(); }, [refresh]);
  useLive(["attendance:update", "grades:update"], refresh);
  const counts = useMemo(() => riskSummaryCounts(scored), [scored]);

  return (
    <>
      <RiskSummaryStats counts={counts} />
      <Card title="Risk Insights" actions={<InfoTooltip text={RISK_FORMULA_TEXT} />}>
        <div className="ri-formula-note">
          <Icon name="alert" size={13} />
          <span>Computed live from attendance, marks and fee records — an early-warning signal, not a verdict. Hover the info icon for the formula.</span>
        </div>
        <SortableTable columns={RISK_COLUMNS} rows={scored} defaultSortKey="healthScore" defaultSortDir="asc" empty="No students found for your subjects." rowClassName={(r) => "ri-row-" + r.riskLevel} />
      </Card>
    </>
  );
}

function AdminRiskInsights() {
  const [scored, setScored] = useState([]);
  const refresh = useCallback(() => { api.admin.riskScores().then(setScored); }, []);
  useEffect(() => { refresh(); }, [refresh]);
  useLive(["attendance:update", "grades:update", "fees:update"], refresh);
  const counts = useMemo(() => riskSummaryCounts(scored), [scored]);

  return (
    <>
      <RiskSummaryStats counts={counts} />
      <Card title="Campus-wide Risk Insights" actions={<InfoTooltip text={RISK_FORMULA_TEXT} />}>
        <div className="ri-formula-note">
          <Icon name="alert" size={13} />
          <span>Computed live from attendance, marks and fee records — an early-warning signal, not a verdict. Hover the info icon for the formula.</span>
        </div>
        <SortableTable columns={RISK_COLUMNS} rows={scored} defaultSortKey="healthScore" defaultSortDir="asc" empty="No students found." rowClassName={(r) => "ri-row-" + r.riskLevel} />
      </Card>
    </>
  );
}

function FieldInput({ icon, placeholder, value, onChange, type = "text", autoComplete, onEnter }) {
  const [reveal, setReveal] = useState(false);
  const isPassword = type === "password";
  return (
    <label className={"a2-field" + (isPassword ? " a2-field--pw" : "")}>
      <input type={isPassword ? (reveal ? "text" : "password") : type} placeholder={placeholder} value={value} autoComplete={autoComplete}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={(e) => { if (e.key === "Enter" && onEnter) onEnter(); }} />
      <span className="a2-field-icon"><Icon name={icon} size={16} /></span>
      {isPassword ? (
        <button type="button" className="a2-field-toggle" tabIndex={-1}
          aria-label={reveal ? "Hide password" : "Show password"}
          onClick={() => setReveal((v) => !v)}>
          <Icon name={reveal ? "eyeOff" : "eye"} size={16} />
        </button>
      ) : null}
    </label>
  );
}
function RoleDropdown({ role, setRole, options = ROLES }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const current = roleInfo(role);
  useEffect(() => {
    function onDocClick(e) { if (ref.current && !ref.current.contains(e.target)) setOpen(false); }
    document.addEventListener("mousedown", onDocClick);
    return () => document.removeEventListener("mousedown", onDocClick);
  }, []);
  return (
    <div className="a2-role-select" ref={ref}>
      <button type="button" className={"a2-role-trigger" + (open ? " is-open" : "")} onClick={() => setOpen((o) => !o)}>
        <span className="a2-role-trigger-icon"><Icon name={current.icon} size={16} /></span>
        <span className="a2-role-trigger-text"><span className="a2-rt-label">{current.label}</span><span className="a2-rt-sub">{current.sub}</span></span>
        <span className={"a2-chevron" + (open ? " is-open" : "")}><Icon name="chevronDown" size={15} /></span>
      </button>
      <div className={"a2-role-panel" + (open ? " is-open" : "")}>
        {options.map((r) => (
          <button type="button" key={r.key} className={"a2-role-option" + (r.key === role ? " is-selected" : "")} onClick={() => { setRole(r.key); setOpen(false); }}>
            <span className="a2-role-opt-icon" style={{ background: r.accentSoft, color: r.accentDeep }}><Icon name={r.icon} size={15} /></span>
            <span className="a2-role-opt-text"><span className="a2-ot-label">{r.label}</span><span className="a2-ot-sub">{r.sub}</span></span>
            {r.key === role ? <span className="a2-check"><Icon name="check" size={14} /></span> : null}
          </button>
        ))}
      </div>
    </div>
  );
}
function FloatingStage({ role }) {
  const info = roleInfo(role);
  return (
    <div className="a2-stage">
      <div className="a2-stage-item a2-doc" style={{ top: "0%", left: "64%", "--rot": "7deg", "--dur": "5.2s", "--delay": ".4s" }}><span /><span /><span /></div>
      <div className="a2-stage-item a2-folder" style={{ top: "4%", left: "0%", "--rot": "-9deg", "--dur": "4.6s", "--delay": "0s" }} />
      <div className="a2-stage-item a2-folder a2-folder--alt" style={{ top: "62%", left: "68%", "--rot": "6deg", "--dur": "5.6s", "--delay": ".8s" }} />
      <div className="a2-stage-item a2-chip" style={{ top: "68%", left: "2%", "--rot": "0deg", "--dur": "4.8s", "--delay": "1.1s" }}><Icon name="check" size={18} /></div>
      <div className="a2-stage-item a2-center" style={{ top: "24%", left: "32%", "--rot": "0deg", "--dur": "5.8s", "--delay": ".15s" }}><Icon name={info.icon} size={30} /></div>
    </div>
  );
}

const AUTH_NAV_PANELS = {
  Home: {
    title: "Welcome to CampusPilot",
    body: "CampusPilot is a campus ERP covering attendance, grades, fees, placements, grievances and more — for students, faculty and administrators in one place. Sign in above, or create a student/faculty account to get started.",
  },
  Academics: {
    title: "Academics",
    body: "Students track attendance, sessional marks, assignments and their timetable. Faculty publish grades and attendance, share study material, and manage their subjects — all from their respective portals after signing in.",
  },
  Departments: {
    title: "Departments",
    body: "CampusPilot is department-agnostic: Computer Science, Mathematics and every other department on campus share the same courses, faculty and student records under one roof, managed centrally from the Admin console.",
  },
  Support: {
    title: "Support",
    body: "Having trouble signing in? Double-check you've selected the right portal (Student / Faculty / Admin / Parent) above — an account only works for the portal it was created under. For anything else, reach your campus admin, or use the Grievances desk once you're signed in.",
  },
};

function AuthScreen({ theme, onToggleTheme, onAuthed }) {
  const [mode, setMode] = useState("login");
  const [role, setRole] = useState("student");
  const [name, setName] = useState(""); const [email, setEmail] = useState("");
  const [idLabel, setIdLabel] = useState(""); const [password, setPassword] = useState(""); const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false); const [error, setError] = useState("");
  const [showDemoCreds, setShowDemoCreds] = useState(false);
  const [navPanel, setNavPanel] = useState(null);
  const info = roleInfo(role);

  const signupRoles = useMemo(() => ROLES.filter((r) => r.key !== "admin" && r.key !== "parent"), []);
  const roleOptions = mode === "signup" ? signupRoles : ROLES;

  function switchMode(m) {
    setMode(m); setError("");
    if (m === "signup" && (role === "admin" || role === "parent")) setRole("student");
  }

  async function handleLogin() {
    setError("");
    if (!email.trim() || !password) return setError("Enter both your email and password to continue.");
    setLoading(true);
    try { const user = await api.auth.login(email, password, role); onAuthed(user); }
    catch (err) { setError(err.message); }
    setLoading(false);
  }
  async function handleSignup() {
    setError("");
    if (!name.trim() || !email.trim() || !password) return setError("Fill in your name, email and password to continue.");
    if (password !== confirm) return setError("Passwords do not match.");
    if (password.length < 8 || !/[A-Za-z]/.test(password) || !/\d/.test(password)) return setError("Use at least 8 characters with both letters and numbers.");
    setLoading(true);
    try { const user = await api.auth.signup({ name: name.trim(), email: email.trim(), password, role, idLabel: idLabel.trim() }); onAuthed(user); }
    catch (err) { setError(err.message); }
    setLoading(false);
  }
  const submit = mode === "login" ? handleLogin : handleSignup;

  return (
    <div className="a2-page" style={{ "--a2-accent": info.accent, "--a2-accent-deep": info.accentDeep, "--a2-accent-soft": info.accentSoft }}>
      <span className="a2-shape a2-shape--1" /><span className="a2-shape a2-shape--2" /><span className="a2-shape a2-shape--3" /><span className="a2-shape a2-shape--4" />
      <div className="a2-shell">
        <div className="a2-card">
          <div className="a2-nav">
            <div className="a2-brand"><BrandMark size={30} />
              <span className="a2-brand-name">Campus<span className="a2-pilot">Pilot</span></span></div>
            <ul className="a2-nav-links">
              {Object.keys(AUTH_NAV_PANELS).map((label) => (
                <li key={label}><button type="button" className="a2-nav-link-btn" onClick={() => setNavPanel(label)}>{label}</button></li>
              ))}
            </ul>
            <div className="a2-nav-right">
              <LangToggle compact />
              <button type="button" className="a2-theme-toggle" aria-label="Toggle dark mode" onClick={onToggleTheme}><Icon name={theme === "dark" ? "moon" : "sun"} size={16} /></button>
              <div className="a2-badge">{info.label} Portal</div>
            </div>
          </div>
          <div className="a2-grid">
            <div className="a2-panel-form"><div className="a2-form-inner">
              <div className="a2-tabs">
                <button type="button" className={"a2-tab" + (mode === "login" ? " is-active" : "")} onClick={() => switchMode("login")}>Login</button>
                <button type="button" className={"a2-tab" + (mode === "signup" ? " is-active" : "")} onClick={() => switchMode("signup")}>Sign up</button>
                <span className="a2-tab-underline" style={{ transform: `translateX(${mode === "signup" ? "100%" : "0"})` }} />
              </div>
              <label className="a2-field-label">{mode === "login" ? "I am signing in as" : "I am signing up as"}</label>
              <RoleDropdown role={role} setRole={setRole} options={roleOptions} />
              {mode === "signup" && (
                <p className="a2-role-note">{t("Admin and parent accounts aren't self-serve — the college office creates those.")}</p>
              )}
              {error ? <div className="a2-error">{error}</div> : null}
              {mode === "login" ? (
                <div>
                  <FieldInput icon="mail" placeholder="Email address" value={email} onChange={setEmail} type="email" autoComplete="username" onEnter={submit} />
                  <FieldInput icon="lock" placeholder="Password" value={password} onChange={setPassword} type="password" autoComplete="current-password" onEnter={submit} />
                  <button type="button" className="a2-submit" disabled={loading} onClick={submit}>{loading ? "Signing in…" : `Sign in as ${info.label}`}</button>
                </div>
              ) : (
                <div>
                  <FieldInput icon="user" placeholder="Full name" value={name} onChange={setName} autoComplete="name" onEnter={submit} />
                  <FieldInput icon="mail" placeholder="Email address" value={email} onChange={setEmail} type="email" autoComplete="username" onEnter={submit} />
                  <FieldInput icon="clipboard" placeholder={info.idLabel} value={idLabel} onChange={setIdLabel} onEnter={submit} />
                  <FieldInput icon="lock" placeholder="Password" value={password} onChange={setPassword} type="password" autoComplete="new-password" onEnter={submit} />
                  <PasswordStrengthHint password={password} />
                  <FieldInput icon="lock" placeholder="Confirm password" value={confirm} onChange={setConfirm} type="password" autoComplete="new-password" onEnter={submit} />
                  <button type="button" className="a2-submit" disabled={loading} onClick={submit}>{loading ? "Creating account…" : `Create ${info.label.toLowerCase()} account`}</button>
                </div>
              )}
              <p className="a2-switch">
                {mode === "login" ? <>New to CampusPilot? <button type="button" onClick={() => switchMode("signup")}>Create an account</button></>
                  : <>Already have an account? <button type="button" onClick={() => switchMode("login")}>Sign in</button></>}
              </p>
              {DEMO_MODE && <div className="a2-demo-creds">
                <button
                  type="button"
                  className="a2-demo-toggle"
                  onClick={() => setShowDemoCreds((v) => !v)}
                  aria-expanded={showDemoCreds}
                >
                  <Icon name={showDemoCreds ? "chevronDown" : "chevronRight"} size={13} />
                  Demo credentials
                </button>
                {showDemoCreds && (
                  <div className="a2-demo-panel">
                    <div className="a2-demo-row"><span>Student</span><code>rohan@campuspilot.edu</code> / <code>student123</code></div>
                    <div className="a2-demo-row"><span>Faculty</span><code>priya@campuspilot.edu</code> / <code>teach123</code></div>
                    <div className="a2-demo-row"><span>Admin</span><code>admin@campuspilot.edu</code> / <code>admin123</code></div>
                    <div className="a2-demo-row"><span>Parent</span><code>parent@campuspilot.edu</code> / <code>parent123</code></div>
                    <div className="a2-demo-warn">Demo mode only — hidden automatically in production.</div>
                  </div>
                )}
              </div>}
            </div></div>
            <div className="a2-panel-visual">
              <div className="a2-blob" /><div className="a2-orbit2" /><div className="a2-orbit" />
              <div className="a2-particles"><span /><span /><span /><span /><span /></div>
              <div className="a2-visual-content">
                <FloatingStage role={role} />
                <div className="a2-role-caption"><h3>{info.label}</h3><p>{info.authDesc}</p></div>
              </div>
            </div>
          </div>
        </div>
        <div className="a2-page-foot"><span>CampusPilot ERP</span><span className="a2-dot" /><span>Built for colleges &amp; universities</span><span className="a2-dot" /><span>v2.0</span></div>
      </div>
      <Modal open={!!navPanel} onClose={() => setNavPanel(null)} title={navPanel ? AUTH_NAV_PANELS[navPanel].title : ""}>
        <p>{navPanel ? AUTH_NAV_PANELS[navPanel].body : ""}</p>
      </Modal>
    </div>
  );
}

function NavItem({ item, active, onClick }) {
  const [ripples, addRipple] = useRipples();
  return (
    <button className={"cp-nav-item" + (active ? " is-active" : "")} data-nav={item.key} aria-current={active ? "page" : undefined} onPointerDown={addRipple} onClick={onClick}>
      <span className="cp-nav-ico"><Icon name={item.icon} size={17} /></span><span>{t(item.label)}</span>
      {item.badge ? <span className="cp-nav-badge">{item.badge}</span> : null}
      <RippleField ripples={ripples} />
    </button>
  );
}

function PortalShell({ roleKey, navItems, active, onNavigate, user, theme, onToggleTheme, onLogout, headerTitle, headerSub, children, onToast }) {
  const info = roleInfo(roleKey);
  const [mounted, setMounted] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const zoomCtl = useZoom();
  const [tourOpen, setTourOpen] = useState(false);
  useEffect(() => { const tm = setTimeout(() => setMounted(true), 40); return () => clearTimeout(tm); }, []);
  useEffect(() => {  // first visit on this device: offer the guided tour once
    let done = true;
    try { done = !!localStorage.getItem(tourKey(roleKey)); } catch { /* ignore */ }
    if (done) return undefined;
    const tm = setTimeout(() => setTourOpen(true), 1200);
    return () => clearTimeout(tm);
  }, [roleKey]);
  useEffect(() => { setMobileNavOpen(false); }, [active]);

  function navigate(key) { onNavigate(key); }

  return (
    <div className={`cp-shell cp-shell--${roleKey}`} data-theme={theme} style={{ "--accent": info.accent, "--accent-deep": info.accentDeep, "--accent-soft": info.accentSoft }}>
      <AuroraBackground />
      {roleKey !== "parent" && <CopilotWidget user={user} roleKey={roleKey} api={api} />}
      <GuidedTour role={roleKey} open={tourOpen} onClose={() => setTourOpen(false)} />
      <div className={"cp-frame" + (mounted ? " is-mounted" : "")}>
        {mobileNavOpen && <div className="cp-sidebar-veil" onClick={() => setMobileNavOpen(false)} aria-hidden="true" />}
        <aside className={"cp-sidebar" + (mobileNavOpen ? " is-open" : "")}>
          <div className="cp-brand"><BrandMark size={28} /><span className="cp-brand-name">CampusPilot</span>
            <button className="cp-sidebar-close" aria-label="Close menu" onClick={() => setMobileNavOpen(false)}><Icon name="close" size={16} /></button>
          </div>
          <div className="cp-profile-card">
            <div className="cp-profile-card-avatar">{initialsOf(user.name)}</div>
            <div className="cp-profile-card-name">{user.name}</div>
            <div className="cp-profile-card-id">{t(info.label)}{roleKey !== "parent" ? ` · ${t(info.idLabel)} ${user.idLabel || "—"}` : ""}</div>
          </div>
          <div className="cp-nav-label">{t(`${info.label} Menu`)}</div>
          <nav className="cp-nav cp-nav--full">
            {navItems.map((item, i) => (
              <div key={item.key} className="cp-nav-item-wrap" style={{ "--i": i }}>
                <NavItem item={item} active={active === item.key} onClick={() => navigate(item.key)} />
              </div>
            ))}
          </nav>
          <div className="cp-sidebar-tools">
            <LangToggle />
            <button type="button" className="cp-tour-btn" onClick={() => { setMobileNavOpen(false); setTimeout(() => setTourOpen(true), 250); }}><Icon name="sparkle" size={14} /> {t("Take the tour")}</button>
            <InstallAppButton />
          </div>
          <button className="cp-sidebar-logout" onClick={onLogout}><Icon name="logout" size={15} /> {t("Log out")}</button>
          <div className="cp-sidebar-foot">CampusPilot ERP · {t(`${info.label} view`)}</div>
        </aside>

        <main className="cp-main">
          <header className="cp-topbar">
            <button className="cp-hamburger" aria-label="Open menu" onClick={() => setMobileNavOpen(true)}>
              <Icon name="grid" size={17} />
            </button>
            <div className="cp-topbar-title"><h1>{t(headerTitle)}</h1><p>{t(headerSub)}</p></div>
            <div className="cp-topbar-actions">
              <LiveBadge />
              <ZoomControl {...zoomCtl} />
              <NotificationBell onToast={onToast} />
              <ThemeToggle theme={theme} onToggle={onToggleTheme} />
              <div className="cp-profile"><div className="cp-avatar">{initialsOf(user.name)}</div>
                <div className="cp-profile-text"><div className="cp-profile-name">{user.name}</div><div className="cp-profile-handle">{info.label}</div></div>
              </div>
              <Pill tone="ghost" onClick={onLogout}><Icon name="logout" size={13} /> {t("Log out")}</Pill>
            </div>
          </header>
          <div className="cp-content" key={active} style={zoomCtl.zoom !== 1 ? { zoom: zoomCtl.zoom } : undefined}>{children}</div>
        </main>
      </div>
    </div>
  );
}

const STUDENT_NAV = [
  { key: "overview", label: "Dashboard", icon: "grid" },
  { key: "attendance", label: "Attendance", icon: "target" },
  { key: "marks", label: "Sessional Marks", icon: "barchart" },
  { key: "exams", label: "Exams & Results", icon: "exam" },
  { key: "assignments", label: "Assignments", icon: "clipboard" },
  { key: "placements", label: "Placements", icon: "briefcase" },
  { key: "grievances", label: "Grievances", icon: "alert" },
  { key: "fees", label: "Fee Information", icon: "rupee" },
  { key: "library", label: "Library", icon: "book" },
  { key: "timetable", label: "Time Table", icon: "clock" },
  { key: "calendar", label: "Calendar", icon: "calendar" },
  { key: "documents", label: "ID Card & Certificates", icon: "idcard" },
];
const TILE_COLORS = ["teal", "coral", "yellow", "navy"];
const DAY_KEYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

function StudentApp({ user, theme, onToggleTheme, onLogout }) {
  const [active, setActive] = useState(() => {  // app shortcut: /?go=attendance opens the check-in screen
    try { return new URLSearchParams(window.location.search).get("go") === "attendance" ? "attendance" : "overview"; } catch { return "overview"; }
  });
  const [toast, showToast] = useToast();
  const [summary, setSummary] = useState(null);
  const [assignments, setAssignments] = useState([]);
  const [attendance, setAttendance] = useState({ perCourse: [], weeklyTrend: [] });
  const [grades, setGrades] = useState(null);
  const [notices, setNotices] = useState([]);
  const [courses, setCourses] = useState([]);
  const [timetable, setTimetable] = useState(null);
  const [fees, setFees] = useState(null);

  const refreshSummary = useCallback(() => {
    api.student.summary().then(setSummary);
    api.student.attendance().then(setAttendance);
  }, []);
  const refreshAssignments = useCallback(() => { api.student.assignments().then(setAssignments); }, []);
  const refreshGrades = useCallback(() => { api.student.grades().then(setGrades); api.student.summary().then(setSummary); }, []);
  const refreshNotices = useCallback(() => { api.student.notices().then(setNotices); }, []);
  const refreshFees = useCallback(() => { api.student.fees().then(setFees); api.student.summary().then(setSummary); }, []);
  useEffect(() => {
    refreshSummary(); refreshAssignments(); refreshGrades(); refreshNotices(); refreshFees();
    api.student.courses().then(setCourses);
    api.student.timetable().then(setTimetable);
  }, [refreshSummary, refreshAssignments, refreshGrades, refreshNotices, refreshFees]);
  useLive(["attendance:update"], refreshSummary);
  useLive(["grades:update"], refreshGrades);
  useLive(["notice:new"], refreshNotices);
  useLive(["fees:update"], refreshFees);
  useLive(["notification:new"], (n) => { if (n && /assignment/i.test(n.title)) refreshAssignments(); });
  const [checkinResult, clearCheckin] = usePendingCheckin(showToast, refreshSummary);

  async function submit(a) {
    try { await api.student.submitAssignment(a.id); refreshAssignments(); showToast("Assignment submitted"); }
    catch (err) { showToast(err.message, "warn"); }
  }

  if (!summary) return <PortalLoading label="your dashboard" />;
  const pending = assignments.filter((a) => a.status === "pending").length;
  const week = attendance.weeklyTrend.length ? attendance.weeklyTrend : [summary.attendancePct];
  const todayKey = DAY_KEYS[new Date().getDay()];
  const todays = (timetable && timetable[todayKey]) || [];
  const lowCourses = attendance.perCourse.filter((c) => c.pct < 75);

  return (
    <PortalShell roleKey="student" navItems={STUDENT_NAV} active={active} onNavigate={setActive} user={user} theme={theme} onToggleTheme={onToggleTheme} onLogout={onLogout} onToast={showToast}
      headerTitle="Academic Overview" headerSub={`Welcome back, ${user.name.split(" ")[0]} — attendance, marks and campus updates in one place.`}>
      <Toast toast={toast} />

      {active === "overview" && (
        <>
          <section className="cp-hero">
            <div className="cp-hero-text">
              <div className="cp-hero-eyebrow"><span className="cp-live-dot" aria-hidden="true" />Live campus dashboard</div>
              <h2>Predict. Automate. Act.</h2>
              <p>{summary.risk && !/No risk factors|Not enough data/.test(summary.risk.reasons.join(" "))
                ? `Heads up: ${summary.risk.reasons.join(" · ")}.${lowCourses.length ? ` ${lowCourses.length} subject${lowCourses.length > 1 ? "s are" : " is"} below 75%.` : ""}`
                : "You're on track — attendance, grades and fees all look healthy."}</p>
              <div className="cp-hero-stats">
                <div className="cp-hero-stat"><span className="cp-hero-ico cp-hero-ico--coral"><Icon name="check" size={15} /></span>
                  <div><div className="cp-hero-stat-value">{summary.hasAttendance ? `${summary.attendancePct}%` : "—"}</div><div className="cp-hero-stat-label">Attendance</div></div></div>
                <div className="cp-hero-stat"><span className="cp-hero-ico cp-hero-ico--yellow"><Icon name="target" size={15} /></span>
                  <div><div className="cp-hero-stat-value">{summary.cgpa ? <CountUp to={summary.cgpa} decimals={2} /> : "—"}</div><div className="cp-hero-stat-label">CGPA · out of 10</div></div></div>
              </div>
              <div className="cp-hero-actions">
                <Pill tone="hero-solid" onClick={() => setActive("marks")}>View Full Report <Icon name="arrowUpRight" size={13} /></Pill>
                <div className="cp-hero-quicklinks">
                  <button className="cp-hero-chip" onClick={() => setActive("attendance")}>Attendance</button>
                  <button className="cp-hero-chip" onClick={() => setActive("marks")}>Marks</button>
                  <button className="cp-hero-chip" onClick={() => setActive("assignments")}>{t("Assignments")}</button>
                  <button className="cp-hero-chip" onClick={() => setActive("attendance")}><Icon name="qr" size={12} /> {t("Check in")}</button>
                  <button className="cp-hero-chip" onClick={() => setActive("exams")}>{t("Exams")}</button>
                </div>
              </div>
            </div>
            <div className="cp-hero-art"><HeroIllustration /></div>
          </section>

          <section className="cp-quickgrid">
            <div className="cp-quick cp-quick--navy"><div className="cp-quick-label">My Attendance</div>
              <div className="cp-quick-main">Present {summary.present} / {summary.totalLectures}</div><Pill tone="quick" onClick={() => setActive("attendance")}>Details ({summary.attendancePct}%)</Pill></div>
            <div className="cp-quick cp-quick--teal"><div className="cp-quick-label">My Marks</div>
              <div className="cp-quick-main">{grades ? `${grades.courses.length} subjects graded` : "Loading…"}</div><Pill tone="quick" onClick={() => setActive("marks")}>View marks</Pill></div>
            <div className="cp-quick cp-quick--purple"><div className="cp-quick-label">Fee</div>
              <div className="cp-quick-main">{summary.feeDue ? `₹${summary.feeDue.toLocaleString("en-IN")} due` : "Fully paid"}</div><Pill tone="quick" onClick={() => setActive("fees")}>Fee details</Pill></div>
            <div className="cp-quick cp-quick--coral"><div className="cp-quick-label">Assignments</div>
              <div className="cp-quick-main">{pending} pending</div><Pill tone="quick" onClick={() => setActive("assignments")}>Open assignments</Pill></div>
          </section>

          <section className="cp-panelgrid">
            <Card wide title="Notice Board" actions={<LiveBadge />}>
              <div className="cp-notice-list">
                {notices.length ? notices.slice(0, 6).map((n, i) => (
                  <div className="cp-notice-row" key={n.id} style={{ "--i": i }}>
                    <span className="cp-notice-tag">{n.course}</span><span className="cp-notice-title">{n.title}</span><span className="cp-notice-date">{timeAgo(n.ts)}</span>
                  </div>
                )) : <EmptyState art="default" text="No notices from your classes yet." />}
              </div>
            </Card>
            <Card title="Info At A Glance">
              <div className="cp-glance">
                {[["My Attendance", `${summary.attendancePct}%`, summary.attendancePct < 75 ? "coral" : "teal"], ["Total Lectures", summary.totalLectures, "teal"], ["Total Present", summary.present, "yellow"],
                  ["Subjects below 75%", lowCourses.length, lowCourses.length ? "coral" : "teal"], ["Pending Work", pending, "navy"]].map(([label, val, tone], i) => (
                  <div className="cp-glance-row" key={label} style={{ "--i": i }}><span>{label}</span><span className={`cp-badge cp-badge--${tone}`}>{val}</span></div>
                ))}
              </div>
            </Card>
          </section>

          <section className="cp-columns">
            <div className="cp-col cp-col--wide">
              <div className="cp-col-head"><h3>Today's Classes</h3><Pill tone="ghost" onClick={() => setActive("timetable")}>Full week <Icon name="chevronRight" size={14} /></Pill></div>
              <div className="cp-list">
                {todays.length ? todays.map((row, i) => (
                  <div className="cp-row" key={i} style={{ "--i": i }}>
                    <span className={`cp-tile cp-tile--${TILE_COLORS[i % TILE_COLORS.length]}`}>{row.code.slice(0, 2)}</span>
                    <div className="cp-row-body"><div className="cp-row-title">{row.course}</div><div className="cp-row-sub">{row.code} · {row.room} · {row.time}</div></div>
                  </div>
                )) : <EmptyState art="calendar" text="No classes scheduled today." />}
              </div>
            </div>
            <div className="cp-col">
              <div className="cp-col-head"><h3>Current Activity</h3></div>
              <div className="cp-progress-card">
                <div className="cp-progress-top"><div><div className="cp-progress-title">Weekly Attendance</div><div className="cp-progress-sub">Last {week.length} week{week.length !== 1 ? "s" : ""}</div></div>
                  <span className="cp-progress-badge">{week[week.length - 1] >= week[0] ? "+" : ""}{week[week.length - 1] - week[0]}%</span></div>
                <ChartSparkline data={week} stroke="#fff" fillFrom="#fff" />
              </div>
              <div className="cp-mini-grid">
                <div className="cp-mini-card cp-mini-card--yellow"><div className="cp-mini-value">{assignments.filter((a) => a.status === "submitted").length}</div><div className="cp-mini-label">Assignments Done</div></div>
                <div className="cp-mini-card cp-mini-card--coral"><div className="cp-mini-value">{pending}</div><div className="cp-mini-label">Assignments Pending</div></div>
              </div>
            </div>
            <div className="cp-col">
              <div className="cp-col-head"><h3>My Faculty</h3></div>
              <div className="cp-list cp-list--faculty">
                {courses.map((c, i) => (
                  <div className="cp-row" key={c.id} style={{ "--i": i }}>
                    <span className="cp-avatar cp-avatar--sm">{initialsOf(c.faculty)}</span>
                    <div className="cp-row-body"><div className="cp-row-title">{c.faculty}</div><div className="cp-row-sub">{c.code} · {c.name}</div></div>
                  </div>
                ))}
              </div>
            </div>
          </section>
        </>
      )}

      <CheckinResultModal result={checkinResult} onClose={clearCheckin} />
      {active === "attendance" && (
        <>
          <StudentCheckinCard showToast={showToast} onDone={refreshSummary} />
          <div className="cp-stat-grid"><StatCard icon="target" label="Overall Attendance" value={`${summary.attendancePct}%`} />
            <StatCard icon="check" label="Lectures Present" value={summary.present} /><StatCard icon="clock" label="Total Lectures" value={summary.totalLectures} /></div>
          <Card title="Subject-wise attendance" actions={<LiveBadge />}>
            <DataTable columns={[
              { key: "code", label: "Code" }, { key: "name", label: "Subject" },
              { key: "present", label: "Attended", render: (r) => `${r.present} / ${r.total}` },
              { key: "pct", label: "Attendance", render: (r) => <Badge tone={r.pct >= 85 ? "green" : r.pct >= 75 ? "amber" : "red"}>{r.pct}%</Badge> },
              { key: "plan", label: "What it means", render: (r) => r.pct >= 75
                ? <span className="cp-muted">Can miss {r.canMiss} more and stay at 75%</span>
                : <strong style={{ color: "var(--danger, #e5484d)" }}>Attend the next {r.mustAttend} classes to reach 75%</strong> },
            ]} rows={attendance.perCourse} empty="No attendance has been recorded for your subjects yet." />
          </Card>
          {attendance.weeklyTrend.length > 1 && <Card title="Weekly trend"><ChartSparkline data={attendance.weeklyTrend} /></Card>}
        </>
      )}
      {active === "marks" && (grades ? (
        <>
          <div className="cp-stat-grid"><StatCard icon="barchart" label="CGPA" value={grades.cgpa || "—"} sub="out of 10 (equal credits)" />
            <StatCard icon="book" label="Subjects graded" value={grades.courses.length} />
            <StatCard icon="clipboard" label="Assignments Submitted" value={assignments.filter((a) => a.status === "submitted").length} /></div>
          {grades.courses.map((c) => (
            <Card key={c.courseId} title={`${c.code} — ${c.name}`} actions={<Badge tone={c.average >= 70 ? "green" : c.average >= 50 ? "amber" : "red"}>Avg {c.average} · GP {c.gradePoint}</Badge>}>
              <DataTable columns={[{ key: "assessment", label: "Assessment" }, { key: "score", label: "Score", render: (r) => `${r.score}/100` }, { key: "ts", label: "Published", render: (r) => timeAgo(r.ts) }]} rows={c.assessments} />
            </Card>
          ))}
          {!grades.courses.length && <Card title="Marks"><EmptyState text="No marks have been published yet." /></Card>}
        </>
      ) : <SectionLoading label="Loading marks…" />)}
      {active === "assignments" && (
        <Card title="Assignments" actions={<LiveBadge />}>
          <DataTable columns={[
            { key: "title", label: "Assignment" }, { key: "course", label: "Course" }, { key: "due", label: "Due" },
            { key: "status", label: "Status", render: (r) => <Badge tone={r.status === "submitted" ? "green" : "amber"}>{r.status}</Badge> },
            { key: "actions", label: "", render: (r) => r.status === "pending" ? <Pill tone="solid" onClick={() => submit(r)}><Icon name="upload" size={13} /> Mark submitted</Pill> : <span className="cp-muted">Submitted</span> },
          ]} rows={assignments} empty="No assignments posted for your subjects yet." />
        </Card>
      )}
      {active === "placements" && <StudentPlacements user={user} summary={summary} showToast={showToast} />}
      {active === "grievances" && <StudentGrievances user={user} showToast={showToast} />}
      {active === "fees" && (
        <Card title="Fee Information" actions={<LiveBadge />}>
          <div className="cp-stat-grid">
            <StatCard icon="wallet" label="Total fee" value={fees ? `₹${(fees.total || 0).toLocaleString("en-IN")}` : "—"} />
            <StatCard icon="check" label="Paid" value={fees ? `₹${(fees.paid || 0).toLocaleString("en-IN")}` : "—"} />
            <StatCard icon="rupee" label="Balance due" value={fees ? `₹${(fees.due || 0).toLocaleString("en-IN")}` : "—"} sub={fees && fees.dueDate ? `due by ${fees.dueDate}` : ""} />
          </div>
          {fees && <p className="cp-muted">Status: <Badge tone={fees.status === "paid" ? "green" : fees.status === "overdue" ? "red" : "amber"}>{fees.status}</Badge></p>}
        </Card>
      )}
      {active === "library" && <StudentLibrary user={user} showToast={showToast} />}
      {active === "timetable" && <StudentTimetable />}
      {active === "exams" && <StudentExams showToast={showToast} />}
      {active === "calendar" && <AcademicCalendar showToast={showToast} />}
      {active === "documents" && <MyDocuments user={user} showToast={showToast} />}
    </PortalShell>
  );
}

function StudentPlacements({ user, summary, showToast }) {
  const [postings, setPostings] = useState([]);
  const [applications, setApplications] = useState([]);
  const [applying, setApplying] = useState(null);

  const refresh = useCallback(() => {
    api.placements.list().then(setPostings);
    api.placements.myApplications().then(setApplications);
  }, []);
  useEffect(() => { refresh(); }, [refresh]);
  useLive(["placement:new", "placement:application", "attendance:update", "grades:update"], refresh);

  const statusFor = (id) => applications.find((a) => a.placementId === id)?.status;
  const eligibleCount = postings.filter((p) => p.eligible && p.status === "open").length;

  async function apply(posting) {
    setApplying(posting.id);
    try {
      await api.placements.apply(posting.id);
      showToast(`Applied to ${posting.company}`);
      refresh();
    } catch (err) {
      showToast(err.message, "warn");
    }
    setApplying(null);
  }

  return (
    <>
      <div className="cp-stat-grid">
        <StatCard icon="briefcase" label="Open drives" value={postings.filter((p) => p.status === "open").length} />
        <StatCard icon="check" label="You're eligible for" value={eligibleCount} sub={`CGPA ${summary.cgpa || "—"} · attendance ${summary.attendancePct}%`} />
        <StatCard icon="clipboard" label="Applications sent" value={applications.length} />
      </div>
      <Card title="Placement Drives" actions={<LiveBadge />}>
        <DataTable columns={[
          { key: "company", label: "Company" },
          { key: "role", label: "Role" },
          { key: "package", label: "Package" },
          { key: "location", label: "Location" },
          { key: "deadline", label: "Deadline" },
          { key: "eligible", label: "Eligibility", render: (r) => (
            <Badge tone={r.eligible ? "green" : "red"}>{r.eligible ? "Eligible" : `Needs ${(r.ineligibleReasons || []).join(", ")}`}</Badge>
          ) },
          { key: "actions", label: "", render: (r) => {
            const status = statusFor(r.id);
            if (status) return <Badge tone={status === "selected" ? "green" : status === "rejected" ? "red" : "amber"}>{status}</Badge>;
            if (r.status !== "open") return <span className="cp-muted">Closed</span>;
            return <Pill tone="solid" disabled={!r.eligible || applying === r.id} onClick={() => r.eligible && apply(r)}>
              {applying === r.id ? "Applying…" : "Apply"}
            </Pill>;
          } },
        ]} rows={postings} empty="No placement drives posted yet." />
      </Card>
    </>
  );
}

function StudentLibrary({ user, showToast }) {
  const [books, setBooks] = useState([]);
  const [requests, setRequests] = useState([]);
  const [query, setQuery] = useState("");
  const [requesting, setRequesting] = useState(null);

  const refreshRequests = useCallback(() => { api.student.myLibraryRequests().then(setRequests); }, []);
  useEffect(() => { api.student.libraryCatalog().then(setBooks); refreshRequests(); }, [refreshRequests]);
  useLive(["library:update"], () => { refreshRequests(); api.student.libraryCatalog().then(setBooks); });

  const filtered = books.filter((b) => `${b.title} ${b.author} ${b.category}`.toLowerCase().includes(query.toLowerCase()));
  const activeRequestFor = (bookId) => requests.find((r) => r.bookId === bookId && r.status !== "returned");
  // (copies shown are live — they drop as requests are fulfilled)

  async function request(book) {
    setRequesting(book.id);
    try {
      await api.student.requestBook(book);
      showToast(`Requested "${book.title}" — the library desk will confirm shortly.`);
    } catch (err) { showToast(err.message, "warn"); }
    setRequesting(null);
    refreshRequests();
  }

  return (
    <>
      <div className="cp-stat-grid">
        <StatCard icon="book" label="Titles in catalog" value={books.length} />
        <StatCard icon="clock" label="My active requests" value={requests.filter((r) => r.status === "pending").length} />
        <StatCard icon="rupee" label="Late fine" value="₹0" />
      </div>
      <Card title="Book Catalog" actions={<input className="cp-search-input" placeholder="Search title, author, category…" value={query} onChange={(e) => setQuery(e.target.value)} />}>
        <DataTable
          columns={[
            { key: "title", label: "Title" }, { key: "author", label: "Author" }, { key: "category", label: "Category" },
            { key: "copies", label: "Availability", render: (r) => <Badge tone={r.copies > 0 ? "green" : "red"}>{r.copies > 0 ? `${r.copies} available` : "All copies out"}</Badge> },
            {
              key: "actions", label: "", render: (r) => {
                const existing = activeRequestFor(r.id);
                if (existing) return <Badge tone={existing.status === "ready-for-pickup" ? "green" : existing.status === "waitlisted" ? "amber" : "neutral"}>{existing.status.replace(/-/g, " ")}</Badge>;
                return <Pill tone="solid" disabled={requesting === r.id} onClick={() => request(r)}>{requesting === r.id ? "Requesting…" : <><Icon name="plus" size={13} /> Request</>}</Pill>;
              },
            },
          ]}
          rows={filtered}
          empty="No books match your search."
        />
      </Card>
      {requests.length > 0 && (
        <Card title="My Library Requests" actions={<LiveBadge />}>
          <DataTable
            columns={[
              { key: "title", label: "Book" },
              { key: "status", label: "Status", render: (r) => <Badge tone={r.status === "ready-for-pickup" ? "green" : r.status === "waitlisted" ? "amber" : "neutral"}>{r.status.replace(/-/g, " ")}</Badge> },
              { key: "ts", label: "Requested", render: (r) => timeAgo(r.ts) },
            ]}
            rows={requests}
          />
        </Card>
      )}
    </>
  );
}

function StudentTimetable() {
  const [grid, setGrid] = useState(null);
  useEffect(() => { api.student.timetable().then(setGrid); }, []);
  if (!grid) return <SectionLoading label="Building your timetable…" />;
  const hasAny = WEEKDAYS.some((d) => grid[d].length);
  return (
    <Card title="My Timetable" actions={<LiveBadge />}>
      {hasAny ? (
        <div className="cp-timetable">
          {WEEKDAYS.map((day, i) => (
            <div className="cp-tt-col" key={day} style={{ "--i": i }}>
              <div className="cp-tt-day">{day}</div>
              {grid[day].length ? grid[day].map((slot, si) => (
                <div className="cp-tt-slot" key={si}>
                  <div className="cp-tt-time">{slot.time}</div>
                  <div className="cp-tt-course">{slot.code}</div>
                  <div className="cp-tt-room">{slot.room}</div>
                </div>
              )) : <div className="cp-tt-empty">Free</div>}
            </div>
          ))}
        </div>
      ) : <p className="cp-muted">Your schedule will appear here once courses are set up for the term.</p>}
    </Card>
  );
}

const GMAIL_RE = /^[A-Za-z0-9._%+-]+@gmail\.com$/i;

function GrievanceDesk({ user, showToast, raiseFn, listFn, introText, categories }) {
  const cats = categories || GRIEVANCE_CATEGORIES_STUDENT;
  const [category, setCategory] = useState(cats[0]);
  const [description, setDescription] = useState("");
  const [contactEmail, setContactEmail] = useState(user.email || "");
  const [items, setItems] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [justSubmitted, setJustSubmitted] = useState(false);

  const suggestion = description.trim().length > 8 ? autoClassifyGrievance(description, user.role) : null;
  const emailTouched = contactEmail.trim().length > 0;
  const emailValid = !emailTouched || GMAIL_RE.test(contactEmail.trim());

  const refresh = useCallback(() => { listFn().then(setItems); }, [listFn]);
  useEffect(() => { refresh(); }, [refresh]);
  useLive(["grievance:update"], refresh);

  async function submit() {
    if (!description.trim()) return showToast("Describe your grievance first", "warn");
    if (!emailValid) return showToast("Enter a valid Gmail address (e.g. name@gmail.com), or leave the contact email blank", "warn");
    setSubmitting(true);
    if (description.trim().length < 10) return showToast("Please describe the issue in a little more detail (10+ characters)", "warn");
    let g;
    try {
      g = await raiseFn({ category, description: description.trim(), contactEmail: contactEmail.trim() || null });
    } catch (err) {
      setSubmitting(false);
      return showToast(err.message || "Couldn't submit grievance", "warn");
    }
    setSubmitting(false);
    setDescription("");
    refresh();
    showToast(`Submitted — ${g.priority} priority, routed to ${g.routedTo}`);
    setJustSubmitted(true);
    window.setTimeout(() => setJustSubmitted(false), 1800);
  }

  const openCount = items.filter((g) => g.status !== "resolved").length;

  return (
    <>
      <div className="cp-stat-grid">
        <StatCard icon="clipboard" label="Total raised" value={items.length} />
        <StatCard icon="clock" label="Open / in review" value={openCount} />
        <StatCard icon="check" label="Resolved" value={items.filter((g) => g.status === "resolved").length} />
      </div>

      <Card title="Raise a Grievance">
        {introText && <p className="cp-muted" style={{ marginTop: 0 }}>{introText}</p>}
        <div className={"cp-form-grid" + (justSubmitted ? " cp-form-grid--flash" : "")}>
          <select value={category} onChange={(e) => setCategory(e.target.value)}>
            {cats.map((c) => <option key={c}>{c}</option>)}
          </select>
          <textarea rows={4} placeholder="Describe the issue in detail…" value={description} onChange={(e) => setDescription(e.target.value)} />
          <div>
            <FieldInput
              icon="mail"
              placeholder="Contact email (Gmail) — so admin/teacher can reply"
              value={contactEmail}
              onChange={setContactEmail}
              type="email"
            />
            {!emailValid && (
              <div className="cp-autotag-hint" style={{ color: "var(--danger, #e5484d)" }}>
                Enter a valid Gmail address (e.g. name@gmail.com), or clear this field to skip it.
              </div>
            )}
          </div>
          {suggestion && (
            <div className="cp-autotag-hint">
              <span className="cp-autotag-label">Suggested category:</span>
              <span className="cp-autotag-value">{suggestion}</span>
              {suggestion !== category && (
                <Pill tone="ghost" onClick={() => setCategory(suggestion)}>Use this category</Pill>
              )}
            </div>
          )}
          <button type="button" className="cp-btn-accent" disabled={submitting || !emailValid} onClick={submit}>
            {submitting ? "Submitting…" : justSubmitted ? <><Icon name="check" size={13} /> Submitted</> : "Submit grievance"}
          </button>
        </div>
      </Card>

      <Card title="My Grievances" actions={<LiveBadge />}>
        <DataTable
          columns={[
            { key: "category", label: "Category" },
            { key: "priority", label: "Priority", render: (r) => <PriorityBadge priority={r.priority} /> },
            { key: "description", label: "Description", render: (r) => <span className="cp-grv-desc">{r.description}{r.resolution ? <em className="cp-grv-resolution"> — Resolution: {r.resolution}</em> : null}</span> },
            { key: "status", label: "Status", render: (r) => <GrievanceStatusBadge status={r.status} /> },
            { key: "routedTo", label: "Routed to", render: (r) => r.routedTo || "—" },
            { key: "assignedTo", label: "Handled by", render: (r) => r.assignedTo || "—" },
            { key: "ts", label: "Raised", render: (r) => timeAgo(r.ts) },
          ]}
          rows={items}
          empty="You haven't raised any grievances yet."
        />
      </Card>
    </>
  );
}

function StudentGrievances({ user, showToast }) {
  return <GrievanceDesk user={user} showToast={showToast} raiseFn={api.student.raiseGrievance} listFn={api.student.myGrievances} categories={GRIEVANCE_CATEGORIES_STUDENT} />;
}

function TeacherGrievances({ user, showToast }) {
  return (
    <GrievanceDesk
      user={user}
      showToast={showToast}
      raiseFn={api.teacher.raiseGrievance}
      listFn={api.teacher.myGrievances}
      categories={GRIEVANCE_CATEGORIES_TEACHER}
      introText="Raise an issue with admin — curriculum, timetable & workload, payroll/HR, infrastructure, or workplace conduct concerns."
    />
  );
}

const TEACHER_NAV = [
  { key: "overview", label: "My Dashboard", icon: "grid" },
  { key: "profile", label: "My Profile", icon: "user" },
  { key: "subjects", label: "My Subjects", icon: "book" },
  { key: "students", label: "My Students", icon: "users" },
  { key: "attendance", label: "Take Attendance", icon: "camera" },
  { key: "qr", label: "QR Attendance", icon: "qr" },
  { key: "assignments", label: "Manage Assignments", icon: "clipboard" },
  { key: "marks", label: "Enter Marks", icon: "barchart" },
  { key: "exams", label: "Exams & Results", icon: "exam" },
  { key: "material", label: "Study Material", icon: "upload" },
  { key: "timetable", label: "My Timetable", icon: "clock" },
  { key: "notices", label: "Class Notices", icon: "forum" },
  { key: "leave", label: "Apply Leave", icon: "calendar" },
  { key: "grievances", label: "Grievances", icon: "alert" },
  { key: "reports", label: "My Reports", icon: "activity" },
  { key: "calendar", label: "Calendar", icon: "calendar" },
  { key: "documents", label: "My ID Card", icon: "idcard" },
];

function TeacherApp({ user, theme, onToggleTheme, onLogout }) {
  const [active, setActive] = useState("overview");
  const [toast, showToast] = useToast();
  const [courses, setCourses] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [roster, setRoster] = useState([]);
  const [recentAudit, setRecentAudit] = useState([]);
  const [studentStats, setStudentStats] = useState([]);
  const [reportSummary, setReportSummary] = useState(null);
  const [pendingLeave, setPendingLeave] = useState(0);
  const [openGrievances, setOpenGrievances] = useState(0);

  const refreshCourses = useCallback(() => { api.teacher.myCourses().then((cs) => { setCourses(cs); setSelectedCourse((sel) => sel || (cs[0] && cs[0].id)); }); }, []);
  const refreshRoster = useCallback(() => { api.teacher.roster().then(setRoster); }, []);
  const refreshAudit = useCallback(() => { api.teacher.activity().then(setRecentAudit); }, []);
  const refreshStats = useCallback(() => {
    api.teacher.studentsWithStats([]).then(setStudentStats);
    api.teacher.reportsSummary().then(setReportSummary);
  }, []);
  const refreshLeave = useCallback(() => { api.teacher.listMyLeave().then((l) => setPendingLeave(l.filter((x) => x.status === "pending").length)); }, []);
  const refreshGrievances = useCallback(() => { api.teacher.myGrievances().then((g) => setOpenGrievances(g.filter((x) => x.status !== "resolved").length)); }, []);

  useEffect(() => { refreshCourses(); refreshRoster(); refreshAudit(); refreshLeave(); refreshGrievances(); refreshStats(); },
    [refreshCourses, refreshRoster, refreshAudit, refreshLeave, refreshGrievances, refreshStats]);
  useLive(["attendance:update", "grades:update"], () => { refreshStats(); refreshAudit(); });
  useLive(["leave:update"], refreshLeave);
  useLive(["grievance:update"], refreshGrievances);
  useLive(["subjectRequest:update"], () => { refreshCourses(); refreshRoster(); });

  const [hod, setHod] = useState(null);
  useEffect(() => { api.insights.access().then((a) => setHod(a.allowed ? a.dept : null)).catch(() => {}); }, []);
  useLive(["notification:new"], (n) => { if (n && /Head of Department/i.test(n.title || "")) api.insights.access().then((a) => setHod(a.allowed ? a.dept : null)); });
  const navWithBadges = useMemo(() => {
    const items = TEACHER_NAV.map((n) => {
      if (n.key === "leave" && pendingLeave) return { ...n, badge: pendingLeave };
      if (n.key === "grievances" && openGrievances) return { ...n, badge: openGrievances };
      return n;
    });
    if (hod) items.splice(1, 0, { key: "analytics", label: "Department Analytics", icon: "pie" });
    return items;
  }, [pendingLeave, openGrievances, hod]);

  return (
    <PortalShell roleKey="teacher" navItems={navWithBadges} onToast={showToast}
      active={active} onNavigate={setActive} user={user} theme={theme} onToggleTheme={onToggleTheme} onLogout={onLogout}
      headerTitle="Faculty Workspace" headerSub="Mark attendance, publish grades, and keep every class moving — all from one desk.">
      <Toast toast={toast} />
      {active === "overview" && (
        <TeacherOverview user={user} courses={courses} roster={roster} recentAudit={recentAudit} reportSummary={reportSummary} pendingLeave={pendingLeave} setActive={setActive} />
      )}
      {active === "profile" && <TeacherProfile user={user} showToast={showToast} />}
      {active === "subjects" && <MySubjects user={user} setActive={setActive} showToast={showToast} />}
      {active === "students" && <MyStudents students={studentStats} courses={courses} />}
      {active === "attendance" && <AttendanceOCR courses={courses} selectedCourse={selectedCourse} setSelectedCourse={setSelectedCourse} showToast={showToast} />}
      {active === "assignments" && <AssignmentsManager courses={courses} user={user} showToast={showToast} />}
      {active === "marks" && <Gradebook courses={courses} selectedCourse={selectedCourse} setSelectedCourse={setSelectedCourse} showToast={showToast} />}
      {active === "material" && <StudyMaterial courses={courses} user={user} showToast={showToast} />}
      {active === "timetable" && <TeacherTimetable courses={courses} />}
      {active === "notices" && <ClassNotices courses={courses} user={user} showToast={showToast} />}
      {active === "leave" && <ApplyLeave user={user} showToast={showToast} onChange={refreshLeave} />}
      {active === "grievances" && <TeacherGrievances user={user} showToast={showToast} />}
      {active === "reports" && <TeacherReports courses={courses} summary={reportSummary} />}
      {active === "qr" && <TeacherQrAttendance courses={courses} showToast={showToast} />}
      {active === "exams" && <TeacherExams showToast={showToast} />}
      {active === "calendar" && <AcademicCalendar showToast={showToast} />}
      {active === "documents" && <MyDocuments user={user} showToast={showToast} />}
      {active === "analytics" && hod && <AnalyticsDashboard showToast={showToast} />}
    </PortalShell>
  );
}

function TeacherOverview({ user, courses, roster, recentAudit, reportSummary, pendingLeave, setActive }) {
  return (
    <>
      <section className="cp-hero cp-hero--teacher">
        <div className="cp-hero-text">
          <div className="cp-hero-eyebrow"><span className="cp-live-dot" aria-hidden="true" />Faculty Workspace</div>
          <h2>Good to see you, {user.name.split(" ").slice(-1)[0]}.</h2>
          <p>{courses.length} {courses.length === 1 ? "class" : "classes"} in your charge this term — attendance, grading and notices, all synced live.</p>
          <div className="cp-hero-stats">
            <div className="cp-hero-stat"><span className="cp-hero-ico cp-hero-ico--coral"><Icon name="target" size={15} /></span>
              <div><div className="cp-hero-stat-value">{reportSummary ? `${reportSummary.avgAttendance}%` : "—"}</div><div className="cp-hero-stat-label">Avg. class attendance</div></div></div>
            <div className="cp-hero-stat"><span className="cp-hero-ico cp-hero-ico--yellow"><Icon name="barchart" size={15} /></span>
              <div><div className="cp-hero-stat-value">{reportSummary ? reportSummary.avgScore || "—" : "—"}</div><div className="cp-hero-stat-label">Avg. score / 100</div></div></div>
          </div>
          <div className="cp-hero-actions">
            <Pill tone="hero-solid" onClick={() => setActive("attendance")}><Icon name="camera" size={13} /> Take attendance by photo</Pill>
            <div className="cp-hero-quicklinks">
              <button className="cp-hero-chip" onClick={() => setActive("marks")}>Enter marks</button>
              <button className="cp-hero-chip" onClick={() => setActive("assignments")}>Assignments</button>
              <button className="cp-hero-chip" onClick={() => setActive("notices")}>Send notice</button>
            </div>
          </div>
        </div>
      </section>

      <div className="cp-stat-grid">
        <StatCard icon="building" label="My Subjects" value={courses.length} />
        <StatCard icon="users" label="Students Taught" value={roster.length} />
        <StatCard icon="clipboard" label="Assignments Posted" value={reportSummary ? reportSummary.assignmentsPosted : "—"} />
        <StatCard icon="calendar" label="Leave Requests Open" value={pendingLeave} />
      </div>

      <section className="cp-panelgrid">
        <Card wide title="My recent actions" actions={<LiveBadge />}><AuditList entries={recentAudit} /></Card>
        <Card title="My classes">
          <div className="cp-glance">
            {courses.map((c, i) => (
              <div className="cp-glance-row" key={c.id} style={{ "--i": i }}><span>{c.code} — {c.name}</span><span className="cp-badge cp-badge--teal">{c.students} students</span></div>
            ))}
          </div>
        </Card>
      </section>
    </>
  );
}

// Shrink large phone photos in the browser before upload (faster on mobile
// data; the server doesn't need 12 MP). Also converts HEIC→JPEG on Safari.
async function prepareSheetPhoto(file, maxSide = 2800) {
  try {
    if (!file.type.startsWith("image/") || typeof createImageBitmap !== "function") return file;
    const bmp = await createImageBitmap(file, { imageOrientation: "from-image" });
    const scale = Math.min(1, maxSide / Math.max(bmp.width, bmp.height));
    if (scale === 1 && /jpe?g|png|webp/i.test(file.type) && file.size < 6 * 1024 * 1024) { bmp.close && bmp.close(); return file; }
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(bmp.width * scale); canvas.height = Math.round(bmp.height * scale);
    canvas.getContext("2d").drawImage(bmp, 0, 0, canvas.width, canvas.height);
    bmp.close && bmp.close();
    const blob = await new Promise((res) => canvas.toBlob(res, "image/jpeg", 0.9));
    return blob ? new File([blob], (file.name || "photo").replace(/\.\w+$/, "") + ".jpg", { type: "image/jpeg" }) : file;
  } catch {
    return file;
  }
}

const todayIso = () => { const d = new Date(); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); };

function AttendanceStatusBadge({ status }) {
  if (status === "present") return <Badge tone="green">Present</Badge>;
  if (status === "absent") return <Badge tone="red">Absent</Badge>;
  return <Badge tone="amber">Not found</Badge>;
}

function AttendanceOCR({ courses, selectedCourse, setSelectedCourse, showToast }) {
  const [mode, setMode] = useState("ocr");
  const [date, setDate] = useState(todayIso());
  const [draft, setDraft] = useState(null);
  const [queue, setQueue] = useState([]);          // [{id, name, state: queued|reading|done|error, note}]
  const [busy, setBusy] = useState(false);
  const [reviewOnly, setReviewOnly] = useState(false);
  const [roster, setRoster] = useState([]);
  const [manual, setManual] = useState({});
  const [history, setHistory] = useState([]);
  const [publishing, setPublishing] = useState(false);
  const cameraRef = useRef(null);
  const fileRef = useRef(null);
  const course = courses.find((c) => c.id === selectedCourse);

  // Resume an open draft for this course+date (e.g. one started on your phone).
  useEffect(() => {
    setDraft(null); setQueue([]);
    if (!selectedCourse) return;
    api.teacher.listDrafts().then((ds) => {
      const d = ds.find((x) => x.courseId === selectedCourse && x.date === date);
      if (d) setDraft(d);
    }).catch(() => {});
    api.teacher.roster(selectedCourse).then((r) => { setRoster(r); setManual(Object.fromEntries(r.map((s) => [s.id, true]))); }).catch(() => setRoster([]));
    api.teacher.attendanceSessions(selectedCourse).then(setHistory).catch(() => setHistory([]));
  }, [selectedCourse, date]);

  useLive(["draft:update"], (d, ev) => {
    if (ev !== "draft:update" || !d) return;
    setDraft((cur) => {
      if (!cur || cur.id !== d.id) return cur;
      return d.status === "open" ? d : null;
    });
  });
  useLive(["attendance:update"], (d) => { if (selectedCourse && (!d || d.courseId === selectedCourse)) api.teacher.attendanceSessions(selectedCourse).then(setHistory).catch(() => {}); });

  async function startDraft() {
    try { setDraft(await api.teacher.createDraft(selectedCourse, date)); }
    catch (err) { showToast(err.message, "warn"); }
  }

  async function handleFiles(e) {
    const files = Array.from((e.target.files) || []);
    e.target.value = "";
    if (!files.length || !draft) return;
    const items = files.map((f, i) => ({ id: `${Date.now()}-${i}`, name: f.name || `photo-${i + 1}.jpg`, state: "queued", file: f }));
    setQueue((q) => [...q, ...items]);
    setBusy(true);
    let current = draft;
    for (const it of items) {       // one at a time so results appear as each photo finishes
      setQueue((q) => q.map((x) => (x.id === it.id ? { ...x, state: "reading" } : x)));
      try {
        const prepared = await prepareSheetPhoto(it.file);
        current = await api.teacher.addDraftPhotos(current.id, [prepared]);
        setDraft(current);
        const ph = current.photos[current.photos.length - 1];
        setQueue((q) => q.map((x) => (x.id === it.id ? { ...x, state: "done", note: `${ph.matched} students read · ${(ph.ms / 1000).toFixed(1)}s` } : x)));
      } catch (err) {
        setQueue((q) => q.map((x) => (x.id === it.id ? { ...x, state: "error", note: err.message } : x)));
      }
    }
    setBusy(false);
  }

  async function override(s, present) {
    try { setDraft(await api.teacher.overrideDraft(draft.id, s.studentId, present)); }
    catch (err) { showToast(err.message, "warn"); }
  }

  async function publishDraft() {
    const unseen = draft.summary.unseen;
    if (unseen && !window.confirm(`${unseen} student(s) weren't found on any photo and will be marked ABSENT. Publish anyway?`)) return;
    setPublishing(true);
    try {
      await api.teacher.publishDraft(draft.id);
      showToast(`Attendance published — ${draft.summary.present}/${draft.summary.total} present`);
      setDraft(null); setQueue([]);
    } catch (err) { showToast(err.message, "warn"); }
    setPublishing(false);
  }

  async function discard() {
    if (!window.confirm("Discard this attendance draft and its photos?")) return;
    await api.teacher.discardDraft(draft.id).catch(() => {});
    setDraft(null); setQueue([]);
  }

  async function publishManual() {
    if (!course) return showToast("Pick a course first", "warn");
    setPublishing(true);
    try {
      await api.teacher.markAttendance(course.id, roster.map((s) => ({ studentId: s.id, present: !!manual[s.id] })), date);
      showToast("Attendance published");
    } catch (err) { showToast(err.message, "warn"); }
    setPublishing(false);
  }

  const rows = draft ? (reviewOnly ? draft.students.filter((s) => s.needsReview) : draft.students) : [];
  const sm = draft && draft.summary;

  return (
    <Card title="Mark Attendance" actions={
      courses.length ? (
        <div className="cp-inline-controls">
          <select value={selectedCourse || ""} onChange={(e) => setSelectedCourse(e.target.value)} className="cp-select" aria-label="Course">
            {courses.map((c) => <option key={c.id} value={c.id}>{c.code} — {c.name}</option>)}
          </select>
          <input type="date" className="cp-select" value={date} max={todayIso()} onChange={(e) => setDate(e.target.value)} aria-label="Class date" />
          <LiveBadge />
        </div>
      ) : <span className="cp-muted">No courses assigned</span>}>
      <Tabs tabs={[{ key: "ocr", label: "Photo (OCR)" }, { key: "manual", label: "Manual" }, { key: "history", label: "History" }]} active={mode} onChange={setMode} />

      {mode === "ocr" && (
        <div className="cp-ocr-panel">
          {!draft && (
            <div className="cp-ocr-start">
              <Icon name="camera" size={28} />
              <div>
                <strong>Photograph the attendance sheet — we'll mark it for you</strong>
                <span>Works with daily P/A sheets, sign-in sheets and monthly registers. Add several photos (e.g. one per page); each is read and merged live.
                  You review anything uncertain before it's published.</span>
              </div>
              <Pill tone="solid" disabled={!course} onClick={startDraft}>Start for {course ? course.code : "…"} · {date}</Pill>
            </div>
          )}

          {draft && (
            <>
              {!draft.engineAvailable && <div className="cp-ocr-source-banner cp-ocr-source-banner--sim"><Icon name="alert" size={14} /><span>The OCR engine isn't installed on the server — use the Manual tab.</span></div>}
              <div className="cp-ocr-uploaders">
                <label className="cp-ocr-drop cp-ocr-drop--compact">
                  <Icon name="camera" size={22} />
                  <div><strong>Take photo</strong><span>Opens your camera</span></div>
                  <input ref={cameraRef} type="file" accept="image/*" capture="environment" onChange={handleFiles} hidden disabled={busy} />
                </label>
                <label className="cp-ocr-drop cp-ocr-drop--compact">
                  <Icon name="upload" size={22} />
                  <div><strong>Upload photos</strong><span>Select one or many</span></div>
                  <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" multiple onChange={handleFiles} hidden disabled={busy} />
                </label>
              </div>
              <p className="cp-muted cp-ocr-tip">Tips: fill the frame with the sheet, keep it flat and well lit, and avoid shadows. For registers, the photo must show the date row.</p>

              {queue.length > 0 && (
                <div className="cp-ocr-queue">
                  {queue.map((q) => (
                    <div key={q.id} className={"cp-ocr-qitem is-" + q.state}>
                      {q.state === "reading" ? <span className="cp-spinner cp-spinner--sm" /> : <Icon name={q.state === "error" ? "alert" : q.state === "done" ? "check" : "clock"} size={14} />}
                      <span className="cp-ocr-qname">{q.name}</span>
                      <span className="cp-ocr-qnote">{q.state === "reading" ? "Reading sheet…" : q.state === "queued" ? "Waiting…" : q.note}</span>
                    </div>
                  ))}
                </div>
              )}

              {draft.photos.map((ph) => (ph.warnings.length || ph.unrecognized.length) ? (
                <div key={ph.index} className="cp-ocr-source-banner cp-ocr-source-banner--sim">
                  <Icon name="alert" size={14} />
                  <span><strong>Photo {ph.index}</strong> ({ph.mode} sheet, {ph.matched} students read). {ph.warnings.join(" ")}
                    {ph.unrecognized.length ? ` Unrecognised rows (not on this class roster?): ${ph.unrecognized.slice(0, 5).join(" | ")}` : ""}</span>
                </div>
              ) : null)}

              <div className="cp-ocr-chips">
                <span className="cp-ocr-chip cp-ocr-chip--green">{sm.present} present</span>
                <span className="cp-ocr-chip cp-ocr-chip--red">{sm.absent} absent</span>
                <span className="cp-ocr-chip cp-ocr-chip--amber">{sm.unseen} not found</span>
                <span className="cp-ocr-chip">{sm.needsReview} to review</span>
                <span className="cp-ocr-chip">{sm.photos} photo{sm.photos !== 1 ? "s" : ""}</span>
                <label className="cp-ocr-filter"><input type="checkbox" checked={reviewOnly} onChange={(e) => setReviewOnly(e.target.checked)} /> Show only rows needing review</label>
              </div>

              <DataTable columns={[
                { key: "name", label: "Student", render: (r) => <span className={r.needsReview ? "cp-ocr-flag" : ""}>{r.needsReview && <Icon name="alert" size={12} />} {r.name}</span> },
                { key: "idLabel", label: "Roll no." },
                { key: "status", label: "Reading", render: (r) => <AttendanceStatusBadge status={r.status} /> },
                { key: "confidence", label: "Confidence", render: (r) => r.status === "unseen" ? "—" : <Badge tone={r.confidence >= 85 ? "green" : r.confidence >= 70 ? "amber" : "red"}>{r.confidence}%</Badge> },
                { key: "evidence", label: "Why", render: (r) => <span className="cp-muted">{r.conflict ? "Photos disagree · " : ""}{r.evidence || "—"}{r.photo ? ` (photo ${r.photo})` : ""}</span> },
                { key: "present", label: "Present", render: (r) => <Switch checked={r.status === "present"} onChange={() => override(r, r.status !== "present")} /> },
              ]} rows={rows} empty={reviewOnly ? "Nothing needs review 🎉" : "No students enrolled."} />

              <div className="cp-ocr-actions">
                <Pill tone="ghost" onClick={discard}>Discard draft</Pill>
                <Pill tone="solid" disabled={busy || publishing} onClick={publishDraft}>{publishing ? "Publishing…" : `Confirm & publish (${sm.present}/${sm.total} present)`}</Pill>
              </div>
            </>
          )}
        </div>
      )}

      {mode === "manual" && (
        <>
          <DataTable columns={[
            { key: "name", label: "Student" }, { key: "idLabel", label: "Roll no." },
            { key: "present", label: "Present", render: (r) => <Switch checked={!!manual[r.id]} onChange={() => setManual((m) => ({ ...m, [r.id]: !m[r.id] }))} /> },
          ]} rows={roster} empty="No students enrolled in this course." />
          <div className="cp-ocr-actions">
            <Pill tone="ghost" onClick={() => setManual(Object.fromEntries(roster.map((s) => [s.id, false])))}>Mark all absent</Pill>
            <Pill tone="solid" disabled={publishing || !roster.length} onClick={publishManual}>Publish attendance for {date}</Pill>
          </div>
        </>
      )}

      {mode === "history" && (
        <DataTable columns={[
          { key: "date", label: "Date" },
          { key: "present", label: "Present", render: (r) => `${r.present} / ${r.total}` },
          { key: "pct", label: "%", render: (r) => r.total ? `${Math.round((r.present / r.total) * 100)}%` : "—" },
          { key: "method", label: "Method", render: (r) => <Badge tone={r.method === "ocr" ? "teal" : "neutral"}>{r.method === "ocr" ? "Photo OCR" : "Manual"}</Badge> },
          { key: "markedBy", label: "Marked by" },
        ]} rows={history} empty="No attendance recorded for this course yet." />
      )}
    </Card>
  );
}

function Gradebook({ courses, selectedCourse, setSelectedCourse, showToast }) {
  const [assessment, setAssessment] = useState("Midterm");
  const [scores, setScores] = useState({});
  const [history, setHistory] = useState([]);
  const [roster, setRoster] = useState([]);
  const [publishing, setPublishing] = useState(false);
  const course = courses.find((c) => c.id === selectedCourse);
  const refreshHistory = useCallback(() => { if (selectedCourse) api.teacher.gradeHistory(selectedCourse).then(setHistory).catch(() => setHistory([])); }, [selectedCourse]);
  useEffect(() => {
    if (!selectedCourse) return;
    api.teacher.roster(selectedCourse).then((r) => { setRoster(r); setScores(Object.fromEntries(r.map((s) => [s.id, ""]))); }).catch(() => setRoster([]));
    refreshHistory();
  }, [selectedCourse, refreshHistory]);
  useLive(["grades:update"], (g) => { if (!g || g.courseId === selectedCourse) refreshHistory(); });

  const filled = roster.filter((s) => scores[s.id] !== "" && scores[s.id] !== undefined);
  const invalid = filled.filter((s) => { const v = Number(scores[s.id]); return !(v >= 0 && v <= 100); });
  const liveEntries = filled.filter((s) => !invalid.includes(s)).map((s) => ({ studentId: s.id, score: Number(scores[s.id]) }));
  const distribution = gradeDistribution(liveEntries);

  async function publish() {
    if (!course) return showToast("Pick a course first", "warn");
    if (invalid.length) return showToast("Scores must be between 0 and 100", "warn");
    if (!liveEntries.length) return showToast("Enter at least one score", "warn");
    if (liveEntries.length < roster.length && !window.confirm(`${roster.length - liveEntries.length} student(s) have no score and will be left out. Publish anyway?`)) return;
    setPublishing(true);
    try {
      await api.teacher.publishGrades(course.id, assessment, liveEntries);
      showToast("Grades published");
      setScores(Object.fromEntries(roster.map((s) => [s.id, ""])));
    } catch (err) { showToast(err.message, "warn"); }
    setPublishing(false);
  }

  return (
    <>
      <Card title="Enter Marks" actions={
        <div className="cp-inline-controls">
          <select value={selectedCourse || ""} onChange={(e) => setSelectedCourse(e.target.value)} className="cp-select">
            {courses.map((c) => <option key={c.id} value={c.id}>{c.code} — {c.name}</option>)}
          </select>
          <select value={assessment} onChange={(e) => setAssessment(e.target.value)} className="cp-select">
            <option>Midterm</option><option>Final</option><option>Assignment 1</option><option>Assignment 2</option><option>Quiz 1</option><option>Quiz 2</option>
          </select>
        </div>}>
        <div className="cp-gradebook-meta">
          <span className="cp-muted">{filled.length} / {roster.length} entered{invalid.length ? ` · ${invalid.length} invalid` : ""}</span>
          <div className="cp-gradebook-bar"><div className="cp-gradebook-bar-fill" style={{ width: `${roster.length ? (filled.length / roster.length) * 100 : 0}%` }} /></div>
        </div>
        <DataTable columns={[
          { key: "name", label: "Student" }, { key: "idLabel", label: "Roll no." },
          { key: "score", label: "Score (/100)", render: (r) => <input className={"cp-score-input" + (invalid.includes(r) ? " is-invalid" : "")} type="number" min="0" max="100" inputMode="decimal" value={scores[r.id] ?? ""} onChange={(e) => setScores((s) => ({ ...s, [r.id]: e.target.value }))} /> },
        ]} rows={roster} empty="No students enrolled in this course." />
        <div className="cp-ocr-actions"><Pill tone="solid" disabled={publishing} onClick={publish}>{publishing ? "Publishing…" : "Publish grades"}</Pill></div>
      </Card>
      {liveEntries.length > 1 && <Card title="Live distribution preview"><ChartBarRow data={distribution} suffix="" /></Card>}
      <Card title="Previously published" actions={<LiveBadge />}>
        <DataTable columns={[
          { key: "assessment", label: "Assessment" },
          { key: "entries", label: "Avg. score", render: (r) => r.entries.length ? Math.round(r.entries.reduce((a, e) => a + e.score, 0) / r.entries.length) : "—" },
          { key: "count", label: "Students", render: (r) => r.entries.length },
          { key: "publishedBy", label: "Published by" },
          { key: "ts", label: "When", render: (r) => timeAgo(r.ts) },
        ]} rows={history} empty="No assessments published yet for this subject." />
      </Card>
    </>
  );
}

function TeacherProfile({ user, showToast }) {
  const [profile, setProfile] = useState(null);
  const [edit, setEdit] = useState(false);
  const [form, setForm] = useState({});
  useEffect(() => { api.teacher.getProfile().then((p) => { setProfile(p); setForm(p); }); }, [user.id]);

  async function save() {
    try {
      const updated = await api.teacher.updateProfile(user.id, form);
      setProfile(updated); setEdit(false); showToast("Profile updated");
    } catch (err) { showToast(err.message, "warn"); }
  }
  if (!profile) return <SectionLoading label="Loading your profile…" />;

  return (
    <>
      <Card title="My Profile" actions={edit
        ? <><Pill tone="ghost" onClick={() => { setForm(profile); setEdit(false); }}>Cancel</Pill><Pill tone="solid" onClick={save}>Save changes</Pill></>
        : <Pill tone="solid" onClick={() => setEdit(true)}><Icon name="gear" size={13} /> Edit profile</Pill>}>
        <div className="cp-profile-detail">
          <div className="cp-profile-detail-avatar">{initialsOf(profile.name)}</div>
          <div className="cp-profile-detail-grid">
            {[
              ["Full name", "name"], ["Email", "email"], ["Phone", "phone"], ["Staff ID", "idLabel"],
              ["Department", "department"], ["Designation", "designation"], ["Qualification", "qualification"],
              ["Office", "office"], ["Joined", "joined"],
            ].map(([label, key]) => (
              <label className="cp-pd-field" key={key}>
                <span>{label}</span>
                {edit ? <input value={form[key] || ""} onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))} />
                  : <strong>{profile[key] || "—"}</strong>}
              </label>
            ))}
            <label className="cp-pd-field cp-pd-field--wide">
              <span>Bio</span>
              {edit ? <textarea rows={3} value={form.bio || ""} onChange={(e) => setForm((f) => ({ ...f, bio: e.target.value }))} />
                : <strong>{profile.bio || "—"}</strong>}
            </label>
          </div>
        </div>
      </Card>
    </>
  );
}

function MySubjects({ user, setActive, showToast }) {
  const teacherName = user.name;
  const [subjects, setSubjects] = useState([]);
  const [requests, setRequests] = useState([]);
  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ code: "", name: "", dept: "", notes: "" });
  const [submitting, setSubmitting] = useState(false);

  const refreshSubjects = useCallback(() => { api.teacher.subjects(teacherName).then(setSubjects); }, [teacherName]);
  const refreshRequests = useCallback(() => { api.teacher.mySubjectRequests(teacherName).then(setRequests); }, [teacherName]);
  useEffect(() => { refreshSubjects(); refreshRequests(); }, [refreshSubjects, refreshRequests]);
  useLive(["subjectRequest:update"], () => { refreshRequests(); refreshSubjects(); });

  async function submitRequest() {
    if (!form.code.trim() || !form.name.trim()) return showToast && showToast("Add a subject code and name", "warn");
    setSubmitting(true);
    try { await api.teacher.requestSubject(form); }
    catch (err) { setSubmitting(false); return showToast && showToast(err.message, "warn"); }
    setSubmitting(false);
    setModal(false); setForm({ code: "", name: "", dept: "", notes: "" });
    showToast && showToast("Subject request sent to admin for approval");
    refreshRequests();
  }

  const pendingCount = requests.filter((r) => r.status === "pending").length;

  return (
    <>
      <Card title="My Subjects" actions={
        <div className="cp-inline-controls">
          <Pill tone="solid" onClick={() => setModal(true)}><Icon name="plus" size={14} /> Request new subject</Pill>
          <LiveBadge />
        </div>}>
        <div className="cp-subject-grid">
          {subjects.map((s, i) => (
            <div className="cp-subject-card" key={s.id} style={{ "--i": i }}>
              <div className="cp-subject-top">
                <span className="cp-subject-code">{s.code}</span>
                <Badge tone="teal">{s.students} students</Badge>
              </div>
              <h4>{s.name}</h4>
              <div className="cp-subject-dept">{s.dept}</div>
              <div className="cp-subject-progress-label"><span>Term progress ({s.classesHeld} classes held)</span><span>{s.progress}%</span></div>
              <div className="cp-gradebook-bar"><div className="cp-gradebook-bar-fill" style={{ width: `${s.progress}%` }} /></div>
              <div className="cp-subject-actions">
                <Pill tone="outline" onClick={() => setActive("attendance")}>Attendance</Pill>
                <Pill tone="outline" onClick={() => setActive("material")}>Materials</Pill>
              </div>
            </div>
          ))}
          {!subjects.length && <EmptyState art="default" text="No subjects assigned yet — request one above to get started." />}
        </div>
      </Card>

      {requests.length > 0 && (
        <Card title="My Subject Requests" actions={pendingCount ? <Badge tone="amber">{pendingCount} pending</Badge> : null}>
          <DataTable
            columns={[
              { key: "code", label: "Code" }, { key: "name", label: "Subject" }, { key: "dept", label: "Department" },
              { key: "status", label: "Status", render: (r) => <Badge tone={r.status === "approved" ? "green" : r.status === "rejected" ? "red" : "amber"}>{r.status}</Badge> },
              { key: "ts", label: "Requested", render: (r) => timeAgo(r.ts) },
            ]}
            rows={requests}
          />
        </Card>
      )}

      <Modal open={modal} onClose={() => setModal(false)} title="Request a new subject">
        <div className="cp-form-grid">
          <p className="cp-muted" style={{ marginTop: 0 }}>Sent to admin for approval — once approved, it's added straight to your subjects.</p>
          <input placeholder="Subject code (e.g. CS410)" value={form.code} onChange={(e) => setForm((f) => ({ ...f, code: e.target.value }))} />
          <input placeholder="Subject name" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
          <input placeholder="Department" value={form.dept} onChange={(e) => setForm((f) => ({ ...f, dept: e.target.value }))} />
          <textarea rows={3} placeholder="Notes for admin (optional)" value={form.notes} onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))} />
          <button type="button" className="cp-btn-accent" disabled={submitting} onClick={submitRequest}>{submitting ? "Sending…" : "Send request"}</button>
        </div>
      </Modal>
    </>
  );
}

function MyStudents({ students, courses }) {
  const [tab, setTab] = useState("roster");
  const [query, setQuery] = useState("");
  const filtered = students.filter((s) => s.name.toLowerCase().includes(query.toLowerCase()) || (s.idLabel || "").toLowerCase().includes(query.toLowerCase()));
  const atRisk = students.filter((s) => s.attendancePct != null && s.attendancePct < 75).length;
  const scored = students.filter((s) => s.avgScore != null);
  return (
    <>
      <div className="cp-stat-grid">
        <StatCard icon="users" label="Total students" value={students.length} sub={`across ${courses.length} subjects`} />
        <StatCard icon="target" label="Below 75% attendance" value={atRisk} sub="needs attention" />
        <StatCard icon="barchart" label="Avg. score" value={scored.length ? Math.round(scored.reduce((a, s) => a + s.avgScore, 0) / scored.length) : "—"} />
      </div>
      <Tabs tabs={[{ key: "roster", label: "Roster" }, { key: "risk", label: "Risk Insights" }]} active={tab} onChange={setTab} />
      {tab === "roster" && (
        <Card title="My Students" actions={<input className="cp-search-input" placeholder="Search by name or ID…" value={query} onChange={(e) => setQuery(e.target.value)} />}>
          <DataTable columns={[
            { key: "name", label: "Student" }, { key: "idLabel", label: "ID" },
            { key: "attendancePct", label: "Attendance", render: (r) => r.attendancePct == null ? "—" : <Badge tone={r.attendancePct >= 85 ? "green" : r.attendancePct >= 75 ? "amber" : "red"}>{r.attendancePct}%</Badge> },
            { key: "avgScore", label: "Avg. score", render: (r) => r.avgScore == null ? "—" : <Badge tone={r.avgScore >= 75 ? "green" : r.avgScore >= 50 ? "amber" : "red"}>{r.avgScore}/100</Badge> },
            { key: "riskLevel", label: "Risk", render: (r) => <RiskBadge level={r.riskLevel} /> },
          ]} rows={filtered} />
        </Card>
      )}
      {tab === "risk" && <TeacherRiskInsights courses={courses} />}
    </>
  );
}

function AssignmentsManager({ courses, user, showToast }) {
  const [items, setItems] = useState([]);
  const [modal, setModal] = useState(false);
  const blank = () => ({ title: "", courseId: (courses[0] && courses[0].id) || "", due: "" });
  const [form, setForm] = useState(blank());
  const refresh = useCallback(() => { api.teacher.listAssignments().then(setItems); }, []);
  useEffect(() => { refresh(); }, [refresh]);
  useEffect(() => { setForm((f) => ({ ...f, courseId: f.courseId || (courses[0] && courses[0].id) || "" })); }, [courses]);
  useLive(["assignment:submitted"], refresh);

  async function create() {
    if (!form.title.trim() || !form.due.trim()) return showToast("Add a title and due date", "warn");
    try { await api.teacher.createAssignment({ title: form.title.trim(), courseId: form.courseId, due: form.due.trim() }); }
    catch (err) { return showToast(err.message, "warn"); }
    setModal(false); setForm(blank());
    refresh(); showToast("Assignment posted to class");
  }

  return (
    <Card title="Manage Assignments" actions={<div className="cp-inline-controls"><LiveBadge /><Pill tone="solid" onClick={() => setModal(true)}><Icon name="plus" size={14} /> New assignment</Pill></div>}>
      <DataTable columns={[
        { key: "title", label: "Assignment" }, { key: "course", label: "Subject" }, { key: "due", label: "Due" },
        { key: "submittedCount", label: "Submissions", render: (r) => `${r.submittedCount} / ${r.totalStudents}` },
        { key: "progress", label: "", render: (r) => <div className="cp-gradebook-bar" style={{ minWidth: 80 }}><div className="cp-gradebook-bar-fill" style={{ width: `${r.totalStudents ? (r.submittedCount / r.totalStudents) * 100 : 0}%` }} /></div> },
      ]} rows={items} empty="No assignments posted for your subjects yet." />
      <Modal open={modal} onClose={() => setModal(false)} title="New assignment">
        <div className="cp-form-grid">
          <input placeholder="Assignment title" maxLength={150} value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} />
          <select value={form.courseId} onChange={(e) => setForm((f) => ({ ...f, courseId: e.target.value }))}>
            {courses.map((c) => <option key={c.id} value={c.id}>{c.code} — {c.name}</option>)}
          </select>
          <input type="date" value={form.due} onChange={(e) => setForm((f) => ({ ...f, due: e.target.value }))} />
          <button type="button" className="cp-btn-accent" onClick={create}>Post to class</button>
        </div>
      </Modal>
    </Card>
  );
}

function StudyMaterial({ courses, user, showToast }) {
  const [items, setItems] = useState([]);
  const [courseId, setCourseId] = useState((courses[0] && courses[0].id) || "");
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef(null);
  const refresh = useCallback(() => { api.teacher.listMaterial().then(setItems); }, []);
  useEffect(() => { refresh(); }, [refresh]);
  useEffect(() => { setCourseId((c) => c || (courses[0] && courses[0].id) || ""); }, [courses]);

  async function handleFile(e) {
    const f = e.target.files && e.target.files[0];
    if (!f || !courseId) return;
    setUploading(true);
    const ext = (f.name.split(".").pop() || "").toUpperCase();
    const type = ["PDF", "PPT", "DOC"].find((t) => ext.startsWith(t)) || (ext === "PPTX" ? "PPT" : ext === "DOCX" ? "DOC" : /MP4|MOV|WEBM/.test(ext) ? "Video" : "Other");
    const sizeKb = Math.max(1, Math.round(f.size / 1024));
    try {
      await api.teacher.uploadMaterial({ title: f.name.slice(0, 150), courseId, type, size: sizeKb > 1024 ? `${(sizeKb / 1024).toFixed(1)} MB` : `${sizeKb} KB` });
      showToast("Study material listed for the class");
    } catch (err) { showToast(err.message, "warn"); }
    setUploading(false); if (fileRef.current) fileRef.current.value = "";
    refresh();
  }

  return (
    <Card title="Study Material" actions={
      courses.length
        ? <select value={courseId} onChange={(e) => setCourseId(e.target.value)} className="cp-select">
            {courses.map((c) => <option key={c.id} value={c.id}>{c.code} — {c.name}</option>)}
          </select>
        : <span className="cp-muted">No subjects assigned</span>}>
      <label className="cp-ocr-drop">
        <Icon name="upload" size={26} />
        <div><strong>{uploading ? "Saving…" : "Add a file to this subject"}</strong><span>Notes, slides, lab manuals — enrolled students are notified instantly.</span></div>
        <input ref={fileRef} type="file" onChange={handleFile} hidden disabled={uploading || !courseId} />
      </label>
      <DataTable columns={[
        { key: "title", label: "File" }, { key: "course", label: "Subject" },
        { key: "type", label: "Type", render: (r) => <Badge tone="navy">{r.type}</Badge> }, { key: "size", label: "Size" },
        { key: "ts", label: "Uploaded", render: (r) => timeAgo(r.ts) },
      ]} rows={items} empty="No material uploaded yet." />
    </Card>
  );
}

function TeacherTimetable({ courses }) {
  const [grid, setGrid] = useState(null);
  useEffect(() => { api.teacher.timetable().then(setGrid); }, [courses]);
  if (!grid) return <SectionLoading label="Building your timetable…" />;
  return (
    <Card title="My Timetable" actions={<LiveBadge />}>
      <div className="cp-timetable">
        {WEEKDAYS.map((day, i) => (
          <div className="cp-tt-col" key={day} style={{ "--i": i }}>
            <div className="cp-tt-day">{day}</div>
            {grid[day].length ? grid[day].map((slot, si) => (
              <div className="cp-tt-slot" key={si}>
                <div className="cp-tt-time">{slot.time}</div>
                <div className="cp-tt-course">{slot.code}</div>
                <div className="cp-tt-room">{slot.room}</div>
              </div>
            )) : <div className="cp-tt-empty">Free</div>}
          </div>
        ))}
      </div>
    </Card>
  );
}

function ClassNotices({ courses, user, showToast }) {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({ title: "", courseId: "" });
  const refresh = useCallback(() => { api.teacher.listNotices().then(setItems); }, []);
  useEffect(() => { refresh(); }, [refresh]);
  useEffect(() => { setForm((f) => ({ ...f, courseId: f.courseId || (courses[0] && courses[0].id) || "" })); }, [courses]);

  async function send() {
    if (!form.title.trim()) return showToast("Write a notice first", "warn");
    try { await api.teacher.sendNotice({ title: form.title.trim(), courseId: form.courseId }); }
    catch (err) { return showToast(err.message, "warn"); }
    setForm({ title: "", courseId: form.courseId }); refresh(); showToast("Notice sent — students notified live");
  }

  return (
    <>
      <Card title="Send Class Notice">
        <div className="cp-notice-composer">
          <select value={form.courseId} onChange={(e) => setForm((f) => ({ ...f, courseId: e.target.value }))} className="cp-select">
            {courses.map((c) => <option key={c.id} value={c.id}>{c.code} — {c.name}</option>)}
          </select>
          <textarea rows={3} maxLength={250} placeholder="e.g. Tomorrow's lecture moved to Lab 3, 10am." value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} />
          <div className="cp-ocr-actions"><Pill tone="solid" onClick={send}><Icon name="forum" size={13} /> Send to class</Pill></div>
        </div>
      </Card>
      <Card title="Sent Notices" actions={<LiveBadge />}>
        <div className="cp-notice-list">
          {items.length ? items.map((n, i) => (
            <div className="cp-notice-row" key={n.id} style={{ "--i": i }}>
              <span className="cp-notice-tag">{n.course}</span><span className="cp-notice-title">{n.title}</span><span className="cp-notice-date">{timeAgo(n.ts)}</span>
            </div>
          )) : <EmptyState art="default" text="You haven't sent any notices yet." />}
        </div>
      </Card>
    </>
  );
}

function ApplyLeave({ user, showToast, onChange }) {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({ type: "Casual", from: "", to: "", reason: "" });
  const refresh = useCallback(() => { api.teacher.listMyLeave().then(setItems); }, []);
  useEffect(() => { refresh(); }, [refresh]);
  useLive(["leave:update"], () => { refresh(); onChange && onChange(); });

  async function apply() {
    if (!form.from || !form.to || !form.reason.trim()) return showToast("Fill in dates and a reason", "warn");
    if (form.to < form.from) return showToast("The end date must be on or after the start date", "warn");
    try { await api.teacher.applyLeave(form); } catch (err) { return showToast(err.message, "warn"); }
    setForm({ type: "Casual", from: "", to: "", reason: "" });
    refresh(); onChange && onChange();
    showToast("Leave request submitted");
  }

  return (
    <>
      <Card title="Apply for Leave">
        <div className="cp-form-grid">
          <select value={form.type} onChange={(e) => setForm((f) => ({ ...f, type: e.target.value }))}>
            <option>Casual</option><option>Medical</option><option>Conference</option><option>Earned</option>
          </select>
          <div className="cp-leave-dates">
            <label>From<input type="date" value={form.from} onChange={(e) => setForm((f) => ({ ...f, from: e.target.value }))} /></label>
            <label>To<input type="date" value={form.to} onChange={(e) => setForm((f) => ({ ...f, to: e.target.value }))} /></label>
          </div>
          <textarea placeholder="Reason for leave" rows={3} value={form.reason} onChange={(e) => setForm((f) => ({ ...f, reason: e.target.value }))} />
          <button type="button" className="cp-btn-accent" onClick={apply}>Submit request</button>
        </div>
      </Card>
      <Card title="My Leave History" actions={<LiveBadge />}>
        <DataTable columns={[
          { key: "type", label: "Type" }, { key: "from", label: "From" }, { key: "to", label: "To" }, { key: "reason", label: "Reason" },
          { key: "status", label: "Status", render: (r) => <Badge tone={r.status === "approved" ? "green" : r.status === "rejected" ? "red" : "amber"}>{r.status}</Badge> },
        ]} rows={items} empty="No leave requests filed yet." />
      </Card>
    </>
  );
}

function TeacherReports({ courses, summary }) {
  if (!summary) return <SectionLoading label="Crunching your reports…" />;
  return (
    <>
      <div className="cp-stat-grid">
        <StatCard icon="target" label="Avg. attendance" value={`${summary.avgAttendance}%`} />
        <StatCard icon="barchart" label="Avg. score" value={summary.avgScore || "—"} />
        <StatCard icon="camera" label="Classes held" value={summary.classesHeld} />
        <StatCard icon="check" label="Assessments published" value={summary.gradesPublished} />
      </div>
      {summary.trend.length > 1 && <Card title={`Attendance trend (last ${summary.trend.length} classes)`}><ChartSparkline data={summary.trend} /></Card>}
      <Card title="Grade distribution across your subjects"><ChartBarRow data={summary.distribution} suffix="" /></Card>
      <Card title="Subjects covered">
        <DataTable columns={[{ key: "code", label: "Code" }, { key: "name", label: "Subject" }, { key: "dept", label: "Department" }, { key: "students", label: "Students" }]} rows={courses} />
      </Card>
    </>
  );
}

const ADMIN_NAV = [
  { key: "overview", label: "Overview", icon: "grid" },
  { key: "users", label: "Users & Roles", icon: "users" },
  { key: "courses", label: "Courses & Faculty", icon: "building" },
  { key: "placements", label: "Placements", icon: "briefcase" },
  { key: "grievances", label: "Grievances", icon: "alert" },
  { key: "leave", label: "Leave Requests", icon: "calendar" },
  { key: "fees", label: "Fees & Finance", icon: "wallet" },
  { key: "exams", label: "Exams", icon: "exam" },
  { key: "alerts", label: "Parents & Alerts", icon: "family" },
  { key: "reports", label: "Analytics", icon: "pie" },
  { key: "accreditation", label: "NAAC / NBA Reports", icon: "award" },
  { key: "calendar", label: "Academic Calendar", icon: "calendar" },
  { key: "import", label: "Data Import", icon: "upload" },
  { key: "audit", label: "Audit Log", icon: "activity" },
];

function SecretReveal({ title, lines, onClose }) {
  return (
    <Modal open={!!lines} onClose={onClose} title={title}>
      <div className="cp-form-grid">
        <p className="cp-muted" style={{ marginTop: 0 }}>Share this securely with the person — it's shown <strong>only once</strong>. They'll be asked to choose their own password at first sign-in.</p>
        {(lines || []).map((l) => <div key={l.email} className="cp-secret-row"><span>{l.email}</span><code>{l.tempPassword}</code></div>)}
        <button type="button" className="cp-btn-accent" onClick={() => { navigator.clipboard && navigator.clipboard.writeText((lines || []).map((l) => `${l.email}\t${l.tempPassword}`).join("\n")); }}>Copy to clipboard</button>
      </div>
    </Modal>
  );
}

function AdminApp({ user, theme, onToggleTheme, onLogout }) {
  const [active, setActive] = useState("overview");
  const [toast, showToast] = useToast();
  const [users, setUsers] = useState([]);
  const [userQuery, setUserQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState("");
  const [courses, setCourses] = useState([]);
  const [fees, setFees] = useState([]);
  const [summary, setSummary] = useState(null);
  const [audit, setAudit] = useState([]);
  const [reportsTab, setReportsTab] = useState("overview");
  const [userModal, setUserModal] = useState(false);
  const [courseModal, setCourseModal] = useState(false);
  const [newUser, setNewUser] = useState({ name: "", email: "", role: "student", idLabel: "", department: "" });
  const [newCourse, setNewCourse] = useState({ code: "", name: "", dept: "", facultyId: "" });
  const [rejectTarget, setRejectTarget] = useState(null);
  const [rejectReason, setRejectReason] = useState("");
  const [openGrievances, setOpenGrievances] = useState(0);
  const [openDrives, setOpenDrives] = useState(0);
  const [pendingLeave, setPendingLeave] = useState(0);
  const [subjectRequests, setSubjectRequests] = useState([]);
  const [secret, setSecret] = useState(null);
  const [enrollTarget, setEnrollTarget] = useState(null);
  const [payTarget, setPayTarget] = useState(null);
  const [payAmount, setPayAmount] = useState("");

  const refreshUsers = useCallback(() => { api.admin.listUsers({ q: userQuery, role: roleFilter }).then(setUsers); }, [userQuery, roleFilter]);
  const refreshCourses = useCallback(() => { api.admin.listCourses().then(setCourses); }, []);
  const refreshFees = useCallback(() => { api.admin.listFees().then(setFees); }, []);
  const refreshReports = useCallback(() => { api.admin.reportsSummary().then(setSummary); }, []);
  const refreshAudit = useCallback(() => { api.admin.listAuditLog({ limit: 100 }).then(setAudit); }, []);
  const refreshGrievanceBadge = useCallback(() => { api.admin.listGrievances().then((g) => setOpenGrievances(g.filter((x) => x.status !== "resolved").length)); }, []);
  const refreshDrivesBadge = useCallback(() => { api.placements.list().then((p) => setOpenDrives(p.filter((x) => x.status === "open").length)); }, []);
  const refreshLeaveBadge = useCallback(() => { api.admin.listLeave().then((l) => setPendingLeave(l.filter((x) => x.status === "pending").length)); }, []);
  const refreshSubjectRequests = useCallback(() => { api.admin.listSubjectRequests().then(setSubjectRequests); }, []);
  useEffect(() => { const t = setTimeout(refreshUsers, 250); return () => clearTimeout(t); }, [refreshUsers]);
  useEffect(() => { refreshCourses(); refreshFees(); refreshReports(); refreshAudit(); refreshGrievanceBadge(); refreshDrivesBadge(); refreshSubjectRequests(); refreshLeaveBadge(); },
    [refreshCourses, refreshFees, refreshReports, refreshAudit, refreshGrievanceBadge, refreshDrivesBadge, refreshSubjectRequests, refreshLeaveBadge]);
  useLive(["audit:new"], (entry, ev) => { if (ev === "audit:new" && entry) setAudit((a) => [entry, ...a.filter((x) => x.id !== entry.id)].slice(0, 100)); else refreshAudit(); });
  useLive(["grievance:update"], refreshGrievanceBadge);
  useLive(["placement:new"], refreshDrivesBadge);
  useLive(["leave:update"], refreshLeaveBadge);
  useLive(["subjectRequest:update"], () => { refreshSubjectRequests(); refreshCourses(); });
  useLive(["attendance:update", "grades:update", "fees:update"], () => { refreshReports(); refreshFees(); });

  const teachers = useMemo(() => users.filter((u) => u.role === "teacher"), [users]);
  const [allTeachers, setAllTeachers] = useState([]);
  useEffect(() => { api.admin.listUsers({ role: "teacher" }).then(setAllTeachers); }, [courseModal]);
  const pendingSubjectRequests = subjectRequests.filter((r) => r.status === "pending").length;
  const navWithBadges = useMemo(() => ADMIN_NAV.map((n) => {
    if (n.key === "grievances" && openGrievances) return { ...n, badge: openGrievances };
    if (n.key === "placements" && openDrives) return { ...n, badge: openDrives };
    if (n.key === "courses" && pendingSubjectRequests) return { ...n, badge: pendingSubjectRequests };
    if (n.key === "leave" && pendingLeave) return { ...n, badge: pendingLeave };
    return n;
  }), [openGrievances, openDrives, pendingSubjectRequests, pendingLeave]);

  async function run(fn, ok) {
    try { const r = await fn(); if (ok) showToast(ok); return r; }
    catch (err) { showToast(err.message, "warn"); return null; }
  }
  async function addUser() {
    if (!newUser.name.trim() || !newUser.email.trim()) return showToast("Name and email are required", "warn");
    const u = await run(() => api.admin.createUser(newUser), "User created");
    if (!u) return;
    setUserModal(false); setNewUser({ name: "", email: "", role: "student", idLabel: "", department: "" });
    setSecret({ title: `Temporary password for ${u.name}`, lines: [{ email: u.email, tempPassword: u.tempPassword }] });
    refreshUsers();
  }
  async function toggleStatus(u) {
    if (u.status === "active" && !window.confirm(`Deactivate ${u.name}? They'll be signed out everywhere immediately.`)) return;
    await run(() => api.admin.setUserStatus(u.id, u.status === "active" ? "inactive" : "active"), u.status === "active" ? "User deactivated" : "User reactivated");
    refreshUsers();
  }
  async function resetPw(u) {
    if (!window.confirm(`Reset ${u.name}'s password? They'll be signed out and given a one-time password.`)) return;
    const r = await run(() => api.admin.resetPassword(u.id));
    if (r) setSecret({ title: `New temporary password for ${u.name}`, lines: [{ email: u.email, tempPassword: r.tempPassword }] });
  }
  async function addCourse() {
    if (!newCourse.code.trim() || !newCourse.name.trim()) return showToast("Code and name are required", "warn");
    const c = await run(() => api.admin.createCourse(newCourse), "Course added");
    if (!c) return;
    setCourseModal(false); setNewCourse({ code: "", name: "", dept: "", facultyId: "" });
    refreshCourses();
  }
  async function recordPayment() {
    const amt = Number(payAmount) || null;
    await run(() => api.admin.markFeePaid(payTarget.id, amt), "Payment recorded");
    setPayTarget(null); setPayAmount(""); refreshFees();
  }
  async function approveSubject(r) { await run(() => api.admin.approveSubjectRequest(r.id), `Approved ${r.code} for ${r.teacherName}`); refreshSubjectRequests(); refreshCourses(); }
  async function confirmRejectSubject() {
    await run(() => api.admin.rejectSubjectRequest(rejectTarget.id, rejectReason.trim()), `Declined ${rejectTarget.code} request`);
    setRejectTarget(null); setRejectReason("");
    refreshSubjectRequests();
  }

  return (
    <PortalShell roleKey="admin" navItems={navWithBadges} active={active} onNavigate={setActive} user={user} theme={theme} onToggleTheme={onToggleTheme} onLogout={onLogout} onToast={showToast}
      headerTitle="Admin Console" headerSub="Users, courses, finance and the campus-wide audit trail.">
      <Toast toast={toast} />
      {active === "overview" && (summary ? (
        <>
          <div className="cp-stat-grid">
            <StatCard icon="users" label="Active students" value={summary.totalStudents} /><StatCard icon="user" label="Faculty" value={summary.totalTeachers} />
            <StatCard icon="target" label="Avg. attendance" value={`${summary.avgAttendance}%`} /><StatCard icon="wallet" label="Fees collected" value={`${summary.feeCollectedPct}%`} />
          </div>
          <div className="cp-stat-grid">
            <StatCard icon="building" label="Courses" value={summary.totalCourses} />
            <StatCard icon="barchart" label="Avg. CGPA" value={summary.avgCGPA || "—"} />
            <StatCard icon="alert" label="Open grievances" value={summary.openGrievances} sub={summary.highPriorityGrievances ? `${summary.highPriorityGrievances} high priority` : ""} />
          </div>
          <Card title="Attendance by department" actions={<LiveBadge />}><ChartBarRow data={summary.attendanceByDept} /></Card>
          {summary.attendanceTrend.length > 1 && <Card title="Campus attendance — last 2 weeks"><ChartSparkline data={summary.attendanceTrend.map((d) => d.value)} /></Card>}
          <Card title="Recent activity" actions={<Pill tone="ghost" onClick={() => setActive("audit")}>View all</Pill>}><AuditList entries={audit.slice(0, 6)} /></Card>
        </>
      ) : <SectionLoading label="Loading campus overview…" />)}
      {active === "users" && (
        <Card title="Users & Roles" actions={
          <div className="cp-inline-controls">
            <input className="cp-search-input" placeholder="Search name, email, roll no…" value={userQuery} onChange={(e) => setUserQuery(e.target.value)} />
            <select className="cp-select" value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)}>
              <option value="">{t("All roles")}</option><option value="student">{t("Students")}</option><option value="teacher">{t("Faculty")}</option><option value="admin">{t("Admins")}</option><option value="parent">{t("Parents")}</option>
            </select>
            <Pill tone="solid" onClick={() => setUserModal(true)}><Icon name="plus" size={14} /> Add user</Pill>
          </div>}>
          <DataTable columns={[
            { key: "name", label: "Name" }, { key: "email", label: "Email" },
            { key: "role", label: "Role", render: (r) => <Badge tone={r.role === "admin" ? "navy" : r.role === "teacher" ? "amber" : r.role === "parent" ? "purple" : "teal"}>{t(r.role)}</Badge> },
            { key: "idLabel", label: "ID" }, { key: "department", label: "Department", render: (r) => r.department || "—" },
            { key: "status", label: "Status", render: (r) => <Badge tone={r.status === "active" ? "green" : "red"}>{r.status}</Badge> },
            { key: "actions", label: "", render: (r) => r.id === user.id ? <span className="cp-muted">You</span> : (
              <div className="cp-inline-controls">
                <Pill tone="ghost" onClick={() => resetPw(r)}>Reset password</Pill>
                <Pill tone="ghost" onClick={() => toggleStatus(r)}>{r.status === "active" ? "Deactivate" : "Reactivate"}</Pill>
              </div>) },
          ]} rows={users} empty="No users match." />
        </Card>
      )}
      {active === "courses" && (
        <>
          {pendingSubjectRequests > 0 && (
            <Card title="Pending Subject Requests" actions={<Badge tone="amber">{pendingSubjectRequests} pending</Badge>}>
              <DataTable
                columns={[
                  { key: "code", label: "Code" }, { key: "name", label: "Subject" }, { key: "dept", label: "Department" },
                  { key: "teacherName", label: "Requested by" },
                  { key: "notes", label: "Notes", render: (r) => r.notes || "—" },
                  { key: "ts", label: "Requested", render: (r) => timeAgo(r.ts) },
                  { key: "actions", label: "", render: (r) => (
                    <div className="cp-inline-controls">
                      <Pill tone="solid" onClick={() => approveSubject(r)}>Approve</Pill>
                      <Pill tone="ghost" onClick={() => { setRejectTarget(r); setRejectReason(""); }}>Decline</Pill>
                    </div>) },
                ]}
                rows={subjectRequests.filter((r) => r.status === "pending")}
              />
            </Card>
          )}
          <Card title="Courses & Faculty" actions={<Pill tone="solid" onClick={() => setCourseModal(true)}><Icon name="plus" size={14} /> Add course</Pill>}>
            <DataTable columns={[{ key: "code", label: "Code" }, { key: "name", label: "Course" }, { key: "dept", label: "Department" }, { key: "faculty", label: "Faculty" },
              { key: "students", label: "Enrolled" },
              { key: "actions", label: "", render: (r) => <Pill tone="ghost" onClick={() => setEnrollTarget(r)}>Students</Pill> }]} rows={courses} />
          </Card>
        </>
      )}
      {active === "placements" && <AdminPlacements user={user} showToast={showToast} />}
      {active === "grievances" && <AdminGrievances user={user} showToast={showToast} />}
      {active === "leave" && <AdminLeave showToast={showToast} />}
      {active === "fees" && (
        <>
          <div className="cp-stat-grid">
            <StatCard icon="wallet" label="Total collected" value={`₹${fees.reduce((s, f) => s + f.paid, 0).toLocaleString("en-IN")}`} />
            <StatCard icon="wallet" label="Pending" value={`₹${fees.reduce((s, f) => s + (f.total - f.paid), 0).toLocaleString("en-IN")}`} />
            <StatCard icon="user" label="Overdue accounts" value={fees.filter((f) => f.status === "overdue").length} />
          </div>
          <Card title="Fee records" actions={<LiveBadge />}>
            <DataTable columns={[
              { key: "student", label: "Student" }, { key: "idLabel", label: "Roll no." }, { key: "total", label: "Total", render: (r) => `₹${r.total.toLocaleString("en-IN")}` },
              { key: "paid", label: "Paid", render: (r) => `₹${r.paid.toLocaleString("en-IN")}` },
              { key: "due", label: "Due", render: (r) => `₹${(r.due || 0).toLocaleString("en-IN")}` },
              { key: "status", label: "Status", render: (r) => <Badge tone={r.status === "paid" ? "green" : r.status === "overdue" ? "red" : "amber"}>{r.status}</Badge> },
              { key: "actions", label: "", render: (r) => (r.status !== "paid" ? <Pill tone="ghost" onClick={() => { setPayTarget(r); setPayAmount(String(r.due)); }}>Record payment</Pill> : null) },
            ]} rows={fees} />
          </Card>
        </>
      )}
      {active === "reports" && (
        <>
          <Tabs tabs={[{ key: "overview", label: "Dashboard" }, { key: "risk", label: "Risk Insights" }]} active={reportsTab} onChange={setReportsTab} />
          {reportsTab === "overview" && <AnalyticsDashboard isAdmin showToast={showToast} />}
          {reportsTab === "risk" && <AdminRiskInsights />}
        </>
      )}
      {active === "import" && <AdminImport showToast={showToast} onDone={(creds) => { refreshUsers(); refreshCourses(); refreshFees(); if (creds && creds.length) setSecret({ title: `Temporary passwords for ${creds.length} new account(s)`, lines: creds }); }} />}
      {active === "audit" && <Card title="System-wide audit log" actions={<LiveBadge />}><AuditList entries={audit} /></Card>}
      {active === "exams" && <AdminExams courses={courses} showToast={showToast} />}
      {active === "alerts" && <AdminParentsAlerts showToast={showToast} onSecret={setSecret} />}
      {active === "accreditation" && <Accreditation showToast={showToast} />}
      {active === "calendar" && <AcademicCalendar isAdmin showToast={showToast} />}

      <Modal open={userModal} onClose={() => setUserModal(false)} title="Add user">
        <div className="cp-form-grid">
          <input placeholder="Full name" maxLength={150} value={newUser.name} onChange={(e) => setNewUser((v) => ({ ...v, name: e.target.value }))} />
          <input placeholder="Email" type="email" maxLength={254} value={newUser.email} onChange={(e) => setNewUser((v) => ({ ...v, email: e.target.value }))} />
          <select value={newUser.role} onChange={(e) => setNewUser((v) => ({ ...v, role: e.target.value }))}>
            <option value="student">Student</option><option value="teacher">Faculty</option><option value="admin">Admin</option>
          </select>
          <input placeholder="ID (roll no. / staff ID)" maxLength={50} value={newUser.idLabel} onChange={(e) => setNewUser((v) => ({ ...v, idLabel: e.target.value }))} />
          <input placeholder="Department" maxLength={120} value={newUser.department} onChange={(e) => setNewUser((v) => ({ ...v, department: e.target.value }))} />
          <p className="cp-muted" style={{ margin: 0 }}>A one-time password is generated and shown to you once.</p>
          <button type="button" className="cp-btn-accent" onClick={addUser}>Create user</button>
        </div>
      </Modal>
      <Modal open={courseModal} onClose={() => setCourseModal(false)} title="Add course">
        <div className="cp-form-grid">
          <input placeholder="Course code (e.g. CS401)" maxLength={30} value={newCourse.code} onChange={(e) => setNewCourse((v) => ({ ...v, code: e.target.value }))} />
          <input placeholder="Course name" maxLength={150} value={newCourse.name} onChange={(e) => setNewCourse((v) => ({ ...v, name: e.target.value }))} />
          <input placeholder="Department" maxLength={120} value={newCourse.dept} onChange={(e) => setNewCourse((v) => ({ ...v, dept: e.target.value }))} />
          <select value={newCourse.facultyId} onChange={(e) => setNewCourse((v) => ({ ...v, facultyId: e.target.value }))}>
            <option value="">— Assign faculty later —</option>
            {(allTeachers.length ? allTeachers : teachers).map((t) => <option key={t.id} value={t.id}>{t.name} ({t.department || "—"})</option>)}
          </select>
          <button type="button" className="cp-btn-accent" onClick={addCourse}>Add course</button>
        </div>
      </Modal>
      <Modal open={!!rejectTarget} onClose={() => setRejectTarget(null)} title={rejectTarget ? `Decline ${rejectTarget.code} — ${rejectTarget.name}` : "Decline request"}>
        <div className="cp-form-grid">
          <textarea rows={3} maxLength={1000} placeholder="Reason for the teacher (optional)" value={rejectReason} onChange={(e) => setRejectReason(e.target.value)} />
          <button type="button" className="cp-btn-accent" onClick={confirmRejectSubject}>Confirm decline</button>
        </div>
      </Modal>
      <Modal open={!!payTarget} onClose={() => setPayTarget(null)} title={payTarget ? `Record payment — ${payTarget.student}` : ""}>
        <div className="cp-form-grid">
          <p className="cp-muted" style={{ margin: 0 }}>Balance due: ₹{payTarget ? payTarget.due.toLocaleString("en-IN") : 0}</p>
          <input type="number" min="1" placeholder="Amount received (₹)" value={payAmount} onChange={(e) => setPayAmount(e.target.value)} />
          <button type="button" className="cp-btn-accent" onClick={recordPayment}>Record payment</button>
        </div>
      </Modal>
      {enrollTarget && <EnrollModal course={enrollTarget} onClose={() => { setEnrollTarget(null); refreshCourses(); }} showToast={showToast} />}
      <SecretReveal title={secret ? secret.title : ""} lines={secret ? secret.lines : null} onClose={() => setSecret(null)} />
    </PortalShell>
  );
}

function EnrollModal({ course, onClose, showToast }) {
  const [enrolled, setEnrolled] = useState([]);
  const [students, setStudents] = useState([]);
  const [rolls, setRolls] = useState("");
  const refresh = useCallback(() => { api.admin.courseStudents(course.id).then(setEnrolled); }, [course.id]);
  useEffect(() => { refresh(); api.admin.listUsers({ role: "student" }).then(setStudents); }, [refresh]);
  async function add() {
    const wanted = rolls.split(/[\s,;]+/).map((x) => x.trim().toUpperCase()).filter(Boolean);
    const ids = students.filter((s) => wanted.includes((s.idLabel || "").toUpperCase())).map((s) => s.id);
    const unknown = wanted.filter((w) => !students.some((s) => (s.idLabel || "").toUpperCase() === w));
    if (!ids.length) return showToast(unknown.length ? `Unknown roll numbers: ${unknown.slice(0, 5).join(", ")}` : "Enter roll numbers", "warn");
    try {
      const r = await api.admin.enroll(course.id, ids);
      showToast(`Enrolled ${r.enrolled}${r.alreadyEnrolled ? `, ${r.alreadyEnrolled} already enrolled` : ""}${unknown.length ? `, ${unknown.length} unknown` : ""}`);
      setRolls(""); refresh();
    } catch (err) { showToast(err.message, "warn"); }
  }
  return (
    <Modal open onClose={onClose} title={`${course.code} — ${course.name}: students`}>
      <div className="cp-form-grid">
        <textarea rows={2} placeholder="Add by roll numbers, e.g. CS21B045, CS21B012" value={rolls} onChange={(e) => setRolls(e.target.value)} />
        <button type="button" className="cp-btn-accent" onClick={add}>Enroll</button>
        <div className="cp-enroll-list">
          <strong>{enrolled.length} enrolled</strong>
          {enrolled.map((s) => <div key={s.id} className="cp-enroll-row"><span>{s.idLabel}</span><span>{s.name}</span></div>)}
        </div>
      </div>
    </Modal>
  );
}

function AdminLeave({ showToast }) {
  const [items, setItems] = useState([]);
  const refresh = useCallback(() => { api.admin.listLeave().then(setItems); }, []);
  useEffect(() => { refresh(); }, [refresh]);
  useLive(["leave:update"], refresh);
  async function decide(lv, status) {
    try { await api.admin.decideLeave(lv.id, status); showToast(`Leave ${status}`); } catch (err) { showToast(err.message, "warn"); }
    refresh();
  }
  return (
    <Card title="Leave Requests" actions={<LiveBadge />}>
      <DataTable columns={[
        { key: "applicant", label: "Faculty" }, { key: "type", label: "Type" }, { key: "from", label: "From" }, { key: "to", label: "To" },
        { key: "reason", label: "Reason", render: (r) => <span className="cp-grv-desc">{r.reason || "—"}</span> },
        { key: "status", label: "Status", render: (r) => <Badge tone={r.status === "approved" ? "green" : r.status === "rejected" ? "red" : "amber"}>{r.status}</Badge> },
        { key: "actions", label: "", render: (r) => r.status === "pending" ? (
          <div className="cp-inline-controls"><Pill tone="solid" onClick={() => decide(r, "approved")}>Approve</Pill><Pill tone="ghost" onClick={() => decide(r, "rejected")}>Reject</Pill></div>
        ) : <span className="cp-muted">by {r.decidedBy || "—"}</span> },
      ]} rows={items} empty="No leave requests." />
    </Card>
  );
}

const IMPORT_HELP = {
  users: "Students, faculty and admins. Each new account gets a one-time password.",
  courses: "Courses with their faculty (by the teacher's email).",
  enrollments: "Which students take which course (course code + roll number).",
  fees: "Fee totals and amounts paid per student (by roll number).",
  parents: "Parent / guardian accounts linked to a student (by roll number), with the mobile number used for SMS / WhatsApp alerts.",
};

function AdminImport({ showToast, onDone }) {
  const [templates, setTemplates] = useState({});
  const [result, setResult] = useState(null);
  const [busy, setBusy] = useState(null);
  useEffect(() => { api.admin.importTemplates().then(setTemplates).catch(() => {}); }, []);
  function downloadTemplate(kind) {
    const blob = new Blob([templates[kind] + "\n"], { type: "text/csv" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = `campuspilot-${kind}.csv`; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }
  async function upload(kind, e) {
    const f = e.target.files && e.target.files[0];
    e.target.value = "";
    if (!f) return;
    setBusy(kind);
    try {
      const r = await api.admin.importCsv(kind, f);
      setResult({ kind, ...r });
      showToast(`${r.imported} ${kind} row(s) imported${r.errors.length ? `, ${r.errors.length} skipped` : ""}`, r.errors.length ? "warn" : "ok");
      onDone && onDone(r.credentials);
    } catch (err) { showToast(err.message, "warn"); }
    setBusy(null);
  }
  return (
    <>
      <Card title="Load your college's data">
        <p className="cp-muted" style={{ marginTop: 0 }}>Import in this order: <strong>users → courses → enrollments → fees</strong>. Download a template, fill it in Excel/Sheets, save as CSV (UTF-8) and upload. Bad rows are skipped and listed below; good rows are saved.</p>
        <div className="cp-import-grid">
          {["users", "courses", "enrollments", "fees", "parents"].map((k, i) => (
            <div key={k} className="cp-import-card">
              <div className="cp-import-step">{i + 1}</div>
              <strong style={{ textTransform: "capitalize" }}>{k}</strong>
              <span className="cp-muted">{IMPORT_HELP[k]}</span>
              <code className="cp-import-cols">{templates[k] || "…"}</code>
              <div className="cp-inline-controls">
                <Pill tone="ghost" onClick={() => downloadTemplate(k)} disabled={!templates[k]}>Template</Pill>
                <label className="cp-pill cp-pill--solid" style={{ cursor: "pointer" }}>
                  {busy === k ? "Importing…" : "Upload CSV"}
                  <input type="file" accept=".csv,text/csv" hidden onChange={(e) => upload(k, e)} disabled={!!busy} />
                </label>
              </div>
            </div>
          ))}
        </div>
      </Card>
      {result && (
        <Card title={`Import result — ${result.kind}`}>
          <p><strong>{result.imported}</strong> row(s) imported, <strong>{result.errors.length}</strong> skipped.</p>
          {result.errors.length > 0 && <DataTable columns={[{ key: "row", label: "CSV row" }, { key: "error", label: "Problem" }]} rows={result.errors} />}
        </Card>
      )}
    </>
  );
}

function AdminPlacements({ user, showToast }) {
  const [tab, setTab] = useState("postings");
  const [postings, setPostings] = useState([]);
  const [modal, setModal] = useState(false);
  const blank = { company: "", role: "", package: "", location: "", minCGPA: 7, minAttendance: 75, deadline: "" };
  const [form, setForm] = useState(blank);
  const [selected, setSelected] = useState(null);
  const [applicants, setApplicants] = useState([]);

  const refreshPostings = useCallback(() => { api.placements.list().then((ps) => { setPostings(ps); setSelected((s) => s || (ps[0] && ps[0].id)); }); }, []);
  useEffect(() => { refreshPostings(); }, [refreshPostings]);
  const refreshApplicants = useCallback(() => { if (selected) api.placements.listApplicants(selected).then(setApplicants); }, [selected]);
  useEffect(() => { refreshApplicants(); }, [refreshApplicants]);
  useLive(["placement:new", "placement:application"], () => { refreshPostings(); refreshApplicants(); });

  async function post() {
    if (!form.company.trim() || !form.role.trim() || !form.deadline.trim()) return showToast("Fill in company, role and deadline", "warn");
    try { await api.placements.create({ ...form, minCGPA: Number(form.minCGPA) || 0, minAttendance: Number(form.minAttendance) || 0 }); }
    catch (err) { return showToast(err.message, "warn"); }
    setModal(false); setForm(blank);
    refreshPostings(); showToast("Placement drive posted — eligible students notified");
  }
  async function setStatus(app, status) {
    try { await api.placements.setApplicationStatus(app.id, status); showToast(`Marked ${app.studentName} as ${status}`); } catch (err) { showToast(err.message, "warn"); }
    refreshApplicants();
  }
  async function toggleDrive(p) {
    try { await api.placements.setStatus(p.id, p.status === "open" ? "closed" : "open"); } catch (err) { showToast(err.message, "warn"); }
    refreshPostings();
  }
  const currentPosting = postings.find((p) => p.id === selected);

  return (
    <>
      <div className="cp-stat-grid">
        <StatCard icon="briefcase" label="Open drives" value={postings.filter((p) => p.status === "open").length} />
        <StatCard icon="users" label={currentPosting ? `Applicants — ${currentPosting.company}` : "Applicants"} value={applicants.length} />
      </div>
      <Tabs tabs={[{ key: "postings", label: "Postings" }, { key: "applicants", label: "Applicants" }]} active={tab} onChange={setTab} />
      {tab === "postings" && (
        <Card title="Placement Drives" actions={<div className="cp-inline-controls"><LiveBadge /><Pill tone="solid" onClick={() => setModal(true)}><Icon name="plus" size={14} /> Post job</Pill></div>}>
          <DataTable columns={[
            { key: "company", label: "Company" }, { key: "role", label: "Role" }, { key: "package", label: "Package" },
            { key: "minCGPA", label: "Min CGPA" }, { key: "minAttendance", label: "Min attendance", render: (r) => `${r.minAttendance}%` },
            { key: "deadline", label: "Deadline" }, { key: "applicants", label: "Applicants" },
            { key: "status", label: "Status", render: (r) => <Badge tone={r.status === "open" ? "green" : "neutral"}>{r.status}</Badge> },
            { key: "actions", label: "", render: (r) => <Pill tone="ghost" onClick={() => toggleDrive(r)}>{r.status === "open" ? "Close" : "Reopen"}</Pill> },
          ]} rows={postings} empty="No drives posted yet." />
        </Card>
      )}
      {tab === "applicants" && (
        <Card title="Applicants" actions={
          postings.length
            ? <select value={selected || ""} onChange={(e) => setSelected(e.target.value)} className="cp-select">
                {postings.map((p) => <option key={p.id} value={p.id}>{p.company} — {p.role}</option>)}
              </select>
            : null}>
          <DataTable columns={[
            { key: "studentName", label: "Student" }, { key: "idLabel", label: "ID" },
            { key: "cgpa", label: "CGPA", render: (r) => r.cgpa ?? "—" }, { key: "attendancePct", label: "Attendance", render: (r) => r.attendancePct != null ? `${r.attendancePct}%` : "—" },
            { key: "status", label: "Status", render: (r) => <Badge tone={r.status === "selected" ? "green" : r.status === "rejected" ? "red" : "amber"}>{r.status}</Badge> },
            { key: "ts", label: "Applied", render: (r) => timeAgo(r.ts) },
            { key: "actions", label: "", render: (r) => (
              <div className="cp-inline-controls">
                <Pill tone="ghost" onClick={() => setStatus(r, "shortlisted")}>Shortlist</Pill>
                <Pill tone="solid" onClick={() => setStatus(r, "selected")}>Select</Pill>
                <Pill tone="ghost" onClick={() => setStatus(r, "rejected")}>Reject</Pill>
              </div>
            ) },
          ]} rows={applicants} empty={currentPosting ? `No applicants for ${currentPosting.company} yet.` : "Pick a posting to see applicants."} />
        </Card>
      )}
      <Modal open={modal} onClose={() => setModal(false)} title="Post a placement drive">
        <div className="cp-form-grid">
          <input placeholder="Company" maxLength={150} value={form.company} onChange={(e) => setForm((f) => ({ ...f, company: e.target.value }))} />
          <input placeholder="Role" maxLength={150} value={form.role} onChange={(e) => setForm((f) => ({ ...f, role: e.target.value }))} />
          <input placeholder="Package (e.g. ₹8 LPA)" maxLength={50} value={form.package} onChange={(e) => setForm((f) => ({ ...f, package: e.target.value }))} />
          <input placeholder="Location" maxLength={120} value={form.location} onChange={(e) => setForm((f) => ({ ...f, location: e.target.value }))} />
          <label className="cp-field-label">Min CGPA<input type="number" step="0.1" min="0" max="10" value={form.minCGPA} onChange={(e) => setForm((f) => ({ ...f, minCGPA: e.target.value }))} /></label>
          <label className="cp-field-label">Min attendance %<input type="number" min="0" max="100" value={form.minAttendance} onChange={(e) => setForm((f) => ({ ...f, minAttendance: e.target.value }))} /></label>
          <input placeholder="Deadline (e.g. 12 Oct)" maxLength={50} value={form.deadline} onChange={(e) => setForm((f) => ({ ...f, deadline: e.target.value }))} />
          <button type="button" className="cp-btn-accent" onClick={post}>Post drive</button>
        </div>
      </Modal>
    </>
  );
}

function AdminGrievances({ user, showToast }) {
  const [items, setItems] = useState([]);
  const [statusFilter, setStatusFilter] = useState("active");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [assignTarget, setAssignTarget] = useState(null);
  const [assignee, setAssignee] = useState("");
  const [resolveTarget, setResolveTarget] = useState(null);
  const [resolution, setResolution] = useState("");

  const refresh = useCallback(() => { api.admin.listGrievances().then(setItems); }, []);
  useEffect(() => { refresh(); }, [refresh]);
  useLive(["grievance:update"], refresh);

  const filtered = items.filter((g) =>
    (statusFilter === "all" || (statusFilter === "active" ? g.status !== "resolved" : g.status === statusFilter)) &&
    (categoryFilter === "all" || g.category === categoryFilter)
  );

  async function confirmAssign() {
    if (!assignee.trim()) return showToast("Enter a name to assign to", "warn");
    try { await api.admin.assignGrievance(assignTarget.id, assignee.trim()); showToast("Grievance assigned — the person who raised it was notified"); }
    catch (err) { showToast(err.message, "warn"); }
    setAssignTarget(null); setAssignee(""); refresh();
  }
  async function confirmResolve() {
    try { await api.admin.resolveGrievance(resolveTarget.id, resolution.trim()); showToast("Grievance resolved"); }
    catch (err) { showToast(err.message, "warn"); }
    setResolveTarget(null); setResolution(""); refresh();
  }

  const counts = {
    total: items.length,
    open: items.filter((g) => g.status === "open").length,
    review: items.filter((g) => g.status === "in-review").length,
    high: items.filter((g) => g.status !== "resolved" && g.priority === "high").length,
  };

  return (
    <>
      <div className="cp-stat-grid">
        <StatCard icon="alert" label="High priority (open)" value={counts.high} sub="handle first" />
        <StatCard icon="clock" label="Open" value={counts.open} />
        <StatCard icon="activity" label="In review" value={counts.review} />
        <StatCard icon="clipboard" label="Total" value={counts.total} />
      </div>

      <Card title="Grievance queue" actions={
        <div className="cp-inline-controls">
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="cp-select">
            <option value="active">Open + in review</option>
            <option value="all">All statuses</option>
            <option value="open">Open</option>
            <option value="in-review">In review</option>
            <option value="resolved">Resolved</option>
          </select>
          <select value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)} className="cp-select">
            <option value="all">All categories</option>
            {GRIEVANCE_CATEGORIES_ALL.map((c) => <option key={c}>{c}</option>)}
          </select>
          <LiveBadge />
        </div>}>
        <DataTable
          columns={[
            { key: "priority", label: "Priority", render: (r) => <PriorityBadge priority={r.priority} /> },
            { key: "raisedBy", label: "Raised by" },
            { key: "role", label: "Role", render: (r) => <Badge tone={r.role === "teacher" ? "amber" : "teal"}>{r.role}</Badge> },
            { key: "category", label: "Category" },
            { key: "routedTo", label: "Route to", render: (r) => r.routedTo || "—" },
            { key: "description", label: "Description", render: (r) => <span className="cp-grv-desc" title={r.description + (r.resolution ? ` — Resolution: ${r.resolution}` : "")}>{r.description}{r.resolution ? <em className="cp-grv-resolution"> — {r.resolution}</em> : null}</span> },
            { key: "status", label: "Status", render: (r) => <GrievanceStatusBadge status={r.status} /> },
            { key: "contactEmail", label: "Contact", render: (r) => r.contactEmail ? <a href={`mailto:${r.contactEmail}`}>{r.contactEmail}</a> : "—" },
            { key: "assignedTo", label: "Assigned to", render: (r) => r.assignedTo || "—" },
            { key: "ts", label: "Raised", render: (r) => timeAgo(r.ts) },
            {
              key: "actions", label: "", render: (r) => r.status !== "resolved" ? (
                <div className="cp-inline-controls">
                  <Pill tone="ghost" onClick={() => { setAssignTarget(r); setAssignee(r.assignedTo || r.routedTo || ""); }}>Assign</Pill>
                  <Pill tone="solid" onClick={() => { setResolveTarget(r); setResolution(""); }}>Resolve</Pill>
                </div>
              ) : <span className="cp-muted">Closed</span>,
            },
          ]}
          rows={filtered}
          empty="No grievances match this filter."
        />
      </Card>

      <Modal open={!!assignTarget} onClose={() => setAssignTarget(null)} title="Assign grievance">
        <div className="cp-form-grid">
          <p className="cp-muted">{assignTarget?.category} — {assignTarget?.description}</p>
          <input placeholder="Assign to (staff name or office)" maxLength={150} value={assignee} onChange={(e) => setAssignee(e.target.value)} />
          <button type="button" className="cp-btn-accent" onClick={confirmAssign}>Confirm assignment</button>
        </div>
      </Modal>
      <Modal open={!!resolveTarget} onClose={() => setResolveTarget(null)} title="Resolve grievance">
        <div className="cp-form-grid">
          <p className="cp-muted">{resolveTarget?.category} — {resolveTarget?.description}</p>
          <textarea rows={3} maxLength={2000} placeholder="What was done? (sent to the person who raised it)" value={resolution} onChange={(e) => setResolution(e.target.value)} />
          <button type="button" className="cp-btn-accent" onClick={confirmResolve}>Mark resolved</button>
        </div>
      </Modal>
    </>
  );
}

const COPILOT_LATENCY = 550;
function copilotDelay(v) { return new Promise((res) => setTimeout(() => res(v), COPILOT_LATENCY)); }

function buildCopilotRules(apiRef) {
  return {
    student: [
      {
        match: ["attendance", "present", "bunk"],
        handle: async (user) => {
          const s = await apiRef.student.summary(user.id);
          return `Your attendance is currently **${s.attendancePct}%** — ${s.present} of ${s.totalLectures} lectures attended. ${
            s.attendancePct < 75 ? "That's below the usual 75% cutoff, so it's worth catching up on a few classes." : "You're comfortably above the usual 75% cutoff."
          }`;
        },
      },
      {
        match: ["cgpa", "gpa", "marks", "grade", "score"],
        handle: async (user) => {
          const s = await apiRef.student.summary(user.id);
          return `Your CGPA is **${s.cgpa}/10**. Head to "Sessional Marks" in the sidebar for a full assessment-by-assessment breakdown.`;
        },
      },
      {
        match: ["fee", "due", "payment", "invoice"],
        handle: async (user) => {
          const s = await apiRef.student.summary(user.id);
          return s.feeDue ? `You have **₹${s.feeDue}** in outstanding fees. Check the "Fee Information" tab for the breakdown.` : `You're all paid up — no outstanding fee balance right now.`;
        },
      },
      {
        match: ["assignment", "homework", "submission", "due date", "deadline"],
        handle: async () => {
          const list = await apiRef.student.assignments();
          const pending = list.filter((a) => a.status === "pending");
          if (!pending.length) return `You have no pending assignments right now — nicely done.`;
          const lines = pending.slice(0, 4).map((a) => `• ${a.title} (${a.course}) — due ${a.due}`).join("\n");
          return `You have ${pending.length} pending assignment${pending.length > 1 ? "s" : ""}:\n${lines}`;
        },
      },
      {
        match: ["placement", "job", "internship", "drive", "hiring", "eligib"],
        handle: async (user) => {
          const posts = await apiRef.placements.list();
          const eligible = posts.filter((p) => p.eligible && p.status === "open");
          if (!eligible.length) return `There are open placement drives, but none match your current CGPA/attendance yet. Check "Placements" for the full list and requirements.`;
          const lines = eligible.slice(0, 4).map((p) => `• ${p.company} — ${p.role} (${p.package})`).join("\n");
          return `You're eligible for ${eligible.length} open drive${eligible.length > 1 ? "s" : ""}:\n${lines}`;
        },
      },
      {
        match: ["grievance", "complaint", "issue", "wifi", "wi-fi"],
        handle: async (user) => {
          const mine = await apiRef.student.myGrievances(user.name);
          if (!mine.length) return `You haven't raised any grievances yet. You can file one from the "Grievances" tab — I'll auto-suggest a category as you type.`;
          const open = mine.filter((g) => g.status !== "resolved").length;
          return `You've raised ${mine.length} grievance${mine.length > 1 ? "s" : ""}, ${open} still open. Check "Grievances" for status and who it's assigned to.`;
        },
      },
      {
        match: ["notice", "notification", "announcement"],
        handle: async () => {
          const [n] = await apiRef.student.notices();
          return n ? `Latest notice (${n.course}): **${n.title}** — ${timeAgo(n.ts)}. See the Notice Board on your Dashboard for more.` : `No notices from your classes yet.`;
        },
      },
      {
        match: ["timetable", "schedule", "class today", "today's class"],
        handle: async () => `Today's classes are on your Dashboard under "Today's Classes" — full weekly view is under "Time Table" in the sidebar.`,
      },
      {
        match: ["library", "book", "borrow"],
        handle: async (user) => {
          const [reqs, catalog] = await Promise.all([apiRef.student.myLibraryRequests(user.name), apiRef.student.libraryCatalog()]);
          const pending = reqs.filter((r) => r.status === "pending" || r.status === "waitlisted").length;
          return `The catalog has ${catalog.length} titles listed. You have ${reqs.length} library request${reqs.length !== 1 ? "s" : ""}${pending ? `, ${pending} still pending` : ""}. Browse and request books from the "Library" tab.`;
        },
      },
    ],
    teacher: [
      {
        match: ["attendance", "class average", "present"],
        handle: async (user) => {
          const courses = await apiRef.teacher.myCourses(user.name);
          const r = await apiRef.teacher.reportsSummary(user.name, courses);
          return `Your average class attendance across ${courses.length} subject${courses.length !== 1 ? "s" : ""} is **${r.avgAttendance}%**, from ${r.classesHeld} recorded session${r.classesHeld !== 1 ? "s" : ""}. Use "Take Attendance" to mark a new class.`;
        },
      },
      {
        match: ["grade", "score", "marks", "gradebook", "distribution"],
        handle: async (user) => {
          const courses = await apiRef.teacher.myCourses(user.name);
          const r = await apiRef.teacher.reportsSummary(user.name, courses);
          return r.gradesPublished ? `You've published ${r.gradesPublished} assessment${r.gradesPublished > 1 ? "s" : ""} with an average score of **${r.avgScore}/100**. Full distribution is under "My Reports".` : `No grades published yet — head to "Enter Marks" to publish your first assessment.`;
        },
      },
      {
        match: ["student", "roster", "at risk", "low attendance"],
        handle: async (user) => {
          const courses = await apiRef.teacher.myCourses(user.name);
          const stats = await apiRef.teacher.studentsWithStats(courses.map((c) => c.id));
          const atRisk = stats.filter((s) => s.attendancePct != null && s.attendancePct < 75);
          if (!atRisk.length) return `All ${stats.length} students across your subjects are at or above 75% attendance.`;
          const lines = atRisk.slice(0, 5).map((s) => `• ${s.name} (${s.idLabel}) — ${s.attendancePct}%`).join("\n");
          return `${atRisk.length} student${atRisk.length > 1 ? "s are" : " is"} below 75% attendance:\n${lines}`;
        },
      },
      {
        match: ["assignment", "submission", "homework"],
        handle: async (user) => {
          const courses = await apiRef.teacher.myCourses(user.name);
          const items = await apiRef.teacher.listAssignments(courses.map((c) => c.name));
          return items.length ? `You have ${items.length} assignment${items.length > 1 ? "s" : ""} posted across your subjects. Check "Manage Assignments" for submission counts.` : `No assignments posted yet — create one from "Manage Assignments".`;
        },
      },
      {
        match: ["leave", "vacation", "time off"],
        handle: async (user) => {
          const leave = await apiRef.teacher.listMyLeave(user.name);
          const pending = leave.filter((l) => l.status === "pending").length;
          return pending ? `You have ${pending} leave request${pending > 1 ? "s" : ""} still pending approval.` : `No pending leave requests — you can file a new one from "Apply Leave".`;
        },
      },
      {
        match: ["material", "notes", "upload", "syllabus"],
        handle: async () => `You can upload notes, slides, or lab manuals for a subject from the "Study Material" tab — students see it instantly.`,
      },
      {
        match: ["risk", "dropout", "struggling", "health score"],
        handle: async (user) => {
          const courses = await apiRef.teacher.myCourses(user.name);
          const scored = await apiRef.teacher.riskScores(courses.map((c) => c.id));
          const high = scored.filter((s) => s.riskLevel === "high");
          if (!high.length) return `No students are flagged high-risk right now. See "My Students → Risk Insights" for the full breakdown.`;
          const lines = high.slice(0, 5).map((s) => `• ${s.name} (${s.idLabel}) — health score ${s.healthScore}`).join("\n");
          return `${high.length} student${high.length > 1 ? "s are" : " is"} flagged high-risk:\n${lines}\nFull details under "My Students → Risk Insights".`;
        },
      },
      {
        match: ["grievance", "complaint"],
        handle: async (user) => {
          const mine = await apiRef.teacher.myGrievances(user.name);
          if (!mine.length) return `You haven't raised any grievances yet. You can file one from the "Grievances" tab.`;
          const open = mine.filter((g) => g.status !== "resolved").length;
          return `You've raised ${mine.length} grievance${mine.length > 1 ? "s" : ""}, ${open} still open. Check "Grievances" for status and who it's assigned to.`;
        },
      },
      {
        match: ["timetable", "my schedule", "class today", "today's class"],
        handle: async (user) => {
          await apiRef.teacher.timetable(user.name);
          return `Your weekly teaching schedule is under "Time Table" in the sidebar.`;
        },
      },
      {
        match: ["subject request", "new subject", "add subject", "request a subject"],
        handle: async (user) => {
          const reqs = await apiRef.teacher.mySubjectRequests(user.name);
          const pending = reqs.filter((r) => r.status === "pending").length;
          if (!reqs.length) return `You haven't requested any new subjects yet. Do that from "My Subjects".`;
          return `You have ${reqs.length} subject request${reqs.length !== 1 ? "s" : ""} on file, ${pending} still pending admin approval.`;
        },
      },
    ],
    admin: [
      {
        match: ["fee", "collection", "revenue", "finance", "overdue"],
        handle: async () => {
          const r = await apiRef.admin.reportsSummary();
          const fees = await apiRef.admin.listFees();
          const overdue = fees.filter((f) => f.status === "overdue").length;
          return `Fee collection stands at **${r.feeCollectedPct}%** campus-wide, with ${overdue} overdue account${overdue !== 1 ? "s" : ""}. See "Fees & Finance" for the full ledger.`;
        },
      },
      {
        match: ["attendance", "average attendance"],
        handle: async () => {
          const r = await apiRef.admin.reportsSummary();
          return `Campus-wide average attendance is **${r.avgAttendance}%**. Department breakdown is available on the "Reports & Analytics" tab.`;
        },
      },
      {
        match: ["student", "teacher", "faculty", "user", "headcount"],
        handle: async () => {
          const r = await apiRef.admin.reportsSummary();
          return `You currently have **${r.totalStudents}** students and **${r.totalTeachers}** teachers across **${r.totalCourses}** courses. Manage them from "Users & Roles".`;
        },
      },
      {
        match: ["grievance", "complaint"],
        handle: async () => {
          const list = await apiRef.admin.listGrievances();
          const open = list.filter((g) => g.status !== "resolved").length;
          return `There are ${open} open or in-review grievance${open !== 1 ? "s" : ""} out of ${list.length} total. Check the "Grievances" tab to assign or resolve them.`;
        },
      },
      {
        match: ["placement", "job", "drive", "hiring"],
        handle: async () => {
          const posts = await apiRef.placements.list();
          const open = posts.filter((p) => p.status === "open").length;
          return `There are ${open} open placement drive${open !== 1 ? "s" : ""} right now. Post a new one from "Placements".`;
        },
      },
      {
        match: ["audit", "log", "activity", "recent action"],
        handle: async () => {
          const log = await apiRef.admin.listAuditLog();
          const last = log[0];
          return last ? `Most recent activity: **${last.actor}** — ${last.action}${last.detail ? ` (${last.detail})` : ""}, ${timeAgo(last.ts)}. Full trail is under "Audit Log".` : `No activity logged yet.`;
        },
      },
      {
        match: ["risk", "dropout", "struggling", "health score"],
        handle: async () => {
          const scored = await apiRef.admin.riskScores();
          const high = scored.filter((s) => s.riskLevel === "high");
          if (!high.length) return `No students are flagged high-risk campus-wide right now. See "Reports & Analytics → Risk Insights" for the full breakdown.`;
          const lines = high.slice(0, 5).map((s) => `• ${s.name} (${s.idLabel}) — health score ${s.healthScore}`).join("\n");
          return `${high.length} student${high.length > 1 ? "s are" : " is"} flagged high-risk campus-wide:\n${lines}\nFull details under "Reports & Analytics → Risk Insights".`;
        },
      },
      {
        match: ["course", "subject request", "new subject", "add subject"],
        handle: async () => {
          const [courses, reqs] = await Promise.all([apiRef.admin.listCourses(), apiRef.admin.listSubjectRequests()]);
          const pending = reqs.filter((r) => r.status === "pending").length;
          return `You have ${courses.length} course${courses.length !== 1 ? "s" : ""} set up${pending ? `, and ${pending} subject request${pending !== 1 ? "s" : ""} awaiting approval` : ""}. Manage both from "Courses" and "Subject Requests".`;
        },
      },
    ],
  };
}

// Small-talk / meta questions that aren't about any specific portal data —
// checked only after the role-specific rules above find no match, so a real
// question like "can you help with my fees" still hits the fee rule instead
// of getting swallowed by the word "help" here. Word-boundary regexes (not
// plain .includes()) so short words like "hi" don't false-match inside
// unrelated words (e.g. "which", "this").
const COPILOT_SMALLTALK = [
  { re: /\b(hi|hello|hey|yo|namaste)\b/i, handle: (user, roleKey) => `Hey ${user.name.split(" ")[0]}! ${COPILOT_FALLBACKS[roleKey] || COPILOT_FALLBACKS.student}` },
  { re: /\b(thanks|thank you|thx|appreciate it)\b/i, handle: () => `You're welcome! Let me know if there's anything else you'd like to check.` },
  { re: /\b(bye|goodbye|see you|see ya)\b/i, handle: () => `Bye for now — I'll be right here if you need anything else.` },
  { re: /\b(who are you|what are you|what can you do|what do you do|help)\b/i, handle: (_user, roleKey) => COPILOT_FALLBACKS[roleKey] || COPILOT_FALLBACKS.student },
];

const COPILOT_FALLBACKS = {
  student: `I can help with your attendance, CGPA/marks, fees, assignments, placements, grievances or timetable — try asking something like "what's my attendance?" or "any pending assignments?"`,
  teacher: `I can help with class attendance, grades, at-risk students, assignments or leave requests — try "what's my class average?" or "any pending leave requests?"`,
  admin: `I can help with fee collection, campus attendance, headcounts, grievances, placements or the audit log — try "fee collection status" or "any open grievances?"`,
};

const copilotApi = {
  ask: async (query, roleKey, user, apiRef) => {
    const q = (query || "").trim().toLowerCase();
    if (!q) return copilotDelay({ text: "Ask me something about your " + (roleKey === "student" ? "attendance, marks, fees or assignments." : roleKey === "teacher" ? "classes, grades or students." : "campus data.") });
    const rules = buildCopilotRules(apiRef)[roleKey] || [];
    const hit = rules.find((r) => r.match.some((kw) => q.includes(kw)));
    if (hit) {
      try {
        const text = await hit.handle(user);
        return copilotDelay({ text, matched: true });
      } catch (err) {
        return copilotDelay({ text: "I couldn't pull that up right now — try again in a moment.", matched: false, error: true });
      }
    }
    const smalltalk = COPILOT_SMALLTALK.find((r) => r.re.test(q));
    if (smalltalk) return copilotDelay({ text: smalltalk.handle(user, roleKey), matched: true });
    return copilotDelay({ text: COPILOT_FALLBACKS[roleKey] || COPILOT_FALLBACKS.student, matched: false });
  },
};
// ---- AI copilot (server-side LLM). Falls back to the rules above when the
// server has no AI provider configured or the provider is unavailable.
copilotApi.status = () => apiFetch("/copilot/status");
copilotApi.chat = (question, history) => apiFetch("/copilot/chat", { method: "POST", body: { question, history }, timeoutMs: 90000 });
api.copilot = copilotApi;

const COPILOT_SUGGESTIONS = {
  student: ["How many classes can I miss?", "Which subjects am I weakest in?", "Am I eligible for any placements?", "What's due this week?"],
  teacher: ["Which students are at high risk?", "How is attendance trending in my classes?", "Assignments with low submissions?", "Apply casual leave next Monday"],
  admin: ["Give me today's campus summary", "Who are the high-risk students in CS?", "Largest fee dues?", "Urgent grievances to handle first?"],
};

// Confirmed copilot actions run through the normal, validated API calls.
const COPILOT_ACTIONS = {
  raise_grievance: (p, role) => (role === "teacher" ? api.teacher : api.student).raiseGrievance(p).then((g) => `Grievance submitted — ${g.priority} priority, routed to ${g.routedTo}.`),
  request_book: (p) => api.student.requestBook({ id: p.bookId }).then(() => `Requested "${p.title}". You'll get a notification when it's ready.`),
  apply_placement: (p) => api.placements.apply(p.placementId).then(() => `Applied to ${p.company}. Good luck!`),
  apply_leave: (p) => api.teacher.applyLeave(p).then(() => "Leave request submitted for admin approval."),
  send_notice: (p) => api.teacher.sendNotice(p).then(() => "Notice sent — students were notified instantly."),
};

function RichText({ text }) {
  // Tiny, safe markdown: **bold**, "- " / "• " bullets, line breaks. Built as React nodes (no HTML injection).
  const inline = (line) => line.split(/\*\*(.+?)\*\*/g).map((part, j) => (j % 2 ? <strong key={j}>{part}</strong> : part));
  const lines = (text || "").split("\n");
  const out = [];
  let bullets = [];
  const flush = () => { if (bullets.length) { out.push(<ul key={`u${out.length}`}>{bullets}</ul>); bullets = []; } };
  lines.forEach((line, i) => {
    const m = line.match(/^\s*(?:[-•*]|\d+\.)\s+(.*)$/);
    if (m) bullets.push(<li key={i}>{inline(m[1])}</li>);
    else { flush(); if (line.trim()) out.push(<div key={i}>{inline(line)}</div>); }
  });
  flush();
  return <>{out}</>;
}

function CopilotIcon({ name, size = 18 }) {
  const paths = {
    chat: "M4 5h16v11H8l-4 4Z",
    close: "M6 6l12 12M18 6L6 18",
    send: "M4 12 20 4l-6 16-3-7-7-1Z",
    sparkle: "M12 3l1.6 4.9L18.5 9.5l-4.9 1.6L12 16l-1.6-4.9L5.5 9.5l4.9-1.6Z",
    bot: "M9 8V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v3M5 8h14v10H5ZM9 13h.01M15 13h.01",
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={paths[name] || ""} />
    </svg>
  );
}

function CopilotWidget({ user, roleKey, api: apiRef }) {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const [ai, setAi] = useState(null);            // null = unknown, else status object
  const [remaining, setRemaining] = useState(null);
  const [progress, setProgress] = useState("");
  const [messages, setMessages] = useState(() => [
    { id: "welcome", from: "bot", text: `Hi ${user.name.split(" ")[0]}, I'm your Campus Copilot. Ask me anything about your campus data.` },
  ]);
  const listRef = useRef(null);
  const info = roleInfo(roleKey);

  useEffect(() => { if (open && ai === null) api.copilot.status().then(setAi).catch(() => setAi({ ai: false })); }, [open, ai]);
  useEffect(() => { if (listRef.current) listRef.current.scrollTop = listRef.current.scrollHeight; }, [messages, thinking, open, progress]);
  // Live "what I'm doing" updates from the server while the AI works.
  useEffect(() => realtimeBus.on("copilot:progress", (d) => setProgress((d && d.label) || "")), []);
  // While a local model is still downloading/starting, re-check every 30s.
  useEffect(() => {
    if (!open || !ai || ai.ai || !ai.note) return undefined;
    const t = setInterval(() => api.copilot.status().then(setAi).catch(() => {}), 30000);
    return () => clearInterval(t);
  }, [open, ai]);

  const push = (m) => setMessages((ms) => [...ms, { id: uid("cwm"), ...m }]);

  async function ruleAnswer(text) {
    const { text: reply } = await copilotApi.ask(text, roleKey, user, apiRef);
    return reply;
  }

  async function send(textArg) {
    const text = (textArg ?? input).trim().slice(0, 500);
    if (!text || thinking) return;
    const history = messages.filter((m) => m.id !== "welcome" && !m.action && !m.error && m.text)
      .slice(-10).map((m) => ({ role: m.from === "user" ? "user" : "assistant", content: m.text.slice(0, 2000) }));
    push({ from: "user", text });
    setInput("");
    setThinking(true);
    setProgress("");
    try {
      if (ai && ai.ai) {
        const r = await api.copilot.chat(text, history);
        if (r.mode === "offline") { setAi({ ai: false }); push({ from: "bot", text: await ruleAnswer(text) }); }
        else {
          push({ from: "bot", text: r.answer, tools: r.toolsUsed });
          if (r.action) push({ from: "bot", action: r.action, state: "pending" });
          setRemaining(r.remaining);
        }
      } else {
        push({ from: "bot", text: await ruleAnswer(text) });
      }
    } catch (err) {
      push({ from: "bot", error: true, text: `${err.message} Here's what I can tell you from the built-in assistant:` });
      push({ from: "bot", text: await ruleAnswer(text).catch(() => "Please try again in a moment.") });
      api.copilot.status().then(setAi).catch(() => {});
    }
    setThinking(false);
    setProgress("");
  }

  async function decide(msg, confirm) {
    setMessages((ms) => ms.map((m) => (m.id === msg.id ? { ...m, state: confirm ? "running" : "cancelled" } : m)));
    if (!confirm) return;
    const run = COPILOT_ACTIONS[msg.action.type];
    try {
      const result = run ? await run(msg.action.params, roleKey) : "That action isn't supported.";
      setMessages((ms) => ms.map((m) => (m.id === msg.id ? { ...m, state: "done", result } : m)));
    } catch (err) {
      setMessages((ms) => ms.map((m) => (m.id === msg.id ? { ...m, state: "failed", result: err.message } : m)));
    }
  }

  function onKeyDown(e) {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); }
  }

  const aiOn = ai && ai.ai;
  const showSuggestions = messages.length <= 1 && !thinking;

  return (
    <div className="cw-root" style={{ "--cw-accent": info.accent, "--cw-accent-deep": info.accentDeep, "--cw-accent-soft": info.accentSoft }}>
      {!open && (
        <button className="cw-fab" onClick={() => setOpen(true)} aria-label="Open Campus Copilot">
          <CopilotIcon name="chat" size={22} />
          <span className="cw-fab-ping" />
        </button>
      )}

      {open && (
        <div className="cw-panel" role="dialog" aria-label="Campus Copilot chat">
          <div className="cw-head">
            <div className="cw-head-left">
              <span className="cw-head-avatar"><CopilotIcon name="bot" size={16} /></span>
              <div>
                <div className="cw-head-title">Campus Copilot</div>
                <div className="cw-head-sub">
                  <span className="cw-proto-badge"><CopilotIcon name="sparkle" size={10} /> {ai === null ? "Connecting…" : aiOn ? ai.label : ai.note ? "AI starting up" : "Built-in assistant"}</span>
                </div>
              </div>
            </div>
            <button className="cw-icon-btn" onClick={() => setOpen(false)} aria-label="Close chat"><CopilotIcon name="close" size={15} /></button>
          </div>

          <div className="cw-disclaimer">
            {aiOn
              ? (ai.provider === "ollama"
                  ? "AI running on your college's own server — your data doesn't leave campus. It uses only your own records and can prepare actions, but nothing happens until you press Confirm."
                  : "AI answers using only your own records. Your question and the records it looks up are sent to the AI service (" + (ai.label || "AI").split(" · ")[0] + "). Nothing happens until you press Confirm.")
              : ai && ai.note
                ? `${ai.note} Meanwhile the built-in assistant answers from your live records.`
                : "Answers come from keyword rules over your own live records."}
          </div>

          <div className="cw-messages" ref={listRef} aria-live="polite">
            {messages.map((m) => (
              <div key={m.id} className={"cw-msg cw-msg--" + m.from}>
                {m.from === "bot" && <span className="cw-msg-avatar"><CopilotIcon name="bot" size={13} /></span>}
                {m.action ? (
                  <div className="cw-action">
                    <div className="cw-action-title">Please confirm</div>
                    <div className="cw-action-summary">{m.action.summary}</div>
                    {m.state === "pending" && (
                      <div className="cw-action-buttons">
                        <button className="cw-btn cw-btn--primary" onClick={() => decide(m, true)}>Confirm</button>
                        <button className="cw-btn" onClick={() => decide(m, false)}>Cancel</button>
                      </div>
                    )}
                    {m.state === "running" && <div className="cw-action-state">Working…</div>}
                    {m.state === "cancelled" && <div className="cw-action-state">Cancelled — nothing was changed.</div>}
                    {m.state === "done" && <div className="cw-action-state cw-action-state--ok">✓ {m.result}</div>}
                    {m.state === "failed" && <div className="cw-action-state cw-action-state--err">{m.result}</div>}
                  </div>
                ) : (
                  <div className={"cw-bubble" + (m.error ? " cw-bubble--err" : "")}><RichText text={m.text} /></div>
                )}
              </div>
            ))}
            {thinking && (
              <div className="cw-msg cw-msg--bot">
                <span className="cw-msg-avatar"><CopilotIcon name="bot" size={13} /></span>
                <div className="cw-typing-wrap">
                  <div className="cw-bubble cw-bubble--typing"><span /><span /><span /></div>
                  {progress && <div className="cw-progress">{progress}</div>}
                  {aiOn && ai.provider === "ollama" && !progress && <div className="cw-progress">Thinking on the local server…</div>}
                </div>
              </div>
            )}
            {showSuggestions && (
              <div className="cw-suggestions">
                {(COPILOT_SUGGESTIONS[roleKey] || []).map((q) => <button key={q} className="cw-chip" onClick={() => send(q)}>{q}</button>)}
              </div>
            )}
          </div>

          <div className="cw-inputbar">
            <input
              placeholder={aiOn ? "Ask anything — English, Hindi or Hinglish…" : roleKey === "student" ? "Ask about attendance, marks, fees…" : roleKey === "teacher" ? "Ask about classes, grades, students…" : "Ask about fees, users, grievances…"}
              value={input}
              maxLength={500}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={onKeyDown}
            />
            <button className="cw-send-btn" onClick={() => send()} disabled={!input.trim() || thinking} aria-label="Send">
              <CopilotIcon name="send" size={15} />
            </button>
          </div>
          {aiOn && remaining != null && remaining < 10 && <div className="cw-quota">{remaining} AI questions left today</div>}
        </div>
      )}
    </div>
  );
}

function ChangePasswordGate({ user, onDone, onLogout }) {
  const [cur, setCur] = useState(""); const [pw, setPw] = useState(""); const [pw2, setPw2] = useState("");
  const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  async function save() {
    setErr("");
    if (pw !== pw2) return setErr("The new passwords don't match.");
    setBusy(true);
    try { const r = await api.auth.changePassword(cur, pw); onDone(r.user); }
    catch (e) { setErr(e.message); }
    setBusy(false);
  }
  return (
    <div className="cp-gate">
      <div className="cp-gate-card">
        <BrandMark size={34} />
        <h2>Choose your own password</h2>
        <p className="cp-muted">Hi {user.name.split(" ")[0]} — your account was set up with a temporary password. Pick a new one to continue.</p>
        {err && <div className="a2-error">{err}</div>}
        <FieldInput icon="lock" placeholder="Temporary / current password" value={cur} onChange={setCur} type="password" autoComplete="current-password" />
        <FieldInput icon="lock" placeholder="New password" value={pw} onChange={setPw} type="password" autoComplete="new-password" />
        <PasswordStrengthHint password={pw} />
        <FieldInput icon="lock" placeholder="Confirm new password" value={pw2} onChange={setPw2} type="password" autoComplete="new-password" onEnter={save} />
        <button type="button" className="a2-submit" disabled={busy} onClick={save}>{busy ? "Saving…" : "Save and continue"}</button>
        <button type="button" className="cp-gate-link" onClick={onLogout}>Sign out</button>
      </div>
    </div>
  );
}



// Hindi translations (keys are the English labels used in the UI).
const HI = {
  // ---- roles & menus
  "Student": "छात्र", "Faculty": "शिक्षक", "Admin": "प्रशासक", "Parent": "अभिभावक",
  "student": "छात्र", "teacher": "शिक्षक", "admin": "प्रशासक", "parent": "अभिभावक",
  "Student Menu": "छात्र मेनू", "Faculty Menu": "शिक्षक मेनू", "Admin Menu": "प्रशासक मेनू", "Parent Menu": "अभिभावक मेनू",
  "Student view": "छात्र दृश्य", "Faculty view": "शिक्षक दृश्य", "Admin view": "प्रशासक दृश्य", "Parent view": "अभिभावक दृश्य",
  "Roll Number": "रोल नंबर", "Staff ID": "स्टाफ़ आईडी", "Admin ID": "प्रशासक आईडी",
  "Dashboard": "डैशबोर्ड", "My Dashboard": "मेरा डैशबोर्ड", "Overview": "सारांश", "Attendance": "उपस्थिति",
  "Sessional Marks": "सत्रीय अंक", "Exams & Results": "परीक्षा और परिणाम", "Exams": "परीक्षाएँ", "Assignments": "असाइनमेंट",
  "Placements": "प्लेसमेंट", "Grievances": "शिकायतें", "Fee Information": "शुल्क जानकारी", "Library": "पुस्तकालय",
  "Time Table": "समय सारणी", "Calendar": "कैलेंडर", "ID Card & Certificates": "पहचान पत्र और प्रमाणपत्र",
  "My Profile": "मेरी प्रोफ़ाइल", "My Subjects": "मेरे विषय", "My Students": "मेरे छात्र", "Take Attendance": "उपस्थिति लें",
  "QR Attendance": "QR उपस्थिति", "Manage Assignments": "असाइनमेंट प्रबंधन", "Enter Marks": "अंक दर्ज करें",
  "Study Material": "अध्ययन सामग्री", "My Timetable": "मेरी समय सारणी", "Class Notices": "कक्षा सूचनाएँ", "Apply Leave": "छुट्टी आवेदन",
  "My Reports": "मेरी रिपोर्ट", "My ID Card": "मेरा पहचान पत्र", "Department Analytics": "विभाग विश्लेषण",
  "Users & Roles": "उपयोगकर्ता और भूमिकाएँ", "Courses & Faculty": "पाठ्यक्रम और शिक्षक", "Leave Requests": "छुट्टी अनुरोध",
  "Fees & Finance": "शुल्क और वित्त", "Parents & Alerts": "अभिभावक और अलर्ट", "Analytics": "विश्लेषण",
  "NAAC / NBA Reports": "NAAC / NBA रिपोर्ट", "Academic Calendar": "शैक्षणिक कैलेंडर", "Data Import": "डेटा आयात", "Audit Log": "ऑडिट लॉग",
  "Marks & Results": "अंक और परिणाम", "Fees": "शुल्क", "Notices": "सूचनाएँ", "Alerts": "अलर्ट",

  // ---- headers & shell
  "Academic Overview": "शैक्षणिक सारांश", "Faculty Workspace": "शिक्षक कार्यक्षेत्र", "Admin Console": "प्रशासक कंसोल", "Parent Portal": "अभिभावक पोर्टल",
  "Mark attendance, publish grades, and keep every class moving — all from one desk.": "उपस्थिति लें, अंक प्रकाशित करें और हर कक्षा को सुचारु रखें — सब एक ही जगह से।",
  "Users, courses, finance and the campus-wide audit trail.": "उपयोगकर्ता, पाठ्यक्रम, वित्त और पूरे परिसर का ऑडिट रिकॉर्ड।",
  "Log out": "लॉग आउट", "Take the tour": "परिचय देखें", "Install app": "ऐप इंस्टॉल करें", "Install CampusPilot": "CampusPilot इंस्टॉल करें",
  "Notifications": "सूचनाएँ", "Toggle dark mode": "डार्क मोड बदलें", "Open menu": "मेनू खोलें", "Close menu": "मेनू बंद करें",
  "Page zoom": "पेज ज़ूम", "Zoom in": "ज़ूम इन", "Zoom out": "ज़ूम आउट", "Zoom in (Alt + =)": "ज़ूम इन (Alt + =)", "Zoom out (Alt + −)": "ज़ूम आउट (Alt + −)",
  "Reset to 100% (Alt + 0)": "100% पर लौटें (Alt + 0)", "You're all caught up.": "कोई नई सूचना नहीं है।",

  // ---- tour
  "Quick tour": "त्वरित परिचय", "Step": "चरण", "Skip tour": "परिचय छोड़ें", "Back": "पीछे", "Next": "आगे", "Finish": "समाप्त",
  "Your menu": "आपका मेनू", "Everything for your role lives here. On a phone, open it with the ☰ button.": "आपकी भूमिका की हर सुविधा यहाँ है। फ़ोन पर ☰ बटन से खोलें।",
  "Zoom in or out": "ज़ूम इन या आउट", "Make pages bigger or smaller. Click the % to reset. Shortcuts: Alt + = and Alt + −.": "पेज बड़ा या छोटा करें। वापस लाने के लिए % दबाएँ। शॉर्टकट: Alt + = और Alt + −।",
  "Live notifications": "लाइव सूचनाएँ", "Attendance, marks, fees and approvals appear here the moment they happen.": "उपस्थिति, अंक, शुल्क और स्वीकृतियाँ होते ही यहाँ दिखती हैं।",
  "Switch the menus and main labels to Hindi at any time.": "मेनू और मुख्य लेबल कभी भी हिंदी या अंग्रेज़ी में बदलें।",
  "Exams & hall ticket": "परीक्षा और प्रवेश पत्र", "Your exam timetable, hall ticket, results and grade card.": "आपकी परीक्षा समय सारणी, प्रवेश पत्र, परिणाम और ग्रेड कार्ड।",
  "QR check-in": "QR चेक-इन", "When your teacher shows a QR code in class, scan it with your phone camera or type the 6-digit code here.": "जब शिक्षक कक्षा में QR कोड दिखाएँ, उसे फ़ोन कैमरे से स्कैन करें या 6 अंकों का कोड यहाँ लिखें।",
  "QR attendance": "QR उपस्थिति", "Show a QR code in class — students scan it and attendance fills itself in.": "कक्षा में QR कोड दिखाएँ — छात्र स्कैन करते हैं और उपस्थिति अपने-आप भर जाती है।",
  "Attendance by photo": "फ़ोटो से उपस्थिति", "Or snap the paper attendance sheet and let CampusPilot read it.": "या काग़ज़ी उपस्थिति शीट की फ़ोटो लें, CampusPilot उसे पढ़ लेगा।",
  "Campus trends, attendance heat-maps and at-risk students — download as PDF.": "परिसर के रुझान, उपस्थिति हीट-मैप और जोखिम वाले छात्र — PDF में डाउनलोड करें।",
  "NAAC / NBA data": "NAAC / NBA डेटा", "Accreditation tables generated from live records, ready to export.": "लाइव रिकॉर्ड से बनी मान्यता तालिकाएँ, निर्यात के लिए तैयार।",
  "Every SMS/WhatsApp alert we send you is also listed here.": "आपको भेजा गया हर SMS/WhatsApp अलर्ट यहाँ भी दिखता है।",
  "Ask the Copilot": "कोपायलट से पूछें", "Ask questions in plain words — it answers from your own records.": "सरल शब्दों में पूछें — जवाब आपके अपने रिकॉर्ड से मिलेगा।",

  // ---- common words / buttons
  "Add": "जोड़ें", "Cancel": "रद्द करें", "Done": "हो गया", "Remove": "हटाएँ", "Retry": "फिर से भेजें", "Send": "भेजें", "View all": "सभी देखें",
  "Today": "आज", "Status": "स्थिति", "Date": "तारीख़", "Time": "समय", "Room": "कमरा", "Course": "पाठ्यक्रम",
  "Code": "कोड", "Subject": "विषय", "Name": "नाम", "Email": "ईमेल", "Role": "भूमिका", "Department": "विभाग", "Students": "छात्र",
  "Total": "कुल", "Paid": "भुगतान", "Due": "देय", "Present": "उपस्थित", "Absent": "अनुपस्थित", "Pending": "लंबित", "Open": "खुला",
  "Resolved": "सुलझा", "Published": "प्रकाशित", "Type": "प्रकार", "Title": "शीर्षक", "Message": "संदेश", "When": "कब", "To": "प्राप्तकर्ता",
  "Priority": "प्राथमिकता", "Category": "श्रेणी", "Description": "विवरण", "Reason": "कारण", "Purpose": "उद्देश्य", "Reference": "संदर्भ",
  "Issued": "जारी", "Mobile": "मोबाइल", "Relation": "संबंध", "Father": "पिता", "Mother": "माता", "Guardian": "अभिभावक (संरक्षक)",
  "Preparing…": "तैयार हो रहा है…", "Checking…": "जाँच हो रही है…", "Live": "लाइव", "ID": "आईडी", "Roll No.": "रोल नं.", "Roll no.": "रोल नं.",
  "Mon": "सोम", "Tue": "मंगल", "Wed": "बुध", "Thu": "गुरु", "Fri": "शुक्र", "Sat": "शनि", "Sun": "रवि",
  "paid": "भुगतान हो गया", "partial": "आंशिक", "overdue": "बकाया", "Pass": "उत्तीर्ण", "Fail": "अनुत्तीर्ण",
  "All roles": "सभी भूमिकाएँ", "Admins": "प्रशासक", "Parents": "अभिभावक", "missing": "नहीं है", "no phone": "फ़ोन नहीं",
  "Language / भाषा": "भाषा / Language",

  // ---- dashboards (existing)
  "Notice Board": "सूचना पट", "Info At A Glance": "एक नज़र में", "Overall Attendance": "कुल उपस्थिति", "Lectures Present": "उपस्थित कक्षाएँ",
  "Total Lectures": "कुल कक्षाएँ", "Subject-wise attendance": "विषयवार उपस्थिति", "Weekly trend": "साप्ताहिक रुझान", "What it means": "इसका अर्थ",
  "Attended": "उपस्थित रहे", "CGPA": "CGPA", "Subjects graded": "अंकित विषय", "Assignments Submitted": "जमा किए असाइनमेंट",
  "Assessment": "मूल्यांकन", "Score": "अंक", "Assignment": "असाइनमेंट", "Total fee": "कुल शुल्क", "Balance due": "शेष देय",
  "Active students": "सक्रिय छात्र", "Avg. attendance": "औसत उपस्थिति", "Fees collected": "एकत्रित शुल्क", "Courses": "पाठ्यक्रम",
  "Avg. CGPA": "औसत CGPA", "Open grievances": "खुली शिकायतें", "Attendance by department": "विभागवार उपस्थिति",
  "Recent activity": "हाल की गतिविधि", "Fee records": "शुल्क रिकॉर्ड", "Total collected": "कुल एकत्रित", "Overdue accounts": "बकाया खाते",
  "System-wide audit log": "संपूर्ण ऑडिट लॉग", "Risk Insights": "जोखिम विश्लेषण", "No activity yet.": "अभी कोई गतिविधि नहीं।",
  "No notices from your classes yet.": "आपकी कक्षाओं से अभी कोई सूचना नहीं।", "No classes scheduled today.": "आज कोई कक्षा निर्धारित नहीं है।",
  "No attendance has been recorded for your subjects yet.": "आपके विषयों की उपस्थिति अभी दर्ज नहीं हुई है।",
  "No assignments posted for your subjects yet.": "आपके विषयों के लिए अभी कोई असाइनमेंट नहीं है।",
  "No marks have been published yet.": "अभी कोई अंक प्रकाशित नहीं हुए हैं।", "No users match.": "कोई उपयोगकर्ता नहीं मिला।",
  "Add user": "उपयोगकर्ता जोड़ें", "Add course": "पाठ्यक्रम जोड़ें", "Students Taught": "पढ़ाए गए छात्र", "Assignments Posted": "पोस्ट किए असाइनमेंट",
  "Leave Requests Open": "खुले छुट्टी अनुरोध", "My recent actions": "मेरी हाल की गतिविधियाँ", "Mark Attendance": "उपस्थिति दर्ज करें",
  "CGPA · out of 10": "CGPA · 10 में से",

  // ---- exams
  "Exam": "परीक्षा", "Exam timetable": "परीक्षा समय सारणी", "Timetable & hall ticket": "समय सारणी और प्रवेश पत्र", "Results": "परिणाम",
  "Grade card": "ग्रेड कार्ड", "Published results": "प्रकाशित परिणाम", "Download hall ticket": "प्रवेश पत्र डाउनलोड करें",
  "Download grade card": "ग्रेड कार्ड डाउनलोड करें", "Eligibility": "पात्रता", "Eligible": "पात्र", "Not eligible": "अपात्र",
  "Next exam": "अगली परीक्षा", "Upcoming exams": "आगामी परीक्षाएँ", "SGPA": "SGPA", "Marks": "अंक", "Grade": "ग्रेड", "Grade point": "ग्रेड पॉइंट",
  "Result": "परिणाम", "Courses passed": "उत्तीर्ण पाठ्यक्रम", "out of 10 (equal credits)": "10 में से (समान क्रेडिट)",
  "No upcoming exams are scheduled yet.": "अभी कोई आगामी परीक्षा निर्धारित नहीं है।", "No results have been published yet.": "अभी कोई परिणाम प्रकाशित नहीं हुआ है।",
  "Your grade card appears here once exam results are out.": "परिणाम आने पर आपका ग्रेड कार्ड यहाँ दिखेगा।",
  "exam(s) show “Not eligible” because your attendance in that course is below": "परीक्षा(ओं) में “अपात्र” दिख रहा है क्योंकि उस विषय में आपकी उपस्थिति कम है:",
  "Attend classes regularly and contact the exam cell.": "नियमित कक्षाओं में आएँ और परीक्षा विभाग से संपर्क करें।",
  "Loading exams…": "परीक्षाएँ लोड हो रही हैं…", "Loading marks…": "अंक लोड हो रहे हैं…", "Exams for my subjects": "मेरे विषयों की परीक्षाएँ",
  "Enter marks": "अंक दर्ज करें", "View marks": "अंक देखें", "Not started": "शुरू नहीं", "entered": "दर्ज", "Max marks": "अधिकतम अंक",
  "Save draft": "ड्राफ़्ट सहेजें", "Save & publish results": "सहेजें और परिणाम प्रकाशित करें", "Back to exams": "परीक्षाओं पर वापस",
  "Marks saved": "अंक सहेजे गए", "Results published": "परिणाम प्रकाशित हुए", "Marks must be between 0 and": "अंक 0 और इसके बीच होने चाहिए:",
  "Publish results? Students and parents are notified and marks can't be changed afterwards.": "परिणाम प्रकाशित करें? छात्रों और अभिभावकों को सूचना जाएगी और बाद में अंक नहीं बदले जा सकेंगे।",
  "The exam cell hasn't scheduled any exams for your subjects yet.": "परीक्षा विभाग ने अभी आपके विषयों की कोई परीक्षा निर्धारित नहीं की है।",
  "No students are enrolled in this course.": "इस पाठ्यक्रम में कोई छात्र नामांकित नहीं है।",
  "Schedule exam": "परीक्षा निर्धारित करें", "Schedule & notify": "निर्धारित करें और सूचित करें", "Total scheduled": "कुल निर्धारित",
  "Start time": "आरंभ समय", "Duration (minutes)": "अवधि (मिनट)", "Room (e.g. Exam Hall A)": "कमरा (जैसे परीक्षा हॉल A)", "— Course —": "— पाठ्यक्रम —",
  "Pick a course and a date.": "पाठ्यक्रम और तारीख़ चुनें।", "Exam cancelled": "परीक्षा रद्द", "No exams scheduled yet.": "अभी कोई परीक्षा निर्धारित नहीं।",
  "Exam scheduled — students, faculty and parents notified": "परीक्षा निर्धारित — छात्रों, शिक्षकों और अभिभावकों को सूचित किया गया",
  "Mid-Semester Exam": "मध्य-सत्र परीक्षा", "End-Semester Exam": "सत्रांत परीक्षा", "Practical Exam": "प्रायोगिक परीक्षा", "Class Test": "कक्षा परीक्षा",
  "Exam results": "परीक्षा परिणाम", "Sessional marks": "सत्रीय अंक", "Average": "औसत", "Assessments": "मूल्यांकन",

  // ---- QR
  "Check in": "चेक-इन", "Check in to class": "कक्षा में चेक-इन करें", "You're marked present": "आपकी उपस्थिति दर्ज हो गई",
  "You were already checked in": "आप पहले ही चेक-इन कर चुके हैं", "Attendance marked": "उपस्थिति दर्ज", "Check-in failed": "चेक-इन नहीं हुआ",
  "Enter the 6-digit code shown on the screen.": "स्क्रीन पर दिखा 6 अंकों का कोड लिखें।",
  "Scan the QR code on your teacher's screen with your phone camera, or type the 6-digit code:": "शिक्षक की स्क्रीन पर दिख रहे QR कोड को फ़ोन कैमरे से स्कैन करें, या 6 अंकों का कोड लिखें:",
  "That QR code has expired — scan the one on the screen now.": "यह QR कोड पुराना हो गया है — स्क्रीन पर अभी वाला स्कैन करें।",
  "Ask your teacher for the current code, or type it on the Attendance page.": "शिक्षक से अभी का कोड पूछें, या उपस्थिति पेज पर लिखें।",
  "Start QR check-in": "QR चेक-इन शुरू करें", "Pick the class and press Start.": "कक्षा चुनें और शुरू करें दबाएँ।",
  "Show the QR on the projector. It changes every few seconds, so a forwarded photo won't work.": "QR को प्रोजेक्टर पर दिखाएँ। यह हर कुछ सेकंड में बदलता है, इसलिए भेजी गई फ़ोटो काम नहीं करेगी।",
  "Students scan it with their phone camera (or type the 6-digit code). Names tick in live.": "छात्र फ़ोन कैमरे से स्कैन करते हैं (या 6 अंकों का कोड लिखते हैं)। नाम तुरंत टिक होते जाते हैं।",
  "Press Publish — everyone who didn't check in is marked absent.": "प्रकाशित करें दबाएँ — जिन्होंने चेक-इन नहीं किया वे अनुपस्थित माने जाएँगे।",
  "Show this to the class": "इसे कक्षा को दिखाएँ", "Live check-ins": "लाइव चेक-इन", "checked in": "चेक-इन हुए", "Full screen": "पूर्ण स्क्रीन",
  "Exit full screen": "पूर्ण स्क्रीन बंद करें", "Publish attendance": "उपस्थिति प्रकाशित करें", "Publish attendance?": "उपस्थिति प्रकाशित करें?",
  "present — everyone else will be marked absent.": "उपस्थित — बाकी सभी अनुपस्थित माने जाएँगे।", "Attendance published": "उपस्थिति प्रकाशित",
  "present": "उपस्थित", "Cancel this check-in? Nothing will be saved.": "यह चेक-इन रद्द करें? कुछ भी सहेजा नहीं जाएगा।",
  "This check-in has expired. Publish or cancel it.": "यह चेक-इन समाप्त हो गया है। प्रकाशित करें या रद्द करें।",
  "added by you": "आपने जोड़ा", "typed code": "कोड लिखा", "scanned QR": "QR स्कैन किया", "same phone": "एक ही फ़ोन",
  "Checked in from the same phone as another student": "किसी दूसरे छात्र वाले फ़ोन से ही चेक-इन किया गया", "Mark absent": "अनुपस्थित करें", "Mark present": "उपस्थित करें",
  "You have no subjects yet.": "अभी आपके पास कोई विषय नहीं है।", "Ask the admin to assign you a course.": "प्रशासक से पाठ्यक्रम आवंटित करने को कहें।",

  // ---- calendar
  "This month": "इस महीने", "Add event": "कार्यक्रम जोड़ें", "Add to calendar": "कैलेंडर में जोड़ें", "Holiday": "अवकाश", "Event": "कार्यक्रम",
  "Exam week": "परीक्षा सप्ताह", "Deadline": "अंतिम तिथि", "Starts": "शुरू", "Ends (optional)": "समाप्त (वैकल्पिक)", "Details (optional)": "विवरण (वैकल्पिक)",
  "Title (e.g. Diwali break)": "शीर्षक (जैसे दिवाली अवकाश)", "Holidays and exam weeks are announced to everyone automatically.": "अवकाश और परीक्षा सप्ताह की घोषणा सभी को अपने-आप होती है।",
  "Added to the calendar": "कैलेंडर में जोड़ा गया", "Add a title and a date.": "शीर्षक और तारीख़ जोड़ें।", "Nothing scheduled this month.": "इस महीने कुछ निर्धारित नहीं है।",
  "Nothing on this day.": "इस दिन कुछ नहीं है।", "items": "आइटम", "Previous month": "पिछला महीना", "Next month": "अगला महीना",

  // ---- documents
  "Identity card": "पहचान पत्र", "ID card": "पहचान पत्र", "Download ID card": "पहचान पत्र डाउनलोड करें",
  "Print-ready (credit-card size), with a QR code anyone can scan to confirm it's genuine.": "प्रिंट के लिए तैयार (क्रेडिट-कार्ड आकार), QR कोड के साथ जिससे कोई भी असली होने की पुष्टि कर सकता है।",
  "BONAFIDE CERTIFICATE": "बोनाफ़ाइड प्रमाणपत्र", "Bonafide certificate": "बोनाफ़ाइड प्रमाणपत्र", "Generate certificate": "प्रमाणपत्र बनाएँ",
  "Instantly issued with a reference number and a QR verification code.": "संदर्भ संख्या और QR सत्यापन कोड के साथ तुरंत जारी।",
  "Certificate issued": "प्रमाणपत्र जारी", "HALL TICKET": "प्रवेश पत्र", "Hall ticket": "प्रवेश पत्र", "Hall ticket & grade card": "प्रवेश पत्र और ग्रेड कार्ड",
  "Your exam hall ticket and statement of grades.": "आपका परीक्षा प्रवेश पत्र और ग्रेड विवरण।", "Issued documents": "जारी दस्तावेज़", "Document": "दस्तावेज़",
  "Nothing issued yet.": "अभी कुछ जारी नहीं हुआ।", "Other…": "अन्य…", "Opening a bank account": "बैंक खाता खोलना", "Passport application": "पासपोर्ट आवेदन",
  "Scholarship application": "छात्रवृत्ति आवेदन", "Education loan": "शिक्षा ऋण", "Internship / training": "इंटर्नशिप / प्रशिक्षण",
  "Bus / railway concession": "बस / रेलवे रियायत",

  // ---- analytics
  "Whole campus": "पूरा परिसर", "department": "विभाग", "Download PDF report": "PDF रिपोर्ट डाउनलोड करें", "Pass rate": "उत्तीर्ण दर",
  "High-risk students": "उच्च जोखिम वाले छात्र", "Fee collection": "शुल्क संग्रह", "below 75%": "75% से कम",
  "Weekly attendance by department": "विभागवार साप्ताहिक उपस्थिति", "Attendance heat-map": "उपस्थिति हीट-मैप", "By course & week": "पाठ्यक्रम और सप्ताह के अनुसार",
  "By weekday": "दिन के अनुसार", "Department comparison": "विभागों की तुलना", "Course performance": "पाठ्यक्रम प्रदर्शन",
  "Avg. score": "औसत अंक", "High risk": "उच्च जोखिम", "Students needing attention": "ध्यान देने योग्य छात्र", "Health": "स्थिति", "Why": "क्यों",
  "No students are flagged right now.": "अभी कोई छात्र चिन्हित नहीं है।", "No attendance recorded in the last 8 weeks.": "पिछले 8 सप्ताह में कोई उपस्थिति दर्ज नहीं।",
  "no classes": "कक्षा नहीं", "75% requirement": "75% आवश्यकता", "Crunching the numbers…": "आँकड़े तैयार हो रहे हैं…",
  "Heads of department (HOD access to analytics)": "विभागाध्यक्ष (HOD को विश्लेषण की पहुँच)", "Head of department": "विभागाध्यक्ष",
  "— None —": "— कोई नहीं —", "An HOD sees analytics for their own department only.": "विभागाध्यक्ष केवल अपने विभाग का विश्लेषण देखते हैं।",
  "Head of department updated": "विभागाध्यक्ष बदले गए", "Head of department removed": "विभागाध्यक्ष हटाए गए",
  "Low risk": "कम जोखिम", "Medium risk": "मध्यम जोखिम",

  // ---- accreditation
  "Criterion": "मानदंड", "Download full PDF": "पूरी PDF डाउनलोड करें", "Target marks %": "लक्ष्य अंक %", "Level": "स्तर",
  "Data tables for your NAAC SSR / AQAR and NBA SAR, built from live CampusPilot records for": "आपकी NAAC SSR / AQAR और NBA SAR के लिए डेटा तालिकाएँ, लाइव CampusPilot रिकॉर्ड से, वर्ष",
  "Always review figures before submitting.": "जमा करने से पहले हर आँकड़ा जाँच लें।", "Building the report from live records…": "लाइव रिकॉर्ड से रिपोर्ट बन रही है…",
  "No data yet.": "अभी कोई डेटा नहीं।",

  // ---- parents & alerts
  "Alert outbox": "अलर्ट आउटबॉक्स", "Parent accounts": "अभिभावक खाते", "Parents linked": "जुड़े अभिभावक", "Queued": "कतार में", "Failed": "विफल",
  "No phone": "फ़ोन नहीं", "Sent": "भेजे गए", "Logged (demo)": "सहेजे गए (डेमो)", "Send fee reminders": "शुल्क अनुस्मारक भेजें", "Send test": "टेस्ट भेजें",
  "Fee reminders": "शुल्क अनुस्मारक", "students": "छात्र", "parents alerted": "अभिभावकों को अलर्ट", "Test message queued": "टेस्ट संदेश कतार में",
  "Link parent": "अभिभावक जोड़ें", "Unlink": "हटाएँ", "Link a parent to a student": "अभिभावक को छात्र से जोड़ें", "— Student —": "— छात्र —",
  "Parent's full name": "अभिभावक का पूरा नाम", "Parent's email (their login)": "अभिभावक का ईमेल (लॉगिन)", "Mobile for SMS / WhatsApp (+91…)": "SMS / WhatsApp के लिए मोबाइल (+91…)",
  "If this email already has a parent account, the student is added to it (one login for all their children).": "अगर इस ईमेल का अभिभावक खाता पहले से है, तो छात्र उसी में जुड़ जाएगा (सभी बच्चों के लिए एक लॉगिन)।",
  "Name, email and student are required.": "नाम, ईमेल और छात्र आवश्यक हैं।", "Parent account created": "अभिभावक खाता बना", "Linked to the existing parent account": "मौजूदा अभिभावक खाते से जोड़ा गया",
  "No alerts yet. They appear here when attendance, marks or fees change for a student with a linked parent.": "अभी कोई अलर्ट नहीं। जुड़े अभिभावक वाले छात्र की उपस्थिति, अंक या शुल्क बदलने पर यहाँ दिखेंगे।",
  "No parents linked yet. Add them here, or in bulk with Data Import → Parents.": "अभी कोई अभिभावक नहीं जुड़ा। यहाँ जोड़ें, या डेटा आयात → अभिभावक से एक साथ।",
  "messages are saved below but not sent. To send real SMS/WhatsApp, set MESSAGING_PROVIDER in .env (see docs/ALERTS.md).": "संदेश नीचे सहेजे जाते हैं पर भेजे नहीं जाते। असली SMS/WhatsApp के लिए .env में MESSAGING_PROVIDER सेट करें (docs/ALERTS.md देखें)।",
  "connected": "जुड़ा हुआ", "not configured yet: add the keys in .env.": "अभी सेट नहीं: .env में कुंजियाँ जोड़ें।",
  "Low attendance": "कम उपस्थिति", "Fee reminder": "शुल्क अनुस्मारक", "Payment": "भुगतान", "Test": "टेस्ट",
  "logged": "सहेजा गया", "sent": "भेजा गया", "queued": "कतार में", "failed": "विफल", "skipped": "छोड़ा गया",

  // ---- parent portal
  "Live updates about": "लाइव जानकारी:", "Needs attention": "ध्यान दें", "Everything looks on track — attendance, marks and fees are healthy.": "सब ठीक चल रहा है — उपस्थिति, अंक और शुल्क सही हैं।",
  "Fee due": "देय शुल्क", "Fully paid": "पूरा भुगतान", "classes": "कक्षाएँ", "Recent alerts": "हाल के अलर्ट", "No alerts yet.": "अभी कोई अलर्ट नहीं।",
  "You'll get a message here (and by SMS/WhatsApp) if attendance drops or results come out.": "उपस्थिति घटने या परिणाम आने पर आपको यहाँ (और SMS/WhatsApp पर) संदेश मिलेगा।",
  "Subjects below 75%": "75% से कम वाले विषय", "All subjects are at 75% or above.": "सभी विषयों में 75% या अधिक है।", "On track": "ठीक है",
  "Needs": "ज़रूरत:", "more classes in a row to reach 75%": "लगातार कक्षाएँ 75% तक पहुँचने के लिए", "No attendance has been recorded yet.": "अभी कोई उपस्थिति दर्ज नहीं हुई।",
  "due by": "अंतिम तिथि", "Alerts sent to you": "आपको भेजे गए अलर्ट", "Sent by": "माध्यम", "demo": "डेमो", "No notices yet.": "अभी कोई सूचना नहीं।",
  "No student is linked to your account yet.": "आपके खाते से अभी कोई छात्र नहीं जुड़ा है।",
  "Ask the college office to link your child's record to this email.": "कॉलेज कार्यालय से अपने बच्चे का रिकॉर्ड इस ईमेल से जोड़ने को कहें।",
  "your dashboard": "आपका डैशबोर्ड", "Choose child": "बच्चा चुनें",

  // ---- verification
  "Document verification": "दस्तावेज़ सत्यापन", "Genuine": "प्रामाणिक", "Could not verify": "सत्यापन नहीं हो सका", "Go to CampusPilot": "CampusPilot पर जाएँ",

  // ---- auth
  "Admin and parent accounts aren't self-serve — the college office creates those.": "प्रशासक और अभिभावक खाते कॉलेज कार्यालय बनाता है।",
};

function inDays(n) { return CURRENT_LANG === "hi" ? `${n} दिन में` : `in ${n} days`; }

// =====================================================================
//  Feature screens: exams, QR attendance, calendar, documents, analytics,
//  accreditation, parents & alerts, parent portal, verification page.
// =====================================================================
function fmtDate(iso) {
  if (!iso) return "—";
  const d = new Date(`${String(iso).slice(0, 10)}T00:00:00`);
  return isNaN(d) ? iso : d.toLocaleDateString(CURRENT_LANG === "hi" ? "hi-IN" : "en-IN", { day: "numeric", month: "short", year: "numeric" });
}
function fmtTime(hhmm) {
  const [h, m] = String(hhmm || "").split(":").map(Number);
  if (isNaN(h)) return hhmm || "";
  return `${((h + 11) % 12) + 1}:${String(m || 0).padStart(2, "0")} ${h < 12 ? "AM" : "PM"}`;
}
function daysUntil(iso) { return Math.round((new Date(`${iso}T00:00:00`) - new Date(new Date().toDateString())) / 86400000); }
const EXAM_KINDS = [["midsem", "Mid-Semester Exam"], ["endsem", "End-Semester Exam"], ["practical", "Practical Exam"], ["quiz", "Class Test"]];

// ------------------------------------------------------------ student exams
function ExamTimetableTable({ exams, showEligibility }) {
  return (
    <DataTable columns={[
      { key: "date", label: "Date", render: (r) => <><strong>{fmtDate(r.date)}</strong><div className="cp-muted cp-small">{daysUntil(r.date) === 0 ? t("Today") : daysUntil(r.date) > 0 ? inDays(daysUntil(r.date)) : ""}</div></> },
      { key: "course", label: "Course", render: (r) => <>{r.courseCode} — {r.courseName}</> },
      { key: "title", label: "Exam" },
      { key: "time", label: "Time", render: (r) => `${fmtTime(r.startTime)} · ${r.durationMin} min` },
      { key: "room", label: "Room", render: (r) => r.room || "TBA" },
      ...(showEligibility ? [{ key: "eligible", label: "Eligibility", render: (r) => r.eligible
        ? <Badge tone="green">{t("Eligible")}</Badge>
        : <span title={`Attendance ${r.attendancePct}%`}><Badge tone="red">{t("Not eligible")}</Badge> <span className="cp-muted cp-small">{r.attendancePct}%</span></span> }] : []),
    ]} rows={exams} empty="No upcoming exams are scheduled yet." />
  );
}
function ResultsTable({ results }) {
  return (
    <DataTable columns={[
      { key: "course", label: "Course", render: (r) => <>{r.courseCode} — {r.courseName}</> },
      { key: "title", label: "Exam" },
      { key: "date", label: "Date", render: (r) => fmtDate(r.date) },
      { key: "marks", label: "Marks", render: (r) => r.absent ? <Badge tone="red">{t("Absent")}</Badge> : <strong>{r.marks} / {r.maxMarks}</strong> },
      { key: "pct", label: "%", render: (r) => r.absent ? "—" : <Badge tone={r.pct >= 60 ? "green" : r.pct >= 40 ? "amber" : "red"}>{r.pct}%</Badge> },
    ]} rows={results} empty="No results have been published yet." />
  );
}
function GradeCardTable({ gradeCard }) {
  if (!gradeCard || !gradeCard.courses.length) return <EmptyState text="No results have been published yet." hint="Your grade card appears here once exam results are out." />;
  return (
    <>
      <div className="cp-stat-grid">
        <StatCard icon="award" label="SGPA" value={gradeCard.sgpa ? gradeCard.sgpa.toFixed(2) : "—"} sub={t("out of 10 (equal credits)")} />
        <StatCard icon="check" label="Courses passed" value={`${gradeCard.courses.filter((c) => c.result === "Pass").length} / ${gradeCard.courses.length}`} />
      </div>
      <DataTable columns={[
        { key: "code", label: "Code" }, { key: "name", label: "Course" },
        { key: "marks", label: "Marks", render: (r) => `${r.obtained} / ${r.max}` },
        { key: "letter", label: "Grade", render: (r) => <Badge tone={r.gp >= 7 ? "green" : r.gp >= 4 ? "amber" : "red"}>{r.letter}</Badge> },
        { key: "gp", label: "Grade point" },
        { key: "result", label: "Result", render: (r) => <Badge tone={r.result === "Pass" ? "green" : "red"}>{t(r.result)}</Badge> },
      ]} rows={gradeCard.courses} />
    </>
  );
}
function StudentExams({ showToast }) {
  const [data, setData] = useState(null);
  const [tab, setTab] = useState("upcoming");
  const refresh = useCallback(() => { api.exams.mine().then(setData).catch((e) => showToast(e.message, "warn")); }, [showToast]);
  useEffect(() => { refresh(); }, [refresh]);
  useLive(["exams:update"], refresh);
  if (!data) return <SectionLoading label={t("Loading exams…")} />;
  const blocked = data.upcoming.filter((e) => !e.eligible);
  const next = data.upcoming[0];
  return (
    <>
      <div className="cp-stat-grid">
        <StatCard icon="calendar" label="Next exam" value={next ? fmtDate(next.date) : "—"} sub={next ? `${next.courseCode} · ${next.title}` : ""} />
        <StatCard icon="clipboard" label="Upcoming exams" value={data.upcoming.length} />
        <StatCard icon="award" label="SGPA" value={data.gradeCard.sgpa ? data.gradeCard.sgpa.toFixed(2) : "—"} />
      </div>
      {blocked.length > 0 && data.minAttendance > 0 && (
        <div className="cp-callout cp-callout--warn"><Icon name="alert" size={16} />
          <span>{blocked.length} {t("exam(s) show “Not eligible” because your attendance in that course is below")} {data.minAttendance}%. {t("Attend classes regularly and contact the exam cell.")}</span></div>
      )}
      <Tabs tabs={[{ key: "upcoming", label: t("Timetable & hall ticket") }, { key: "results", label: t("Results") }, { key: "grades", label: t("Grade card") }]} active={tab} onChange={setTab} />
      {tab === "upcoming" && (
        <Card title="Exam timetable" actions={<DownloadButton label="Download hall ticket" path="/exams/hall-ticket.pdf" filename="hall-ticket.pdf" onError={(m) => showToast(m, "warn")} />}>
          <ExamTimetableTable exams={data.upcoming} showEligibility />
        </Card>
      )}
      {tab === "results" && <Card title="Published results" actions={<LiveBadge />}><ResultsTable results={data.results} /></Card>}
      {tab === "grades" && (
        <Card title="Grade card" actions={data.gradeCard.courses.length ? <DownloadButton label="Download grade card" path="/exams/grade-card.pdf" filename="grade-card.pdf" onError={(m) => showToast(m, "warn")} /> : null}>
          <GradeCardTable gradeCard={data.gradeCard} />
        </Card>
      )}
    </>
  );
}

// ------------------------------------------------------------- QR check-in
function StudentCheckinCard({ showToast, onDone }) {
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState(null);
  async function submit() {
    if (!/^\d{6}$/.test(code)) return showToast(t("Enter the 6-digit code shown on the screen."), "warn");
    setBusy(true);
    try { const r = await api.qr.checkin({ code }); setResult(r); setCode(""); onDone && onDone(); }
    catch (e) { showToast(e.message, "warn"); }
    setBusy(false);
  }
  return (
    <Card title="Check in to class" actions={<Badge tone="teal">QR</Badge>}>
      {result ? (
        <div className="cp-checkin-ok"><span className="cp-checkin-tick"><Icon name="check" size={22} /></span>
          <div><strong>{result.already ? t("You were already checked in") : t("You're marked present")}</strong><div className="cp-muted">{result.course} · {fmtDate(result.date)}</div></div>
          <Pill tone="ghost" onClick={() => setResult(null)}>{t("Done")}</Pill></div>
      ) : (
        <div className="cp-checkin-row">
          <p className="cp-muted" style={{ margin: 0 }}>{t("Scan the QR code on your teacher's screen with your phone camera, or type the 6-digit code:")}</p>
          <div className="cp-inline-controls">
            <input className="cp-code-input" inputMode="numeric" autoComplete="one-time-code" maxLength={6} placeholder="000000" value={code}
              onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))} onKeyDown={(e) => e.key === "Enter" && submit()} aria-label="6-digit check-in code" />
            <Pill tone="solid" onClick={submit} disabled={busy}><Icon name="check" size={13} /> {busy ? t("Checking…") : t("Check in")}</Pill>
          </div>
        </div>
      )}
    </Card>
  );
}

// Handles /checkin?s=..&t=.. links opened from the phone camera.
const PENDING_CHECKIN_KEY = "cp_pending_checkin";
function capturePendingCheckin() {
  if (typeof window === "undefined" || window.location.pathname !== "/checkin") return;
  const p = new URLSearchParams(window.location.search);
  if (p.get("s") && p.get("t")) {
    try { sessionStorage.setItem(PENDING_CHECKIN_KEY, JSON.stringify({ s: p.get("s"), t: p.get("t"), at: Date.now() })); } catch { /* ignore */ }
  }
  window.history.replaceState(null, "", "/");
}
capturePendingCheckin();
function usePendingCheckin(showToast, onDone) {
  const [result, setResult] = useState(null);
  useEffect(() => {
    let pending = null;
    try { pending = JSON.parse(sessionStorage.getItem(PENDING_CHECKIN_KEY) || "null"); sessionStorage.removeItem(PENDING_CHECKIN_KEY); } catch { /* ignore */ }
    if (!pending) return;
    if (Date.now() - pending.at > 5 * 60 * 1000) { showToast(t("That QR code has expired — scan the one on the screen now."), "warn"); return; }
    api.qr.checkin({ s: pending.s, t: pending.t })
      .then((r) => { setResult({ ok: true, ...r }); onDone && onDone(); })
      .catch((e) => setResult({ ok: false, message: e.message }));
  }, []);
  return [result, () => setResult(null)];
}
function CheckinResultModal({ result, onClose }) {
  return (
    <Modal open={!!result} onClose={onClose} title={result && result.ok ? t("Attendance marked") : t("Check-in failed")}>
      {result && (result.ok ? (
        <div className="cp-checkin-big"><span className="cp-checkin-tick cp-checkin-tick--big"><Icon name="check" size={34} /></span>
          <h3>{result.already ? t("You were already checked in") : t("You're marked present")}</h3><p className="cp-muted">{result.course} · {fmtDate(result.date)}</p></div>
      ) : (
        <div className="cp-checkin-big"><span className="cp-checkin-tick cp-checkin-tick--bad"><Icon name="close" size={30} /></span>
          <h3>{result.message}</h3><p className="cp-muted">{t("Ask your teacher for the current code, or type it on the Attendance page.")}</p></div>
      ))}
    </Modal>
  );
}

// ------------------------------------------------------------- teacher QR
function TeacherQrAttendance({ courses, showToast }) {
  const [courseId, setCourseId] = useState("");
  const [session, setSession] = useState(null);
  const [busy, setBusy] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);
  useEffect(() => { if (!courseId && courses[0]) setCourseId(courses[0].id); }, [courses, courseId]);
  useEffect(() => { api.qr.open().then((open) => { if (open[0]) setSession(open[0]); }).catch(() => {}); }, []);
  const poll = useCallback(() => { if (session && session.id) api.qr.live(session.id).then(setSession).catch(() => {}); }, [session && session.id]);
  useEffect(() => {
    if (!session || !session.id || session.status !== "open") return undefined;
    poll();
    const iv = setInterval(poll, 3000);
    return () => clearInterval(iv);
  }, [session && session.id, session && session.status]);
  useLive(["qr:checkin"], (ev) => { if (session && ev && ev.sessionId === session.id) poll(); });

  async function start() {
    if (!courseId) return;
    setBusy(true);
    try { const s = await api.qr.start(courseId); setSession(s); } catch (e) { showToast(e.message, "warn"); }
    setBusy(false);
  }
  async function publish() {
    if (!window.confirm(`${t("Publish attendance?")} ${session.present}/${session.total} ${t("present — everyone else will be marked absent.")}`)) return;
    setBusy(true);
    try { const r = await api.qr.publish(session.id); showToast(`${t("Attendance published")}: ${r.present}/${r.total} ${t("present")}`); setSession(null); setFullscreen(false); }
    catch (e) { showToast(e.message, "warn"); }
    setBusy(false);
  }
  async function cancel() {
    if (!window.confirm(t("Cancel this check-in? Nothing will be saved."))) return;
    await api.qr.cancel(session.id).catch(() => {}); setSession(null); setFullscreen(false);
  }
  async function toggle(st) {
    try { setSession({ ...(await api.qr.mark(session.id, st.id, !st.present)), qr: session.qr, code: session.code, url: session.url }); poll(); }
    catch (e) { showToast(e.message, "warn"); }
  }

  if (!session) {
    return (
      <Card title="QR attendance">
        <div className="cp-qr-intro">
          <div className="cp-qr-steps">
            <div><span>1</span>{t("Pick the class and press Start.")}</div>
            <div><span>2</span>{t("Show the QR on the projector. It changes every few seconds, so a forwarded photo won't work.")}</div>
            <div><span>3</span>{t("Students scan it with their phone camera (or type the 6-digit code). Names tick in live.")}</div>
            <div><span>4</span>{t("Press Publish — everyone who didn't check in is marked absent.")}</div>
          </div>
          <div className="cp-inline-controls">
            <select className="cp-select" value={courseId} onChange={(e) => setCourseId(e.target.value)} aria-label="Course">
              {courses.map((c) => <option key={c.id} value={c.id}>{c.code} — {c.name}</option>)}
            </select>
            <Pill tone="solid" onClick={start} disabled={busy || !courseId}><Icon name="qr" size={14} /> {t("Start QR check-in")}</Pill>
          </div>
          {!courses.length && <EmptyState text="You have no subjects yet." hint="Ask the admin to assign you a course." />}
        </div>
      </Card>
    );
  }
  const pct = session.total ? Math.round((session.present / session.total) * 100) : 0;
  const qrBlock = (
    <div className="cp-qr-display">
      {session.status === "open" && session.qr ? <QrSvg matrix={session.qr} size={fullscreen ? Math.min(window.innerHeight - 220, 560) : 260} label="Scan to check in" /> :
        <div className="cp-qr-expired">{t("This check-in has expired. Publish or cancel it.")}</div>}
      {session.code && <div className="cp-qr-code" aria-label={`Code ${session.code}`}>{session.code.slice(0, 3)} {session.code.slice(3)}</div>}
      <div className="cp-qr-meta">{session.courseLabel} · {fmtDate(session.date)}</div>
      <div className="cp-qr-count"><strong>{session.present}</strong> / {session.total} {t("checked in")}</div>
      <div className="cp-qr-bar"><span style={{ width: `${pct}%` }} /></div>
    </div>
  );
  return (
    <>
      {fullscreen && (
        <div className="cp-qr-full" onClick={() => setFullscreen(false)} role="dialog" aria-label="QR code full screen">
          <div onClick={(e) => e.stopPropagation()}>{qrBlock}<Pill tone="ghost" onClick={() => setFullscreen(false)}>{t("Exit full screen")}</Pill></div>
        </div>
      )}
      <section className="cp-qr-layout">
        <Card title="Show this to the class" actions={<Pill tone="ghost" onClick={() => setFullscreen(true)}><Icon name="zoomIn" size={13} /> {t("Full screen")}</Pill>}>
          {qrBlock}
          <div className="cp-inline-controls" style={{ justifyContent: "center", marginTop: 14 }}>
            <Pill tone="solid" onClick={publish} disabled={busy}><Icon name="check" size={13} /> {t("Publish attendance")}</Pill>
            <Pill tone="ghost" onClick={cancel}>{t("Cancel")}</Pill>
          </div>
        </Card>
        <Card title="Live check-ins" actions={<LiveBadge />}>
          <div className="cp-qr-list">
            {session.students.map((st) => (
              <div key={st.id} className={"cp-qr-student" + (st.present ? " is-present" : "")}>
                <span className="cp-avatar cp-avatar--sm">{initialsOf(st.name)}</span>
                <div className="cp-row-body"><div className="cp-row-title">{st.name}</div>
                  <div className="cp-row-sub">{st.idLabel}{st.present ? ` · ${st.method === "teacher" ? t("added by you") : st.method === "code" ? t("typed code") : t("scanned QR")}` : ""}
                    {st.sharedDevice ? <span className="cp-flag" title={t("Checked in from the same phone as another student")}> · ⚠ {t("same phone")}</span> : null}</div></div>
                <button type="button" className={"cp-mini-toggle" + (st.present ? " is-on" : "")} onClick={() => toggle(st)} aria-pressed={st.present}
                  title={st.present ? t("Mark absent") : t("Mark present")}>{st.present ? t("Present") : t("Absent")}</button>
              </div>
            ))}
          </div>
        </Card>
      </section>
    </>
  );
}

// ------------------------------------------------------------ teacher exams
function ExamMarksEntry({ exam, onBack, showToast, canEditPublished }) {
  const [data, setData] = useState(null);
  const [rows, setRows] = useState([]);
  const [saving, setSaving] = useState(false);
  useEffect(() => { api.exams.results(exam.id).then((d) => { setData(d); setRows(d.rows.map((r) => ({ ...r, marks: r.marks ?? "" }))); }).catch((e) => showToast(e.message, "warn")); }, [exam.id]);
  if (!data) return <SectionLoading label={t("Loading marks…")} />;
  const locked = data.exam.resultsPublished && !canEditPublished;
  const max = data.exam.maxMarks;
  const bad = rows.some((r) => r.marks !== "" && (Number(r.marks) > max || Number(r.marks) < 0));
  const setRow = (i, patch) => setRows((rs) => rs.map((r, j) => (j === i ? { ...r, ...patch } : r)));
  async function save(publish) {
    if (bad) return showToast(`${t("Marks must be between 0 and")} ${max}`, "warn");
    setSaving(true);
    try {
      await api.exams.saveResults(exam.id, rows.filter((r) => r.absent || r.marks !== "").map((r) => ({ studentId: r.studentId, marks: r.absent ? null : Number(r.marks), absent: r.absent })));
      if (publish) {
        if (!window.confirm(t("Publish results? Students and parents are notified and marks can't be changed afterwards."))) { setSaving(false); return; }
        await api.exams.publish(exam.id); showToast(t("Results published")); onBack();
      } else showToast(t("Marks saved"));
    } catch (e) { showToast(e.message, "warn"); }
    setSaving(false);
  }
  const entered = rows.filter((r) => r.absent || r.marks !== "").length;
  return (
    <Card title={`${data.exam.courseCode} — ${data.exam.title}`} actions={<Pill tone="ghost" onClick={onBack}><Icon name="chevronRight" size={13} /> {t("Back to exams")}</Pill>}>
      <p className="cp-muted">{fmtDate(data.exam.date)} · {t("Max marks")} {max} · {entered}/{rows.length} {t("entered")}{data.exam.resultsPublished ? ` · ${t("Published")}` : ""}</p>
      <DataTable columns={[
        { key: "idLabel", label: "Roll No." }, { key: "name", label: "Student" },
        { key: "marks", label: `${t("Marks")} (/${max})`, render: (r) => {
          const i = rows.indexOf(r);
          return <input className={"cp-marks-input" + (r.marks !== "" && (Number(r.marks) > max || Number(r.marks) < 0) ? " is-bad" : "")} type="number" min="0" max={max} step="0.5"
            value={r.absent ? "" : r.marks} disabled={locked || r.absent} onChange={(e) => setRow(i, { marks: e.target.value })} aria-label={`Marks for ${r.name}`} />;
        } },
        { key: "absent", label: "Absent", render: (r) => <input type="checkbox" checked={r.absent} disabled={locked} onChange={(e) => setRow(rows.indexOf(r), { absent: e.target.checked })} aria-label={`${r.name} absent`} /> },
      ]} rows={rows} empty="No students are enrolled in this course." />
      {!locked && (
        <div className="cp-inline-controls" style={{ marginTop: 14 }}>
          <Pill tone="ghost" onClick={() => save(false)} disabled={saving}>{t("Save draft")}</Pill>
          {!data.exam.resultsPublished && <Pill tone="solid" onClick={() => save(true)} disabled={saving || !entered}><Icon name="send" size={13} /> {t("Save & publish results")}</Pill>}
        </div>
      )}
    </Card>
  );
}
function TeacherExams({ showToast }) {
  const [exams, setExams] = useState(null);
  const [editing, setEditing] = useState(null);
  const refresh = useCallback(() => { api.exams.teacher().then(setExams).catch(() => setExams([])); }, []);
  useEffect(() => { refresh(); }, [refresh]);
  useLive(["exams:update"], refresh);
  if (editing) return <ExamMarksEntry exam={editing} showToast={showToast} onBack={() => { setEditing(null); refresh(); }} />;
  if (!exams) return <SectionLoading label={t("Loading exams…")} />;
  return (
    <Card title="Exams for my subjects" actions={<LiveBadge />}>
      <DataTable columns={[
        { key: "date", label: "Date", render: (r) => fmtDate(r.date) },
        { key: "course", label: "Course", render: (r) => <>{r.courseCode} — {r.courseName}</> },
        { key: "title", label: "Exam" }, { key: "time", label: "Time", render: (r) => fmtTime(r.startTime) },
        { key: "room", label: "Room", render: (r) => r.room || "TBA" },
        { key: "status", label: "Results", render: (r) => r.resultsPublished ? <Badge tone="green">{t("Published")}</Badge> : r.resultsEntered ? <Badge tone="amber">{r.resultsEntered} {t("entered")}</Badge> : <Badge tone="neutral">{t("Not started")}</Badge> },
        { key: "a", label: "", render: (r) => <Pill tone={r.resultsPublished ? "ghost" : "solid"} onClick={() => setEditing(r)}>{r.resultsPublished ? t("View marks") : t("Enter marks")}</Pill> },
      ]} rows={exams} empty="The exam cell hasn't scheduled any exams for your subjects yet." />
    </Card>
  );
}

// -------------------------------------------------------------- admin exams
function AdminExams({ courses, showToast }) {
  const [exams, setExams] = useState(null);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ courseId: "", kind: "endsem", date: "", startTime: "10:00", durationMin: 180, room: "", maxMarks: 100 });
  const refresh = useCallback(() => { api.exams.all().then(setExams).catch(() => setExams([])); }, []);
  useEffect(() => { refresh(); }, [refresh]);
  useLive(["exams:update"], refresh);
  async function create() {
    if (!form.courseId || !form.date) return showToast(t("Pick a course and a date."), "warn");
    try { await api.exams.create({ ...form, durationMin: Number(form.durationMin), maxMarks: Number(form.maxMarks), room: form.room || null }); showToast(t("Exam scheduled — students, faculty and parents notified")); setOpen(false); refresh(); }
    catch (e) { showToast(e.message, "warn"); }
  }
  async function remove(ex) {
    if (!window.confirm(`${t("Cancel")} ${ex.courseCode} ${ex.title}?`)) return;
    try { await api.exams.remove(ex.id); showToast(t("Exam cancelled")); refresh(); } catch (e) { showToast(e.message, "warn"); }
  }
  if (editing) return <ExamMarksEntry exam={editing} canEditPublished showToast={showToast} onBack={() => { setEditing(null); refresh(); }} />;
  const upcoming = (exams || []).filter((e) => daysUntil(e.date) >= 0).length;
  const published = (exams || []).filter((e) => e.resultsPublished).length;
  return (
    <>
      <div className="cp-stat-grid">
        <StatCard icon="calendar" label="Upcoming exams" value={upcoming} />
        <StatCard icon="check" label="Results published" value={published} />
        <StatCard icon="clipboard" label="Total scheduled" value={(exams || []).length} />
      </div>
      <Card title="Exam timetable" actions={<Pill tone="solid" onClick={() => setOpen(true)}><Icon name="plus" size={14} /> {t("Schedule exam")}</Pill>}>
        {!exams ? <SectionLoading /> : (
          <DataTable columns={[
            { key: "date", label: "Date", render: (r) => fmtDate(r.date) },
            { key: "course", label: "Course", render: (r) => <>{r.courseCode} — {r.courseName}</> },
            { key: "title", label: "Exam" }, { key: "time", label: "Time", render: (r) => `${fmtTime(r.startTime)} · ${r.durationMin} min` },
            { key: "room", label: "Room", render: (r) => r.room || "TBA" },
            { key: "status", label: "Results", render: (r) => r.resultsPublished ? <Badge tone="green">{t("Published")}</Badge> : <Badge tone="neutral">{r.resultsEntered} {t("entered")}</Badge> },
            { key: "a", label: "", render: (r) => <div className="cp-inline-controls"><Pill tone="ghost" onClick={() => setEditing(r)}>{t("Marks")}</Pill>{!r.resultsPublished && <Pill tone="ghost" onClick={() => remove(r)}>{t("Cancel")}</Pill>}</div> },
          ]} rows={exams} empty="No exams scheduled yet." />
        )}
      </Card>
      <Modal open={open} onClose={() => setOpen(false)} title={t("Schedule exam")}>
        <div className="cp-form-grid">
          <select value={form.courseId} onChange={(e) => setForm({ ...form, courseId: e.target.value })} aria-label="Course">
            <option value="">{t("— Course —")}</option>{courses.map((c) => <option key={c.id} value={c.id}>{c.code} — {c.name}</option>)}
          </select>
          <select value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })} aria-label="Exam type">
            {EXAM_KINDS.map(([k, l]) => <option key={k} value={k}>{t(l)}</option>)}
          </select>
          <label className="cp-field-label">{t("Date")}<input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></label>
          <label className="cp-field-label">{t("Start time")}<input type="time" value={form.startTime} onChange={(e) => setForm({ ...form, startTime: e.target.value })} /></label>
          <label className="cp-field-label">{t("Duration (minutes)")}<input type="number" min="15" max="480" value={form.durationMin} onChange={(e) => setForm({ ...form, durationMin: e.target.value })} /></label>
          <label className="cp-field-label">{t("Max marks")}<input type="number" min="1" max="1000" value={form.maxMarks} onChange={(e) => setForm({ ...form, maxMarks: e.target.value })} /></label>
          <input placeholder={t("Room (e.g. Exam Hall A)")} maxLength={60} value={form.room} onChange={(e) => setForm({ ...form, room: e.target.value })} />
          <button type="button" className="cp-btn-accent" onClick={create}>{t("Schedule & notify")}</button>
        </div>
      </Modal>
    </>
  );
}

// ------------------------------------------------------------------ calendar
const CAL_KIND = { holiday: ["Holiday", "coral"], event: ["Event", "teal"], "exam-week": ["Exam week", "navy"], exam: ["Exam", "navy"], deadline: ["Deadline", "yellow"] };
function AcademicCalendar({ studentId, isAdmin, showToast }) {
  const [month, setMonth] = useState(() => new Date().toISOString().slice(0, 7));
  const [items, setItems] = useState(null);
  const [selected, setSelected] = useState(null);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ title: "", date: "", endDate: "", kind: "event", description: "" });
  const refresh = useCallback(() => { api.calendar.month(month, studentId).then((d) => setItems(d.items)).catch(() => setItems([])); }, [month, studentId]);
  useEffect(() => { setItems(null); refresh(); }, [refresh]);
  useLive(["exams:update"], refresh);
  const [y, m] = month.split("-").map(Number);
  const first = new Date(y, m - 1, 1);
  const days = new Date(y, m, 0).getDate();
  const lead = (first.getDay() + 6) % 7; // Monday first
  const byDay = {};
  (items || []).forEach((it) => {
    const s = new Date(`${it.date}T00:00:00`), e = new Date(`${it.endDate || it.date}T00:00:00`);
    for (let d = new Date(s); d <= e; d.setDate(d.getDate() + 1)) {
      if (d.getFullYear() === y && d.getMonth() === m - 1) (byDay[d.getDate()] = byDay[d.getDate()] || []).push(it);
    }
  });
  const shift = (k) => { const d = new Date(y, m - 1 + k, 1); setMonth(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`); setSelected(null); };
  const today = new Date();
  const label = first.toLocaleDateString(CURRENT_LANG === "hi" ? "hi-IN" : "en-IN", { month: "long", year: "numeric" });
  async function add() {
    if (!form.title.trim() || !form.date) return showToast(t("Add a title and a date."), "warn");
    try { await api.calendar.add({ ...form, endDate: form.endDate || null, description: form.description || null }); setOpen(false); setForm({ title: "", date: "", endDate: "", kind: "event", description: "" }); showToast(t("Added to the calendar")); refresh(); }
    catch (e) { showToast(e.message, "warn"); }
  }
  async function remove(it) {
    if (!window.confirm(`${t("Remove")} “${it.title}”?`)) return;
    try { await api.calendar.remove(it.id); refresh(); } catch (e) { showToast(e.message, "warn"); }
  }
  const list = selected ? byDay[selected] || [] : (items || []);
  return (
    <section className="cp-cal-layout">
      <Card title={label} actions={
        <div className="cp-inline-controls">
          <button type="button" className="cp-icon-btn cp-cal-prev" onClick={() => shift(-1)} aria-label="Previous month"><Icon name="chevronRight" size={15} /></button>
          <Pill tone="ghost" onClick={() => { setMonth(new Date().toISOString().slice(0, 7)); setSelected(null); }}>{t("Today")}</Pill>
          <button type="button" className="cp-icon-btn" onClick={() => shift(1)} aria-label="Next month"><Icon name="chevronRight" size={15} /></button>
          {isAdmin && <Pill tone="solid" onClick={() => setOpen(true)}><Icon name="plus" size={13} /> {t("Add event")}</Pill>}
        </div>}>
        <div className="cp-cal" role="grid" aria-label={label}>
          {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((d) => <div key={d} className="cp-cal-head">{t(d)}</div>)}
          {Array.from({ length: lead }).map((_, i) => <div key={`b${i}`} className="cp-cal-cell is-blank" />)}
          {Array.from({ length: days }).map((_, i) => {
            const d = i + 1, evs = byDay[d] || [];
            const isToday = today.getFullYear() === y && today.getMonth() === m - 1 && today.getDate() === d;
            const holiday = evs.some((e) => e.kind === "holiday");
            return (
              <button type="button" key={d} className={"cp-cal-cell" + (isToday ? " is-today" : "") + (selected === d ? " is-selected" : "") + (holiday ? " is-holiday" : "")}
                onClick={() => setSelected(selected === d ? null : d)} aria-label={`${d} ${label}: ${evs.length} ${t("items")}`}>
                <span className="cp-cal-num">{d}</span>
                <span className="cp-cal-dots">{evs.slice(0, 3).map((e) => <i key={e.id + d} className={`cp-dot cp-dot--${(CAL_KIND[e.kind] || CAL_KIND.event)[1]}`} />)}</span>
                <span className="cp-cal-first">{evs[0] ? evs[0].title : ""}</span>
              </button>
            );
          })}
        </div>
        <div className="cp-cal-legend">{Object.entries(CAL_KIND).filter(([k]) => k !== "exam-week").map(([k, [l, tone]]) => <span key={k}><i className={`cp-dot cp-dot--${tone}`} />{t(l)}</span>)}</div>
      </Card>
      <Card title={selected ? `${selected} ${label}` : t("This month")}>
        {items === null ? <SectionLoading /> : list.length ? (
          <div className="cp-cal-list">
            {list.map((it) => (
              <div key={it.id} className="cp-cal-item">
                <span className={`cp-cal-tag cp-cal-tag--${(CAL_KIND[it.kind] || CAL_KIND.event)[1]}`}>{t((CAL_KIND[it.kind] || CAL_KIND.event)[0])}</span>
                <div className="cp-row-body"><div className="cp-row-title">{it.title}</div>
                  <div className="cp-row-sub">{fmtDate(it.date)}{it.endDate && it.endDate !== it.date ? ` – ${fmtDate(it.endDate)}` : ""}{it.description ? ` · ${it.description}` : ""}</div></div>
                {isAdmin && it.source === "event" && <button type="button" className="cp-icon-btn" onClick={() => remove(it)} aria-label={`Remove ${it.title}`}><Icon name="close" size={13} /></button>}
              </div>
            ))}
          </div>
        ) : <EmptyState art="calendar" text={selected ? "Nothing on this day." : "Nothing scheduled this month."} />}
      </Card>
      <Modal open={open} onClose={() => setOpen(false)} title={t("Add to calendar")}>
        <div className="cp-form-grid">
          <input placeholder={t("Title (e.g. Diwali break)")} maxLength={150} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          <select value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })} aria-label="Type">
            <option value="event">{t("Event")}</option><option value="holiday">{t("Holiday")}</option><option value="exam-week">{t("Exam week")}</option><option value="deadline">{t("Deadline")}</option>
          </select>
          <label className="cp-field-label">{t("Starts")}<input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></label>
          <label className="cp-field-label">{t("Ends (optional)")}<input type="date" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} /></label>
          <textarea rows={2} maxLength={500} placeholder={t("Details (optional)")} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          <p className="cp-muted" style={{ margin: 0 }}>{t("Holidays and exam weeks are announced to everyone automatically.")}</p>
          <button type="button" className="cp-btn-accent" onClick={add}>{t("Add")}</button>
        </div>
      </Modal>
    </section>
  );
}

// ------------------------------------------------------------------ documents
const BONAFIDE_PURPOSES = ["Opening a bank account", "Passport application", "Scholarship application", "Education loan", "Internship / training", "Bus / railway concession"];
function MyDocuments({ user, showToast }) {
  const [docs, setDocs] = useState([]);
  const [purpose, setPurpose] = useState(BONAFIDE_PURPOSES[0]);
  const [custom, setCustom] = useState("");
  const refresh = useCallback(() => { api.docs.mine().then(setDocs).catch(() => {}); }, []);
  useEffect(() => { refresh(); }, [refresh]);
  const isStudent = user.role === "student";
  const finalPurpose = purpose === "__other" ? custom.trim() : purpose;
  return (
    <>
      <section className="cp-doc-grid">
        <div className="cp-doc-card">
          <div className="cp-doc-preview cp-doc-preview--id">
            <div className="cp-idc-band">{t("Identity card")}</div>
            <div className="cp-idc-body"><span className="cp-idc-photo">{initialsOf(user.name)}</span>
              <div><strong>{user.name}</strong><div>{user.idLabel || "—"}</div><div>{user.department || ""}</div></div></div>
          </div>
          <h4>{t("ID card")}</h4>
          <p className="cp-muted">{t("Print-ready (credit-card size), with a QR code anyone can scan to confirm it's genuine.")}</p>
          <DownloadButton label="Download ID card" path="/documents/id-card.pdf" filename={`id-card-${user.idLabel || "me"}.pdf`} onError={(m) => showToast(m, "warn")} onDone={refresh} />
        </div>
        {isStudent && (
          <div className="cp-doc-card">
            <div className="cp-doc-preview"><div className="cp-doc-lines"><b>{t("BONAFIDE CERTIFICATE")}</b><i /><i /><i /><i className="short" /></div></div>
            <h4>{t("Bonafide certificate")}</h4>
            <p className="cp-muted">{t("Instantly issued with a reference number and a QR verification code.")}</p>
            <select className="cp-select" value={purpose} onChange={(e) => setPurpose(e.target.value)} aria-label="Purpose">
              {BONAFIDE_PURPOSES.map((p) => <option key={p} value={p}>{t(p)}</option>)}<option value="__other">{t("Other…")}</option>
            </select>
            {purpose === "__other" && <input className="cp-search-input" maxLength={120} placeholder={t("Purpose")} value={custom} onChange={(e) => setCustom(e.target.value)} />}
            {finalPurpose.length >= 3
              ? <DownloadButton label="Generate certificate" path="/documents/bonafide" method="POST" body={{ purpose: finalPurpose }} filename="bonafide-certificate.pdf" onError={(m) => showToast(m, "warn")} onDone={() => { refresh(); showToast(t("Certificate issued")); }} />
              : <Pill tone="solid" disabled>{t("Generate certificate")}</Pill>}
          </div>
        )}
        {isStudent && (
          <div className="cp-doc-card">
            <div className="cp-doc-preview"><div className="cp-doc-lines"><b>{t("HALL TICKET")}</b><i /><i className="short" /><i /><i /></div></div>
            <h4>{t("Hall ticket & grade card")}</h4>
            <p className="cp-muted">{t("Your exam hall ticket and statement of grades.")}</p>
            <div className="cp-inline-controls">
              <DownloadButton label="Hall ticket" path="/exams/hall-ticket.pdf" filename="hall-ticket.pdf" onError={(m) => showToast(m, "warn")} />
              <DownloadButton tone="ghost" label="Grade card" path="/exams/grade-card.pdf" filename="grade-card.pdf" onError={(m) => showToast(m, "warn")} />
            </div>
          </div>
        )}
      </section>
      <Card title="Issued documents">
        <DataTable columns={[
          { key: "kind", label: "Document", render: (r) => t({ "id-card": "ID card", bonafide: "Bonafide certificate", "hall-ticket": "Hall ticket" }[r.kind] || r.kind) },
          { key: "ref", label: "Reference", render: (r) => r.ref || "—" }, { key: "purpose", label: "Purpose", render: (r) => r.purpose || "—" },
          { key: "ts", label: "Issued", render: (r) => timeAgo(r.ts) },
        ]} rows={docs} empty="Nothing issued yet." />
      </Card>
    </>
  );
}

// ------------------------------------------------------------------ analytics
function AnalyticsDashboard({ isAdmin, showToast }) {
  const [dept, setDept] = useState("");
  const [data, setData] = useState(null);
  const [heatMode, setHeatMode] = useState("course");
  const refresh = useCallback(() => { api.insights.analytics(dept).then(setData).catch((e) => showToast(e.message, "warn")); }, [dept, showToast]);
  useEffect(() => { setData(null); refresh(); }, [refresh]);
  useLive(["attendance:update", "grades:update", "fees:update", "exams:update"], refresh);
  if (!data) return <SectionLoading label={t("Crunching the numbers…")} />;
  const k = data.kpis;
  const fname = `analytics-${(dept || data.scope || "campus").toString().toLowerCase().replace(/[^a-z0-9]+/g, "-")}.pdf`;
  return (
    <>
      <div className="cp-toolbar">
        {isAdmin ? (
          <select className="cp-select" value={dept} onChange={(e) => setDept(e.target.value)} aria-label="Department">
            <option value="">{t("Whole campus")}</option>{data.deptOptions.map((d) => <option key={d} value={d}>{d}</option>)}
          </select>
        ) : <Badge tone="navy">{data.scope} {t("department")}</Badge>}
        <LiveBadge />
        <span style={{ flex: 1 }} />
        <DownloadButton label="Download PDF report" path={`/analytics/report.pdf${dept ? `?dept=${encodeURIComponent(dept)}` : ""}`} filename={fname} onError={(m) => showToast(m, "warn")} />
      </div>
      <div className="cp-stat-grid cp-stat-grid--5">
        <StatCard icon="users" label="Students" value={k.students} />
        <StatCard icon="target" label="Avg. attendance" value={`${k.avgAttendance}%`} sub={`${k.below75} ${t("below 75%")}`} />
        <StatCard icon="award" label="Pass rate" value={`${k.passRate}%`} />
        <StatCard icon="alert" label="High-risk students" value={k.atRisk} />
        <StatCard icon="wallet" label="Fee collection" value={`${k.feeCollectedPct}%`} />
      </div>
      {data.trend.length > 0 && <Card title="Weekly attendance by department"><MultiLineChart labels={data.weeks} series={data.trend} /></Card>}
      <Card title="Attendance heat-map">
        <Tabs tabs={[{ key: "course", label: "By course & week" }, { key: "weekday", label: "By weekday" }]} active={heatMode} onChange={setHeatMode} />
        {heatMode === "course"
          ? (data.heatmap.length ? <Heatmap rows={data.heatmap} cols={data.weeks} rowTitle="Course" /> : <EmptyState text="No attendance recorded in the last 8 weeks." />)
          : (data.weekdayHeatmap.length ? <Heatmap rows={data.weekdayHeatmap} cols={data.weekdayDays.map(t)} rowTitle="Department" /> : <EmptyState text="No attendance recorded in the last 8 weeks." />)}
      </Card>
      <section className="cp-panelgrid">
        <Card wide title="Department comparison">
          <DataTable columns={[
            { key: "dept", label: "Department" }, { key: "students", label: "Students" },
            { key: "attendance", label: "Attendance", render: (r) => <Badge tone={r.attendance >= 75 ? "green" : "red"}>{r.attendance}%</Badge> },
            { key: "avgScore", label: "Avg. score" }, { key: "passRate", label: "Pass rate", render: (r) => `${r.passRate}%` },
            { key: "atRisk", label: "High risk", render: (r) => r.atRisk ? <Badge tone="red">{r.atRisk}</Badge> : "0" },
            { key: "feeCollectedPct", label: "Fees", render: (r) => `${r.feeCollectedPct}%` },
          ]} rows={data.departments} />
        </Card>
        <Card title="Attendance by department"><ChartBarRow data={data.departments.map((d) => ({ label: d.dept.split(" ")[0], value: d.attendance }))} /></Card>
      </section>
      <Card title="Course performance">
        <SortableTable defaultSortKey="attendance" defaultSortDir="asc" columns={[
          { key: "code", label: "Code", sortable: true }, { key: "name", label: "Course" }, { key: "faculty", label: "Faculty" },
          { key: "students", label: "Students", sortable: true },
          { key: "attendance", label: "Attendance", sortable: true, render: (r) => <Badge tone={r.attendance >= 75 ? "green" : "red"}>{r.attendance}%</Badge> },
          { key: "avgScore", label: "Avg. score", sortable: true }, { key: "passRate", label: "Pass rate", sortable: true, render: (r) => `${r.passRate}%` },
        ]} rows={data.courses} />
      </Card>
      <Card title="Students needing attention" actions={<Badge tone="red">{data.atRiskStudents.length}</Badge>}>
        <SortableTable defaultSortKey="healthScore" defaultSortDir="asc" columns={[
          { key: "name", label: "Student", sortable: true }, { key: "idLabel", label: "Roll No." }, { key: "department", label: "Department" },
          { key: "attendancePct", label: "Attendance", sortable: true, render: (r) => r.attendancePct === null ? "—" : `${r.attendancePct}%` },
          { key: "avgScore", label: "Avg. score", sortable: true, render: (r) => r.avgScore ?? "—" },
          { key: "healthScore", label: "Health", sortable: true, render: (r) => <RiskBadge level={r.riskLevel} /> },
          { key: "reasons", label: "Why", render: (r) => <span className="cp-small">{r.reasons.join(" · ")}</span> },
        ]} rows={data.atRiskStudents} empty="No students are flagged right now." />
      </Card>
      {isAdmin && <DepartmentHeads showToast={showToast} />}
    </>
  );
}
function DepartmentHeads({ showToast }) {
  const [rows, setRows] = useState([]);
  const [teachers, setTeachers] = useState([]);
  const refresh = useCallback(() => { api.insights.heads().then(setRows).catch(() => {}); }, []);
  useEffect(() => { refresh(); api.admin.listUsers({ role: "teacher" }).then(setTeachers).catch(() => {}); }, [refresh]);
  async function change(dept, userId) {
    try { await api.insights.setHead(dept, userId); showToast(userId ? t("Head of department updated") : t("Head of department removed")); refresh(); }
    catch (e) { showToast(e.message, "warn"); }
  }
  return (
    <Card title="Heads of department (HOD access to analytics)">
      <DataTable columns={[
        { key: "dept", label: "Department" },
        { key: "head", label: "Head of department", render: (r) => (
          <select className="cp-select" value={r.userId || ""} onChange={(e) => change(r.dept, e.target.value)} aria-label={`HOD for ${r.dept}`}>
            <option value="">{t("— None —")}</option>
            {teachers.filter((tt) => tt.status === "active").map((tt) => <option key={tt.id} value={tt.id}>{tt.name}{tt.department && tt.department !== r.dept ? ` (${tt.department})` : ""}</option>)}
          </select>) },
      ]} rows={rows} />
      <p className="cp-muted cp-small">{t("An HOD sees analytics for their own department only.")}</p>
    </Card>
  );
}

// -------------------------------------------------------------- accreditation
function Accreditation({ showToast }) {
  const [target, setTarget] = useState(60);
  const [rep, setRep] = useState(null);
  const [open, setOpen] = useState("c2");
  useEffect(() => { setRep(null); api.insights.accreditation(target).then(setRep).catch((e) => showToast(e.message, "warn")); }, [target, showToast]);
  if (!rep) return <SectionLoading label={t("Building the report from live records…")} />;
  const sec = rep.sections.find((s) => s.key === open) || rep.sections[0];
  return (
    <>
      <div className="cp-callout"><Icon name="shield" size={16} />
        <span>{t("Data tables for your NAAC SSR / AQAR and NBA SAR, built from live CampusPilot records for")} {rep.academicYear}. {t("Always review figures before submitting.")}</span></div>
      <div className="cp-toolbar">
        <Tabs tabs={rep.sections.map((s) => ({ key: s.key, label: s.key === "nba" ? "NBA" : s.title.split("—")[0].replace("Criterion", t("Criterion")).trim() }))} active={open} onChange={setOpen} />
        <span style={{ flex: 1 }} />
        <DownloadButton label="Download full PDF" path={`/admin/accreditation/report.pdf?target=${target}`} filename={`accreditation-data-${rep.academicYear}.pdf`} onError={(m) => showToast(m, "warn")} />
      </div>
      <h3 className="cp-section-title">{sec.title}</h3>
      {sec.note && <p className="cp-muted">{sec.note}</p>}
      {sec.key === "nba" && (
        <div className="cp-inline-controls" style={{ marginBottom: 10 }}>
          <label className="cp-field-label cp-field-label--inline">{t("Target marks %")}
            <select className="cp-select" value={target} onChange={(e) => setTarget(Number(e.target.value))}>{[50, 55, 60, 65, 70].map((v) => <option key={v} value={v}>{v}%</option>)}</select></label>
        </div>
      )}
      {sec.tables.map((tb) => (
        <Card key={tb.key} title={tb.title} actions={<Pill tone="ghost" onClick={() => downloadCsv(`${sec.key}-${tb.key}.csv`, tb.columns, tb.rows)}><Icon name="download" size={13} /> CSV</Pill>}>
          <DataTable columns={tb.columns.map((c, i) => ({ key: String(i), label: c, render: (r) => (sec.key === "nba" && i === 3 ? <Badge tone={r[i] >= 2 ? "green" : r[i] === 1 ? "amber" : "red"}>{`${t("Level")} ${r[i]}`}</Badge> : r[i]) }))}
            rows={tb.rows.map((r, i) => Object.assign([...r], { id: `${tb.key}${i}` }))} empty="No data yet." />
        </Card>
      ))}
    </>
  );
}

// --------------------------------------------------------- parents & alerts
const KIND_LABEL = { low_attendance: "Low attendance", absent: "Absent", fee_due: "Fee reminder", fee_paid: "Payment", results: "Results", exam: "Exam", test: "Test" };
function stripOrg(body) { return String(body || "").replace(/^[^:]{3,80}:\s+/, ""); }
const MSG_TONE = { logged: "teal", sent: "green", queued: "amber", failed: "red", skipped: "neutral" };
function AdminParentsAlerts({ showToast, onSecret }) {
  const [tab, setTab] = useState("outbox");
  const [links, setLinks] = useState([]);
  const [box, setBox] = useState(null);
  const [students, setStudents] = useState([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", phone: "", studentId: "", relation: "Father" });
  const [testPhone, setTestPhone] = useState("");
  const refresh = useCallback(() => { api.alerts.parents().then(setLinks).catch(() => {}); api.alerts.messages().then(setBox).catch(() => {}); }, []);
  useEffect(() => { refresh(); api.admin.listUsers({ role: "student" }).then(setStudents).catch(() => {}); }, [refresh]);
  useEffect(() => { const iv = setInterval(() => api.alerts.messages().then(setBox).catch(() => {}), 6000); return () => clearInterval(iv); }, []);
  async function add() {
    if (!form.name.trim() || !form.email.trim() || !form.studentId) return showToast(t("Name, email and student are required."), "warn");
    try {
      const r = await api.alerts.addParent(form);
      setOpen(false); setForm({ name: "", email: "", phone: "", studentId: "", relation: "Father" }); refresh();
      if (r.tempPassword) onSecret({ title: `${t("Parent account created")}: ${form.name}`, lines: [{ email: r.email, tempPassword: r.tempPassword }] });
      else showToast(t("Linked to the existing parent account"));
    } catch (e) { showToast(e.message, "warn"); }
  }
  async function unlink(l) {
    if (!window.confirm(`${t("Unlink")} ${l.parent.name} ↔ ${l.student.name}?`)) return;
    try { await api.alerts.unlink(l.linkId); refresh(); } catch (e) { showToast(e.message, "warn"); }
  }
  async function reminders() {
    try { const r = await api.alerts.feeReminders(); showToast(`${t("Fee reminders")}: ${r.students} ${t("students")}, ${r.parentsAlerted} ${t("parents alerted")}`); refresh(); }
    catch (e) { showToast(e.message, "warn"); }
  }
  async function test() {
    try { await api.alerts.test(testPhone); showToast(t("Test message queued")); setTestPhone(""); refresh(); } catch (e) { showToast(e.message, "warn"); }
  }
  const prov = box && box.provider;
  const c = (box && box.counts) || {};
  return (
    <>
      {prov && (
        <div className={"cp-callout" + (prov.ready ? "" : " cp-callout--warn")}><Icon name={prov.ready ? "send" : "alert"} size={16} />
          <span><strong>{prov.label}</strong>{prov.provider === "log"
            ? ` — ${t("messages are saved below but not sent. To send real SMS/WhatsApp, set MESSAGING_PROVIDER in .env (see docs/ALERTS.md).")}`
            : prov.ready ? ` — ${t("connected")}` : ` — ${t("not configured yet: add the keys in .env.")}`}</span></div>
      )}
      <div className="cp-stat-grid cp-stat-grid--5">
        <StatCard icon="users" label="Parents linked" value={new Set(links.map((l) => l.parent.id)).size} />
        <StatCard icon="send" label={prov && prov.provider === "log" ? "Logged (demo)" : "Sent"} value={(c.sent || 0) + (c.logged || 0)} />
        <StatCard icon="clock" label="Queued" value={c.queued || 0} />
        <StatCard icon="alert" label="Failed" value={c.failed || 0} />
        <StatCard icon="minus" label="No phone" value={c.skipped || 0} />
      </div>
      <Tabs tabs={[{ key: "outbox", label: t("Alert outbox") }, { key: "parents", label: t("Parents") }]} active={tab} onChange={setTab} />
      {tab === "outbox" && (
        <Card title="Alert outbox" actions={<div className="cp-inline-controls">
          <Pill tone="solid" onClick={reminders}><Icon name="rupee" size={13} /> {t("Send fee reminders")}</Pill>
          <input className="cp-search-input cp-search-input--sm" placeholder="+91 98765 43210" value={testPhone} onChange={(e) => setTestPhone(e.target.value)} aria-label="Test phone number" />
          <Pill tone="ghost" onClick={test} disabled={!testPhone.trim()}>{t("Send test")}</Pill></div>}>
          {!box ? <SectionLoading /> : (
            <DataTable columns={[
              { key: "ts", label: "When", render: (r) => timeAgo(r.ts) },
              { key: "toName", label: "To", render: (r) => <>{r.toName}<div className="cp-muted cp-small">{r.phone || t("no phone")} · {r.channel}</div></> },
              { key: "kind", label: "Type", render: (r) => <Badge tone="neutral">{t(KIND_LABEL[r.kind] || r.kind)}</Badge> },
              { key: "body", label: "Message", render: (r) => <span className="cp-small">{r.body}</span> },
              { key: "status", label: "Status", render: (r) => <span title={r.error || ""}><Badge tone={MSG_TONE[r.status] || "neutral"}>{t(r.status)}</Badge></span> },
              { key: "a", label: "", render: (r) => (r.status === "failed" ? <Pill tone="ghost" onClick={() => api.alerts.retry(r.id).then(refresh)}>{t("Retry")}</Pill> : null) },
            ]} rows={box.messages} empty="No alerts yet. They appear here when attendance, marks or fees change for a student with a linked parent." />
          )}
        </Card>
      )}
      {tab === "parents" && (
        <Card title="Parent accounts" actions={<Pill tone="solid" onClick={() => setOpen(true)}><Icon name="plus" size={14} /> {t("Link parent")}</Pill>}>
          <DataTable columns={[
            { key: "student", label: "Student", render: (r) => <>{r.student.name}<div className="cp-muted cp-small">{r.student.idLabel}</div></> },
            { key: "parent", label: "Parent", render: (r) => <>{r.parent.name} <Badge tone="neutral">{t(r.relation)}</Badge><div className="cp-muted cp-small">{r.parent.email}</div></> },
            { key: "phone", label: "Mobile", render: (r) => r.parent.phone || <Badge tone="amber">{t("missing")}</Badge> },
            { key: "a", label: "", render: (r) => <Pill tone="ghost" onClick={() => unlink(r)}>{t("Unlink")}</Pill> },
          ]} rows={links} empty="No parents linked yet. Add them here, or in bulk with Data Import → Parents." />
        </Card>
      )}
      <Modal open={open} onClose={() => setOpen(false)} title={t("Link a parent to a student")}>
        <div className="cp-form-grid">
          <select value={form.studentId} onChange={(e) => setForm({ ...form, studentId: e.target.value })} aria-label="Student">
            <option value="">{t("— Student —")}</option>{students.map((s) => <option key={s.id} value={s.id}>{s.name} ({s.idLabel})</option>)}
          </select>
          <input placeholder={t("Parent's full name")} maxLength={150} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <input placeholder={t("Parent's email (their login)")} type="email" maxLength={254} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          <input placeholder={t("Mobile for SMS / WhatsApp (+91…)")} maxLength={20} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          <select value={form.relation} onChange={(e) => setForm({ ...form, relation: e.target.value })} aria-label="Relation">
            {["Father", "Mother", "Guardian"].map((r) => <option key={r} value={r}>{t(r)}</option>)}
          </select>
          <p className="cp-muted" style={{ margin: 0 }}>{t("If this email already has a parent account, the student is added to it (one login for all their children).")}</p>
          <button type="button" className="cp-btn-accent" onClick={add}>{t("Link parent")}</button>
        </div>
      </Modal>
    </>
  );
}

// ================================================================ parent app
const PARENT_NAV = [
  { key: "overview", label: "Dashboard", icon: "grid" },
  { key: "attendance", label: "Attendance", icon: "target" },
  { key: "marks", label: "Marks & Results", icon: "barchart" },
  { key: "exams", label: "Exams", icon: "exam" },
  { key: "fees", label: "Fees", icon: "rupee" },
  { key: "notices", label: "Notices", icon: "forum" },
  { key: "calendar", label: "Calendar", icon: "calendar" },
  { key: "alerts", label: "Alerts", icon: "bell" },
];
function ParentApp({ user, theme, onToggleTheme, onLogout }) {
  const [active, setActive] = useState("overview");
  const [toast, showToast] = useToast();
  const [kids, setKids] = useState(null);
  const [childId, setChildId] = useState(null);
  const [d, setD] = useState({});
  const [messages, setMessages] = useState([]);
  const refreshKids = useCallback(() => { api.parent.children().then((k) => { setKids(k); setChildId((c) => c || (k[0] && k[0].id)); }).catch(() => setKids([])); }, []);
  const load = useCallback(() => {
    if (!childId) return;
    ["summary", "attendance", "grades", "fees", "notices", "exams"].forEach((part) => api.parent.child(childId, part).then((v) => setD((o) => ({ ...o, [part]: v }))).catch(() => {}));
  }, [childId]);
  useEffect(() => { refreshKids(); api.parent.messages().then(setMessages).catch(() => {}); }, [refreshKids]);
  useEffect(() => { setD({}); load(); }, [load]);
  useLive(["notification:new"], () => { load(); refreshKids(); api.parent.messages().then(setMessages).catch(() => {}); });
  if (!kids) return <PortalLoading label={t("your dashboard")} />;
  const kid = kids.find((k) => k.id === childId);
  const s = d.summary;
  const switcher = kids.length > 1 && (
    <div className="cp-kid-switch" role="tablist" aria-label="Choose child">
      {kids.map((k) => <button key={k.id} type="button" role="tab" aria-selected={k.id === childId} className={k.id === childId ? "is-active" : ""} onClick={() => setChildId(k.id)}>
        <span className="cp-avatar cp-avatar--sm">{initialsOf(k.name)}</span>{k.name.split(" ")[0]}</button>)}
    </div>
  );
  return (
    <PortalShell roleKey="parent" navItems={PARENT_NAV} active={active} onNavigate={setActive} user={user} theme={theme} onToggleTheme={onToggleTheme} onLogout={onLogout} onToast={showToast}
      headerTitle="Parent Portal" headerSub={kid ? `${kid.name} · ${kid.idLabel || ""} · ${kid.department || ""}` : ""}>
      <Toast toast={toast} />
      {switcher}
      {!kid ? <EmptyState text="No student is linked to your account yet." hint="Ask the college office to link your child's record to this email." /> : <>
        {active === "overview" && (s ? (
          <>
            <section className="cp-hero cp-hero--parent">
              <div className="cp-hero-text">
                <div className="cp-hero-eyebrow"><span className="cp-live-dot" aria-hidden="true" />{t("Live updates about")} {kid.name.split(" ")[0]}</div>
                <h2>{kid.name}</h2>
                <p>{s.risk && !/No risk factors|Not enough data/.test(s.risk.reasons.join(" ")) ? `${t("Needs attention")}: ${s.risk.reasons.join(" · ")}.` : t("Everything looks on track — attendance, marks and fees are healthy.")}</p>
                <div className="cp-hero-stats">
                  <div className="cp-hero-stat"><span className="cp-hero-ico cp-hero-ico--coral"><Icon name="check" size={15} /></span>
                    <div><div className="cp-hero-stat-value">{s.hasAttendance ? `${s.attendancePct}%` : "—"}</div><div className="cp-hero-stat-label">{t("Attendance")}</div></div></div>
                  <div className="cp-hero-stat"><span className="cp-hero-ico cp-hero-ico--yellow"><Icon name="target" size={15} /></span>
                    <div><div className="cp-hero-stat-value">{s.cgpa || "—"}</div><div className="cp-hero-stat-label">{t("CGPA · out of 10")}</div></div></div>
                </div>
              </div>
              <div className="cp-hero-art"><HeroIllustration /></div>
            </section>
            <div className="cp-stat-grid">
              <StatCard icon="target" label="Attendance" value={`${s.attendancePct}%`} sub={`${s.present}/${s.totalLectures} ${t("classes")}`} />
              <StatCard icon="rupee" label="Fee due" value={s.feeDue ? `₹${s.feeDue.toLocaleString("en-IN")}` : t("Fully paid")} />
              <StatCard icon="calendar" label="Next exam" value={d.exams && d.exams.upcoming[0] ? fmtDate(d.exams.upcoming[0].date) : "—"} sub={d.exams && d.exams.upcoming[0] ? d.exams.upcoming[0].courseCode : ""} />
            </div>
            <section className="cp-panelgrid">
              <Card wide title="Recent alerts" actions={<Pill tone="ghost" onClick={() => setActive("alerts")}>{t("View all")}</Pill>}>
                {messages.length ? <div className="cp-alert-list">{messages.slice(0, 5).map((m) => (
                  <div key={m.id} className="cp-alert-row"><Badge tone="neutral">{t(KIND_LABEL[m.kind] || m.kind)}</Badge><span>{stripOrg(m.body)}</span><span className="cp-muted cp-small">{timeAgo(m.ts)}</span></div>))}</div>
                  : <EmptyState art="bell" text="No alerts yet." hint="You'll get a message here (and by SMS/WhatsApp) if attendance drops or results come out." />}
              </Card>
              <Card title="Subjects below 75%">
                {d.attendance ? (d.attendance.perCourse.filter((c) => c.pct < 75).length
                  ? <div className="cp-glance">{d.attendance.perCourse.filter((c) => c.pct < 75).map((c) => <div className="cp-glance-row" key={c.courseId}><span>{c.code} {c.name}</span><span className="cp-badge cp-badge--coral">{c.pct}%</span></div>)}</div>
                  : <EmptyState text="All subjects are at 75% or above." />) : <SectionLoading />}
              </Card>
            </section>
          </>) : <SectionLoading />)}
        {active === "attendance" && (d.attendance ? (
          <Card title="Subject-wise attendance" actions={<LiveBadge />}>
            <DataTable columns={[
              { key: "code", label: "Code" }, { key: "name", label: "Subject" },
              { key: "present", label: "Attended", render: (r) => `${r.present} / ${r.total}` },
              { key: "pct", label: "Attendance", render: (r) => <Badge tone={r.pct >= 85 ? "green" : r.pct >= 75 ? "amber" : "red"}>{r.pct}%</Badge> },
              { key: "plan", label: "What it means", render: (r) => r.pct >= 75 ? <span className="cp-muted">{t("On track")}</span> : <strong className="cp-danger-text">{t("Needs")} {r.mustAttend} {t("more classes in a row to reach 75%")}</strong> },
            ]} rows={d.attendance.perCourse} empty="No attendance has been recorded yet." />
            {d.attendance.weeklyTrend.length > 1 && <ChartSparkline data={d.attendance.weeklyTrend} />}
          </Card>) : <SectionLoading />)}
        {active === "marks" && (d.grades ? (
          <>
            <div className="cp-stat-grid"><StatCard icon="barchart" label="CGPA" value={d.grades.cgpa || "—"} sub={t("out of 10 (equal credits)")} /><StatCard icon="book" label="Subjects graded" value={d.grades.courses.length} /></div>
            <Card title="Sessional marks">
              <DataTable columns={[{ key: "code", label: "Code" }, { key: "name", label: "Subject" },
                { key: "average", label: "Average", render: (r) => <Badge tone={r.average >= 70 ? "green" : r.average >= 50 ? "amber" : "red"}>{r.average}</Badge> },
                { key: "gradePoint", label: "Grade point" }, { key: "n", label: "Assessments", render: (r) => r.assessments.length }]} rows={d.grades.courses} empty="No marks have been published yet." />
            </Card>
            {d.exams && <Card title="Exam results"><ResultsTable results={d.exams.results} /></Card>}
            {d.exams && <Card title="Grade card"><GradeCardTable gradeCard={d.exams.gradeCard} /></Card>}
          </>) : <SectionLoading />)}
        {active === "exams" && (d.exams ? <Card title="Exam timetable"><ExamTimetableTable exams={d.exams.upcoming} showEligibility /></Card> : <SectionLoading />)}
        {active === "fees" && (d.fees ? (
          <Card title="Fee Information" actions={<LiveBadge />}>
            <div className="cp-stat-grid">
              <StatCard icon="wallet" label="Total fee" value={`₹${(d.fees.total || 0).toLocaleString("en-IN")}`} />
              <StatCard icon="check" label="Paid" value={`₹${(d.fees.paid || 0).toLocaleString("en-IN")}`} />
              <StatCard icon="rupee" label="Balance due" value={`₹${(d.fees.due || 0).toLocaleString("en-IN")}`} sub={d.fees.dueDate ? `${t("due by")} ${fmtDate(d.fees.dueDate)}` : ""} />
            </div>
            <p className="cp-muted">{t("Status")}: <Badge tone={d.fees.status === "paid" ? "green" : d.fees.status === "overdue" ? "red" : "amber"}>{t(d.fees.status)}</Badge></p>
          </Card>) : <SectionLoading />)}
        {active === "notices" && (d.notices ? (
          <Card title="Notice Board">
            {d.notices.length ? <div className="cp-notice-list">{d.notices.map((n, i) => (
              <div className="cp-notice-row" key={n.id} style={{ "--i": i }}><span className="cp-notice-tag">{n.course}</span><span className="cp-notice-title">{n.title}</span><span className="cp-notice-date">{timeAgo(n.ts)}</span></div>))}</div>
              : <EmptyState text="No notices yet." />}
          </Card>) : <SectionLoading />)}
        {active === "calendar" && <AcademicCalendar studentId={childId} showToast={showToast} />}
        {active === "alerts" && (
          <Card title="Alerts sent to you" actions={<LiveBadge />}>
            <DataTable columns={[
              { key: "ts", label: "When", render: (r) => timeAgo(r.ts) },
              { key: "kind", label: "Type", render: (r) => <Badge tone="neutral">{t(KIND_LABEL[r.kind] || r.kind)}</Badge> },
              { key: "body", label: "Message", render: (r) => stripOrg(r.body) },
              { key: "channel", label: "Sent by", render: (r) => (r.channel === "whatsapp" ? "WhatsApp" : "SMS") + (r.status === "logged" ? ` (${t("demo")})` : "") },
            ]} rows={messages} empty="No alerts yet." />
          </Card>
        )}
      </>}
    </PortalShell>
  );
}

// ======================================================== verification page
function VerifyPage({ token, theme }) {
  const [res, setRes] = useState(null);
  useEffect(() => { api.docs.verify(token).then(setRes).catch((e) => setRes({ valid: false, reason: e.message })); }, [token]);
  return (
    <div className="cp-shell cp-shell--auth" data-theme={theme}>
      <div className="cp-verify">
        <div className="cp-verify-card">
          <div className="cp-verify-brand"><BrandMark size={28} /> CampusPilot · {t("Document verification")}</div>
          {!res ? <SectionLoading label={t("Checking…")} /> : res.valid ? (
            <>
              <div className="cp-verify-status is-ok"><Icon name="check" size={28} /></div>
              <h2>{t("Genuine")} {t(res.document)}</h2>
              <dl className="cp-verify-dl">
                <dt>{t("Name")}</dt><dd>{res.name}</dd>
                {res.idLabel && <><dt>{res.role === "Student" ? t("Roll No.") : t("ID")}</dt><dd>{res.idLabel}</dd></>}
                <dt>{t("Role")}</dt><dd>{t(res.role)}</dd>
                {res.department && <><dt>{t("Department")}</dt><dd>{res.department}</dd></>}
                {res.reference && <><dt>{t("Reference")}</dt><dd>{res.reference}</dd></>}
                {res.purpose && <><dt>{t("Purpose")}</dt><dd>{res.purpose}</dd></>}
                <dt>{t("Issued")}</dt><dd>{res.issuedAt ? new Date(res.issuedAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }) : "—"}</dd>
              </dl>
              <p className="cp-muted cp-small">{res.institution}</p>
            </>
          ) : (
            <>
              <div className="cp-verify-status is-bad"><Icon name="close" size={28} /></div>
              <h2>{t("Could not verify")}</h2>
              <p>{res.reason}</p>
            </>
          )}
          <a className="cp-verify-home" href="/">{t("Go to CampusPilot")}</a>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  useLang();  // re-render everything when the language changes
  const verifyToken = typeof window !== "undefined" && window.location.pathname.startsWith("/verify/")
    ? decodeURIComponent(window.location.pathname.slice("/verify/".length)) : null;
  const [theme, setTheme] = useState(() => { try { return localStorage.getItem("cp_theme") || "light"; } catch { return "light"; } });
  const [user, setUser] = useState(null);
  const [restoring, setRestoring] = useState(true);
  const toggleTheme = () => setTheme((t) => { const n = t === "light" ? "dark" : "light"; try { localStorage.setItem("cp_theme", n); } catch { /* ignore */ } return n; });

  // Restore the session from the httpOnly cookie (survives page refresh).
  useEffect(() => {
    let cancelled = false;
    api.auth.me()
      .then((restored) => { if (!cancelled && restored) setUser(restored); })
      .catch(() => {})
      .finally(() => { if (!cancelled) setRestoring(false); });
    return () => { cancelled = true; };
  }, []);

  // Live updates run only while signed in.
  useEffect(() => {
    if (user && !user.mustChangePassword) connectLive(); else disconnectLive();
    return () => {};
  }, [user]);

  // Session revoked/expired (logout elsewhere, password change, deactivation).
  useEffect(() => {
    function onExpired() { disconnectLive(); setUser(null); }
    window.addEventListener("cp:session-expired", onExpired);
    return () => window.removeEventListener("cp:session-expired", onExpired);
  }, []);

  async function logout() { disconnectLive(); await api.auth.logout(); setUser(null); }

  if (verifyToken) {
    return <><Style /><VerifyPage token={verifyToken} theme={theme} /></>;
  }
  if (restoring) {
    return (
      <div className="cp-shell cp-shell--auth" data-theme={theme}>
        <Style />
        <PortalLoading label="CampusPilot" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="cp-shell cp-shell--auth" data-theme={theme}>
        <Style />
        <PortalErrorBoundary label="login screen">
          <AuthScreen theme={theme} onToggleTheme={toggleTheme} onAuthed={setUser} />
        </PortalErrorBoundary>
      </div>
    );
  }
  if (user.mustChangePassword) {
    return (
      <div className="cp-shell cp-shell--auth" data-theme={theme}>
        <Style />
        <ChangePasswordGate user={user} onDone={setUser} onLogout={logout} />
      </div>
    );
  }
  const Portal = user.role === "admin" ? AdminApp : user.role === "teacher" ? TeacherApp : user.role === "parent" ? ParentApp : StudentApp;
  return (
    <>
      <Style />
      <PortalErrorBoundary label={`${user.role} portal`}>
        <Portal user={user} theme={theme} onLogout={logout} onToggleTheme={toggleTheme} />
      </PortalErrorBoundary>
    </>
  );
}

function Style() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700;800&family=Inter:wght@400;500;600;700&family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Manrope:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;600&family=Noto+Sans+Devanagari:wght@400;500;600;700&display=swap');
      *{ box-sizing:border-box; }
      /* The document itself never scrolls — every screen (auth page, each
         portal) owns exactly one internal scroll region. Without this,
         a tall child (e.g. the auth card growing when an error message or
         the demo-credentials panel appears) can make the outer document
         scrollable too, stacking a second scrollbar on top of the screen's
         own — this is what produced the "2 scrollbars / stuck" bug. */
      html,body,#root{ height:100%; margin:0; overflow:hidden; overscroll-behavior:none; }
      body{ overscroll-behavior-y:none; }
      :root{
        --teal:#1FC3B4; --teal-dark:#12756B; --teal-soft:#E3F7F4;
        --coral:#FF7A5C; --coral-soft:#FFE9E3; --yellow:#FFC93C; --yellow-soft:#FFF3D6;
        --purple:#7C6CF0; --navy:#2B3E6B; --radius-lg:26px; --radius-md:18px;
        --ease:cubic-bezier(.22,1,.36,1);
      }

      .cp-shell{ --bg:#E3EFED; --ink:#16232A; --ink-soft:#4C5D64; --ink-faint:#7C8D93;
        --glass:rgba(255,255,255,0.66); --glass-strong:rgba(255,255,255,0.86); --glass-border:rgba(255,255,255,0.75);
        --panel:rgba(255,255,255,0.72); --panel-border:rgba(17,40,45,0.10); --surface:rgba(255,255,255,0.8); --surface-border:rgba(17,40,45,0.14);
        --shadow:0 20px 60px rgba(15,60,55,0.16); --blob-opacity:0.5; }
      .cp-shell[data-theme="dark"]{ --bg:#0B141C; --ink:#EAF3F1; --ink-soft:#9FB2B7; --ink-faint:#66787E;
        --glass:rgba(22,32,40,0.62); --glass-strong:rgba(26,38,47,0.85); --glass-border:rgba(255,255,255,0.09);
        --panel:rgba(22,33,41,0.78); --panel-border:rgba(255,255,255,0.08); --surface:rgba(30,43,52,0.85); --surface-border:rgba(255,255,255,0.1);
        --shadow:0 20px 60px rgba(0,0,0,0.5); --blob-opacity:0.26; }
      body{ background:var(--bg); font-family:'Inter', system-ui, sans-serif; }
      .cp-shell{ position:relative; width:100vw; width:100dvw; height:100vh; height:100dvh; display:flex; align-items:stretch; justify-content:stretch;
        color:var(--ink); background:var(--bg); padding:14px; overflow:hidden; transition:background-color .5s var(--ease), color .5s var(--ease); }
      .cp-shell--auth{ padding:0; overflow:hidden; height:100vh; height:100dvh; }

      .cp-aurora{ position:absolute; inset:0; overflow:hidden; z-index:0;
        background:radial-gradient(circle at 15% 20%, color-mix(in srgb, var(--bg) 60%, white 40%) 0%, var(--bg) 55%); }
      .cp-blob{ position:absolute; border-radius:50%; filter:blur(70px); opacity:var(--blob-opacity); }
      .cp-blob--a{ width:520px; height:520px; background:var(--accent, var(--teal)); top:-160px; left:-120px; animation:blobA 22s ease-in-out infinite; }
      .cp-blob--b{ width:420px; height:420px; background:var(--coral); bottom:-140px; right:-80px; animation:blobB 26s ease-in-out infinite; }
      .cp-blob--c{ width:360px; height:360px; background:var(--yellow); bottom:10%; left:38%; animation:blobC 30s ease-in-out infinite; }
      .cp-grain{ position:absolute; inset:0; background-image:radial-gradient(rgba(255,255,255,0.4) 1px, transparent 1px); background-size:3px 3px; opacity:0.3; mix-blend-mode:overlay; }
      @keyframes blobA{ 0%,100%{ transform:translate(0,0) scale(1);} 50%{ transform:translate(60px,50px) scale(1.12);} }
      @keyframes blobB{ 0%,100%{ transform:translate(0,0) scale(1);} 50%{ transform:translate(-50px,-40px) scale(1.08);} }
      @keyframes blobC{ 0%,100%{ transform:translate(0,0) scale(1);} 50%{ transform:translate(-40px,30px) scale(1.15);} }

      /* NOTE on glass: backdrop-filter (the actual live blur) has been
         removed from the whole app. It was tried in two narrower forms first
         (stacking it on every card, then trimming to a single frame-level
         layer) and the black-rendering bug persisted through both, which
         points at backdrop-filter itself being unreliable in this browser/GPU
         environment rather than how many layers used it. The "glass" look
         now comes entirely from translucent backgrounds (--glass/--panel/
         --surface, all rgba with alpha) layered over the blurred, animated
         --cp-blob shapes in AuroraBackground — those blobs carry their own
         filter:blur(70px) at the source, so panels sitting above them still
         read as soft frosted glass without any element needing its own
         backdrop-filter. This also used to do a continuous mouse-tilt
         (rotateX/rotateY, transform-style:preserve-3d, updated on every
         mousemove); that was purely decorative and already the cause of an
         earlier hover-jank complaint, so it's gone too — the frame now only
         does its one-time fade/rise-in entrance. */
      .cp-frame{ position:relative; z-index:1; flex:1; display:flex; background:var(--glass-strong);
        border:1px solid var(--glass-border); border-radius:var(--radius-lg); box-shadow:var(--shadow), inset 0 1px 0 rgba(255,255,255,0.5);
        overflow:hidden; min-height:0; min-width:0; opacity:0; transform:translateY(18px) scale(0.99);
        transition:opacity .7s var(--ease), transform .7s var(--ease); }
      .cp-frame.is-mounted{ opacity:1; transform:translateY(0) scale(1); }
      h1,h2,h3{ font-family:'Poppins', sans-serif; margin:0; }

      .cp-sidebar{ --sb-x:10px; width:236px; flex-shrink:0; padding:22px 14px 16px; display:flex; flex-direction:column;
        border-right:1px solid var(--panel-border); background:linear-gradient(180deg, color-mix(in srgb, var(--surface) 60%, transparent), transparent);
        min-height:0; position:relative; }
      .cp-sidebar-close{ display:none; }
      .cp-hamburger{ display:none; }
      .cp-sidebar-veil{ display:none; }
      .cp-brand{ display:flex; align-items:center; gap:10px; padding:0 var(--sb-x) 26px; }
      .cp-brand-mark{ position:relative; width:26px; height:20px; flex-shrink:0; }
      .cp-logo-mark{ display:inline-flex; flex-shrink:0; filter:drop-shadow(0 3px 8px rgba(20,60,90,0.28)); }
      .cp-dot-teal, .cp-dot-coral{ position:absolute; width:18px; height:18px; border-radius:50%; top:0; box-shadow:0 3px 8px rgba(0,0,0,0.12); }
      .cp-dot-teal{ background:var(--accent, var(--teal)); left:0; animation:pulseDot 3.6s ease-in-out infinite; }
      .cp-dot-coral{ background:var(--coral); left:9px; opacity:0.9; animation:pulseDot 3.6s ease-in-out infinite 0.4s; }
      @keyframes pulseDot{ 0%,100%{ transform:scale(1);} 50%{ transform:scale(1.15);} }
      .cp-brand-name{ font-family:'Poppins',sans-serif; font-weight:700; font-size:16px; letter-spacing:-0.01em; }

      .cp-profile-card{ display:flex; flex-direction:column; align-items:center; text-align:center; gap:4px; padding:14px var(--sb-x) 16px; margin-bottom:6px; border-bottom:1px solid var(--panel-border); }
      .cp-profile-card-avatar{ width:52px; height:52px; border-radius:50%; background:linear-gradient(135deg, var(--accent, var(--teal)), var(--accent-deep, var(--teal-dark))); color:#fff; font-weight:700; font-size:16px; display:flex; align-items:center; justify-content:center; box-shadow:0 8px 18px rgba(18,60,55,0.28); border:2.5px solid var(--glass-border); margin-bottom:4px; }
      .cp-profile-card-name{ font-family:'Poppins',sans-serif; font-weight:700; font-size:13px; color:var(--ink); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:100%; }
      .cp-profile-card-id{ font-size:10.5px; color:var(--ink-faint); }
      .cp-nav-label{ font-size:10px; font-weight:700; letter-spacing:0.09em; text-transform:uppercase; color:var(--ink-faint); padding:4px var(--sb-x) 8px; }
      .cp-nav--full{ flex:1; min-height:0; overflow-y:auto; display:flex; flex-direction:column; gap:2px; padding-right:2px; scrollbar-width:thin; }
      .cp-nav-item-wrap{ opacity:0; transform:translateX(-10px); animation:navIn .5s var(--ease) forwards; animation-delay:calc(var(--i) * 60ms + 120ms); }
      @keyframes navIn{ to{ opacity:1; transform:translateX(0); } }
      .cp-nav-item{ all:unset; box-sizing:border-box; position:relative; overflow:hidden; display:flex; align-items:center; gap:11px; width:100%;
        padding:9px var(--sb-x); border-radius:12px; font-size:13px; font-weight:500; color:var(--ink-soft); cursor:pointer; transition:background .25s var(--ease), color .25s var(--ease), transform .18s var(--ease); }
      .cp-nav-ico{ display:flex; flex-shrink:0; width:17px; }
      .cp-nav-item:hover{ background:var(--surface); color:var(--ink); transform:translateX(3px); }
      .cp-nav-item.is-active{ background:linear-gradient(120deg, var(--accent-deep, var(--teal-dark)), color-mix(in srgb, var(--accent-deep, var(--teal-dark)) 70%, black));
        color:#fff; box-shadow:0 10px 24px rgba(18,60,55,0.28); }
      .cp-nav-badge{ margin-left:auto; background:var(--coral); color:#fff; font-size:10.5px; font-weight:700; padding:1.5px 6.5px; border-radius:20px; }
      .cp-sidebar-logout{ all:unset; box-sizing:border-box; cursor:pointer; display:flex; align-items:center; gap:9px; margin-top:10px; padding:9px var(--sb-x); border-radius:12px;
        font-size:12.5px; font-weight:600; color:var(--ink-soft); background:var(--surface); border:1px solid var(--surface-border); }
      .cp-sidebar-logout:hover{ background:var(--coral-soft); color:#B84A32; }
      .cp-sidebar-foot{ margin-top:10px; padding-top:12px; border-top:1px solid var(--panel-border); text-align:center; font-size:10px; color:var(--ink-faint); }

      .cp-ripple-field{ position:absolute; inset:0; overflow:hidden; border-radius:inherit; pointer-events:none; }
      .cp-ripple{ position:absolute; border-radius:50%; background:radial-gradient(circle, rgba(255,255,255,0.85) 0%, rgba(255,255,255,0) 70%); transform:scale(0); animation:rippleOut .62s ease-out forwards; }
      @keyframes rippleOut{ to{ transform:scale(1); opacity:0; } }
      .cp-float{ animation:floatY 5.5s ease-in-out infinite; } @keyframes floatY{ 0%,100%{ transform:translateY(0);} 50%{ transform:translateY(-8px);} }

      .cp-main{ flex:1; min-width:0; min-height:0; padding:22px 34px 30px; overflow-y:auto; overflow-x:hidden; -webkit-overflow-scrolling:touch; }
      .cp-topbar{ display:flex; align-items:center; gap:14px; margin-bottom:20px; padding:14px 18px; border-radius:18px;
        background:var(--panel); border:1px solid var(--panel-border);
        box-shadow:0 10px 26px rgba(15,40,45,0.08), inset 0 1px 0 rgba(255,255,255,0.35);
        opacity:0; animation:dropIn .55s var(--ease) forwards; animation-delay:.15s; }
      @keyframes dropIn{ from{ opacity:0; transform:translateY(-8px);} to{ opacity:1; transform:translateY(0);} }
      .cp-topbar-title{ min-width:0; }
      .cp-zoom{ display:flex; align-items:center; gap:2px; padding:3px; border-radius:999px; border:1px solid var(--surface-border); background:var(--surface); }
      .cp-zoom-btn{ all:unset; box-sizing:border-box; width:30px; height:30px; border-radius:50%; display:flex; align-items:center; justify-content:center; cursor:pointer; color:var(--ink-soft); }
      .cp-zoom-btn:hover:not(:disabled){ background:var(--accent-soft); color:var(--accent-deep); }
      .cp-zoom-btn:disabled{ opacity:.35; cursor:default; }
      .cp-zoom-btn:focus-visible, .cp-zoom-pct:focus-visible{ outline:2px solid var(--accent); outline-offset:1px; }
      .cp-zoom-pct{ all:unset; box-sizing:border-box; min-width:46px; text-align:center; font-size:12px; font-weight:700; color:var(--ink); cursor:pointer; padding:4px 2px; border-radius:8px; font-variant-numeric:tabular-nums; }
      .cp-zoom-pct:hover{ color:var(--accent-deep); }
      .cp-topbar-title h1{ font-size:19px; font-weight:800; color:var(--ink); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
      .cp-topbar-title p{ margin:2px 0 0; font-size:12px; color:var(--ink-soft); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
      .cp-topbar-actions{ margin-left:auto; display:flex; align-items:center; gap:10px; flex-shrink:0; flex-wrap:wrap; justify-content:flex-end; }

      .cp-live{ display:inline-flex; align-items:center; gap:6px; font-size:11.5px; font-weight:600; color:var(--ink-soft); background:var(--surface); border:1px solid var(--surface-border); padding:7px 12px; border-radius:20px; white-space:nowrap; }
      .cp-live-dot2{ width:7px; height:7px; border-radius:50%; background:#2ECC71; animation:pulseLive 1.8s ease-in-out infinite; }
      .cp-live-dot2--local{ background:#9AA7AC; animation:none; }
      @keyframes pulseLive{ 0%,100%{ box-shadow:0 0 0 0 rgba(46,204,113,.55);} 50%{ box-shadow:0 0 0 5px rgba(46,204,113,0);} }
      @media (max-width: 1100px){ .cp-live{ display:none; } }
      @media (max-width: 600px){ .cp-zoom-pct{ min-width:38px; font-size:11px; } .cp-zoom-btn{ width:26px; height:26px; } }
      @media (max-width: 480px){ .cp-topbar .cp-profile, .cp-topbar .cp-pill--ghost{ display:none; } }  /* profile + Log out are in the ☰ menu on phones */

      .cp-round-btn{ all:unset; position:relative; overflow:hidden; cursor:pointer; isolation:isolate; width:38px; height:38px; border-radius:50%;
        display:flex; align-items:center; justify-content:center; background:var(--surface); border:1px solid var(--surface-border); color:var(--ink-soft);
        transition:background .22s var(--ease), color .22s var(--ease), transform .2s var(--ease); flex-shrink:0; }
      .cp-round-btn:hover{ background:var(--accent-soft, var(--teal-soft)); color:var(--accent-deep, var(--teal-dark)); transform:translateY(-2px) rotate(-6deg); }
      .cp-theme-icon.is-dark{ transform:rotate(-14deg); }

      .cp-profile{ display:flex; align-items:center; gap:9px; border:1px solid var(--surface-border); background:var(--surface); border-radius:40px; padding:5px 14px 5px 5px; }
      .cp-avatar{ width:32px; height:32px; border-radius:50%; background:linear-gradient(135deg, var(--accent, var(--teal)), var(--accent-deep, var(--teal-dark))); color:#fff; font-size:12px; font-weight:700; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
      .cp-avatar--sm{ width:34px; height:34px; font-size:11.5px; background:linear-gradient(135deg, var(--navy), #1D2C4D); }
      .cp-profile-name{ font-size:12.5px; font-weight:600; line-height:1.2; color:var(--ink); }
      .cp-profile-handle{ font-size:10.5px; color:var(--ink-faint); }

      .cp-content{ display:flex; flex-direction:column; gap:0; min-width:0; animation:contentIn .38s var(--ease); }
      @keyframes contentIn{ from{ opacity:0; transform:translateY(8px);} to{ opacity:1; transform:translateY(0);} }

      .cp-portal-loading{ display:flex; flex-direction:column; align-items:center; justify-content:center; gap:14px; min-height:60vh; color:var(--ink-soft); }
      .cp-portal-loading-spinner{ width:34px; height:34px; border-radius:50%; border:3px solid var(--surface-border); border-top-color:var(--accent, var(--teal)); animation:spin 0.8s linear infinite; }
      .cp-portal-loading-text{ font-size:13px; font-weight:600; }
      .cp-section-loading{ display:flex; align-items:center; gap:10px; padding:26px 4px; color:var(--ink-soft); font-size:12.5px; font-weight:600; }
      .cp-spinner--sm{ width:16px; height:16px; border-width:2px; }

      .cp-hero{ position:relative; overflow:hidden; background:linear-gradient(125deg, var(--accent, #22CDBD), var(--accent-deep, #0F8F84) 70%); border-radius:var(--radius-md);
        padding:34px 34px 30px; display:flex; align-items:center; justify-content:space-between; gap:24px; color:#fff; margin-bottom:18px;
        border:1px solid rgba(255,255,255,0.35); box-shadow:0 22px 48px rgba(15,90,80,0.3); opacity:0; animation:heroIn .7s var(--ease) forwards; animation-delay:.2s; }
      @keyframes heroIn{ from{ opacity:0; transform:translateY(14px);} to{ opacity:1; transform:translateY(0);} }
      .cp-hero-eyebrow{ display:inline-flex; align-items:center; gap:7px; font-size:11px; font-weight:700; letter-spacing:0.05em; text-transform:uppercase; color:rgba(255,255,255,0.92);
        background:rgba(255,255,255,0.16); border:1px solid rgba(255,255,255,0.3); padding:5px 12px 5px 10px; border-radius:20px; margin-bottom:14px; }
      .cp-live-dot{ width:6px; height:6px; border-radius:50%; background:#B6FFCE; animation:liveDot 1.8s ease-in-out infinite; }
      @keyframes liveDot{ 0%,100%{ box-shadow:0 0 0 0 rgba(182,255,206,0.6); } 50%{ box-shadow:0 0 0 5px rgba(182,255,206,0); } }
      .cp-hero-text{ min-width:0; }
      .cp-hero-text h2{ font-size:27px; font-weight:800; margin-bottom:7px; }
      .cp-hero-text p{ font-size:13.5px; opacity:0.92; max-width:360px; margin:0 0 20px; line-height:1.55; }
      .cp-hero-stats{ display:flex; gap:28px; margin-bottom:22px; flex-wrap:wrap; }
      .cp-hero-stat{ display:flex; align-items:center; gap:9px; }
      .cp-hero-ico{ width:32px; height:32px; border-radius:50%; display:flex; align-items:center; justify-content:center; color:#fff; flex-shrink:0; }
      .cp-hero-ico--coral{ background:var(--coral); } .cp-hero-ico--yellow{ background:var(--yellow); color:#5A4200; }
      .cp-hero-stat-value{ font-weight:800; font-size:17px; font-family:'Poppins',sans-serif; }
      .cp-hero-stat-label{ font-size:11px; opacity:0.85; margin-top:1px; }
      .cp-hero-actions{ display:flex; align-items:center; gap:14px; flex-wrap:wrap; }
      .cp-hero-quicklinks{ display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
      .cp-hero-chip{ all:unset; cursor:pointer; font-size:11.5px; font-weight:600; color:rgba(255,255,255,0.92); background:rgba(255,255,255,0.14); border:1px solid rgba(255,255,255,0.3); padding:7px 13px; border-radius:20px; }
      .cp-hero-chip:hover{ background:rgba(255,255,255,0.26); }
      .cp-hero-art{ position:relative; z-index:1; width:240px; flex-shrink:0; }
      @media (max-width: 900px){ .cp-hero-art{ display:none; } .cp-hero{ padding:26px 22px 24px; } }

      .cp-quickgrid{ display:grid; grid-template-columns:repeat(4,1fr); gap:14px; margin:0 0 22px; }
      .cp-quick{ position:relative; overflow:hidden; border-radius:var(--radius-md); padding:16px 16px 14px; color:#fff; display:flex; flex-direction:column; gap:6px; align-items:flex-start; min-width:0;
        border:1px solid rgba(255,255,255,0.3); box-shadow:0 14px 26px rgba(18,40,60,0.16); opacity:0; transform:translateY(12px); animation:rowIn .55s var(--ease) forwards; animation-delay:calc(var(--i,0) * 70ms + .3s); }
      @keyframes rowIn{ to{ opacity:1; transform:translateY(0);} }
      .cp-quick--navy{ background:linear-gradient(135deg, var(--navy), #1D2C4D); } .cp-quick--teal{ background:linear-gradient(135deg, var(--accent, #26D6C4), var(--accent-deep, var(--teal-dark))); }
      .cp-quick--purple{ background:linear-gradient(135deg, var(--purple), #5B4CD6); } .cp-quick--coral{ background:linear-gradient(135deg, var(--coral), #E8503A); }
      .cp-quick-label{ font-size:12px; font-weight:700; opacity:0.92; } .cp-quick-main{ font-family:'Poppins',sans-serif; font-weight:700; font-size:15px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:100%; }
      .cp-quick-sub{ font-size:10.5px; opacity:0.85; margin-top:-4px; }
      .cp-pill--quick{ margin-top:6px; background:rgba(255,255,255,0.22); color:#fff; font-weight:600; }
      .cp-pill--quick:hover{ background:rgba(255,255,255,0.34); }

      .cp-panelgrid{ display:grid; grid-template-columns:1.5fr 1fr; gap:18px; margin-bottom:18px; min-width:0; }
      .cp-columns{ display:grid; grid-template-columns:1.35fr 1fr 1fr; gap:18px; align-items:start; min-width:0; }
      .cp-col{ min-width:0; } .cp-col--wide{ min-width:0; }
      .cp-col-head{ display:flex; align-items:center; justify-content:space-between; margin-bottom:14px; gap:10px; }
      .cp-col-head h3{ font-size:15px; font-weight:700; }
      @media (max-width: 1180px){ .cp-panelgrid{ grid-template-columns:1fr; } .cp-columns{ grid-template-columns:1fr; } }
      @media (max-width: 760px){ .cp-quickgrid{ grid-template-columns:1fr 1fr; } }
      @media (max-width: 480px){ .cp-quickgrid{ grid-template-columns:1fr; } }

      .cp-list{ display:flex; flex-direction:column; gap:10px; }
      .cp-row{ position:relative; display:flex; align-items:center; gap:12px; background:var(--panel); border:1px solid var(--panel-border); border-radius:15px; padding:11px 12px; min-width:0;
        transition:box-shadow .22s var(--ease), transform .2s var(--ease); opacity:0; transform:translateY(10px); animation:rowIn .5s var(--ease) forwards; animation-delay:calc(var(--i) * 70ms + .35s); }
      .cp-row:hover{ box-shadow:0 12px 26px rgba(18,60,55,0.12); transform:translateY(-3px); }
      .cp-tile{ width:36px; height:36px; border-radius:11px; flex-shrink:0; display:flex; align-items:center; justify-content:center; font-weight:700; font-size:13px; color:#fff; box-shadow:0 6px 14px rgba(0,0,0,0.14); }
      .cp-tile--teal{ background:linear-gradient(135deg, var(--teal), var(--teal-dark)); } .cp-tile--coral{ background:linear-gradient(135deg, var(--coral), #E85E3F); } .cp-tile--yellow{ background:linear-gradient(135deg, var(--yellow), #F0AF12); color:#5A4200; }
      .cp-row-body{ flex:1; min-width:0; } .cp-row-title{ font-size:13px; font-weight:600; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; color:var(--ink); }
      .cp-row-sub{ font-size:11px; color:var(--ink-faint); margin-top:2px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }

      .cp-pill{ all:unset; position:relative; overflow:hidden; isolation:isolate; cursor:pointer; flex-shrink:0; display:inline-flex; align-items:center; gap:4px;
        font-size:11.5px; font-weight:600; padding:7px 14px; border-radius:20px; transition:transform .18s var(--ease); white-space:nowrap; }
      .cp-pill-label{ display:inline-flex; align-items:center; gap:4px; } .cp-pill:active{ transform:scale(0.93); }
      .cp-pill--outline{ border:1.4px solid var(--surface-border); background:var(--surface); color:var(--ink-soft); }
      .cp-pill--outline:hover{ border-color:var(--accent, var(--teal)); color:var(--accent-deep, var(--teal-dark)); background:var(--accent-soft, var(--teal-soft)); }
      .cp-pill--solid{ background:linear-gradient(120deg, var(--accent, var(--coral)), var(--accent-deep, #FF9478)); color:#fff; box-shadow:0 6px 14px rgba(0,0,0,0.18); }
      .cp-pill--hero-solid{ background:#fff; color:var(--accent-deep, var(--teal-dark)); font-weight:700; box-shadow:0 8px 18px rgba(0,0,0,0.16); }
      .cp-pill--ghost{ background:var(--surface); color:var(--ink-soft); } .cp-pill--ghost:hover{ background:var(--glass-strong); color:var(--ink); }
      .cp-pill--quick{ margin-top:6px; }
      .cp-pill:disabled{ opacity:.5; cursor:not-allowed; }

      .cp-progress-card{ position:relative; overflow:hidden; background:linear-gradient(135deg, var(--accent, #22CDBD), var(--accent-deep, #0E8A80)); border-radius:var(--radius-md); padding:18px 18px 8px; color:#fff; margin-bottom:14px; border:1px solid rgba(255,255,255,0.3); box-shadow:0 14px 30px rgba(15,90,80,0.24); }
      .cp-progress-top{ display:flex; align-items:flex-start; justify-content:space-between; margin-bottom:6px; gap:10px; }
      .cp-progress-title{ font-weight:700; font-size:14px; } .cp-progress-sub{ font-size:11px; opacity:0.85; margin-top:2px; }
      .cp-progress-badge{ font-size:11px; font-weight:700; background:rgba(255,255,255,0.25); padding:3px 9px; border-radius:20px; white-space:nowrap; }
      .cp-spark-line{ stroke-dasharray:400; stroke-dashoffset:400; transition:stroke-dashoffset 1.1s var(--ease); } .cp-spark-line.is-drawn{ stroke-dashoffset:0; }

      .cp-mini-grid{ display:grid; grid-template-columns:1fr 1fr; gap:12px; }
      .cp-mini-card{ border-radius:var(--radius-md); padding:16px; border:1px solid var(--panel-border); min-width:0; }
      .cp-mini-card--yellow{ background:linear-gradient(160deg, var(--yellow-soft), color-mix(in srgb, var(--yellow-soft) 60%, var(--panel))); }
      .cp-mini-card--coral{ background:linear-gradient(160deg, var(--coral-soft), color-mix(in srgb, var(--coral-soft) 60%, var(--panel))); }
      .cp-mini-value{ font-size:22px; font-weight:800; font-family:'Poppins',sans-serif; color:var(--ink); }
      .cp-mini-label{ font-size:11px; color:var(--ink-soft); margin-top:2px; }

      .cp-card{ background:var(--panel); border:1px solid var(--panel-border); border-radius:var(--radius-md); overflow:hidden;
        box-shadow:0 12px 26px rgba(18,60,55,0.08), inset 0 1px 0 rgba(255,255,255,0.35); margin-bottom:18px; min-width:0; }
      .cp-card-head{ display:flex; align-items:center; justify-content:space-between; gap:10px; padding:14px 18px; color:#fff; background:linear-gradient(120deg, var(--accent-deep, var(--navy)), color-mix(in srgb, var(--accent-deep, var(--navy)) 70%, black)); flex-wrap:wrap; }
      .cp-card-head h3{ font-size:13.5px; font-weight:700; } .cp-card-actions{ display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
      .cp-card-body{ padding:18px; min-width:0; }

      .cp-notice-list{ display:flex; flex-direction:column; gap:8px; }
      .cp-notice-row{ display:flex; align-items:center; gap:10px; background:var(--surface); border:1px solid var(--surface-border); border-radius:11px; padding:9px 12px; opacity:0; transform:translateY(8px); animation:rowIn .45s var(--ease) forwards; animation-delay:calc(var(--i) * 70ms + .1s); flex-wrap:wrap; }
      .cp-notice-tag{ flex-shrink:0; font-size:10px; font-weight:700; color:var(--accent-deep, var(--teal-dark)); background:var(--accent-soft, var(--teal-soft)); padding:3px 9px; border-radius:20px; }
      .cp-notice-title{ flex:1; font-size:12.3px; color:var(--ink); min-width:160px; } .cp-notice-date{ flex-shrink:0; font-size:11px; color:var(--ink-faint); }

      .cp-glance{ display:flex; flex-direction:column; }
      .cp-glance-row{ display:flex; align-items:center; justify-content:space-between; padding:9px 2px; font-size:12.5px; font-weight:600; color:var(--ink); border-bottom:1px dashed var(--panel-border); opacity:0; transform:translateX(-6px); animation:navIn .4s var(--ease) forwards; animation-delay:calc(var(--i) * 60ms + .3s); gap:10px; }
      .cp-glance-row:last-child{ border-bottom:none; }
      .cp-glance-row > span:first-child{ overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
      .cp-badge{ font-size:10.5px; font-weight:700; padding:3px 10px; border-radius:20px; color:#fff; flex-shrink:0; white-space:nowrap; }
      .cp-badge--coral{ background:var(--coral); } .cp-badge--teal{ background:var(--teal); } .cp-badge--yellow{ background:var(--yellow); color:#5A4200; } .cp-badge--navy{ background:var(--navy); }

      .cp-muted{ color:var(--ink-faint); font-size:12.5px; }

      /* generic glass widgets: stats, badges2, tabs2, tables, modal, toast, switch, bars, audit */
      .cp-stat-grid{ display:grid; grid-template-columns:repeat(auto-fit,minmax(170px,1fr)); gap:14px; margin-bottom:16px; }
      .cp-stat{ display:flex; align-items:center; gap:12px; background:var(--panel); border:1px solid var(--panel-border); border-radius:var(--radius-md); padding:14px 16px; min-width:0; }
      .cp-stat-ico{ width:36px; height:36px; border-radius:10px; background:var(--accent-soft); color:var(--accent-deep); display:flex; align-items:center; justify-content:center; flex-shrink:0; }
      .cp-stat-value{ font-size:19px; font-weight:800; font-family:'Poppins',sans-serif; color:var(--ink); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
      .cp-stat-label{ font-size:11px; color:var(--ink-soft); } .cp-stat-sub{ font-size:10px; color:var(--ink-faint); }

      .cp-badge2{ font-size:10.5px; font-weight:700; padding:3px 9px; border-radius:20px; display:inline-flex; align-items:center; gap:5px; text-transform:capitalize; white-space:nowrap; }
      .cp-badge-pulse-dot{ width:5px; height:5px; border-radius:50%; background:currentColor; animation:pulseLive 1.8s ease-in-out infinite; flex-shrink:0; }
      .cp-badge2--green{ background:#DCF6E6; color:#1D8A4E; } .cp-badge2--red{ background:#FBE4E1; color:#B23A2C; }
      .cp-badge2--amber{ background:#FBF0D9; color:#8A6A22; } .cp-badge2--teal{ background:#DCF3EE; color:#12756B; }
      .cp-badge2--navy{ background:#E4EAF3; color:#1B2C4A; } .cp-badge2--neutral{ background:var(--surface); color:var(--ink-soft); }

      .cp-tabs2{ display:flex; gap:6px; margin-bottom:14px; border-bottom:1px solid var(--panel-border); flex-wrap:wrap; overflow-x:auto; }
      .cp-tab2{ all:unset; cursor:pointer; padding:8px 14px; font-size:12.5px; font-weight:600; color:var(--ink-faint); border-radius:8px 8px 0 0; white-space:nowrap; }
      .cp-tab2.is-active{ color:var(--accent-deep); box-shadow:0 -2px 0 var(--accent) inset; }

      .cp-modal-veil{ position:fixed; inset:0; background:rgba(10,20,25,.4); display:flex; align-items:center; justify-content:center; z-index:300; padding:20px; overflow-y:auto; }
      .cp-modal{ background:var(--glass-strong); border:1px solid var(--glass-border); border-radius:18px; width:100%; max-width:420px; box-shadow:0 30px 60px rgba(0,0,0,.3); max-height:calc(100vh - 40px); max-height:calc(100dvh - 40px); display:flex; flex-direction:column; margin:auto; }
      .cp-modal-head{ display:flex; align-items:center; justify-content:space-between; padding:14px 18px; border-bottom:1px solid var(--panel-border); flex-shrink:0; }
      .cp-modal-head h3{ margin:0; font-size:14px; font-weight:700; color:var(--ink); } .cp-modal-body{ padding:18px; overflow-y:auto; min-height:0; }
      .cp-icon-btn{ all:unset; cursor:pointer; display:flex; align-items:center; justify-content:center; color:var(--ink-soft); }
      .cp-form-grid{ display:flex; flex-direction:column; gap:10px; }
      .cp-form-grid input, .cp-form-grid select{ padding:10px 12px; border-radius:10px; border:1.4px solid var(--surface-border); background:var(--surface); font-size:13px; color:var(--ink); width:100%; }
      .cp-btn-accent{ all:unset; text-align:center; cursor:pointer; background:var(--accent); color:#fff; font-weight:700; font-size:12.5px; padding:10px 15px; border-radius:20px; box-shadow:0 8px 18px color-mix(in srgb, var(--accent) 45%, transparent); transition:transform .15s var(--ease), background .2s var(--ease); }
      .cp-btn-accent:hover{ background:var(--accent-deep); }
      .cp-btn-accent:active{ transform:scale(.96); }
      .cp-btn-accent:disabled{ opacity:.6; cursor:not-allowed; }
      .cp-form-grid--flash{ animation:formFlash .9s var(--ease); border-radius:14px; }
      @keyframes formFlash{ 0%{ box-shadow:0 0 0 0 color-mix(in srgb, var(--accent) 55%, transparent); } 60%{ box-shadow:0 0 0 10px color-mix(in srgb, var(--accent) 0%, transparent); } 100%{ box-shadow:0 0 0 0 transparent; } }

      .cp-table-wrap{ overflow-x:auto; -webkit-overflow-scrolling:touch; border-radius:10px; }
      .cp-data-table{ width:100%; min-width:560px; border-collapse:collapse; font-size:12.8px; }
      .cp-data-table th{ text-align:left; font-size:10.5px; text-transform:uppercase; letter-spacing:.05em; color:var(--ink-faint); padding:8px 10px; border-bottom:1px solid var(--panel-border); white-space:nowrap; }
      .cp-data-table td{ padding:10px; border-bottom:1px solid var(--panel-border); color:var(--ink); vertical-align:middle; }
      .cp-data-table tr:last-child td{ border-bottom:none; } .cp-table-empty{ text-align:center; color:var(--ink-faint); padding:20px; }
      .ri-th-sortable{ cursor:pointer; user-select:none; }
      .ri-th-inner{ display:inline-flex; align-items:center; gap:4px; }
      .ri-formula-note{ display:flex; align-items:center; gap:7px; font-size:11.5px; color:var(--ink-faint);
        background:var(--surface); border:1px solid var(--surface-border); padding:8px 12px; border-radius:10px; margin-bottom:12px; }
      /* Risk Insights rows — a quick-scan left-border + tint per risk band, on top of the RiskBadge cell */
      .ri-row-high{ box-shadow:inset 3px 0 0 #C0392B; background:color-mix(in srgb, #FBE4E1 30%, transparent); }
      .ri-row-medium{ box-shadow:inset 3px 0 0 #C7900F; background:color-mix(in srgb, #FBF0D9 22%, transparent); }
      .ri-row-low{ box-shadow:inset 3px 0 0 #1D8A4E; }
      .ri-tooltip-wrap{ position:relative; display:inline-flex; align-items:center; justify-content:center;
        width:22px; height:22px; border-radius:50%; color:#fff; background:rgba(255,255,255,0.18);
        border:1px solid rgba(255,255,255,0.3); cursor:help; }
      .ri-tooltip-icon{ display:flex; }
      .ri-tooltip-bubble{ position:absolute; right:0; top:calc(100% + 8px); width:260px; max-width:80vw; font-size:11.5px; line-height:1.5;
        color:#fff; background:#16232A; padding:10px 12px; border-radius:10px; box-shadow:0 14px 30px rgba(0,0,0,.25); z-index:50; text-align:left; }

      .cp-toast{ position:fixed; top:18px; right:18px; left:auto; max-width:calc(100vw - 36px); z-index:400; padding:12px 18px; border-radius:12px; font-size:13px; font-weight:600; color:#fff; background:var(--accent-deep, #12756B); box-shadow:0 14px 30px rgba(0,0,0,.2); animation:toastIn .25s ease; display:flex; align-items:center; gap:8px; }
      .cp-toast-ico{ display:flex; flex-shrink:0; width:20px; height:20px; border-radius:50%; background:rgba(255,255,255,0.2); align-items:center; justify-content:center; }
      .cp-toast--warn{ background:#B8551F; } @keyframes toastIn{ from{ opacity:0; transform:translateY(-8px);} to{ opacity:1; transform:translateY(0);} }

      .cp-switch{ position:relative; display:inline-block; width:38px; height:22px; flex-shrink:0; }
      .cp-switch input{ opacity:0; width:0; height:0; }
      .cp-switch span{ position:absolute; inset:0; background:var(--surface-border); border-radius:20px; transition:.2s; }
      .cp-switch span::before{ content:''; position:absolute; width:16px; height:16px; left:3px; top:3px; background:#fff; border-radius:50%; transition:.2s; }
      .cp-switch input:checked + span{ background:var(--accent); } .cp-switch input:checked + span::before{ transform:translateX(16px); }

      .cp-audit-list{ display:flex; flex-direction:column; gap:2px; }
      .cp-audit-row{ display:flex; align-items:flex-start; gap:10px; padding:9px 2px; border-bottom:1px dashed var(--panel-border); }
      .cp-audit-row:last-child{ border-bottom:none; } .cp-audit-dot{ width:8px; height:8px; border-radius:50%; margin-top:5px; flex-shrink:0; }
      .cp-audit-dot--admin{ background:#3A5A8C; } .cp-audit-dot--teacher{ background:#C79A3E; } .cp-audit-dot--student{ background:#1FC3B4; } .cp-audit-dot--system{ background:#8C8C8C; }
      .cp-audit-body{ flex:1; min-width:0; } .cp-audit-line{ font-size:12.5px; color:var(--ink); } .cp-audit-detail{ font-size:11.5px; color:var(--ink-faint); }
      .cp-audit-time{ font-size:10.5px; color:var(--ink-faint); white-space:nowrap; }

      .cp-select{ font-size:12.5px; padding:8px 10px; border-radius:10px; border:1.4px solid var(--surface-border); background:var(--surface); color:var(--ink); max-width:100%; }
      .cp-inline-controls{ display:flex; gap:8px; flex-wrap:wrap; }
      .cp-score-input{ width:70px; padding:6px 8px; border-radius:8px; border:1.4px solid var(--surface-border); background:var(--surface); font-size:12.5px; color:var(--ink); }

      .cp-ocr-panel{ display:flex; flex-direction:column; gap:14px; }
      .cp-ocr-drop{ display:flex; align-items:center; gap:14px; padding:22px; border:1.6px dashed var(--surface-border); border-radius:14px; cursor:pointer; color:var(--ink-soft); background:var(--surface); flex-wrap:wrap; }
      .cp-ocr-drop:hover{ border-color:var(--accent); color:var(--accent-deep); }
      .cp-ocr-drop strong{ display:block; color:var(--ink); font-size:13.5px; } .cp-ocr-drop span{ font-size:12px; }
      .cp-ocr-processing{ display:flex; align-items:center; gap:16px; padding:20px; background:var(--surface); border-radius:14px; flex-wrap:wrap; }
      .cp-spinner{ width:30px; height:30px; border-radius:50%; border:3px solid var(--surface-border); border-top-color:var(--accent); animation:spin 0.8s linear infinite; flex-shrink:0; }
      @keyframes spin{ to{ transform:rotate(360deg); } }
      .cp-ocr-steps div{ font-size:12.5px; color:var(--ink-faint); padding:2px 0; }
      .cp-ocr-steps div.is-active{ color:var(--ink); font-weight:700; } .cp-ocr-steps div.is-done{ color:var(--accent-deep); text-decoration:line-through; opacity:.7; }
      .cp-ocr-summary{ font-size:12.5px; color:var(--ink-soft); } .cp-ocr-actions{ display:flex; justify-content:flex-end; gap:10px; margin-top:14px; flex-wrap:wrap; }
      .cp-ocr-source-banner{ display:flex; align-items:flex-start; gap:8px; padding:10px 12px; border-radius:12px; font-size:12px; line-height:1.5; margin-bottom:10px; }
      .cp-ocr-source-banner--real{ background:var(--green-soft, rgba(52,199,89,.12)); color:var(--green-deep, #1a7f37); }
      .cp-ocr-source-banner--sim{ background:var(--amber-soft, rgba(255,159,10,.14)); color:var(--amber-deep, #9a5b00); }

      /* ---- teacher: new module styling ---- */
      .cp-hero--teacher{ background:linear-gradient(125deg, var(--accent, #C79A3E), var(--accent-deep, #8A6A22) 70%); }
      .cp-hero--teacher h2{ font-family:'Fraunces', serif; font-weight:600; }

      .cp-gradebook-meta{ display:flex; align-items:center; gap:12px; margin-bottom:12px; }
      .cp-gradebook-bar{ flex:1; height:7px; border-radius:20px; background:var(--surface-border); overflow:hidden; }
      .cp-gradebook-bar-fill{ height:100%; background:linear-gradient(90deg, var(--accent), var(--accent-deep)); border-radius:20px; transition:width .5s var(--ease); }

      .cp-search-input{ padding:8px 14px; border-radius:20px; border:1.4px solid var(--surface-border); background:var(--surface); font-size:12.5px; color:var(--ink); min-width:0; width:100%; max-width:220px; }

      .cp-profile-detail{ display:flex; gap:24px; align-items:flex-start; }
      .cp-profile-detail-avatar{ width:76px; height:76px; border-radius:50%; flex-shrink:0; background:linear-gradient(135deg, var(--accent), var(--accent-deep)); color:#fff; font-size:24px; font-weight:800; display:flex; align-items:center; justify-content:center; box-shadow:0 14px 26px rgba(0,0,0,0.16); }
      .cp-profile-detail-grid{ flex:1; min-width:0; display:grid; grid-template-columns:1fr 1fr; gap:14px 20px; }
      .cp-pd-field{ display:flex; flex-direction:column; gap:5px; font-size:11.5px; color:var(--ink-faint); min-width:0; }
      .cp-pd-field strong{ font-size:13.5px; font-weight:600; color:var(--ink); word-break:break-word; }
      .cp-pd-field input, .cp-pd-field textarea{ padding:9px 11px; border-radius:10px; border:1.4px solid var(--surface-border); background:var(--surface); font-size:13px; color:var(--ink); font-family:inherit; width:100%; }
      .cp-pd-field--wide{ grid-column:1 / -1; }
      @media (max-width: 700px){ .cp-profile-detail{ flex-direction:column; } .cp-profile-detail-grid{ grid-template-columns:1fr; } }

      .cp-subject-grid{ display:grid; grid-template-columns:repeat(auto-fill,minmax(240px,1fr)); gap:16px; }
      .cp-subject-card{ background:var(--surface); border:1px solid var(--surface-border); border-radius:16px; padding:16px; display:flex; flex-direction:column; gap:8px; min-width:0;
        opacity:0; transform:translateY(10px); animation:rowIn .5s var(--ease) forwards; animation-delay:calc(var(--i) * 80ms + .15s); }
      .cp-subject-top{ display:flex; align-items:center; justify-content:space-between; }
      .cp-subject-code{ font-family:'JetBrains Mono', monospace; font-size:11px; font-weight:700; color:var(--accent-deep); background:var(--accent-soft); padding:3px 8px; border-radius:8px; }
      .cp-subject-card h4{ font-family:'Fraunces', serif; font-size:16px; font-weight:600; margin:2px 0 0; color:var(--ink); }
      .cp-subject-dept{ font-size:11.5px; color:var(--ink-faint); margin-bottom:4px; }
      .cp-subject-progress-label{ display:flex; justify-content:space-between; font-size:11px; font-weight:600; color:var(--ink-soft); }
      .cp-subject-next{ font-size:11.5px; color:var(--ink-faint); margin-top:2px; }
      .cp-subject-actions{ display:flex; gap:8px; margin-top:6px; flex-wrap:wrap; }

      .cp-timetable{ display:grid; grid-template-columns:repeat(6,1fr); gap:10px; }
      .cp-tt-col{ display:flex; flex-direction:column; gap:8px; opacity:0; transform:translateY(8px); animation:rowIn .45s var(--ease) forwards; animation-delay:calc(var(--i) * 70ms + .1s); min-width:0; }
      .cp-tt-day{ text-align:center; font-family:'Fraunces', serif; font-weight:600; font-size:13px; color:var(--accent-deep); padding-bottom:6px; border-bottom:1.4px solid var(--panel-border); }
      .cp-tt-slot{ background:var(--surface); border:1px solid var(--surface-border); border-radius:11px; padding:8px 9px; text-align:center; }
      .cp-tt-time{ font-size:10px; color:var(--ink-faint); font-weight:600; } .cp-tt-course{ font-size:12px; font-weight:700; color:var(--ink); font-family:'JetBrains Mono', monospace; }
      .cp-tt-room{ font-size:10.5px; color:var(--ink-soft); } .cp-tt-empty{ text-align:center; font-size:11px; color:var(--ink-faint); padding:14px 0; }
      @media (max-width: 900px){ .cp-timetable{ grid-template-columns:repeat(3,1fr); } }
      @media (max-width: 520px){ .cp-timetable{ grid-template-columns:repeat(2,1fr); } }

      .cp-notice-composer{ display:flex; flex-direction:column; gap:10px; }
      .cp-notice-composer textarea{ padding:11px 13px; border-radius:12px; border:1.4px solid var(--surface-border); background:var(--surface); font-size:13px; color:var(--ink); font-family:inherit; resize:vertical; width:100%; }

      .cp-leave-dates{ display:flex; gap:12px; flex-wrap:wrap; }
      .cp-leave-dates label{ flex:1; min-width:140px; display:flex; flex-direction:column; gap:5px; font-size:11.5px; color:var(--ink-faint); }
      .cp-leave-dates input{ padding:9px 11px; border-radius:10px; border:1.4px solid var(--surface-border); background:var(--surface); font-size:13px; color:var(--ink); width:100%; }
      .cp-form-grid textarea{ padding:10px 12px; border-radius:10px; border:1.4px solid var(--surface-border); background:var(--surface); font-size:13px; color:var(--ink); font-family:inherit; resize:vertical; width:100%; }

      .cp-grv-desc{ display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden; max-width:280px; font-size:12.5px; color:var(--ink); }
      .cp-autotag-hint{ display:flex; align-items:center; gap:8px; flex-wrap:wrap; font-size:11.5px; padding:8px 10px; border-radius:10px; background:var(--accent-soft); color:var(--accent-deep); }
      .cp-autotag-label{ font-weight:700; }
      .cp-autotag-value{ font-family:'JetBrains Mono', monospace; font-weight:600; }

      .cp-shell--teacher h1, .cp-shell--teacher h2, .cp-shell--teacher h3, .cp-shell--teacher .cp-brand-name{ font-family:'Fraunces', serif; font-weight:600; }
      .cp-shell--teacher .cp-sidebar{ background:linear-gradient(180deg, color-mix(in srgb, var(--accent-soft) 45%, var(--surface)), transparent); }
      .cp-shell--teacher .cp-card{ border-width:1.4px; }

      .cp-shell--admin .cp-sidebar{ background:linear-gradient(180deg, var(--accent-deep), color-mix(in srgb, var(--accent-deep) 80%, black)); border-right:none; }
      .cp-shell--admin .cp-brand-name, .cp-shell--admin .cp-profile-card-name{ color:#fff; }
      .cp-shell--admin .cp-profile-card-id, .cp-shell--admin .cp-nav-label{ color:rgba(255,255,255,.55); }
      .cp-shell--admin .cp-nav-item{ color:rgba(255,255,255,.78); }
      .cp-shell--admin .cp-nav-item:hover{ background:rgba(255,255,255,.1); color:#fff; }
      .cp-shell--admin .cp-nav-item.is-active{ background:rgba(255,255,255,.16); box-shadow:none; }
      .cp-shell--admin .cp-sidebar-logout{ background:rgba(255,255,255,.08); border-color:rgba(255,255,255,.15); color:rgba(255,255,255,.78); }
      .cp-shell--admin .cp-sidebar-foot{ color:rgba(255,255,255,.4); border-top-color:rgba(255,255,255,.12); }
      .cp-shell--admin .cp-profile-card{ border-bottom-color:rgba(255,255,255,.12); }
      .cp-shell--admin .cp-profile-card-avatar{ border-color:rgba(255,255,255,.25); }
      .cp-shell--admin .cp-stat-value, .cp-shell--admin .cp-audit-time{ font-family:'JetBrains Mono', monospace; }
      .cp-shell--admin .cp-frame{ --radius-lg:16px; --radius-md:12px; }

      /* ===========================================================
         RESPONSIVE / FIT-TO-SCREEN — collapsible sidebar on narrow
         viewports so nothing gets clipped and only the content area
         scrolls (the shell itself never grows past the viewport).
      =========================================================== */
      @media (max-width: 960px){
        .cp-shell{ padding:0; }
        .cp-frame{ border-radius:0; border-width:0 0 0 0; }
        .cp-hamburger{ all:unset; box-sizing:border-box; display:flex; align-items:center; justify-content:center; width:36px; height:36px; border-radius:10px;
          background:var(--surface); border:1px solid var(--surface-border); color:var(--ink-soft); cursor:pointer; flex-shrink:0; }
        .cp-hamburger:hover{ color:var(--ink); }
        .cp-sidebar{ position:fixed; top:0; bottom:0; left:0; z-index:200; width:min(80vw, 280px); max-width:280px; height:100vh; height:100dvh;
          background:var(--bg); box-shadow:0 0 0 1px var(--panel-border); transform:translateX(-100%); transition:transform .3s var(--ease); border-right:1px solid var(--panel-border); }
        .cp-shell--admin .cp-sidebar{ background:linear-gradient(180deg, var(--accent-deep), color-mix(in srgb, var(--accent-deep) 80%, black)); }
        .cp-sidebar.is-open{ transform:translateX(0); }
        .cp-sidebar-veil{ display:block; position:fixed; inset:0; background:rgba(6,14,18,.5); z-index:190; animation:toastIn .2s ease; }
        .cp-sidebar-close{ display:flex; align-items:center; justify-content:center; margin-left:auto; width:28px; height:28px; border-radius:50%; color:var(--ink-soft); cursor:pointer; background:transparent; border:none; }
        .cp-topbar-title p{ display:none; }
        .cp-main{ padding:16px 16px 24px; }
        .cp-topbar{ padding:10px 12px; margin-bottom:14px; }
      }
      @media (max-width: 600px){
        .cp-topbar-actions{ gap:6px; }
        .cp-profile-text{ display:none; }
        .cp-topbar .cp-pill--ghost .cp-pill-label span{ display:none; }
        .cp-hero{ padding:22px 18px; }
        .cp-hero-text h2{ font-size:21px; }
        .cp-hero-stats{ gap:16px; }
        .cp-card-body{ padding:14px; }
      }

      /* ===========================================================
         AUTH SCREEN (a2-*) — full-bleed split card, role-aware
      =========================================================== */
      .a2-page{ position:fixed; inset:0; z-index:5; --a2-ink:#0F2A26; --a2-ink-soft:#5C7A73; --a2-line:#DCEBE5; --a2-paper:#F3FAF7; --a2-white:#ffffff;
        --a2-glass:rgba(255,255,255,0.88); --a2-glass-border:rgba(255,255,255,0.8);
        --a2-mint1:#CFEDE3; --a2-mint2:#A9E0D2; --a2-mint3:#8FD6C6; --a2-shape-opacity:.55; --a2-shadow:rgba(14,60,50,.35);
        font-family:'Manrope', sans-serif; color:var(--a2-ink); min-height:100vh; min-height:100dvh; overflow-y:auto; overflow-x:hidden; -webkit-overflow-scrolling:touch;
        background: radial-gradient(1200px 800px at 85% 10%, var(--a2-mint3) 0%, transparent 55%), radial-gradient(1000px 900px at 10% 95%, var(--a2-mint3) 0%, transparent 50%), linear-gradient(160deg, #EAF7F2 0%, var(--a2-mint1) 60%, var(--a2-mint2) 100%);
        display:flex; flex-direction:column; align-items:center; justify-content:center; padding:48px 24px;
        /* When the card grows taller than the viewport (an error message or the
           demo-credentials panel expanding it), plain center-alignment clips the
           start edge and makes it unreachable even with a scrollbar — "safe
           center" falls back to start-alignment instead of clipping, so the
           whole card always stays scrollable into view. Unsupported browsers
           just keep the plain "center" above, which is still fine. */
        align-items:safe center; justify-content:safe center; }
      .cp-shell[data-theme="dark"] .a2-page{ --a2-ink:#EAF6F1; --a2-ink-soft:#8FAFA7; --a2-line:#1C3A34; --a2-paper:#0F2723; --a2-white:#132E29;
        --a2-glass:rgba(19,46,41,0.86); --a2-glass-border:rgba(255,255,255,0.1);
        --a2-mint1:#0A1F1B; --a2-mint2:#0D2A24; --a2-mint3:#11362E; --a2-shape-opacity:.28; --a2-shadow:rgba(0,0,0,.55);
        background: radial-gradient(1200px 800px at 85% 10%, var(--a2-mint3) 0%, transparent 55%), radial-gradient(1000px 900px at 10% 95%, var(--a2-mint3) 0%, transparent 50%), linear-gradient(160deg, #081714 0%, var(--a2-mint1) 60%, var(--a2-mint2) 100%); }
      .a2-shape{ position:fixed; border-radius:50%; filter:blur(2px); opacity:var(--a2-shape-opacity); animation:a2Drift 14s ease-in-out infinite; pointer-events:none; }
      .a2-shape--1{ width:420px; height:420px; background:var(--a2-mint3); top:-120px; right:-120px; }
      .a2-shape--2{ width:300px; height:300px; background:var(--a2-mint2); bottom:-90px; left:-90px; animation-delay:2s; }
      .a2-shape--3{ width:170px; height:170px; background:var(--a2-accent); opacity:calc(var(--a2-shape-opacity) * .6); top:60%; right:8%; animation-delay:4s; }
      .a2-shape--4{ width:120px; height:120px; background:var(--a2-accent); opacity:calc(var(--a2-shape-opacity) * .5); top:8%; left:6%; animation-delay:1.4s; }
      @keyframes a2Drift{ 0%,100%{ transform:translateY(0) scale(1);} 50%{ transform:translateY(-22px) scale(1.04);} }
      .a2-shell{ position:relative; z-index:2; width:100%; max-width:1120px; display:flex; flex-direction:column; align-items:center; gap:22px; }
      .a2-card{ width:100%; max-width:1120px; min-height:min(680px, 86vh); background:var(--a2-glass); border:1px solid var(--a2-glass-border);
        border-radius:28px; box-shadow:0 40px 90px -30px var(--a2-shadow), inset 0 1px 0 rgba(255,255,255,0.45); display:flex; flex-direction:column; overflow:hidden;
        opacity:0; transform:translateY(18px); animation:a2CardIn .7s cubic-bezier(.2,.8,.2,1) forwards; }
      @keyframes a2CardIn{ to{ opacity:1; transform:translateY(0);} }
      .a2-page-foot{ display:flex; align-items:center; gap:10px; color:var(--a2-ink-soft); font-size:12.5px; opacity:0; animation:a2CardIn .7s cubic-bezier(.2,.8,.2,1) .15s forwards; flex-wrap:wrap; justify-content:center; text-align:center; }
      .a2-dot{ width:4px; height:4px; border-radius:50%; background:var(--a2-ink-soft); opacity:.6; }
      .a2-nav{ display:flex; align-items:center; justify-content:space-between; padding:24px 42px; gap:12px; flex-wrap:wrap; }
      .a2-brand{ display:flex; align-items:center; gap:11px; } .a2-brand-mark{ position:relative; width:26px; height:20px; flex-shrink:0; }
      .a2-brand-name{ font-family:'Fraunces', serif; font-weight:600; font-size:19px; color:var(--a2-ink); } .a2-pilot{ color:var(--a2-accent); }
      .a2-nav-links{ display:flex; gap:32px; list-style:none; margin:0; padding:0; } .a2-nav-links li{ font-size:13.5px; font-weight:600; color:var(--a2-ink-soft); }
      .a2-nav-link-btn{ background:none; border:none; padding:0; margin:0; font:inherit; font-size:13.5px; font-weight:600; color:var(--a2-ink-soft); cursor:pointer; } .a2-nav-link-btn:hover{ color:var(--a2-ink); }
      .a2-nav-right{ display:flex; align-items:center; gap:12px; }
      .a2-badge{ padding:9px 18px; border-radius:999px; background:var(--a2-accent); color:#fff; font-size:12px; font-weight:800; white-space:nowrap; }
      .a2-theme-toggle{ all:unset; box-sizing:border-box; width:38px; height:38px; border-radius:50%; flex-shrink:0; cursor:pointer; border:1.5px solid var(--a2-line); background:var(--a2-paper); display:flex; align-items:center; justify-content:center; color:var(--a2-ink-soft); }
      .a2-theme-toggle:hover{ border-color:var(--a2-accent); color:var(--a2-accent); }
      .a2-grid{ display:grid; grid-template-columns:1fr 1fr; flex:1; min-height:0; }
      .a2-panel-form{ display:flex; flex-direction:column; justify-content:center; padding:10px min(6.5vw, 90px) 36px; min-width:0; }
      .a2-form-inner{ width:100%; max-width:400px; margin:0 auto; }
      .a2-tabs{ display:flex; gap:30px; border-bottom:1.5px solid var(--a2-line); margin-bottom:22px; position:relative; }
      .a2-tab{ all:unset; box-sizing:border-box; cursor:pointer; font-weight:700; font-size:16px; color:#B9C7C2; padding:0 0 13px; }
      .a2-tab.is-active{ color:var(--a2-accent); }
      .a2-tab-underline{ position:absolute; bottom:-1.5px; left:0; height:2.5px; width:50%; background:var(--a2-accent); border-radius:2px; transition:transform .35s cubic-bezier(.4,0,.2,1); }
      .a2-field-label{ font-size:11.5px; font-weight:800; text-transform:uppercase; letter-spacing:.08em; color:var(--a2-ink-soft); margin-bottom:9px; display:block; }
      .a2-role-select{ position:relative; margin-bottom:16px; }
      .a2-role-trigger{ all:unset; box-sizing:border-box; width:100%; display:flex; align-items:center; gap:12px; padding:12px 14px; border:1.5px solid var(--a2-line); border-radius:999px; background:var(--a2-paper); cursor:pointer; }
      .a2-role-trigger.is-open{ border-color:var(--a2-accent); box-shadow:0 0 0 3px color-mix(in srgb, var(--a2-accent) 16%, transparent); }
      .a2-role-trigger-icon{ width:32px; height:32px; border-radius:50%; flex-shrink:0; background:var(--a2-accent-soft); color:var(--a2-accent); display:flex; align-items:center; justify-content:center; }
      .a2-role-trigger-text{ flex:1; min-width:0; text-align:left; } .a2-rt-label{ display:block; font-weight:700; font-size:14px; color:var(--a2-ink); } .a2-rt-sub{ display:block; font-size:11px; color:var(--a2-ink-soft); }
      .a2-chevron{ display:flex; color:var(--a2-ink-soft); transition:transform .3s cubic-bezier(.4,0,.2,1); flex-shrink:0; } .a2-chevron.is-open{ transform:rotate(180deg); color:var(--a2-accent); }
      .a2-role-panel{ position:absolute; left:0; right:0; top:calc(100% + 8px); background:var(--a2-white); border:1.5px solid var(--a2-line); border-radius:16px; box-shadow:0 20px 40px -18px rgba(16,26,48,0.28); padding:7px; z-index:20; opacity:0; transform:translateY(-8px); pointer-events:none; transition:opacity .22s ease, transform .22s cubic-bezier(.2,.8,.2,1); max-height:60vh; overflow-y:auto; }
      .a2-role-panel.is-open{ opacity:1; transform:translateY(0); pointer-events:auto; }
      .a2-role-option{ all:unset; box-sizing:border-box; display:flex; align-items:center; gap:12px; width:100%; padding:10px; border-radius:12px; cursor:pointer; text-align:left; }
      .a2-role-option:hover{ background:var(--a2-paper); } .a2-role-option.is-selected{ background:var(--a2-accent-soft); }
      .a2-role-opt-icon{ width:30px; height:30px; border-radius:50%; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
      .a2-role-opt-text{ flex:1; min-width:0; } .a2-ot-label{ display:block; font-weight:700; font-size:13.5px; color:var(--a2-ink); } .a2-ot-sub{ display:block; font-size:11px; color:var(--a2-ink-soft); }
      .a2-check{ margin-left:auto; color:var(--a2-accent); display:flex; flex-shrink:0; }
      .a2-field{ position:relative; display:block; margin-bottom:14px; }
      .a2-field input{ width:100%; box-sizing:border-box; padding:14px 16px 14px 44px; border:1.5px solid var(--a2-line); border-radius:999px; font-size:14.5px; background:var(--a2-paper); color:var(--a2-ink); outline:none; }
      .a2-field input:focus{ border-color:var(--a2-accent); background:var(--a2-white); box-shadow:0 0 0 3px color-mix(in srgb, var(--a2-accent) 16%, transparent); }
      .a2-field-icon{ position:absolute; left:15px; top:50%; transform:translateY(-50%); width:16px; height:16px; color:#9DB3AC; pointer-events:none; display:flex; }
      .a2-field--pw input{ padding-right:44px; }
      .a2-field-toggle{ position:absolute; right:6px; top:50%; transform:translateY(-50%); width:32px; height:32px; border:none; background:transparent; color:#9DB3AC; display:flex; align-items:center; justify-content:center; border-radius:999px; cursor:pointer; transition:color .15s ease, background .15s ease; }
      .a2-field-toggle:hover{ color:var(--a2-accent); background:color-mix(in srgb, var(--a2-accent) 10%, transparent); }
      .a2-role-note{ margin:-4px 0 12px; font-size:12px; color:var(--a2-ink-soft); }
      .a2-submit{ all:unset; box-sizing:border-box; width:100%; text-align:center; margin-top:4px; padding:15px; border-radius:999px; background:var(--a2-accent); color:#fff; font-weight:800; font-size:14.5px; cursor:pointer; box-shadow:0 14px 26px -12px color-mix(in srgb, var(--a2-accent) 70%, transparent); }
      .a2-submit:hover{ background:var(--a2-accent-deep); } .a2-submit:disabled{ opacity:.6; cursor:default; }
      .a2-error{ font-size:13px; color:#a13d3d; background:#fbeaea; border:1px solid #f0cccc; padding:10px 13px; border-radius:10px; margin-bottom:14px; }
      .cp-shell[data-theme="dark"] .a2-error{ background:rgba(161,61,61,0.18); border-color:rgba(161,61,61,0.4); color:#ff9c9c; }
      .a2-switch{ text-align:center; font-size:12.5px; color:var(--a2-ink-soft); margin-top:16px; } .a2-switch button{ all:unset; cursor:pointer; color:var(--a2-accent); font-weight:700; }
      .a2-foot-note{ padding-top:18px; font-size:11px; color:var(--a2-ink-soft); text-align:center; line-height:1.6; }
      .a2-foot-note code{ background:var(--a2-paper); padding:1px 5px; border-radius:5px; }

      /* password strength hint (Prompt 7) */
      .a2-pw-hint{ margin:-6px 0 14px; font-size:11px; color:var(--a2-ink-soft); }
      .a2-pw-hint--idle{ line-height:1.4; }
      .a2-pw-bar{ height:5px; border-radius:20px; background:var(--a2-line); overflow:hidden; margin-bottom:5px; }
      .a2-pw-bar-fill{ height:100%; border-radius:20px; transition:width .25s ease, background .25s ease; }
      .a2-pw-bar-fill--weak{ background:#D9534F; }
      .a2-pw-bar-fill--mid{ background:#E8A33D; }
      .a2-pw-bar-fill--good{ background:#4FA37A; }
      .a2-pw-bar-fill--strong{ background:var(--a2-accent); }
      .a2-pw-label--weak{ color:#B23A2C; } .a2-pw-label--mid{ color:#8A6A22; }
      .a2-pw-label--good, .a2-pw-label--strong{ color:#1D8A4E; }

      /* collapsible demo credentials (Prompt 7) */
      .a2-demo-creds{ padding-top:16px; }
      .a2-demo-toggle{ all:unset; box-sizing:border-box; cursor:pointer; display:inline-flex; align-items:center; gap:6px;
        font-size:11.5px; font-weight:700; color:var(--a2-ink-soft); }
      .a2-demo-toggle:hover{ color:var(--a2-accent); }
      .a2-demo-panel{ margin-top:10px; padding:12px 14px; border-radius:12px; background:var(--a2-paper); border:1px solid var(--a2-line); }
      .a2-demo-row{ display:flex; align-items:center; gap:8px; font-size:11.5px; color:var(--a2-ink-soft); padding:3px 0; flex-wrap:wrap; }
      .a2-demo-row span{ flex-shrink:0; width:52px; font-weight:700; color:var(--a2-ink); }
      .a2-demo-row code{ background:var(--a2-white); padding:1px 6px; border-radius:5px; }
      .a2-demo-warn{ margin-top:8px; font-size:10.5px; color:var(--a2-ink-soft); opacity:.8; }

      .a2-panel-visual{ position:relative; overflow:hidden; display:flex; align-items:center; justify-content:center; min-height:420px; padding:40px 24px; }
      .a2-blob{ position:absolute; inset:-6%; background:linear-gradient(150deg, var(--a2-accent) 0%, var(--a2-accent-deep) 100%); border-radius:38% 62% 61% 39% / 42% 46% 54% 58%; animation:a2Morph 11s ease-in-out infinite; }
      @keyframes a2Morph{ 0%,100%{ border-radius:38% 62% 61% 39% / 42% 46% 54% 58%; } 33%{ border-radius:60% 40% 42% 58% / 55% 40% 60% 45%; } 66%{ border-radius:40% 60% 55% 45% / 60% 48% 52% 40%; } }
      .a2-orbit{ position:absolute; width:66%; height:66%; border:1.5px dashed rgba(255,255,255,.32); border-radius:50%; animation:a2Spin 28s linear infinite; }
      .a2-orbit2{ position:absolute; width:84%; height:84%; border:1px dashed rgba(255,255,255,.2); border-radius:50%; animation:a2Spin 42s linear infinite reverse; }
      @keyframes a2Spin{ to{ transform:rotate(360deg); } }
      .a2-visual-content{ position:relative; z-index:2; display:flex; flex-direction:column; align-items:center; gap:26px; width:100%; }
      .a2-stage{ position:relative; width:min(280px, 82%); height:200px; flex-shrink:0; }
      .a2-stage-item{ position:absolute; animation:a2Float var(--dur,4.5s) ease-in-out infinite; animation-delay:var(--delay,0s); filter:drop-shadow(0 14px 20px rgba(10,40,34,.22)); }
      @keyframes a2Float{ 0%,100%{ transform:translateY(0) rotate(var(--rot,0deg)); } 50%{ transform:translateY(-14px) rotate(calc(var(--rot,0deg) + 2deg)); } }
      .a2-doc{ width:52px; height:64px; background:#fff; border-radius:9px; padding:9px 8px; display:flex; flex-direction:column; gap:5px; }
      .a2-doc span{ display:block; height:4px; border-radius:2px; background:var(--a2-accent); opacity:.85; }
      .a2-doc span:nth-child(1){ width:85%; } .a2-doc span:nth-child(2){ width:100%; } .a2-doc span:nth-child(3){ width:60%; }
      .a2-folder{ width:64px; height:48px; background:var(--a2-accent); border-radius:3px 12px 12px 12px; position:relative; opacity:0.92; }
      .a2-folder::before{ content:''; position:absolute; top:-9px; left:0; width:30px; height:11px; background:var(--a2-accent); border-radius:7px 7px 0 0; }
      .a2-folder--alt{ background:var(--a2-accent-deep); } .a2-folder--alt::before{ background:var(--a2-accent-deep); }
      .a2-chip{ width:44px; height:44px; border-radius:50%; background:var(--a2-accent-deep); display:flex; align-items:center; justify-content:center; color:#fff; }
      .a2-center{ width:78px; height:78px; border-radius:22px; background:#fff; display:flex; align-items:center; justify-content:center; color:var(--a2-accent); box-shadow:0 18px 30px rgba(10,40,34,.28); z-index:3; }
      .a2-particles span{ position:absolute; width:5px; height:5px; background:rgba(255,255,255,.55); border-radius:50%; animation:a2Drift2 6s ease-in-out infinite; }
      .a2-particles span:nth-child(1){ top:10%; left:12%; } .a2-particles span:nth-child(2){ top:78%; left:10%; animation-delay:1.2s; }
      .a2-particles span:nth-child(3){ top:14%; left:88%; animation-delay:2.1s; } .a2-particles span:nth-child(4){ top:82%; left:86%; animation-delay:3s; }
      .a2-particles span:nth-child(5){ top:46%; left:94%; animation-delay:.6s; }
      @keyframes a2Drift2{ 0%,100%{ transform:translateY(0) scale(1); opacity:.6;} 50%{ transform:translateY(-14px) scale(1.3); opacity:1;} }
      .a2-role-caption{ text-align:center; position:relative; z-index:2; }
      .a2-role-caption h3{ font-family:'Fraunces', serif; color:#fff; font-weight:600; font-size:22px; margin:0 0 7px; }
      .a2-role-caption p{ color:rgba(255,255,255,.85); font-size:13px; margin:0 auto; max-width:260px; line-height:1.55; }
      @media (max-width: 900px){
        .a2-grid{ grid-template-columns:1fr; } .a2-panel-visual{ order:-1; min-height:260px; } .a2-nav-links{ display:none; }
        .a2-nav{ padding:18px 22px; } .a2-panel-form{ padding:24px 22px; } .a2-page{ padding:20px 14px; } .a2-card{ border-radius:20px; min-height:auto; }
      }
      @media (max-width: 480px){
        .a2-nav{ padding:14px 16px; } .a2-badge{ padding:7px 12px; font-size:11px; }
        .a2-panel-visual{ min-height:180px; padding:24px 16px; }
        .a2-stage{ height:150px; }
        .a2-role-caption h3{ font-size:18px; }
      }
      @media (prefers-reduced-motion: reduce){
        *{ animation-duration:0.001ms !important; animation-iteration-count:1 !important; transition-duration:0.001ms !important; }
        .cp-blob, .a2-shape{ animation:none !important; }
      }

      /* ===========================================================
         AI COPILOT WIDGET (cw-*)
      =========================================================== */
      .cw-root{ position:fixed; right:26px; bottom:26px; z-index:500; font-family:'Inter', system-ui, sans-serif; }

      .cw-fab{ all:unset; box-sizing:border-box; cursor:pointer; position:relative; width:56px; height:56px; border-radius:50%;
        display:flex; align-items:center; justify-content:center; color:#fff;
        background:linear-gradient(135deg, var(--cw-accent), var(--cw-accent-deep));
        box-shadow:0 16px 32px rgba(0,0,0,0.28), inset 0 1px 0 rgba(255,255,255,0.35);
        transition:transform .22s cubic-bezier(.22,1,.36,1); }
      .cw-fab:hover{ transform:translateY(-3px) scale(1.04); }
      .cw-fab-ping{ position:absolute; inset:-4px; border-radius:50%; border:2px solid var(--cw-accent); opacity:.55; animation:cwPing 2.4s ease-out infinite; }
      @keyframes cwPing{ 0%{ transform:scale(0.85); opacity:.55; } 100%{ transform:scale(1.35); opacity:0; } }

      .cw-panel{ position:fixed; right:22px; bottom:22px; width:min(380px, calc(100vw - 32px)); height:min(560px, calc(100vh - 48px)); height:min(560px, calc(100dvh - 48px));
        display:flex; flex-direction:column; overflow:hidden; border-radius:22px;
        background:var(--glass-strong, rgba(255,255,255,0.92)); border:1px solid var(--glass-border, rgba(255,255,255,0.6));
        box-shadow:0 30px 70px rgba(10,30,28,0.32);
        opacity:0; transform:translateY(16px) scale(.97); animation:cwPanelIn .32s cubic-bezier(.22,1,.36,1) forwards; }
      @keyframes cwPanelIn{ to{ opacity:1; transform:translateY(0) scale(1); } }

      .cw-head{ display:flex; align-items:center; justify-content:space-between; gap:10px; padding:14px 14px 12px;
        background:linear-gradient(120deg, var(--cw-accent-deep), color-mix(in srgb, var(--cw-accent-deep) 70%, black)); color:#fff; flex-shrink:0; }
      .cw-head-left{ display:flex; align-items:center; gap:10px; min-width:0; }
      .cw-head-avatar{ width:32px; height:32px; border-radius:50%; background:rgba(255,255,255,0.18); border:1px solid rgba(255,255,255,0.3);
        display:flex; align-items:center; justify-content:center; flex-shrink:0; }
      .cw-head-title{ font-weight:700; font-size:13.5px; font-family:'Poppins', sans-serif; }
      .cw-head-sub{ margin-top:2px; }
      .cw-proto-badge{ display:inline-flex; align-items:center; gap:4px; font-size:9.5px; font-weight:700; letter-spacing:.02em;
        color:#fff; background:rgba(255,255,255,0.18); border:1px solid rgba(255,255,255,0.3); padding:2.5px 8px; border-radius:20px; white-space:nowrap; }
      .cw-icon-btn{ all:unset; cursor:pointer; width:28px; height:28px; border-radius:50%; flex-shrink:0; display:flex; align-items:center; justify-content:center;
        color:rgba(255,255,255,0.85); }
      .cw-icon-btn:hover{ background:rgba(255,255,255,0.14); color:#fff; }

      .cw-disclaimer{ flex-shrink:0; font-size:10.5px; line-height:1.4; color:var(--ink-soft, #5C7A73); background:var(--cw-accent-soft);
        padding:8px 14px; border-bottom:1px solid var(--panel-border, rgba(17,40,45,0.1)); }

      .cw-messages{ flex:1; min-height:0; overflow-y:auto; padding:14px; display:flex; flex-direction:column; gap:10px; }
      .cw-msg{ display:flex; align-items:flex-end; gap:7px; max-width:88%; animation:cwMsgIn .28s var(--ease); }
      .cw-msg--bot{ align-self:flex-start; }
      .cw-msg--user{ align-self:flex-end; flex-direction:row-reverse; }
      @keyframes cwMsgIn{ from{ opacity:0; transform:translateY(6px) scale(.97);} to{ opacity:1; transform:translateY(0) scale(1);} }
      .cw-msg-avatar{ width:22px; height:22px; border-radius:50%; flex-shrink:0; display:flex; align-items:center; justify-content:center;
        background:var(--cw-accent-soft); color:var(--cw-accent-deep); }
      .cw-bubble{ font-size:12.8px; line-height:1.5; padding:9px 12px; border-radius:14px; word-break:break-word; }
      .cw-msg--bot .cw-bubble{ background:var(--surface, rgba(255,255,255,0.8)); border:1px solid var(--surface-border, rgba(17,40,45,0.14)); color:var(--ink, #16232A); border-bottom-left-radius:4px; }
      .cw-msg--user .cw-bubble{ background:linear-gradient(120deg, var(--cw-accent), var(--cw-accent-deep)); color:#fff; border-bottom-right-radius:4px; }
      .cw-bubble--typing{ display:flex; align-items:center; gap:4px; padding:11px 13px; }
      .cw-bubble--typing span{ width:5px; height:5px; border-radius:50%; background:var(--ink-faint, #7C8D93); animation:cwTyping 1.1s ease-in-out infinite; }
      .cw-bubble--typing span:nth-child(2){ animation-delay:.15s; } .cw-bubble--typing span:nth-child(3){ animation-delay:.3s; }
      @keyframes cwTyping{ 0%,60%,100%{ transform:translateY(0); opacity:.5; } 30%{ transform:translateY(-4px); opacity:1; } }

      .cw-inputbar{ flex-shrink:0; display:flex; align-items:center; gap:8px; padding:10px 12px; border-top:1px solid var(--panel-border, rgba(17,40,45,0.1)); }
      .cw-inputbar input{ flex:1; min-width:0; padding:10px 13px; border-radius:20px; border:1.4px solid var(--surface-border, rgba(17,40,45,0.14));
        background:var(--surface, rgba(255,255,255,0.8)); font-size:12.8px; color:var(--ink, #16232A); outline:none; }
      .cw-inputbar input:focus{ border-color:var(--cw-accent); }
      .cw-send-btn{ all:unset; box-sizing:border-box; cursor:pointer; flex-shrink:0; width:34px; height:34px; border-radius:50%;
        display:flex; align-items:center; justify-content:center; color:#fff; background:linear-gradient(135deg, var(--cw-accent), var(--cw-accent-deep));
        transition:transform .18s ease, opacity .18s ease; }
      .cw-send-btn:hover{ transform:scale(1.06); }
      .cw-send-btn:disabled{ opacity:.45; cursor:not-allowed; }

      @media (max-width: 480px){
        .cw-root{ right:14px; bottom:14px; }
        .cw-fab{ width:50px; height:50px; }
        .cw-panel{ right:8px; bottom:8px; width:calc(100vw - 16px); height:min(76vh, 560px); border-radius:18px; }
      }

      /* ---- live notifications bell ---- */
      .cp-bell-wrap{ position:relative; }
      .cp-bell{ position:relative; width:38px; height:38px; border-radius:12px; border:1px solid var(--surface-border); background:var(--surface); color:var(--ink); display:grid; place-items:center; cursor:pointer; }
      .cp-bell-count{ position:absolute; top:-5px; right:-5px; min-width:18px; height:18px; padding:0 4px; border-radius:9px; background:#e5484d; color:#fff; font-size:10.5px; font-weight:800; display:grid; place-items:center; }
      .cp-bell-panel{ position:absolute; right:0; top:46px; width:min(360px, 92vw); max-height:420px; display:flex; flex-direction:column; background:var(--panel); border:1px solid var(--panel-border); border-radius:14px; box-shadow:0 18px 40px rgba(0,0,0,0.18); z-index:60; overflow:hidden; }
      .cp-bell-head{ display:flex; justify-content:space-between; align-items:center; padding:12px 14px; border-bottom:1px solid var(--panel-border); color:var(--ink); }
      .cp-bell-head button{ border:0; background:none; color:var(--accent-deep); font-weight:700; cursor:pointer; font-size:12px; }
      .cp-bell-list{ overflow:auto; }
      .cp-bell-item{ padding:10px 14px; border-bottom:1px solid var(--panel-border); cursor:pointer; }
      .cp-bell-item.is-unread{ background:var(--accent-soft, rgba(31,195,180,0.08)); }
      .cp-bell-title{ font-weight:700; font-size:13px; color:var(--ink); }
      .cp-bell-body{ font-size:12.5px; color:var(--ink-soft); margin-top:2px; }
      .cp-bell-time{ font-size:11px; color:var(--ink-faint); margin-top:4px; }
      .cp-shell[data-theme="dark"] .cp-bell-item.is-unread{ background:rgba(255,255,255,0.05); }

      /* ---- OCR attendance ---- */
      .cp-ocr-start{ display:flex; align-items:center; gap:16px; padding:22px; border:1.6px dashed var(--surface-border); border-radius:14px; background:var(--surface); color:var(--ink-soft); flex-wrap:wrap; }
      .cp-ocr-start > div{ flex:1; min-width:220px; display:flex; flex-direction:column; gap:4px; }
      .cp-ocr-start strong{ color:var(--ink); }
      .cp-ocr-uploaders{ display:grid; grid-template-columns:repeat(auto-fit, minmax(210px, 1fr)); gap:12px; }
      .cp-ocr-drop--compact{ padding:16px; }
      .cp-ocr-drop--compact div{ display:flex; flex-direction:column; }
      .cp-ocr-tip{ font-size:12px; margin:8px 0 4px; }
      .cp-ocr-queue{ display:flex; flex-direction:column; gap:6px; margin:10px 0; }
      .cp-ocr-qitem{ display:flex; align-items:center; gap:10px; padding:8px 12px; border-radius:10px; background:var(--surface); border:1px solid var(--surface-border); font-size:12.5px; color:var(--ink); }
      .cp-ocr-qitem.is-error{ border-color:#f0cccc; color:#a13d3d; }
      .cp-ocr-qitem.is-done{ border-color:rgba(29,138,78,0.35); }
      .cp-ocr-qname{ font-weight:700; max-width:40%; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
      .cp-ocr-qnote{ color:var(--ink-soft); }
      .cp-ocr-chips{ display:flex; flex-wrap:wrap; align-items:center; gap:8px; margin:12px 0; }
      .cp-ocr-chip{ padding:5px 11px; border-radius:999px; font-size:12px; font-weight:700; background:var(--surface); border:1px solid var(--surface-border); color:var(--ink); }
      .cp-ocr-chip--green{ background:#DCF6E6; color:#1D8A4E; border-color:transparent; }
      .cp-ocr-chip--red{ background:#FBE4E1; color:#B23A2C; border-color:transparent; }
      .cp-ocr-chip--amber{ background:#FCEFD6; color:#9A6A12; border-color:transparent; }
      .cp-ocr-filter{ margin-left:auto; font-size:12.5px; color:var(--ink-soft); display:flex; align-items:center; gap:6px; cursor:pointer; }
      .cp-ocr-flag{ color:#b7791f; font-weight:700; display:inline-flex; align-items:center; gap:4px; }
      .cp-score-input.is-invalid{ border-color:#e5484d !important; }
      .cp-grv-resolution{ color:var(--ink-soft); font-style:italic; }
      .cp-field-label{ display:flex; flex-direction:column; gap:4px; font-size:12px; color:var(--ink-soft); }

      /* ---- first-login password gate ---- */
      .cp-gate{ min-height:100vh; display:grid; place-items:center; padding:16px; background:var(--bg); }
      .cp-gate-card{ width:min(420px, 100%); background:var(--panel); border:1px solid var(--panel-border); border-radius:20px; padding:28px; box-shadow:0 20px 50px rgba(0,0,0,0.12); color:var(--ink); }
      .cp-gate-card h2{ margin:14px 0 4px; }
      .cp-gate-link{ margin-top:12px; border:0; background:none; color:var(--ink-soft); cursor:pointer; width:100%; }

      /* ---- admin ---- */
      .cp-secret-row{ display:flex; justify-content:space-between; gap:12px; padding:8px 12px; border-radius:10px; background:var(--surface); border:1px solid var(--surface-border); flex-wrap:wrap; }
      .cp-secret-row code{ font-weight:800; letter-spacing:0.5px; }
      .cp-enroll-list{ max-height:260px; overflow:auto; display:flex; flex-direction:column; gap:4px; }
      .cp-enroll-row{ display:flex; gap:14px; font-size:13px; padding:4px 0; border-bottom:1px solid var(--panel-border); }
      .cp-enroll-row span:first-child{ font-weight:700; min-width:90px; }
      .cp-import-grid{ display:grid; grid-template-columns:repeat(auto-fit, minmax(230px, 1fr)); gap:12px; }
      .cp-import-card{ position:relative; display:flex; flex-direction:column; gap:8px; padding:16px; border-radius:14px; background:var(--surface); border:1px solid var(--surface-border); }
      .cp-import-step{ position:absolute; top:12px; right:12px; width:24px; height:24px; border-radius:50%; background:var(--accent); color:#fff; display:grid; place-items:center; font-weight:800; font-size:12px; }
      .cp-import-cols{ font-size:11px; word-break:break-all; color:var(--ink-soft); }
      @media (max-width: 640px){ .cp-ocr-filter{ margin-left:0; } .cp-ocr-qname{ max-width:55%; } }

      /* ---- AI copilot ---- */
      .cw-bubble ul{ margin:4px 0; padding-left:18px; } .cw-bubble li{ margin:2px 0; }
      .cw-bubble--err{ border-color:#f0cccc !important; color:#a13d3d !important; }
      .cw-suggestions{ display:flex; flex-wrap:wrap; gap:6px; padding:4px 0 2px 30px; }
      .cw-chip{ border:1px solid var(--cw-accent); background:var(--cw-accent-soft); color:var(--cw-accent-deep); border-radius:999px; padding:5px 10px; font-size:11.5px; font-weight:600; cursor:pointer; text-align:left; }
      .cw-chip:hover{ background:var(--cw-accent); color:#fff; }
      .cw-action{ flex:1; border:1.5px solid var(--cw-accent); border-radius:14px; padding:10px 12px; background:var(--surface, #fff); color:var(--ink, #16232A); font-size:12.5px; }
      .cw-action-title{ font-weight:800; font-size:11px; text-transform:uppercase; letter-spacing:.04em; color:var(--cw-accent-deep); margin-bottom:4px; }
      .cw-action-buttons{ display:flex; gap:8px; margin-top:8px; }
      .cw-btn{ border:1px solid var(--surface-border, #ccc); background:transparent; color:inherit; border-radius:10px; padding:6px 12px; font-weight:700; font-size:12px; cursor:pointer; }
      .cw-btn--primary{ background:linear-gradient(120deg, var(--cw-accent), var(--cw-accent-deep)); color:#fff; border-color:transparent; }
      .cw-action-state{ margin-top:8px; font-size:12px; color:var(--ink-soft, #5C7A73); }
      .cw-action-state--ok{ color:#1D8A4E; font-weight:700; } .cw-action-state--err{ color:#B23A2C; font-weight:700; }
      .cw-typing-wrap{ display:flex; flex-direction:column; gap:4px; }
      .cw-progress{ font-size:11px; color:var(--ink-soft, #5C7A73); font-style:italic; padding-left:4px; }
      .cw-quota{ font-size:10.5px; text-align:center; color:var(--ink-faint, #8a9a97); padding:0 0 8px; }

      /* ================= new features ================= */
      html:lang(hi) .cp-shell, html:lang(hi) .cp-shell *:not(code):not(.cp-qr-code):not(.cp-code-input){ font-family:'Noto Sans Devanagari', 'Inter', system-ui, sans-serif !important; }
      .cp-card-head .cp-icon-btn{ color:#fff; background:rgba(255,255,255,.14); }
      .cp-card-head .cp-icon-btn:hover{ background:rgba(255,255,255,.28); color:#fff; }
      .cp-card-body > .cp-tabs2{ margin-bottom:12px; }
      .cp-shell[data-theme="dark"] .cp-tab2.is-active{ color:#fff; border-color:color-mix(in srgb, var(--accent) 70%, #fff); }
      .cp-shell[data-theme="dark"] .cp-stat-ico{ background:color-mix(in srgb, var(--accent) 22%, transparent); color:#fff; }

      .cp-badge2--purple{ background:#EDE7FB; color:#5B3AA8; }
      .cp-shell[data-theme="dark"] .cp-badge2--purple{ background:rgba(139,92,246,.2); color:#C9B6FF; }
      .cp-small{ font-size:11.5px; }
      .cp-danger-text{ color:var(--danger, #D93F3F); }
      .cp-section-title{ font-size:16px; font-weight:800; color:var(--ink); margin:6px 0 4px; }
      .cp-toolbar{ display:flex; align-items:center; gap:10px; flex-wrap:wrap; margin-bottom:14px; }
      .cp-stat-grid--5{ grid-template-columns:repeat(auto-fit, minmax(150px, 1fr)); }
      .cp-callout{ display:flex; gap:10px; align-items:flex-start; padding:12px 14px; border-radius:14px; margin-bottom:14px; font-size:13px; line-height:1.5;
        background:var(--accent-soft); color:var(--ink); border:1px solid color-mix(in srgb, var(--accent) 30%, transparent); }
      .cp-callout > svg{ flex-shrink:0; margin-top:2px; color:var(--accent-deep); }
      .cp-callout--warn{ background:#FFF4E0; border-color:#F2C46B; }
      .cp-callout--warn > svg{ color:#B7791F; }
      .cp-shell[data-theme="dark"] .cp-callout{ background:color-mix(in srgb, var(--accent) 14%, transparent); }
      .cp-shell[data-theme="dark"] .cp-callout--warn{ background:rgba(242,196,107,.12); }
      .cp-field-label{ display:flex; flex-direction:column; gap:4px; font-size:11.5px; font-weight:600; color:var(--ink-soft); }
      .cp-field-label--inline{ flex-direction:row; align-items:center; gap:8px; }
      .cp-search-input--sm{ max-width:170px; }
      .cp-cal-prev svg{ transform:rotate(180deg); }
      .cp-icon-btn{ width:30px; height:30px; border-radius:50%; }
      .cp-icon-btn:hover{ background:var(--accent-soft); color:var(--accent-deep); }
      .cp-icon-btn:focus-visible{ outline:2px solid var(--accent); outline-offset:1px; }

      /* empty states */
      .cp-empty{ display:flex; flex-direction:column; align-items:center; text-align:center; gap:6px; padding:22px 12px; color:var(--ink-soft); }
      .cp-empty .es-fill{ fill:var(--accent-soft); stroke:color-mix(in srgb, var(--accent) 45%, transparent); stroke-width:2; }
      .cp-empty .es-line{ fill:none; stroke:color-mix(in srgb, var(--accent) 60%, transparent); stroke-width:3; stroke-linecap:round; stroke-linejoin:round; }
      .cp-empty .es-accent{ fill:var(--accent); }
      .cp-empty .es-check{ fill:none; stroke:#fff; stroke-width:2.2; stroke-linecap:round; stroke-linejoin:round; }
      .cp-empty-text{ font-weight:700; font-size:13.5px; color:var(--ink); max-width:420px; }
      .cp-empty-hint{ font-size:12px; max-width:380px; }
      .cp-table-empty-cell{ padding:0 !important; }

      /* language + sidebar tools */
      .cp-lang{ display:inline-flex; border:1.4px solid var(--surface-border); border-radius:999px; padding:2px; background:var(--surface); }
      .cp-lang button{ all:unset; cursor:pointer; font-size:11.5px; font-weight:700; padding:4px 10px; border-radius:999px; color:var(--ink-soft); }
      .cp-lang button.is-active{ background:var(--accent); color:#fff; }
      .cp-lang button:focus-visible{ outline:2px solid var(--accent); outline-offset:1px; }
      .cp-lang--compact button{ padding:3px 8px; }
      .a2-nav-right .cp-lang{ background:var(--a2-paper, #fff); border-color:var(--a2-line, #ddd); }
      .a2-nav-right .cp-lang button.is-active{ background:var(--a2-accent); }
      .cp-sidebar-tools{ display:flex; flex-wrap:wrap; align-items:center; gap:8px; margin:12px 0 6px; }
      .cp-tour-btn, .cp-install-btn{ all:unset; cursor:pointer; display:inline-flex; align-items:center; gap:6px; font-size:12px; font-weight:600; color:var(--ink-soft);
        padding:6px 10px; border-radius:10px; border:1.4px dashed var(--surface-border); }
      .cp-tour-btn:hover, .cp-install-btn:hover{ color:var(--accent-deep); border-color:var(--accent); }
      .cp-tour-btn:focus-visible, .cp-install-btn:focus-visible{ outline:2px solid var(--accent); outline-offset:1px; }
      .cp-install-btn{ border-style:solid; background:var(--accent-soft); color:var(--accent-deep); border-color:transparent; }
      .cp-steps-list{ margin:0; padding-left:20px; line-height:1.8; font-size:13.5px; }

      /* guided tour */
      .cp-tour{ position:fixed; inset:0; z-index:200; }
      .cp-tour-hole{ position:fixed; border-radius:14px; box-shadow:0 0 0 9999px rgba(8,20,24,.62); outline:2px solid #fff; transition:all .3s var(--ease); pointer-events:none; }
      .cp-tour-card{ position:fixed; width:320px; max-width:calc(100vw - 24px); background:#fff; color:#16232A;
        border-radius:16px; padding:16px 16px 12px; box-shadow:0 20px 50px rgba(0,0,0,.35); animation:cpTourIn .25s var(--ease); }
      .cp-shell[data-theme="dark"] .cp-tour-card{ background:#15232B; color:#EAF3F1; }
      @keyframes cpTourIn{ from{ opacity:0; transform:translateY(6px); } to{ opacity:1; transform:none; } }
      .cp-tour-step{ font-size:11px; font-weight:700; color:var(--accent-deep); text-transform:uppercase; letter-spacing:.06em; }
      .cp-tour-card h4{ margin:4px 0 4px; font-size:15.5px; }
      .cp-tour-card p{ margin:0 0 12px; font-size:13px; line-height:1.5; color:var(--ink-soft); }
      .cp-tour-actions{ display:flex; justify-content:space-between; align-items:center; gap:8px; }
      .cp-tour-actions button{ all:unset; cursor:pointer; font-size:12.5px; font-weight:700; padding:7px 13px; border-radius:999px; }
      .cp-tour-actions .cp-tour-skip{ color:var(--ink-faint); }
      .cp-tour-actions .cp-tour-back{ color:var(--ink-soft); }
      .cp-tour-actions .cp-tour-next{ background:var(--accent); color:#fff; margin-left:6px; }
      .cp-tour-actions button:focus-visible{ outline:2px solid var(--accent); outline-offset:2px; }

      /* QR check-in (student) */
      .cp-checkin-row{ display:flex; flex-direction:column; gap:10px; }
      .cp-code-input{ font-size:22px; font-weight:800; letter-spacing:.35em; width:170px; text-align:center; padding:8px 10px; border-radius:12px;
        border:1.6px solid var(--surface-border); background:var(--surface); color:var(--ink); font-variant-numeric:tabular-nums; }
      .cp-code-input:focus{ outline:none; border-color:var(--accent); box-shadow:0 0 0 3px var(--accent-soft); }
      .cp-checkin-ok{ display:flex; align-items:center; gap:12px; flex-wrap:wrap; }
      .cp-checkin-tick{ width:40px; height:40px; border-radius:50%; background:#1F9D6B; color:#fff; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
      .cp-checkin-tick--big{ width:70px; height:70px; animation:cpPop .4s var(--ease); }
      .cp-checkin-tick--bad{ width:64px; height:64px; background:#D93F3F; }
      @keyframes cpPop{ from{ transform:scale(.4); opacity:0; } to{ transform:scale(1); opacity:1; } }
      .cp-checkin-big{ display:flex; flex-direction:column; align-items:center; text-align:center; gap:6px; padding:8px 0; }
      .cp-checkin-big h3{ margin:8px 0 0; }

      /* QR attendance (teacher) */
      .cp-qr-intro{ display:flex; flex-direction:column; gap:16px; }
      .cp-qr-steps{ display:grid; grid-template-columns:repeat(auto-fit, minmax(190px, 1fr)); gap:10px; }
      .cp-qr-steps > div{ display:flex; gap:10px; align-items:flex-start; font-size:13px; line-height:1.45; padding:12px; border-radius:14px; background:var(--surface); border:1px solid var(--surface-border); color:var(--ink); }
      .cp-qr-steps span{ width:24px; height:24px; border-radius:50%; background:var(--accent); color:#fff; font-weight:800; font-size:12px; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
      .cp-qr-layout{ display:grid; grid-template-columns:minmax(0, 1fr) minmax(0, 1fr); gap:18px; }
      @media (max-width: 900px){ .cp-qr-layout{ grid-template-columns:1fr; } }
      .cp-qr-display{ display:flex; flex-direction:column; align-items:center; gap:8px; }
      .cp-qr{ border-radius:14px; box-shadow:0 10px 30px rgba(0,0,0,.12); background:#fff; padding:4px; max-width:100%; height:auto; }
      .cp-qr-code{ font-size:34px; font-weight:800; letter-spacing:.12em; font-variant-numeric:tabular-nums; color:var(--ink); }
      .cp-qr-meta{ font-size:12.5px; color:var(--ink-soft); }
      .cp-qr-count{ font-size:14px; color:var(--ink); } .cp-qr-count strong{ font-size:22px; color:var(--accent-deep); }
      .cp-qr-bar{ width:min(320px, 100%); height:8px; border-radius:99px; background:var(--surface-border); overflow:hidden; }
      .cp-qr-bar span{ display:block; height:100%; background:linear-gradient(90deg, var(--accent), var(--accent-deep)); transition:width .5s var(--ease); }
      .cp-qr-expired{ padding:40px 20px; text-align:center; color:var(--ink-soft); }
      .cp-qr-full{ position:fixed; inset:0; z-index:150; background:rgba(6,16,20,.92); display:flex; align-items:center; justify-content:center; padding:20px; }
      .cp-qr-full > div{ background:#fff; color:#111; border-radius:24px; padding:24px 28px; display:flex; flex-direction:column; align-items:center; gap:12px; max-height:100%; overflow:auto; }
      .cp-qr-full .cp-qr-code{ color:#111; font-size:48px; } .cp-qr-full .cp-qr-meta, .cp-qr-full .cp-qr-count{ color:#333; }
      .cp-qr-list{ display:flex; flex-direction:column; gap:6px; max-height:520px; overflow:auto; }
      .cp-qr-student{ display:flex; align-items:center; gap:10px; padding:8px 10px; border-radius:12px; border:1px solid var(--surface-border); transition:background .3s; }
      .cp-qr-student.is-present{ background:color-mix(in srgb, #1F9D6B 12%, transparent); border-color:color-mix(in srgb, #1F9D6B 35%, transparent); }
      .cp-flag{ color:#B7791F; font-weight:700; }
      .cp-mini-toggle{ all:unset; cursor:pointer; font-size:11.5px; font-weight:700; padding:5px 11px; border-radius:999px; background:var(--surface-border); color:var(--ink-soft); }
      .cp-mini-toggle.is-on{ background:#1F9D6B; color:#fff; }
      .cp-mini-toggle:focus-visible{ outline:2px solid var(--accent); outline-offset:2px; }
      .cp-marks-input{ width:84px; padding:6px 8px; border-radius:8px; border:1.4px solid var(--surface-border); background:var(--surface); color:var(--ink); }
      .cp-marks-input.is-bad{ border-color:#D93F3F; background:#FDECEC; }

      /* calendar */
      .cp-cal-layout{ display:grid; grid-template-columns:minmax(0, 1.6fr) minmax(0, 1fr); gap:18px; align-items:start; }
      @media (max-width: 1000px){ .cp-cal-layout{ grid-template-columns:1fr; } }
      .cp-cal{ display:grid; grid-template-columns:repeat(7, minmax(0, 1fr)); gap:6px; }
      .cp-cal-head{ font-size:11px; font-weight:700; color:var(--ink-faint); text-align:center; text-transform:uppercase; padding:4px 0; }
      .cp-cal-cell{ all:unset; box-sizing:border-box; cursor:pointer; min-height:78px; border-radius:12px; padding:6px; background:var(--surface); border:1px solid var(--surface-border);
        display:flex; flex-direction:column; gap:3px; overflow:hidden; transition:border-color .2s; min-width:0; }
      .cp-cal-cell:hover{ border-color:var(--accent); }
      .cp-cal-cell:focus-visible{ outline:2px solid var(--accent); outline-offset:1px; }
      .cp-cal-cell.is-blank{ background:transparent; border:none; cursor:default; }
      .cp-cal-cell.is-today .cp-cal-num{ background:var(--accent); color:#fff; }
      .cp-cal-cell.is-selected{ border-color:var(--accent); box-shadow:0 0 0 2px var(--accent-soft); }
      .cp-cal-cell.is-holiday{ background:color-mix(in srgb, var(--coral) 12%, var(--surface)); }
      .cp-cal-num{ font-size:12px; font-weight:700; width:22px; height:22px; border-radius:50%; display:flex; align-items:center; justify-content:center; color:var(--ink); flex-shrink:0; }
      .cp-cal-dots{ display:flex; gap:3px; }
      .cp-cal-first{ font-size:10.5px; line-height:1.25; color:var(--ink-soft); display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden; }
      @media (max-width: 600px){ .cp-cal-cell{ min-height:46px; padding:4px; } .cp-cal-first{ display:none; } .cp-cal{ gap:3px; } .cp-cal-head{ font-size:9.5px; } }
      .cp-dot{ width:7px; height:7px; border-radius:50%; display:inline-block; }
      .cp-dot--coral{ background:var(--coral); } .cp-dot--teal{ background:#1FC3B4; } .cp-dot--navy{ background:var(--navy); } .cp-dot--yellow{ background:#E0A800; }
      .cp-shell[data-theme="dark"] .cp-dot--navy{ background:#7C9CD6; }
      .cp-cal-legend{ display:flex; flex-wrap:wrap; gap:14px; margin-top:12px; font-size:11.5px; color:var(--ink-soft); }
      .cp-cal-legend span{ display:inline-flex; align-items:center; gap:6px; }
      .cp-cal-list{ display:flex; flex-direction:column; gap:8px; }
      .cp-cal-item{ display:flex; align-items:flex-start; gap:10px; padding:10px; border-radius:12px; background:var(--surface); border:1px solid var(--surface-border); }
      .cp-cal-tag{ font-size:10.5px; font-weight:700; padding:3px 8px; border-radius:999px; white-space:nowrap; }
      .cp-cal-tag--coral{ background:var(--coral-soft); color:#B23A1E; } .cp-cal-tag--teal{ background:#DCF3EE; color:#12756B; }
      .cp-cal-tag--navy{ background:#E4EAF3; color:#1B2C4A; } .cp-cal-tag--yellow{ background:#FFF3D6; color:#8A6A22; }

      /* documents */
      .cp-doc-grid{ display:grid; grid-template-columns:repeat(auto-fit, minmax(240px, 1fr)); gap:18px; margin-bottom:18px; }
      .cp-doc-card{ background:var(--panel); border:1px solid var(--panel-border); border-radius:var(--radius-md); padding:18px; display:flex; flex-direction:column; gap:10px; }
      .cp-doc-card h4{ margin:4px 0 0; font-size:15px; color:var(--ink); }
      .cp-doc-card p{ margin:0; }
      .cp-doc-card .cp-search-input{ max-width:none; }
      .cp-doc-preview{ height:132px; border-radius:14px; background:linear-gradient(135deg, var(--accent-soft), var(--surface)); display:flex; align-items:center; justify-content:center; overflow:hidden; }
      .cp-doc-preview--id{ flex-direction:column; align-items:stretch; justify-content:flex-start; background:#fff; border:1px solid var(--surface-border); }
      .cp-idc-band{ background:var(--accent-deep); color:#fff; font-size:10.5px; font-weight:700; letter-spacing:.08em; text-transform:uppercase; padding:8px 12px; }
      .cp-idc-body{ display:flex; gap:12px; align-items:center; padding:12px; font-size:11.5px; color:#344; }
      .cp-idc-body strong{ font-size:13px; color:#123; }
      .cp-idc-photo{ width:46px; height:56px; border-radius:8px; background:var(--accent-soft); color:var(--accent-deep); font-weight:800; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
      .cp-doc-lines{ width:70%; background:#fff; border-radius:8px; padding:12px; display:flex; flex-direction:column; gap:6px; box-shadow:0 6px 16px rgba(0,0,0,.08); }
      .cp-doc-lines b{ font-size:9px; letter-spacing:.08em; color:var(--accent-deep); text-align:center; }
      .cp-doc-lines i{ height:5px; border-radius:3px; background:#E3EAEA; } .cp-doc-lines i.short{ width:55%; }

      /* heat-map + line chart */
      .cp-shell{ --heat-1:#F4A999; --heat-2:#F9D98B; --heat-3:#A7E2C9; --heat-4:#4FC2A0; --heat-none:rgba(128,140,145,.14); }
      .cp-heat-wrap{ overflow-x:auto; }
      .cp-heat{ border-collapse:separate; border-spacing:3px; font-size:11.5px; min-width:100%; }
      .cp-heat th{ font-weight:600; color:var(--ink-soft); padding:4px 6px; white-space:nowrap; text-align:left; }
      .cp-heat thead th{ text-align:center; font-size:10.5px; }
      .cp-heat td{ text-align:center; min-width:42px; height:30px; border-radius:6px; font-weight:700; color:#10312E; font-variant-numeric:tabular-nums; }
      .cp-heat-legend{ display:flex; flex-wrap:wrap; gap:12px; margin-top:10px; font-size:11px; color:var(--ink-soft); }
      .cp-heat-legend span{ display:inline-flex; align-items:center; gap:5px; } .cp-heat-legend i{ width:14px; height:10px; border-radius:3px; display:inline-block; }
      .cp-linechart svg{ display:block; overflow:visible; }
      .cp-lc-grid{ stroke:var(--surface-border); stroke-width:1; }
      .cp-lc-target{ stroke:#D93F3F; stroke-width:1.2; stroke-dasharray:5 4; opacity:.7; }
      .cp-lc-axis{ fill:var(--ink-faint); font-size:11px; }
      .cp-lc-legend{ display:flex; flex-wrap:wrap; gap:14px; font-size:11.5px; color:var(--ink-soft); margin-top:6px; }
      .cp-lc-legend span{ display:inline-flex; align-items:center; gap:6px; } .cp-lc-legend i{ width:14px; height:3px; border-radius:2px; display:inline-block; }
      .cp-lc-legend-target{ background:repeating-linear-gradient(90deg, #D93F3F 0 5px, transparent 5px 8px) !important; }

      /* parent portal */
      .cp-shell--parent .cp-hero{ background:linear-gradient(135deg, #8B5CF6, #5B3AA8); }
      .cp-kid-switch{ display:flex; gap:8px; flex-wrap:wrap; margin-bottom:14px; }
      .cp-kid-switch button{ all:unset; cursor:pointer; display:inline-flex; align-items:center; gap:8px; padding:6px 12px 6px 6px; border-radius:999px; border:1.4px solid var(--surface-border); background:var(--surface); font-weight:600; font-size:13px; color:var(--ink); }
      .cp-kid-switch button.is-active{ border-color:var(--accent); box-shadow:0 0 0 3px var(--accent-soft); }
      .cp-alert-list{ display:flex; flex-direction:column; gap:8px; }
      .cp-alert-row{ display:grid; grid-template-columns:auto 1fr auto; gap:10px; align-items:center; font-size:13px; padding:8px 0; border-bottom:1px solid var(--surface-border); color:var(--ink); }
      @media (max-width: 600px){ .cp-alert-row{ grid-template-columns:1fr; gap:4px; } }

      /* verification page */
      .cp-verify{ min-height:100vh; min-height:100dvh; width:100%; display:flex; align-items:center; justify-content:center; padding:24px 16px; box-sizing:border-box;
        background:radial-gradient(circle at 20% 10%, rgba(31,195,180,.25), transparent 50%), var(--bg); overflow:auto; }
      .cp-verify-card{ width:100%; max-width:440px; background:var(--glass-strong); border:1px solid var(--glass-border); border-radius:24px; padding:26px 24px; box-shadow:var(--shadow); text-align:center; color:var(--ink); }
      .cp-verify-brand{ display:flex; align-items:center; justify-content:center; gap:8px; font-size:12.5px; font-weight:700; color:var(--ink-soft); margin-bottom:18px; }
      .cp-verify-status{ width:64px; height:64px; margin:0 auto 10px; border-radius:50%; color:#fff; display:flex; align-items:center; justify-content:center; }
      .cp-verify-status.is-ok{ background:#1F9D6B; } .cp-verify-status.is-bad{ background:#D93F3F; }
      .cp-verify-card h2{ margin:0 0 14px; font-size:20px; }
      .cp-verify-dl{ display:grid; grid-template-columns:auto 1fr; gap:8px 14px; text-align:left; margin:0 0 14px; font-size:14px; }
      .cp-verify-dl dt{ color:var(--ink-faint); font-weight:600; } .cp-verify-dl dd{ margin:0; font-weight:600; overflow-wrap:anywhere; }
      .cp-verify-home{ display:inline-block; margin-top:8px; color:#12756B; font-weight:700; font-size:13px; }

      @media print{
        .cp-sidebar, .cp-topbar, .cw-fab, .cw-panel, .cp-tour{ display:none !important; }
        .cp-shell, .cp-frame, .cp-main{ height:auto !important; overflow:visible !important; }
        .cp-card{ break-inside:avoid; box-shadow:none !important; }
      }
    `}</style>
  );
}
