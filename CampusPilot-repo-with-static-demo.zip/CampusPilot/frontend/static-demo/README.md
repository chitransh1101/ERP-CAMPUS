# Static demo (GitHub Pages)
`demo-mock.js` answers the app's `/api` calls from `demo-data.json` (responses recorded from the seeded demo campus),
so the site runs with no server. The Pages workflow (`.github/workflows/pages.yml`) copies these files in and builds with `--base=./`.
Real deployment (Docker / Render) is unchanged. Demo logins: rohan@campuspilot.edu / student123, priya@campuspilot.edu / teach123,
admin@campuspilot.edu / admin123, parent@campuspilot.edu / parent123.
