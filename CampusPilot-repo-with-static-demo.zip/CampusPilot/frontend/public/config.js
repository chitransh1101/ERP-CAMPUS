window.__CAMPUSPILOT_API__ = "/api";
window.__CAMPUSPILOT_DEMO__ = true;
