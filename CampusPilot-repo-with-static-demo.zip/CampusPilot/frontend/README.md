# CampusPilot web app

React 18 + Vite, served by nginx (`templates/default.conf.template`). nginx also
proxies `/api` (and the `/api/ws` WebSocket) to the backend, so the browser only
ever talks to one origin. That's what lets the session be an httpOnly cookie
and the CSP be strict.

```
npm install
npm run dev        # http://localhost:5173 — proxies /api to the backend on :8000
npm run build      # production bundle in dist/
```

Runtime config is `/config.js`, written by `docker-entrypoint.sh` when the container starts:
- `API_BASE` (default `/api`)
- `DEMO_MODE` (shows demo logins on the sign-in page)
- `BACKEND_URL` (where nginx proxies `/api`; default `http://backend:8000`)
- `BACKEND_HOST_HEADER` (see the template)

All screens read live data from the API. `realtimeBus` is fed by the WebSocket,
and components subscribe with `useLive([...events], refresh)`.
