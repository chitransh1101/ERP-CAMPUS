import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// `npm run dev`: the dev server proxies /api (and the /api/ws WebSocket) to
// the backend on :8000, so development uses the same same-origin setup as
// production. public/config.js provides the dev runtime config.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      "/api": {
        target: "http://127.0.0.1:8000",
        changeOrigin: false,
        ws: true,
        rewrite: (p) => p.replace(/^\/api/, ""),
      },
    },
  },
  build: { sourcemap: false },
});
