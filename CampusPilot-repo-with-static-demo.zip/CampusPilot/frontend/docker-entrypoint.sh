#!/bin/sh
# Runs before nginx starts (nginx:alpine executes /docker-entrypoint.d/*.sh).
# Writes runtime config to /config.js — an external file, so the strict
# Content-Security-Policy (script-src 'self') needs no inline scripts.
set -e
API_BASE="${API_BASE:-/api}"
case "$DEMO_MODE" in true|1|yes) DEMO=true ;; *) DEMO=false ;; esac
# Only allow a safe character set in API_BASE (it's written into JavaScript).
if ! printf '%s' "$API_BASE" | grep -Eq '^[A-Za-z0-9:/._-]+$'; then
  echo "campuspilot: refusing unsafe API_BASE value" >&2; exit 1
fi
printf 'window.__CAMPUSPILOT_API__ = "%s";\nwindow.__CAMPUSPILOT_DEMO__ = %s;\n' "$API_BASE" "$DEMO" > /usr/share/nginx/html/config.js
echo "campuspilot: API at ${API_BASE} (proxied to ${BACKEND_URL}), demo mode: ${DEMO}"
