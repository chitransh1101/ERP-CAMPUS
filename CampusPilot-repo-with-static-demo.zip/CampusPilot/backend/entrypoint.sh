#!/bin/sh
set -e
# Creates tables; seeds demo data (SEED_DEMO=true) or the first admin
# (ADMIN_EMAIL/ADMIN_PASSWORD) only when the database has no users yet.
python seed.py

# --proxy-headers: trust X-Forwarded-For from the nginx container so rate
# limits and audit logs see the real client IP. FORWARDED_ALLOW_IPS should be
# the proxy's address; "*" is safe only when this port isn't publicly exposed
# (the default docker-compose setup publishes only nginx).
# One worker: live WebSocket fan-out and rate limits are in-process (see
# app/realtime.py for scaling to more workers with Redis).
exec uvicorn app.main:app --host 0.0.0.0 --port 8000 --proxy-headers \
     --forwarded-allow-ips "${FORWARDED_ALLOW_IPS:-*}" --no-server-header
