"""
Try the attendance OCR on your own sheet photo, from the command line.

    python test_ocr.py sheet.jpg --course CS301            # roster from the database
    python test_ocr.py sheet.jpg --course CS301 --day 26   # register: read the day-26 column
    python test_ocr.py sheet.jpg --roster roster.csv       # roster from a CSV (name,id_label)

Prints what was read for every student, the confidence, and why — so you can
check how well your college's sheet format works before rolling it out.
"""
import argparse
import csv
import sys
from datetime import date

from app.ai.attendance_ocr import analyze_photo, engine_available


def roster_from_db(code):
    from app.database.db import SessionLocal
    from app.models.models import Course, Enrollment, User
    db = SessionLocal()
    try:
        course = db.query(Course).filter(Course.code == code.upper()).first()
        if not course:
            sys.exit(f"No course with code {code} in the database.")
        users = (db.query(User).join(Enrollment, Enrollment.student_id == User.id)
                 .filter(Enrollment.course_id == course.id, User.status == "active").order_by(User.id_label).all())
        return [{"studentId": f"u_{u.id}", "name": u.name, "idLabel": u.id_label} for u in users]
    finally:
        db.close()


def roster_from_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        return [{"studentId": f"r{i}", "name": r.get("name", ""), "idLabel": r.get("id_label", "")}
                for i, r in enumerate(csv.DictReader(f))]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("photo")
    src = ap.add_mutually_exclusive_group(required=True)
    src.add_argument("--course", help="course code whose enrolled students form the roster")
    src.add_argument("--roster", help="CSV with columns name,id_label")
    ap.add_argument("--day", type=int, default=date.today().day, help="day of month (for register sheets)")
    args = ap.parse_args()

    if not engine_available():
        sys.exit("Tesseract isn't installed — see requirements.txt for install instructions.")
    roster = roster_from_db(args.course) if args.course else roster_from_csv(args.roster)
    result = analyze_photo(open(args.photo, "rb").read(), roster, target_day=args.day)

    print(f"Sheet type: {result.mode} · rows read: {result.rows_read} · {result.ms} ms")
    for w in result.warnings:
        print(f"WARNING: {w}")
    found = 0
    for s in roster:
        r = result.readings.get(s["studentId"])
        if r and r.status:
            found += 1
            flag = "  <- review" if r.confidence < 70 else ""
            print(f"  {s['idLabel'] or '':10} {s['name'][:24]:24} {r.status.upper():8} {r.confidence:3}%  {r.evidence}{flag}")
        else:
            print(f"  {s['idLabel'] or '':10} {s['name'][:24]:24} NOT FOUND {'(' + r.evidence + ')' if r else ''}")
    for u in result.unrecognized:
        print(f"  unrecognised row: {u}")
    print(f"\n{found}/{len(roster)} students read from this photo.")


if __name__ == "__main__":
    main()
