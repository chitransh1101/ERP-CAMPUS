"""
Central configuration, read once from environment variables.

Every security-relevant knob lives here so it can be audited in one place.
In production (ENV=production) the app refuses to start with unsafe
settings instead of silently running with them.
"""
import os
import secrets


def _bool(name: str, default: bool) -> bool:
    v = os.environ.get(name)
    if v is None or v == "":
        return default
    return v.strip().lower() in ("1", "true", "yes", "on")


def _int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, "") or default)
    except ValueError:
        return default


def _list(name: str, default: str) -> list:
    return [x.strip() for x in (os.environ.get(name) or default).split(",") if x.strip()]


ENV = (os.environ.get("ENV") or "development").strip().lower()
IS_PROD = ENV == "production"

# --------------------------------------------------------------- Secrets
_secret = os.environ.get("SECRET_KEY") or ""
if IS_PROD and len(_secret) < 32:
    raise RuntimeError(
        "SECRET_KEY must be set to a random string of at least 32 characters in production. "
        "Generate one with: python -c \"import secrets; print(secrets.token_hex(32))\""
    )
SECRET_KEY = _secret or secrets.token_hex(32)

# -------------------------------------------------------------- Database
DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite:///./campuspilot.db")
# Render/Heroku hand out postgres:// URLs; SQLAlchemy 2 needs postgresql://
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = "postgresql+psycopg2://" + DATABASE_URL[len("postgres://"):]
elif DATABASE_URL.startswith("postgresql://"):
    DATABASE_URL = "postgresql+psycopg2://" + DATABASE_URL[len("postgresql://"):]

# Demo data (known passwords!) is only seeded when explicitly allowed.
SEED_DEMO = _bool("SEED_DEMO", not IS_PROD)

# -------------------------------------------------------------- Sessions
SESSION_HOURS = _int("SESSION_HOURS", 12)
COOKIE_NAME = "cp_session"
CSRF_COOKIE_NAME = "cp_csrf"
CSRF_HEADER_NAME = "X-CSRF-Token"
COOKIE_SECURE = _bool("COOKIE_SECURE", IS_PROD)
# "lax" works for the default same-origin setup (nginx proxies /api). Use
# "none" (+ COOKIE_SECURE=true) only if frontend and API live on different sites.
COOKIE_SAMESITE = (os.environ.get("COOKIE_SAMESITE") or "lax").lower()
if COOKIE_SAMESITE == "none" and not COOKIE_SECURE:
    raise RuntimeError("COOKIE_SAMESITE=none requires COOKIE_SECURE=true (browsers reject it otherwise).")

# ------------------------------------------------------------------ HTTP
# Browser origins allowed to call the API / open the live-updates socket.
# If only PUBLIC_URL is set (e.g. on Render), that address is used.
if not os.environ.get("CORS_ORIGINS") and os.environ.get("PUBLIC_URL"):
    os.environ["CORS_ORIGINS"] = os.environ["PUBLIC_URL"].rstrip("/")
CORS_ORIGINS = _list("CORS_ORIGINS", "http://localhost:8080,http://127.0.0.1:8080,http://localhost:5173,http://127.0.0.1:5173")
if IS_PROD and "*" in CORS_ORIGINS:
    raise RuntimeError("CORS_ORIGINS='*' is not allowed in production — list your real frontend origin(s).")
TRUSTED_HOSTS = _list("TRUSTED_HOSTS", "*")
ENABLE_DOCS = _bool("ENABLE_DOCS", not IS_PROD)

# ------------------------------------------------------------- Passwords
PBKDF2_ITERATIONS = 600_000  # OWASP 2023 recommendation for PBKDF2-HMAC-SHA256
PASSWORD_MIN_LENGTH = 8

# ------------------------------------------------------ Abuse protection
LOGIN_MAX_FAILURES = _int("LOGIN_MAX_FAILURES", 5)
LOGIN_LOCKOUT_SECONDS = _int("LOGIN_LOCKOUT_SECONDS", 300)
RATE_LIMIT_PER_MINUTE = _int("RATE_LIMIT_PER_MINUTE", 300)       # all requests, per IP
LOGIN_RATE_PER_MINUTE = _int("LOGIN_RATE_PER_MINUTE", 10)        # login attempts, per IP
SIGNUP_RATE_PER_HOUR = _int("SIGNUP_RATE_PER_HOUR", 10)          # signups, per IP
ALLOW_SELF_SIGNUP = _bool("ALLOW_SELF_SIGNUP", True)

# ------------------------------------------------------------------- OCR
MAX_UPLOAD_MB = _int("MAX_UPLOAD_MB", 12)
MAX_PHOTOS_PER_REQUEST = _int("MAX_PHOTOS_PER_REQUEST", 10)
MAX_IMAGE_PIXELS = _int("MAX_IMAGE_PIXELS", 40_000_000)  # decompression-bomb guard
OCR_RATE_PER_MINUTE = _int("OCR_RATE_PER_MINUTE", 30)

# ------------------------------------------------------ Public address
# The address people open (used in QR codes on hall tickets, ID cards and the
# QR-attendance screen). Defaults to the first CORS origin.
PUBLIC_URL = (os.environ.get("PUBLIC_URL") or (CORS_ORIGINS[0] if CORS_ORIGINS else "http://localhost:8080")).rstrip("/")
INSTITUTION_NAME = os.environ.get("INSTITUTION_NAME") or "CampusPilot Institute of Technology"
INSTITUTION_ADDRESS = os.environ.get("INSTITUTION_ADDRESS") or "Campus Road, New Delhi"

# ------------------------------------------- Parent alerts (SMS / WhatsApp)
#   MESSAGING_PROVIDER = log     -> messages are stored in the outbox only (default; free, for demos)
#                        twilio  -> real SMS / WhatsApp through Twilio
#                        meta    -> WhatsApp Cloud API (Meta)
MESSAGING_PROVIDER = (os.environ.get("MESSAGING_PROVIDER") or "log").strip().lower()
MESSAGING_CHANNEL = (os.environ.get("MESSAGING_CHANNEL") or "whatsapp").strip().lower()   # whatsapp | sms
TWILIO_ACCOUNT_SID = os.environ.get("TWILIO_ACCOUNT_SID", "")
TWILIO_AUTH_TOKEN = os.environ.get("TWILIO_AUTH_TOKEN", "")
TWILIO_FROM_SMS = os.environ.get("TWILIO_FROM_SMS", "")               # e.g. +1415XXXXXXX
TWILIO_FROM_WHATSAPP = os.environ.get("TWILIO_FROM_WHATSAPP", "")     # e.g. +14155238886 (sandbox)
META_WHATSAPP_TOKEN = os.environ.get("META_WHATSAPP_TOKEN", "")
META_WHATSAPP_PHONE_ID = os.environ.get("META_WHATSAPP_PHONE_ID", "")
META_GRAPH_VERSION = os.environ.get("META_GRAPH_VERSION") or "v23.0"
# Which events alert parents (comma list): low_attendance, absent, fee_due, fee_paid, results, exam
PARENT_ALERTS = set(_list("PARENT_ALERTS", "low_attendance,absent,fee_due,fee_paid,results,exam"))
LOW_ATTENDANCE_THRESHOLD = _int("LOW_ATTENDANCE_THRESHOLD", 75)

# ----------------------------------------------------------------- Exams
# Students below this attendance % in a course are flagged "not eligible" on the hall ticket (0 = off).
EXAM_MIN_ATTENDANCE = _int("EXAM_MIN_ATTENDANCE", 75)
QR_WINDOW_SECONDS = _int("QR_WINDOW_SECONDS", 15)   # how often the attendance QR changes
