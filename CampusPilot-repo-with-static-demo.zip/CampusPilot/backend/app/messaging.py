"""
Parent alerts over SMS / WhatsApp.

How it works
  1. Something happens (attendance published, fee recorded, results out).
     The router calls `alert_parents(db, student, kind, text)` inside its own
     transaction. That adds an in-app notification for each linked parent
     and an `OutboundMessage` row with status "queued".
  2. A background worker (started with the app) picks up queued rows every
     few seconds and hands them to the configured provider. A slow or broken
     SMS gateway therefore never slows down or breaks the page the teacher is on,
     and a failed send is retried (3 attempts) and visible in the admin outbox.

Providers (MESSAGING_PROVIDER):
  log     default. Nothing leaves the server; messages are kept in the outbox
          with status "logged" so you can demo the feature for free.
  twilio  SMS or WhatsApp through Twilio (TWILIO_* settings).
  meta    WhatsApp Cloud API (META_WHATSAPP_TOKEN, META_WHATSAPP_PHONE_ID).
          Note: Meta only allows free-form text inside a 24-hour window after
          the parent last messaged you; for cold alerts create an approved
          template in Meta Business Manager (see docs/ALERTS.md).
"""
import logging
import re
import threading
import time
from datetime import datetime, timedelta

import httpx

from app import config

log = logging.getLogger("campuspilot.messaging")

PHONE_RE = re.compile(r"^\+\d{8,15}$")
MAX_ATTEMPTS = 3
KIND_LABELS = {"low_attendance": "Low attendance", "absent": "Absent today", "fee_due": "Fee reminder",
               "fee_paid": "Payment received", "results": "Results", "exam": "Exam schedule", "test": "Test message"}


def normalize_phone(phone) -> str:
    """'98765 43210' -> '+919876543210'. Returns '' if it isn't a usable mobile number."""
    p = re.sub(r"[\s\-().]", "", str(phone or ""))
    if p.startswith("00"):
        p = "+" + p[2:]
    if re.fullmatch(r"0?[6-9]\d{9}", p):          # Indian 10-digit mobile (optionally with leading 0)
        p = "+91" + p[-10:]
    elif re.fullmatch(r"91[6-9]\d{9}", p):
        p = "+" + p
    return p if PHONE_RE.match(p) else ""


def provider_status() -> dict:
    prov, ch = config.MESSAGING_PROVIDER, config.MESSAGING_CHANNEL
    if prov == "twilio":
        ready = bool(config.TWILIO_ACCOUNT_SID and config.TWILIO_AUTH_TOKEN and
                     (config.TWILIO_FROM_WHATSAPP if ch == "whatsapp" else config.TWILIO_FROM_SMS))
        label = f"Twilio {'WhatsApp' if ch == 'whatsapp' else 'SMS'}"
    elif prov == "meta":
        ready, ch = bool(config.META_WHATSAPP_TOKEN and config.META_WHATSAPP_PHONE_ID), "whatsapp"
        label = "WhatsApp Cloud API"
    else:
        ready, prov, label = True, "log", "Demo mode (saved to outbox, not sent)"
    return {"provider": prov, "channel": ch, "ready": ready, "label": label, "alerts": sorted(config.PARENT_ALERTS)}


# ------------------------------------------------------------ queueing
def parents_of(db, student_id: int):
    from app.models.models import ParentLink, User
    return (db.query(User).join(ParentLink, ParentLink.parent_id == User.id)
            .filter(ParentLink.student_id == student_id, User.status == "active").all())


def recently_alerted(db, student_id: int, kind: str, days: int) -> bool:
    from app.models.models import OutboundMessage
    since = datetime.utcnow() - timedelta(days=days)
    return db.query(OutboundMessage.id).filter(OutboundMessage.student_id == student_id, OutboundMessage.kind == kind,
                                               OutboundMessage.ts >= since).first() is not None


def queue_message(db, user, text: str, kind: str, student_id=None):
    from app.models.models import OutboundMessage
    phone = normalize_phone(user.phone)
    msg = OutboundMessage(user_id=user.id, student_id=student_id, to_name=user.name, phone=phone or (user.phone or ""),
                          channel="whatsapp" if config.MESSAGING_PROVIDER == "meta" else config.MESSAGING_CHANNEL,
                          kind=kind, body=text[:1000], status="queued" if phone else "skipped",
                          error=None if phone else "No valid mobile number on file")
    db.add(msg)
    return msg


def alert_parents(db, student, kind: str, text: str, title: str = None, dedupe_days: int = 0) -> int:
    """In-app notification + SMS/WhatsApp to every parent of `student`. Returns how many parents were alerted."""
    from app.common import notify_users
    if kind not in config.PARENT_ALERTS:
        return 0
    if dedupe_days and recently_alerted(db, student.id, kind, dedupe_days):
        return 0
    parents = parents_of(db, student.id)
    if not parents:
        return 0
    notify_users(db, [p.id for p in parents], title or KIND_LABELS.get(kind, "CampusPilot alert"), text)
    for p in parents:
        queue_message(db, p, f"{config.INSTITUTION_NAME}: {text}", kind, student_id=student.id)
    return len(parents)


# ------------------------------------------------------------ sending
def _send_twilio(msg):
    ch = msg.channel
    sender = config.TWILIO_FROM_WHATSAPP if ch == "whatsapp" else config.TWILIO_FROM_SMS
    to = msg.phone
    if ch == "whatsapp":
        sender, to = f"whatsapp:{sender}", f"whatsapp:{to}"
    r = httpx.post(f"https://api.twilio.com/2010-04-01/Accounts/{config.TWILIO_ACCOUNT_SID}/Messages.json",
                   data={"From": sender, "To": to, "Body": msg.body},
                   auth=(config.TWILIO_ACCOUNT_SID, config.TWILIO_AUTH_TOKEN), timeout=20)
    if r.status_code >= 300:
        raise RuntimeError(f"Twilio {r.status_code}: {r.text[:200]}")
    return r.json().get("sid", "")


def _send_meta(msg):
    version = config.META_GRAPH_VERSION
    r = httpx.post(f"https://graph.facebook.com/{version}/{config.META_WHATSAPP_PHONE_ID}/messages",
                   headers={"Authorization": f"Bearer {config.META_WHATSAPP_TOKEN}"},
                   json={"messaging_product": "whatsapp", "to": msg.phone.lstrip("+"), "type": "text",
                         "text": {"preview_url": False, "body": msg.body}}, timeout=20)
    if r.status_code >= 300:
        raise RuntimeError(f"WhatsApp Cloud API {r.status_code}: {r.text[:200]}")
    data = r.json()
    return (data.get("messages") or [{}])[0].get("id", "")


def deliver(msg):
    """Send one message with the configured provider; updates the row in place."""
    st = provider_status()
    msg.attempts = (msg.attempts or 0) + 1
    msg.provider = st["provider"]
    if st["provider"] == "log":
        msg.status, msg.sent_at = "logged", datetime.utcnow()
        log.info("[outbox] %s -> %s: %s", msg.channel, msg.to_name, msg.body[:80])
        return
    if not st["ready"]:
        msg.status, msg.error = "failed", f"{st['label']} is not configured (see .env)"
        return
    try:
        ref = _send_twilio(msg) if st["provider"] == "twilio" else _send_meta(msg)
        msg.status, msg.provider_ref, msg.sent_at, msg.error = "sent", ref[:120], datetime.utcnow(), None
    except Exception as e:  # network / provider error: retry a few times
        msg.error = str(e)[:300]
        msg.status = "failed" if msg.attempts >= MAX_ATTEMPTS else "queued"


def process_outbox(limit: int = 25) -> int:
    from app.database.db import SessionLocal
    from app.models.models import OutboundMessage
    db = SessionLocal()
    try:
        rows = (db.query(OutboundMessage).filter(OutboundMessage.status == "queued")
                .order_by(OutboundMessage.id).limit(limit).all())
        for m in rows:
            deliver(m)
        if rows:
            db.commit()
        return len(rows)
    finally:
        db.close()


_worker_started = False


def start_worker(interval: float = 3.0):
    global _worker_started
    if _worker_started:
        return
    _worker_started = True

    def _loop():
        while True:
            try:
                process_outbox()
            except Exception:
                log.exception("outbox worker error")
            time.sleep(interval)
    threading.Thread(target=_loop, name="outbox-worker", daemon=True).start()
