from typing import Literal, Optional
from pydantic import Field
from app.schemas.base import In, Short, Name, Email, Password, Text

class LoginRequest(In):
    email: Email
    password: Password
    role: Optional[Literal["student", "teacher", "admin", "parent"]] = None

class SignupRequest(In):
    name: Name
    email: Email
    password: Password
    role: Literal["student", "teacher", "admin"]
    id_label: Optional[Short] = Field(default=None, alias="idLabel")

class ChangePasswordRequest(In):
    current_password: Password = Field(alias="currentPassword")
    new_password: Password = Field(alias="newPassword")

class UserCreateByAdmin(In):
    name: Name
    email: Email
    role: Literal["student", "teacher", "admin"]
    id_label: Optional[Short] = Field(default=None, alias="idLabel")
    department: Optional[Short] = None
    designation: Optional[Short] = None
    phone: Optional[Short] = None
    year: Optional[int] = Field(default=None, ge=1, le=6)
    section: Optional[Short] = None

class UserStatusUpdate(In):
    status: Literal["active", "inactive"]

class ProfileUpdate(In):
    phone: Optional[Short] = None
    department: Optional[Short] = None
    designation: Optional[Short] = None
    qualification: Optional[Short] = None
    office: Optional[Short] = None
    bio: Optional[Text] = None
