from app.schemas.base import In, Annotated
from pydantic import StringConstraints

class CopilotQuestion(In):
    question: Annotated[str, StringConstraints(min_length=1, max_length=500)]


from typing import List, Literal
from pydantic import Field

class ChatTurn(In):
    role: Literal["user", "assistant"]
    content: Annotated[str, StringConstraints(min_length=1, max_length=2000)]

class CopilotChat(In):
    question: Annotated[str, StringConstraints(min_length=1, max_length=500)]
    history: List[ChatTurn] = Field(default_factory=list, max_length=12)
