from typing import List, Literal, Optional
from pydantic import Field
from app.schemas.base import In, Short, Name, Code, Text, Id

class CourseCreate(In):
    code: Code
    name: Name
    dept: Optional[Short] = ""
    faculty: Optional[Short] = ""          # faculty display name (legacy) ...
    faculty_id: Optional[Id] = Field(default=None, alias="facultyId")  # ... or explicit id

class EnrollRequest(In):
    student_ids: List[Id] = Field(alias="studentIds", max_length=5000)

class SubjectRejectRequest(In):
    reason: Optional[Text] = ""

class GrievanceAssignRequest(In):
    assignee: Name

class GrievanceResolveRequest(In):
    resolution: Optional[Text] = ""

class LeaveDecision(In):
    status: Literal["approved", "rejected"]

class FeePayment(In):
    amount: Optional[float] = Field(default=None, gt=0, le=10_000_000)
