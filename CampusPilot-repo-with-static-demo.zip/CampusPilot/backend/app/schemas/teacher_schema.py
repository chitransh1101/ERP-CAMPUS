from typing import List, Literal, Optional
from pydantic import Field
from app.schemas.base import In, Short, Name, Code, Text, Id, IsoDate

class SubjectRequestCreate(In):
    code: Code
    name: Name
    dept: Optional[Short] = "General"
    notes: Optional[Text] = ""

class AttendanceRecordIn(In):
    student_id: Id = Field(alias="studentId")
    present: bool
    confidence: Optional[float] = Field(default=None, ge=0, le=100)

class MarkAttendanceRequest(In):
    course_id: Id = Field(alias="courseId")
    course_label: Optional[Short] = Field(default=None, alias="courseLabel")
    date: Optional[IsoDate] = None
    records: List[AttendanceRecordIn] = Field(max_length=2000)

class GradeEntryIn(In):
    student_id: Id = Field(alias="studentId")
    score: float = Field(ge=0, le=100)

class PublishGradesRequest(In):
    course_id: Id = Field(alias="courseId")
    course_label: Optional[Short] = Field(default=None, alias="courseLabel")
    assessment: Name
    entries: List[GradeEntryIn] = Field(max_length=2000)

class AssignmentCreate(In):
    title: Name
    course: Optional[Short] = None
    course_id: Optional[Id] = Field(default=None, alias="courseId")
    due: Name

class MaterialUpload(In):
    title: Name
    course: Optional[Short] = None
    course_id: Optional[Id] = Field(default=None, alias="courseId")
    type: Literal["PDF", "PPT", "DOC", "Video", "Link", "Other"] = "PDF"
    size: Optional[Short] = None

class NoticeCreate(In):
    title: Name
    course: Optional[Short] = None
    course_id: Optional[Id] = Field(default=None, alias="courseId")

class LeaveRequestCreate(In):
    type: Short
    from_date: IsoDate = Field(alias="from")
    to_date: IsoDate = Field(alias="to")
    reason: Optional[Text] = ""

class DraftCreate(In):
    course_id: Id = Field(alias="courseId")
    date: Optional[IsoDate] = None

class DraftOverride(In):
    present: bool
