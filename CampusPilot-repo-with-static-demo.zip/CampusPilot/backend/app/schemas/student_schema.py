from typing import Optional
from pydantic import Field
from app.schemas.base import In, Short, Email, Id, Annotated
from pydantic import StringConstraints

Description = Annotated[str, StringConstraints(min_length=10, max_length=4000)]

class GrievanceCreate(In):
    category: Short = "Other"
    description: Description
    contact_email: Optional[Email] = Field(default=None, alias="contactEmail")

class BookRequestCreate(In):
    book_id: Id = Field(alias="bookId")
