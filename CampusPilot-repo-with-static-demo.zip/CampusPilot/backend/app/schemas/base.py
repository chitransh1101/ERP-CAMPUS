from typing import Annotated  # noqa: F401 (re-exported)
from pydantic import BaseModel, ConfigDict, StringConstraints

class In(BaseModel):
    """Base for every request body: trims whitespace, accepts camelCase or
    snake_case, and ignores unknown keys (they can never be mass-assigned)."""
    model_config = ConfigDict(populate_by_name=True, str_strip_whitespace=True, extra="ignore")

Short = Annotated[str, StringConstraints(max_length=150)]
Name = Annotated[str, StringConstraints(min_length=1, max_length=150)]
Code = Annotated[str, StringConstraints(min_length=1, max_length=30)]
Text = Annotated[str, StringConstraints(max_length=4000)]
Email = Annotated[str, StringConstraints(min_length=3, max_length=254)]
Password = Annotated[str, StringConstraints(min_length=1, max_length=128)]
Id = Annotated[str, StringConstraints(min_length=3, max_length=40, pattern=r"^[a-z]{1,5}_\d{1,12}$")]
IsoDate = Annotated[str, StringConstraints(pattern=r"^\d{4}-\d{2}-\d{2}$")]
