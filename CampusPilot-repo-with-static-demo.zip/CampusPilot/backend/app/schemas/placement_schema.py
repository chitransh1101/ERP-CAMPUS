from typing import Literal
from pydantic import Field
from app.schemas.base import In, Short, Name

class PlacementCreate(In):
    company: Name
    role: Name
    package: Short = ""
    location: Short = ""
    min_cgpa: float = Field(alias="minCGPA", ge=0, le=10)
    min_attendance: float = Field(alias="minAttendance", ge=0, le=100)
    deadline: Name

class ApplicationStatusUpdate(In):
    status: Literal["applied", "shortlisted", "selected", "rejected"]

class PlacementStatusUpdate(In):
    status: Literal["open", "closed"]
