"""
Abuse protection and HTTP hardening that isn't specific to login.

- SlidingWindowLimiter: bounded-memory, per-key request limiter.
- SecurityHeadersMiddleware: sets defensive response headers on every reply.
- client_ip(): the caller's address. uvicorn is started with
  --proxy-headers --forwarded-allow-ips so behind nginx this is the real
  client, and a direct caller can't spoof it with X-Forwarded-For.
"""
import threading
import time
from collections import OrderedDict, deque

from fastapi import HTTPException, Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

from app import config


def client_ip(request: Request) -> str:
    return (request.client.host if request.client else "unknown") or "unknown"


class SlidingWindowLimiter:
    """At most `limit` hits per `window` seconds per key. Memory is bounded
    by `max_keys` (least-recently-seen keys are evicted), so a flood of
    distinct keys can't exhaust RAM. For multi-worker deployments move this
    to Redis."""

    def __init__(self, limit: int, window: float, max_keys: int = 50_000):
        self.limit, self.window, self.max_keys = limit, window, max_keys
        self._hits = OrderedDict()
        self._lock = threading.Lock()

    def hit(self, key: str) -> float:
        """Record a hit. Returns 0 if allowed, else seconds until retry."""
        now = time.monotonic()
        with self._lock:
            q = self._hits.get(key)
            if q is None:
                q = deque()
                self._hits[key] = q
                if len(self._hits) > self.max_keys:
                    self._hits.popitem(last=False)
            else:
                self._hits.move_to_end(key)
            while q and q[0] <= now - self.window:
                q.popleft()
            if len(q) >= self.limit:
                return max(1.0, q[0] + self.window - now)
            q.append(now)
            return 0.0

    def check(self, key: str, message: str = "Too many requests — slow down and try again shortly."):
        retry = self.hit(key)
        if retry:
            raise HTTPException(status_code=429, detail=message, headers={"Retry-After": str(int(retry) + 1)})

    def reset(self):
        with self._lock:
            self._hits.clear()


global_limiter = SlidingWindowLimiter(config.RATE_LIMIT_PER_MINUTE, 60)
login_ip_limiter = SlidingWindowLimiter(config.LOGIN_RATE_PER_MINUTE, 60)
signup_ip_limiter = SlidingWindowLimiter(config.SIGNUP_RATE_PER_HOUR, 3600)
ocr_user_limiter = SlidingWindowLimiter(config.OCR_RATE_PER_MINUTE, 60)


class RateLimitMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        if request.url.path not in ("/health",):
            retry = global_limiter.hit(client_ip(request))
            if retry:
                return JSONResponse({"detail": "Too many requests — slow down and try again shortly."},
                                    status_code=429, headers={"Retry-After": str(int(retry) + 1)})
        return await call_next(request)


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        response = await call_next(request)
        h = response.headers
        h.setdefault("X-Content-Type-Options", "nosniff")
        h.setdefault("X-Frame-Options", "DENY")
        h.setdefault("Referrer-Policy", "no-referrer")
        h.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        h.setdefault("Cross-Origin-Opener-Policy", "same-origin")
        if not request.url.path.startswith(("/docs", "/redoc", "/openapi.json")):
            h.setdefault("Content-Security-Policy", "default-src 'none'; frame-ancestors 'none'")
        if request.url.path.startswith(("/auth", "/admin", "/teacher", "/student", "/placements", "/notifications", "/copilot",
                                        "/parent", "/exams", "/analytics", "/documents", "/calendar", "/verify")):
            h.setdefault("Cache-Control", "no-store")
        if config.COOKIE_SECURE:
            h.setdefault("Strict-Transport-Security", "max-age=63072000; includeSubDomains")
        return response


class BodySizeLimitMiddleware(BaseHTTPMiddleware):
    """Reject oversized bodies up front (Content-Length), before they are
    parsed or spooled to disk."""

    def __init__(self, app, max_json_bytes: int, max_upload_bytes: int):
        super().__init__(app)
        self.max_json, self.max_upload = max_json_bytes, max_upload_bytes

    async def dispatch(self, request, call_next):
        length = request.headers.get("content-length")
        if length and length.isdigit():
            ctype = request.headers.get("content-type", "")
            limit = self.max_upload if ctype.startswith("multipart/") else self.max_json
            if int(length) > limit:
                return JSONResponse({"detail": "Request body too large."}, status_code=413)
        return await call_next(request)
