"""
Real-time push over WebSockets.

Routers never talk to sockets directly. They call `queue_event(db, ...)`,
which parks the event on the SQLAlchemy session; an `after_commit` hook
publishes it only once the data is really saved (a rolled-back request
never announces something that didn't happen).

Targets: a set of user ids, a set of roles, or both.

Scaling note: connections live in this process's memory, which is correct
for the default single uvicorn worker. To run several workers or
machines, fan events out through Redis pub/sub in `_publish` — nothing
else needs to change.
"""
import asyncio
import json
import logging
from collections import defaultdict

from sqlalchemy import event
from sqlalchemy.orm import Session

log = logging.getLogger("campuspilot.realtime")


class ConnectionManager:
    def __init__(self):
        self.by_user = defaultdict(set)   # user_id -> {websocket}
        self.role_of = {}                 # user_id -> role
        self.loop_of = {}                 # websocket -> the event loop it lives on
        self.loop = None
        self.max_per_user = 8

    async def connect(self, ws, user_id: int, role: str):
        conns = self.by_user[user_id]
        if len(conns) >= self.max_per_user:  # cap sockets per account (resource-exhaustion guard)
            oldest = next(iter(conns))
            conns.discard(oldest)
            try:
                await oldest.close(code=4000)
            except Exception:
                pass
        conns.add(ws)
        self.loop_of[ws] = asyncio.get_running_loop()
        self.role_of[user_id] = role

    def disconnect(self, ws, user_id: int):
        self.loop_of.pop(ws, None)
        conns = self.by_user.get(user_id)
        if conns:
            conns.discard(ws)
            if not conns:
                self.by_user.pop(user_id, None)
                self.role_of.pop(user_id, None)

    def online_count(self):
        return sum(len(v) for v in self.by_user.values())

    async def _send(self, user_ids, message: str):
        dead = []
        for uid in user_ids:
            for ws in list(self.by_user.get(uid, ())):
                try:
                    await ws.send_text(message)
                except Exception:
                    dead.append((ws, uid))
        for ws, uid in dead:
            self.disconnect(ws, uid)

    def _targets(self, users, roles):
        targets = set(users or ())
        if roles:
            roles = set(roles)
            targets |= {uid for uid, r in self.role_of.items() if r in roles}
        return targets

    async def publish(self, type_: str, data, users=None, roles=None):
        targets = self._targets(users, roles)
        if targets:
            await self._send(targets, json.dumps({"type": type_, "data": data}, default=str))

    async def close_user(self, user_id: int):
        for ws in list(self.by_user.get(user_id, ())):
            try:
                await ws.send_text(json.dumps({"type": "session:revoked", "data": {}}))
                await ws.close(code=4001)
            except Exception:
                pass
            self.disconnect(ws, user_id)

    # ---- thread-safe entry points (sync route handlers run in a threadpool)
    async def _safe_send(self, ws, uid, message):
        try:
            await ws.send_text(message)
        except Exception:
            self.disconnect(ws, uid)

    def publish_threadsafe(self, type_, data, users=None, roles=None):
        targets = self._targets(users, roles)
        if not targets:
            return
        message = json.dumps({"type": type_, "data": data}, default=str)
        for uid in targets:
            for ws in list(self.by_user.get(uid, ())):
                loop = self.loop_of.get(ws)
                if loop and not loop.is_closed():
                    try:
                        asyncio.run_coroutine_threadsafe(self._safe_send(ws, uid, message), loop)
                    except RuntimeError:
                        pass

    def close_user_threadsafe(self, user_id):
        for ws in list(self.by_user.get(user_id, ())):
            loop = self.loop_of.get(ws)
            if loop and not loop.is_closed():
                try:
                    asyncio.run_coroutine_threadsafe(self.close_user(user_id), loop)
                except RuntimeError:
                    pass
                break


manager = ConnectionManager()


def queue_event(db: Session, type_: str, data=None, users=None, roles=None):
    """Publish after the current transaction commits."""
    db.info.setdefault("pending_events", []).append(
        (type_, data if data is not None else {}, set(users or ()), set(roles or ()))
    )


def queue_disconnect(db: Session, user_id: int):
    db.info.setdefault("pending_disconnects", []).append(user_id)


@event.listens_for(Session, "after_commit")
def _flush_events(session):
    events = session.info.pop("pending_events", [])
    for type_, data, users, roles in events:
        manager.publish_threadsafe(type_, data, users, roles)
    for uid in session.info.pop("pending_disconnects", []):
        manager.close_user_threadsafe(uid)


@event.listens_for(Session, "after_rollback")
def _drop_events(session):
    session.info.pop("pending_events", None)
    session.info.pop("pending_disconnects", None)
