"""
Printable documents (PDF) and QR codes.

  * QR codes: `qr_matrix(text)` returns the module grid (the frontend draws it
    as SVG; PDFs draw it with ReportLab) — no image files involved.
  * Verification: every ID card, hall ticket and certificate carries a QR
    code pointing to  <PUBLIC_URL>/verify/<token>.  The token is signed with
    SECRET_KEY (HMAC-SHA256), so it can't be forged or edited; the page shows
    only minimal details (name, roll no., department, validity).
  * PDFs are generated with ReportLab (pure Python). Built-in PDF fonts have
    no rupee glyph, so amounts are printed as "Rs.".
"""
import base64
import hashlib
import hmac
import io
import time
from datetime import date, datetime

from reportlab.graphics.barcode import qrencoder
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas
from reportlab.platypus import (
    KeepTogether, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle,
)

from app import config

INK = colors.HexColor("#14323A")
ACCENT = colors.HexColor("#12756B")
ACCENT_SOFT = colors.HexColor("#DCF3EE")
MUTED = colors.HexColor("#5B6B70")
LINE = colors.HexColor("#C9D5D6")
DANGER = colors.HexColor("#B42318")


# ================================================================ QR codes
def qr_matrix(text: str, level: str = "M") -> list:
    """Module grid of a QR code as a list of '0'/'1' strings (version picked automatically)."""
    q = qrencoder.QRCode(None, getattr(qrencoder.QRErrorCorrectLevel, level))  # version (size) picked automatically
    q.addData(text)
    q.make()
    n = q.getModuleCount()
    return ["".join("1" if q.isDark(r, c) else "0" for c in range(n)) for r in range(n)]


def draw_qr(c: canvas.Canvas, text: str, x: float, y: float, size: float, border: int = 2):
    rows = qr_matrix(text)
    n = len(rows)
    box = size / (n + 2 * border)
    c.setFillColor(colors.white)
    c.rect(x, y, size, size, stroke=0, fill=1)
    c.setFillColor(colors.black)
    for r, row in enumerate(rows):
        for col, bit in enumerate(row):
            if bit == "1":
                c.rect(x + (col + border) * box, y + size - (r + 1 + border) * box, box + 0.05, box + 0.05, stroke=0, fill=1)


def qr_flowable(text: str, size: float):
    from reportlab.platypus import Flowable

    class _QR(Flowable):
        def wrap(self, *_):
            return size, size

        def draw(self):
            draw_qr(self.canv, text, 0, 0, size)
    return _QR()


# ====================================================== signed verify tokens
def _b64(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def _unb64(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


_KIND_CODE = {"id": "i", "hallticket": "h", "gradecard": "g", "bonafide": "b"}
_CODE_KIND = {v: k for k, v in _KIND_CODE.items()}


def _b36(n: int) -> str:
    chars = "0123456789abcdefghijklmnopqrstuvwxyz"
    out = ""
    while True:
        n, r = divmod(n, 36)
        out = chars[r] + out
        if not n:
            return out


def _sig(payload: str) -> str:
    return _b64(hmac.new(config.SECRET_KEY.encode(), f"verify:{payload}".encode(), hashlib.sha256).digest()[:12])


def sign_token(kind: str, user_id: int, ref: int = 0) -> str:
    """Short, URL-safe and signed, e.g. 'b.9.21.tfn8mo.<16-char signature>' — short
    tokens keep the printed QR codes simple enough to scan off a small ID card."""
    payload = f"{_KIND_CODE[kind]}.{int(user_id)}.{int(ref)}.{_b36(int(time.time()))}"
    return f"{payload}.{_sig(payload)}"


def read_token(token: str):
    """Returns {'k','u','r','t'}, or None if the token was forged/edited/garbled."""
    try:
        payload, sig = str(token).rsplit(".", 1)
        if len(payload) > 80 or not hmac.compare_digest(sig, _sig(payload)):
            return None
        code, u, r, t36 = payload.split(".")
        return {"k": _CODE_KIND[code], "u": int(u), "r": int(r), "t": int(t36, 36)}
    except Exception:
        return None


def verify_url(kind: str, user_id: int, ref: int = 0) -> str:
    return f"{config.PUBLIC_URL}/verify/{sign_token(kind, user_id, ref)}"


# ============================================================ shared styles
_ss = getSampleStyleSheet()
H1 = ParagraphStyle("h1", parent=_ss["Title"], fontName="Helvetica-Bold", fontSize=17, leading=21, textColor=INK, spaceAfter=2)
H2 = ParagraphStyle("h2", parent=_ss["Heading2"], fontName="Helvetica-Bold", fontSize=12.5, leading=16, textColor=ACCENT,
                    spaceBefore=10, spaceAfter=5, keepWithNext=1)
H3 = ParagraphStyle("h3", parent=_ss["Heading3"], fontName="Helvetica-Bold", fontSize=10.5, leading=13, textColor=INK,
                    spaceBefore=6, spaceAfter=3, keepWithNext=1)
BODY = ParagraphStyle("body", parent=_ss["BodyText"], fontName="Helvetica", fontSize=10, leading=14, textColor=INK)
SMALL = ParagraphStyle("small", parent=BODY, fontSize=8.3, leading=11, textColor=MUTED)
CELL = ParagraphStyle("cell", parent=BODY, fontSize=8.8, leading=11)
CENTER = ParagraphStyle("center", parent=BODY, alignment=TA_CENTER)


def esc(s) -> str:
    return (str(s if s is not None else "")).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def fmt_date(iso) -> str:
    try:
        return date.fromisoformat(str(iso)[:10]).strftime("%d %b %Y")
    except Exception:
        return str(iso or "—")


def money(v) -> str:
    return "Rs. " + f"{float(v or 0):,.0f}"


def table(rows, widths, header=True, zebra=True, align_right=()):
    data = [[c if hasattr(c, "wrap") else Paragraph(esc(c), CELL) for c in r] for r in rows]
    t = Table(data, colWidths=widths, repeatRows=1 if header else 0)
    style = [("GRID", (0, 0), (-1, -1), 0.4, LINE), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
             ("TOPPADDING", (0, 0), (-1, -1), 3.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 3.5)]
    if header:
        style += [("BACKGROUND", (0, 0), (-1, 0), ACCENT), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white)]
        data[0] = [Paragraph(f"<font color='white'><b>{esc(c)}</b></font>", CELL) for c in rows[0]]
        t = Table(data, colWidths=widths, repeatRows=1)
    if zebra:
        for i in range(1 if header else 0, len(data)):
            if i % 2 == 0:
                style.append(("BACKGROUND", (0, i), (-1, i), colors.HexColor("#F3F8F8")))
    for col in align_right:
        style.append(("ALIGN", (col, 0), (col, -1), "RIGHT"))
    t.setStyle(TableStyle(style))
    return t


def _letterhead(c: canvas.Canvas, doc, title: str):
    w, h = doc.pagesize
    c.saveState()
    c.setFillColor(ACCENT)
    c.rect(0, h - 26 * mm, w, 26 * mm, stroke=0, fill=1)
    # crest
    c.setFillColor(colors.white)
    c.circle(20 * mm, h - 13 * mm, 7.5 * mm, stroke=0, fill=1)
    c.setFillColor(ACCENT)
    c.setFont("Helvetica-Bold", 11)
    c.drawCentredString(20 * mm, h - 14.8 * mm, "CP")
    c.setFillColor(colors.white)
    c.setFont("Helvetica-Bold", 15)
    c.drawString(31 * mm, h - 12 * mm, config.INSTITUTION_NAME)
    c.setFont("Helvetica", 9)
    c.drawString(31 * mm, h - 18 * mm, config.INSTITUTION_ADDRESS)
    c.setFont("Helvetica-Bold", 10)
    c.drawRightString(w - 12 * mm, h - 12 * mm, title.upper())
    c.setFont("Helvetica", 8)
    c.drawRightString(w - 12 * mm, h - 18 * mm, f"Generated {datetime.now().strftime('%d %b %Y, %I:%M %p')}")
    # footer
    c.setFillColor(MUTED)
    c.setFont("Helvetica", 7.5)
    c.drawString(12 * mm, 8 * mm, "Generated by CampusPilot ERP. Scan the QR code (where present) to verify this document online.")
    c.drawRightString(w - 12 * mm, 8 * mm, f"Page {doc.page}")
    c.restoreState()


def _build(story, title: str, pagesize=A4) -> bytes:
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=pagesize, leftMargin=14 * mm, rightMargin=14 * mm, topMargin=33 * mm,
                            bottomMargin=16 * mm, title=title, author=config.INSTITUTION_NAME, creator="CampusPilot")
    doc.build(story, onFirstPage=lambda c, d: _letterhead(c, d, title), onLaterPages=lambda c, d: _letterhead(c, d, title))
    return buf.getvalue()


def _photo_box(initials: str, size=26 * mm):
    from reportlab.platypus import Flowable

    class _P(Flowable):
        def wrap(self, *_):
            return size, size * 1.2

        def draw(self):
            c = self.canv
            c.setStrokeColor(LINE)
            c.setFillColor(ACCENT_SOFT)
            c.roundRect(0, 0, size, size * 1.2, 3 * mm, stroke=1, fill=1)
            c.setFillColor(ACCENT)
            c.setFont("Helvetica-Bold", 20)
            c.drawCentredString(size / 2, size * 0.55, initials)
            c.setFont("Helvetica", 6.5)
            c.setFillColor(MUTED)
            c.drawCentredString(size / 2, 3 * mm, "Affix photo")
    return _P()


def initials(name: str) -> str:
    parts = [p for p in str(name or "").replace(".", " ").split() if p and p[0].isalpha() and p.lower() not in ("dr", "prof", "mr", "ms")]
    return ("".join(p[0] for p in parts[:2]) or "?").upper()


def _signature_row(left="Student's signature", right="Controller of Examinations"):
    t = Table([["", "", ""], [left, "", right]], colWidths=[62 * mm, 58 * mm, 62 * mm], rowHeights=[14 * mm, 6 * mm])
    t.setStyle(TableStyle([("LINEABOVE", (0, 1), (0, 1), 0.6, INK), ("LINEABOVE", (2, 1), (2, 1), 0.6, INK),
                           ("FONT", (0, 1), (-1, 1), "Helvetica", 8.5), ("TEXTCOLOR", (0, 1), (-1, 1), MUTED),
                           ("ALIGN", (0, 1), (-1, 1), "CENTER")]))
    return t


# ================================================================ ID card
CARD = (85.6 * mm, 54 * mm)


def id_card_pdf(user, role_label: str, extra: dict) -> bytes:
    """Credit-card sized ID (front + back)."""
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=CARD)
    c.setTitle(f"ID card — {user.name}")
    w, h = CARD
    # ---- front
    c.setFillColor(colors.white)
    c.rect(0, 0, w, h, stroke=0, fill=1)
    c.setFillColor(ACCENT)
    c.rect(0, h - 12 * mm, w, 12 * mm, stroke=0, fill=1)
    c.setFillColor(colors.white)
    c.setFont("Helvetica-Bold", 8.2)
    c.drawString(4 * mm, h - 5.4 * mm, config.INSTITUTION_NAME[:48])
    c.setFont("Helvetica", 6)
    c.drawString(4 * mm, h - 9.2 * mm, f"{role_label.upper()} IDENTITY CARD")
    # photo
    c.setFillColor(ACCENT_SOFT)
    c.setStrokeColor(LINE)
    c.roundRect(4 * mm, 9 * mm, 20 * mm, 24 * mm, 2 * mm, stroke=1, fill=1)
    c.setFillColor(ACCENT)
    c.setFont("Helvetica-Bold", 15)
    c.drawCentredString(14 * mm, 19.5 * mm, initials(user.name))
    # details
    x = 27 * mm
    c.setFillColor(INK)
    c.setFont("Helvetica-Bold", 9.5)
    c.drawString(x, 35.5 * mm, user.name[:30])
    c.setFont("Helvetica", 6.6)
    yy = 31 * mm
    for label, val in extra.items():
        c.setFillColor(MUTED)
        c.drawString(x, yy, label)
        c.setFillColor(INK)
        c.drawString(x + 15 * mm, yy, str(val)[:26])
        yy -= 3.6 * mm
    draw_qr(c, verify_url("id", user.id), w - 22.5 * mm, 2.5 * mm, 20 * mm)
    c.setFillColor(ACCENT)
    c.rect(0, 0, w, 2 * mm, stroke=0, fill=1)
    c.showPage()
    # ---- back
    c.setFillColor(colors.white)
    c.rect(0, 0, w, h, stroke=0, fill=1)
    c.setFillColor(INK)
    c.setFont("Helvetica-Bold", 7.5)
    c.drawString(5 * mm, h - 8 * mm, "Instructions")
    c.setFont("Helvetica", 6.4)
    lines = ["This card is the property of the institute and must be carried on campus.",
             "It is non-transferable. Loss must be reported to the admin office immediately.",
             "Scan the QR code on the front to verify this card online.",
             "If found, please return to:"]
    y = h - 13 * mm
    for ln in lines:
        c.drawString(5 * mm, y, ln)
        y -= 3.8 * mm
    c.setFont("Helvetica-Bold", 6.6)
    c.drawString(5 * mm, y, config.INSTITUTION_NAME[:60])
    c.setFont("Helvetica", 6.4)
    c.drawString(5 * mm, y - 3.6 * mm, config.INSTITUTION_ADDRESS[:70])
    c.setStrokeColor(INK)
    c.line(w - 32 * mm, 9 * mm, w - 5 * mm, 9 * mm)
    c.setFont("Helvetica", 6)
    c.drawCentredString(w - 18.5 * mm, 6 * mm, "Issuing authority")
    c.setFillColor(ACCENT)
    c.rect(0, 0, w, 2 * mm, stroke=0, fill=1)
    c.showPage()
    c.save()
    return buf.getvalue()


# ============================================================== Bonafide
def bonafide_pdf(student, ref_no: str, purpose: str, doc_id: int) -> bytes:
    year = date.today().year
    ay = f"{year}-{str(year + 1)[-2:]}" if date.today().month >= 6 else f"{year - 1}-{str(year)[-2:]}"
    story = [
        Table([[Paragraph(f"Ref. No.: <b>{esc(ref_no)}</b>", BODY), Paragraph(f"Date: <b>{date.today().strftime('%d %b %Y')}</b>", BODY)]],
              colWidths=[120 * mm, 62 * mm]),
        Spacer(1, 14 * mm),
        Paragraph("BONAFIDE CERTIFICATE", ParagraphStyle("t", parent=H1, alignment=TA_CENTER, fontSize=19)),
        Spacer(1, 10 * mm),
        Paragraph(
            f"This is to certify that <b>{esc(student.name)}</b> (Roll No. <b>{esc(student.id_label or '—')}</b>) is a "
            f"bonafide student of {esc(config.INSTITUTION_NAME)}, currently studying in "
            f"<b>Year {esc(student.year or '—')}</b>{', Section ' + esc(student.section) if student.section else ''} of the "
            f"<b>{esc(student.department or '—')}</b> department during the academic year <b>{ay}</b>.",
            ParagraphStyle("b", parent=BODY, fontSize=12, leading=20)),
        Spacer(1, 5 * mm),
        Paragraph(f"This certificate is issued on the student's request for the purpose of <b>{esc(purpose)}</b>.",
                  ParagraphStyle("b2", parent=BODY, fontSize=12, leading=20)),
        Spacer(1, 5 * mm),
        Paragraph("To the best of our knowledge, the student bears a good moral character.",
                  ParagraphStyle("b3", parent=BODY, fontSize=12, leading=20)),
        Spacer(1, 24 * mm),
        Table([[qr_flowable(verify_url("bonafide", student.id, doc_id), 28 * mm), "",
                Paragraph("______________________<br/><b>Registrar</b><br/>" + esc(config.INSTITUTION_NAME), CENTER)]],
              colWidths=[40 * mm, 72 * mm, 70 * mm]),
        Spacer(1, 3 * mm),
        Paragraph("Scan the QR code to confirm this certificate was issued by the institute.", SMALL),
    ]
    return _build(story, "Bonafide Certificate")


# ============================================================ Hall ticket
def hall_ticket_pdf(student, exams: list, min_att: int) -> bytes:
    """exams: dicts with code, name, title, date, time, durationMin, room, attendancePct, eligible."""
    details = Table([
        [Paragraph("<b>Name</b>", CELL), Paragraph(esc(student.name), CELL), Paragraph("<b>Roll No.</b>", CELL), Paragraph(esc(student.id_label or "—"), CELL)],
        [Paragraph("<b>Department</b>", CELL), Paragraph(esc(student.department or "—"), CELL), Paragraph("<b>Year / Section</b>", CELL),
         Paragraph(f"{esc(student.year or '—')} / {esc(student.section or '—')}", CELL)],
        [Paragraph("<b>Email</b>", CELL), Paragraph(esc(student.email), CELL), Paragraph("<b>Issued</b>", CELL), Paragraph(date.today().strftime("%d %b %Y"), CELL)],
    ], colWidths=[22 * mm, 45 * mm, 25 * mm, 32 * mm])
    details.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.4, LINE), ("BACKGROUND", (0, 0), (0, -1), ACCENT_SOFT),
                                 ("BACKGROUND", (2, 0), (2, -1), ACCENT_SOFT), ("VALIGN", (0, 0), (-1, -1), "MIDDLE")]))
    qr = Table([[qr_flowable(verify_url("hallticket", student.id), 26 * mm)], [Paragraph("Scan to verify", SMALL)]], colWidths=[28 * mm])
    qr.setStyle(TableStyle([("ALIGN", (0, 0), (-1, -1), "CENTER"), ("LEFTPADDING", (0, 0), (-1, -1), 0)]))
    head = Table([[details, _photo_box(initials(student.name)), qr]], colWidths=[126 * mm, 28 * mm, 28 * mm])
    head.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LEFTPADDING", (0, 0), (-1, -1), 0)]))
    rows = [["Course", "Exam", "Date", "Time", "Room", "Eligibility"]]
    any_block = False
    for e in exams:
        ok = e["eligible"]
        any_block |= not ok
        elig = Paragraph("<font color='#12756B'><b>Eligible</b></font>" if ok else
                         f"<font color='#B42318'><b>Not eligible</b></font><br/><font size=7>Attendance {e['attendancePct']}%</font>", CELL)
        rows.append([f"{e['code']} — {e['name']}", e["title"], fmt_date(e["date"]),
                     f"{e['time']} ({e['durationMin']} min)", e["room"] or "TBA", elig])
    story = [head, Spacer(1, 6 * mm), Paragraph("Examination schedule", H2)]
    story.append(table(rows, [50 * mm, 32 * mm, 23 * mm, 28 * mm, 18 * mm, 31 * mm]) if exams else
                 Paragraph("No upcoming exams are scheduled for your courses yet.", BODY))
    if any_block and min_att:
        story += [Spacer(1, 3 * mm), Paragraph(
            f"<font color='#B42318'>Courses marked <b>Not eligible</b> are below the required {min_att}% attendance. "
            "Contact the examination cell before the exam.</font>", SMALL)]
    story += [Spacer(1, 5 * mm), Paragraph("Instructions", H3)]
    for i, line in enumerate(["Carry this hall ticket and your college ID card to every exam.",
                              "Report to the exam room at least 20 minutes before the start time.",
                              "Mobile phones, smart watches and written material are not allowed inside the exam hall.",
                              "Any form of malpractice will lead to cancellation of the exam."], 1):
        story.append(Paragraph(f"{i}. {line}", BODY))
    story += [Spacer(1, 10 * mm), KeepTogether([_signature_row()])]
    return _build(story, "Hall Ticket")


# ============================================================= Grade card
LETTERS = [(90, "O", 10), (80, "A+", 9), (70, "A", 8), (60, "B+", 7), (50, "B", 6), (45, "C", 5), (40, "P", 4)]


def letter_grade(pct):
    for minimum, letter, gp in LETTERS:
        if pct >= minimum:
            return letter, gp
    return "F", 0


def grade_card_pdf(student, courses: list, sgpa, term_label: str) -> bytes:
    """courses: dicts code, name, obtained, max, pct, letter, gp, result."""
    info = table([["Name", student.name, "Roll No.", student.id_label or "—"],
                  ["Department", student.department or "—", "Year / Section", f"{student.year or '—'} / {student.section or '—'}"]],
                 [28 * mm, 63 * mm, 30 * mm, 61 * mm], header=False, zebra=False)
    rows = [["Code", "Course", "Marks", "%", "Grade", "Grade point", "Result"]]
    for c in courses:
        rows.append([c["code"], c["name"], f"{c['obtained']:g} / {c['max']:g}", f"{c['pct']:.1f}", c["letter"], str(c["gp"]),
                     Paragraph(f"<font color='{'#12756B' if c['result'] == 'Pass' else '#B42318'}'><b>{c['result']}</b></font>", CELL)])
    story = [Paragraph(f"Statement of Grades — {esc(term_label)}", H1), Spacer(1, 3 * mm), info, Spacer(1, 6 * mm)]
    if courses:
        story.append(table(rows, [18 * mm, 62 * mm, 26 * mm, 16 * mm, 16 * mm, 22 * mm, 22 * mm]))
        credits = len(courses)
        story += [Spacer(1, 5 * mm), table([["Courses", "Passed", "SGPA (10-point scale)"],
                                             [str(credits), str(sum(1 for c in courses if c["result"] == "Pass")), f"{sgpa:.2f}"]],
                                            [60 * mm, 60 * mm, 62 * mm])]
    else:
        story.append(Paragraph("No exam results have been published for you yet.", BODY))
    story += [Spacer(1, 4 * mm),
              Paragraph("Grades: O 90+, A+ 80+, A 70+, B+ 60+, B 50+, C 45+, P 40+, F below 40 (percent). SGPA assumes equal credits per course.", SMALL),
              Spacer(1, 10 * mm),
              Table([[qr_flowable(verify_url("gradecard", student.id), 26 * mm), Paragraph("Scan to verify.", SMALL)]], colWidths=[32 * mm, 150 * mm]),
              Spacer(1, 2 * mm), _signature_row("Checked by", "Controller of Examinations")]
    return _build(story, "Grade Card")


# ===================================================== Analytics report
def _bar_chart(labels, values, width=175 * mm, height=55 * mm, max_value=100, suffix="%"):
    from reportlab.graphics.charts.barcharts import VerticalBarChart
    from reportlab.graphics.shapes import Drawing, String
    d = Drawing(width, height)
    ch = VerticalBarChart()
    ch.x, ch.y, ch.width, ch.height = 12 * mm, 10 * mm, width - 16 * mm, height - 16 * mm
    ch.data = [values or [0]]
    ch.categoryAxis.categoryNames = [str(l)[:18] for l in (labels or [""])]
    ch.categoryAxis.labels.fontSize = 7
    ch.categoryAxis.labels.fontName = "Helvetica"
    ch.valueAxis.valueMin, ch.valueAxis.valueMax = 0, max_value
    ch.valueAxis.valueStep = max_value / 4
    ch.valueAxis.labels.fontSize = 7
    ch.bars[0].fillColor = ACCENT
    ch.bars[0].strokeColor = None
    ch.barWidth = 6
    d.add(ch)
    for i, v in enumerate(values or []):
        step = ch.width / max(1, len(values))
        d.add(String(ch.x + step * (i + 0.5), ch.y + ch.height * min(1, v / max_value) + 2, f"{v:g}{suffix}",
                     fontSize=6.5, fontName="Helvetica-Bold", textAnchor="middle", fillColor=INK))
    return d


def analytics_pdf(data: dict, scope_label: str) -> bytes:
    k = data["kpis"]
    story = [Paragraph(f"Academic analytics — {esc(scope_label)}", H1), Paragraph(date.today().strftime("%d %B %Y"), SMALL),
             Spacer(1, 4 * mm),
             table([["Students", "Avg. attendance", "Pass rate", "At-risk students", "Fee collection"],
                    [str(k["students"]), f"{k['avgAttendance']}%", f"{k['passRate']}%", str(k["atRisk"]), f"{k['feeCollectedPct']}%"]],
                   [36 * mm] * 5, zebra=False),
             Paragraph("Attendance by department", H2),
             _bar_chart([d["dept"] for d in data["departments"]], [d["attendance"] or 0 for d in data["departments"]]),
             Paragraph("Department summary", H2),
             table([["Department", "Students", "Attendance", "Avg. score", "Pass rate", "At risk", "Fees"]] +
                   [[d["dept"], d["students"], f"{d['attendance']}%", d["avgScore"], f"{d['passRate']}%", d["atRisk"], f"{d['feeCollectedPct']}%"]
                    for d in data["departments"]],
                   [52 * mm, 18 * mm, 22 * mm, 22 * mm, 22 * mm, 18 * mm, 28 * mm])]
    if data.get("courses"):
        story += [Paragraph("Course-wise attendance and results", H2),
                  table([["Course", "Faculty", "Students", "Attendance", "Avg. score", "Pass rate"]] +
                        [[f"{c['code']} {c['name']}", c["faculty"], c["students"], f"{c['attendance']}%", c["avgScore"], f"{c['passRate']}%"]
                         for c in data["courses"]], [58 * mm, 38 * mm, 18 * mm, 22 * mm, 22 * mm, 24 * mm])]
    if data.get("atRiskStudents"):
        story += [Paragraph("Students needing attention", H2),
                  table([["Student", "Roll No.", "Department", "Attendance", "Avg. score", "Reasons"]] +
                        [[s["name"], s["idLabel"], s["department"], f"{s['attendancePct'] if s['attendancePct'] is not None else '—'}%",
                          s["avgScore"] if s["avgScore"] is not None else "—", "; ".join(s["reasons"])] for s in data["atRiskStudents"][:40]],
                        [34 * mm, 22 * mm, 30 * mm, 20 * mm, 18 * mm, 58 * mm])]
    return _build(story, "Analytics Report")


# ================================================== Accreditation report
def accreditation_pdf(report: dict) -> bytes:
    story = [Paragraph(f"Accreditation data — {esc(report['academicYear'])}", H1),
             Paragraph("Prepared from live CampusPilot records in the order of the NAAC criteria, with an NBA-style course-outcome "
                       "attainment table. Review every figure before submission.", SMALL), Spacer(1, 3 * mm)]
    for section in report["sections"]:
        story.append(Paragraph(esc(section["title"]), H2))
        if section.get("note"):
            story.append(Paragraph(esc(section["note"]), SMALL))
        for tb in section["tables"]:
            story.append(Paragraph(esc(tb["title"]), H3))
            cols = tb["columns"]
            n = len(cols)
            widths = [182 * mm / n] * n
            if n >= 3:
                widths = [182 * mm * 0.3] + [182 * mm * 0.7 / (n - 1)] * (n - 1)
            story.append(table([cols] + [[str(v) for v in r] for r in tb["rows"]] if tb["rows"] else [cols, ["No data yet"] + [""] * (n - 1)],
                               widths))
            if tb.get("note"):
                story.append(Paragraph(esc(tb["note"]), SMALL))
    return _build(story, "Accreditation Report")
