"""
Authentication and authorization.

Sessions
  Login issues a short JWT carrying a random `jti` that is also stored in
  the `user_sessions` table. Every request re-checks that row AND the
  user's current status/role in the database, so logging out, changing a
  password, or an admin deactivating an account takes effect immediately,
  not when the token eventually expires.

Transport
  Browsers get the token in an httpOnly, SameSite cookie (JavaScript can't
  read it, so an XSS bug can't steal it). Because cookies are sent
  automatically, every state-changing cookie request must also carry an
  X-CSRF-Token header equal to the readable cp_csrf cookie
  (double-submit). Non-browser clients may instead send
  `Authorization: Bearer <token>`, which isn't CSRF-able.

Passwords
  PBKDF2-HMAC-SHA256, 600k iterations, 16-byte salt, constant-time compare,
  with transparent re-hashing of older/weaker hashes on the next login.
"""
import hashlib
import hmac
import re
import secrets
import threading
import time
from datetime import datetime, timedelta, timezone

import jwt
from fastapi import Depends, HTTPException, Request
from sqlalchemy.orm import Session

from app import config
from app.database.db import get_db

ALGORITHM = "HS256"
ISSUER = "campuspilot"
AUDIENCE = "campuspilot-web"


# ================================================================ Passwords
def hash_password(password: str, iterations: int = None) -> str:
    iterations = iterations or config.PBKDF2_ITERATIONS
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return f"pbkdf2_sha256${iterations}${salt.hex()}${digest.hex()}"


def verify_password(plain_password: str, stored_hash: str) -> bool:
    try:
        scheme, iterations, salt, hex_digest = stored_hash.split("$")
        if scheme != "pbkdf2_sha256":
            return False
        digest = hashlib.pbkdf2_hmac("sha256", plain_password.encode("utf-8"), bytes.fromhex(salt), int(iterations))
        return hmac.compare_digest(digest.hex(), hex_digest)
    except (ValueError, AttributeError):
        return False


def needs_rehash(stored_hash: str) -> bool:
    try:
        return int(stored_hash.split("$")[1]) < config.PBKDF2_ITERATIONS
    except (IndexError, ValueError):
        return True


# Used when the email doesn't exist, so "unknown email" costs the same time
# as "wrong password" and response timing can't reveal which accounts exist.
_DUMMY_HASH = hash_password(secrets.token_hex(16))


def burn_password_check(password: str):
    verify_password(password, _DUMMY_HASH)


COMMON_PASSWORDS = {
    "password", "password1", "password123", "12345678", "123456789", "1234567890", "qwerty123",
    "qwertyuiop", "iloveyou", "11111111", "abc12345", "abcd1234", "letmein1", "welcome1",
    "admin1234", "changeme", "changeme123", "campuspilot", "student1", "teacher1",
}


def password_problems(password: str, email: str = "", name: str = "") -> list:
    """Returns human-readable reasons the password is unacceptable ([] = OK)."""
    problems = []
    if len(password) < config.PASSWORD_MIN_LENGTH:
        problems.append(f"at least {config.PASSWORD_MIN_LENGTH} characters")
    if len(password) > 128:
        problems.append("at most 128 characters")
    if not re.search(r"[A-Za-z]", password) or not re.search(r"\d", password):
        problems.append("both letters and numbers")
    low = password.lower()
    if low in COMMON_PASSWORDS:
        problems.append("not a commonly used password")
    local = (email or "").split("@")[0].lower()
    if len(local) >= 4 and local in low:
        problems.append("not contain your email name")
    return problems


def validate_new_password(password: str, email: str = "", name: str = ""):
    problems = password_problems(password, email, name)
    if problems:
        raise HTTPException(status_code=400, detail="Password must have " + ", ".join(problems) + ".")


def generate_temp_password() -> str:
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789"
    while True:
        pw = "".join(secrets.choice(alphabet) for _ in range(12))
        if re.search(r"\d", pw) and re.search(r"[A-Za-z]", pw):
            return pw


# ================================================================= Sessions
def create_session(db: Session, user, ip: str = "", user_agent: str = "") -> str:
    from app.models.models import UserSession
    jti = secrets.token_urlsafe(24)
    now = datetime.now(timezone.utc)
    expires = now + timedelta(hours=config.SESSION_HOURS)
    db.add(UserSession(jti=jti, user_id=user.id, expires_at=expires.replace(tzinfo=None),
                       ip=(ip or "")[:64], user_agent=(user_agent or "")[:255]))
    payload = {"sub": str(user.id), "role": user.role, "jti": jti, "iat": now, "nbf": now, "exp": expires,
               "iss": ISSUER, "aud": AUDIENCE}
    return jwt.encode(payload, config.SECRET_KEY, algorithm=ALGORITHM)


def decode_token(token: str) -> dict:
    return jwt.decode(token, config.SECRET_KEY, algorithms=[ALGORITHM], issuer=ISSUER, audience=AUDIENCE,
                      options={"require": ["exp", "sub", "jti", "iss", "aud"]})


def revoke_all_sessions(db: Session, user_id: int, except_jti: str = None):
    from app.models.models import UserSession
    from app.realtime import queue_disconnect
    q = db.query(UserSession).filter(UserSession.user_id == user_id, UserSession.revoked.is_(False))
    if except_jti:
        q = q.filter(UserSession.jti != except_jti)
    q.update({UserSession.revoked: True}, synchronize_session=False)
    if not except_jti:
        queue_disconnect(db, user_id)


def set_session_cookies(response, token: str):
    max_age = config.SESSION_HOURS * 3600
    response.set_cookie(config.COOKIE_NAME, token, max_age=max_age, httponly=True, secure=config.COOKIE_SECURE,
                        samesite=config.COOKIE_SAMESITE, path="/")
    response.set_cookie(config.CSRF_COOKIE_NAME, secrets.token_urlsafe(24), max_age=max_age, httponly=False,
                        secure=config.COOKIE_SECURE, samesite=config.COOKIE_SAMESITE, path="/")


def clear_session_cookies(response):
    for name in (config.COOKIE_NAME, config.CSRF_COOKIE_NAME):
        response.delete_cookie(name, path="/", secure=config.COOKIE_SECURE, samesite=config.COOKIE_SAMESITE)


class CurrentUser(dict):
    """dict-compatible (routers use current_user["user_id"]) plus attribute access to the ORM row."""
    @property
    def user(self):
        return self["_user"]


def _extract_token(request: Request):
    auth = request.headers.get("authorization", "")
    if auth.lower().startswith("bearer "):
        return auth[7:].strip(), "bearer"
    cookie = request.cookies.get(config.COOKIE_NAME)
    if cookie:
        return cookie, "cookie"
    return None, None


SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}


def authenticate_token(db: Session, token: str):
    """Returns (user, session) or raises 401/403. Shared by HTTP and WebSocket auth."""
    from app.models.models import User, UserSession
    try:
        payload = decode_token(token)
        user_id = int(payload["sub"])
        jti = payload["jti"]
    except Exception:
        raise HTTPException(status_code=401, detail="Your session has expired — please sign in again.")
    sess = db.get(UserSession, jti)
    if not sess or sess.revoked or sess.user_id != user_id or sess.expires_at < datetime.utcnow():
        raise HTTPException(status_code=401, detail="Your session has expired — please sign in again.")
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(status_code=401, detail="Account no longer exists.")
    if user.status != "active":
        raise HTTPException(status_code=401, detail="This account has been deactivated. Contact your campus admin.")
    return user, sess


def get_current_user(request: Request, db: Session = Depends(get_db)) -> CurrentUser:
    token, via = _extract_token(request)
    if not token:
        raise HTTPException(status_code=401, detail="Please sign in.")
    if via == "cookie" and request.method not in SAFE_METHODS:
        sent = request.headers.get(config.CSRF_HEADER_NAME, "")
        expected = request.cookies.get(config.CSRF_COOKIE_NAME, "")
        if not sent or not expected or not hmac.compare_digest(sent, expected):
            raise HTTPException(status_code=403, detail="Security check failed (CSRF). Refresh the page and try again.")
    user, sess = authenticate_token(db, token)
    return CurrentUser(user_id=user.id, role=user.role, name=user.name, jti=sess.jti, _user=user)


def require_role(allowed_roles: list):
    allowed = set(allowed_roles)

    def role_checker(current_user: CurrentUser = Depends(get_current_user)):
        if current_user["role"] not in allowed:
            raise HTTPException(status_code=403, detail="Not authorized for this action")
        return current_user
    return role_checker


# ============================================================ Login lockout
class LoginGuard:
    """Per-account failed-login counter with escalating lockout. Keyed by the
    normalized email whether or not the account exists, so behaviour is
    identical for real and fake addresses. Bounded memory."""

    def __init__(self, max_failures: int, lockout_seconds: int, max_keys: int = 100_000):
        self.max_failures, self.lockout, self.max_keys = max_failures, lockout_seconds, max_keys
        self._state = {}
        self._lock = threading.Lock()

    def check(self, key: str):
        with self._lock:
            st = self._state.get(key)
            if st and st["until"] > time.time():
                secs = int(st["until"] - time.time()) + 1
                raise HTTPException(status_code=429, detail=f"Too many failed attempts. Try again in {secs}s.",
                                    headers={"Retry-After": str(secs)})

    def fail(self, key: str) -> bool:
        with self._lock:
            if len(self._state) > self.max_keys:
                cutoff = time.time()
                for k in [k for k, v in self._state.items() if v["until"] < cutoff][: self.max_keys // 2]:
                    self._state.pop(k, None)
            st = self._state.setdefault(key, {"count": 0, "until": 0, "strikes": 0})
            st["count"] += 1
            if st["count"] >= self.max_failures:
                st["strikes"] += 1
                st["until"] = time.time() + self.lockout * min(8, 2 ** (st["strikes"] - 1))
                st["count"] = 0
                return True
            return False

    def clear(self, key: str):
        with self._lock:
            self._state.pop(key, None)

    def reset_all(self):
        with self._lock:
            self._state.clear()


login_guard = LoginGuard(config.LOGIN_MAX_FAILURES, config.LOGIN_LOCKOUT_SECONDS)
