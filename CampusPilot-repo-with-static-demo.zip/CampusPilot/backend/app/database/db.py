from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker, declarative_base

from app.config import DATABASE_URL

# SQLite (default, zero-setup) or PostgreSQL/MySQL via DATABASE_URL, e.g.
#   postgresql+psycopg2://campuspilot:secret@db:5432/campuspilot
_is_sqlite = DATABASE_URL.startswith("sqlite")

if _is_sqlite:
    engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False, "timeout": 30})

    @event.listens_for(engine, "connect")
    def _sqlite_pragmas(dbapi_conn, _record):
        cur = dbapi_conn.cursor()
        cur.execute("PRAGMA journal_mode=WAL")     # readers don't block the writer
        cur.execute("PRAGMA synchronous=NORMAL")
        cur.execute("PRAGMA foreign_keys=ON")      # enforce FK integrity
        cur.execute("PRAGMA busy_timeout=30000")
        cur.close()
else:
    engine = create_engine(
        DATABASE_URL,
        pool_size=10, max_overflow=20, pool_pre_ping=True, pool_recycle=1800,
    )

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine, expire_on_commit=False)
Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
