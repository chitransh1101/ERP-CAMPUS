import asyncio
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from starlette.middleware.trustedhost import TrustedHostMiddleware
from starlette.responses import JSONResponse

from app import config
from app.ai.attendance_ocr import engine_available
from app.database.db import Base, engine
from app.models import models  # noqa: F401  (registers tables)
from app.realtime import manager
from app.routers import (
    admin_router, auth_router, campus_router, copilot_router, exams_router, insights_router, notification_router,
    parent_router, placements_router, qr_router, student_router, teacher_router, ws_router,
)
from app.security import BodySizeLimitMiddleware, RateLimitMiddleware, SecurityHeadersMiddleware

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("campuspilot")
logging.getLogger("httpx").setLevel(logging.WARNING)  # don't log every AI-provider request


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    manager.loop = asyncio.get_running_loop()
    from app.ai import copilot_llm
    copilot_llm.warm_up()  # preload the local AI model (if Ollama is the copilot) in the background
    from app import messaging
    messaging.start_worker()  # sends queued parent SMS / WhatsApp alerts in the background
    log.info("CampusPilot API starting (env=%s, db=%s, ocr=%s)", config.ENV,
             engine.url.get_backend_name(), "ready" if engine_available() else "UNAVAILABLE")
    yield


app = FastAPI(
    title="CampusPilot API",
    lifespan=lifespan,
    docs_url="/docs" if config.ENABLE_DOCS else None,
    redoc_url=None,
    openapi_url="/openapi.json" if config.ENABLE_DOCS else None,
)

# Order matters: the last-added middleware runs first.
app.add_middleware(GZipMiddleware, minimum_size=1024)
app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=config.CORS_ORIGINS,   # explicit allow-list, never "*" with credentials
    allow_credentials=True,
    allow_methods=["GET", "POST", "PATCH", "DELETE"],
    allow_headers=["Content-Type", config.CSRF_HEADER_NAME, "Authorization"],
    max_age=600,
)
app.add_middleware(BodySizeLimitMiddleware, max_json_bytes=1024 * 1024,
                   max_upload_bytes=(config.MAX_UPLOAD_MB * config.MAX_PHOTOS_PER_REQUEST + 1) * 1024 * 1024)
app.add_middleware(RateLimitMiddleware)
if config.TRUSTED_HOSTS != ["*"]:
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=config.TRUSTED_HOSTS)


@app.exception_handler(RequestValidationError)
async def validation_handler(request: Request, exc: RequestValidationError):
    """Readable validation errors, without echoing submitted values back."""
    msgs = []
    for e in exc.errors()[:5]:
        field = ".".join(str(p) for p in e.get("loc", [])[1:]) or "request"
        msgs.append(f"{field}: {e.get('msg', 'invalid')}")
    return JSONResponse({"detail": "Invalid input — " + "; ".join(msgs)}, status_code=422)


@app.exception_handler(Exception)
async def unhandled(request: Request, exc: Exception):
    """Never leak stack traces or SQL to clients; log them server-side."""
    log.exception("Unhandled error on %s %s", request.method, request.url.path)
    return JSONResponse({"detail": "Something went wrong on our side. Please try again."}, status_code=500)


for r in (auth_router, admin_router, teacher_router, student_router, placements_router, notification_router,
          copilot_router, ws_router, parent_router, exams_router, qr_router, insights_router, campus_router):
    app.include_router(r.router)


@app.get("/health")
def health_check():
    return {"status": "ok", "ocr": engine_available(), "liveConnections": manager.online_count()}
