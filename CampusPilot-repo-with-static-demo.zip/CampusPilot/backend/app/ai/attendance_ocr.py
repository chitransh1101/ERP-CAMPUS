"""
Attendance-sheet OCR.

Turns a phone photo of a paper attendance sheet into per-student
present/absent readings, matched against the real class roster.

Pipeline (per photo)
  1. Safe decode: size/format/pixel-count checks, EXIF orientation.
  2. Quality check: blur, darkness, glare, resolution -> warnings for the teacher.
  3. Geometry: crop + flatten the page if its outline is visible, then deskew.
  4. Clean-up: flatten uneven lighting, strip ruled table lines, binarise.
     Two binarisations are OCR'd and their readings merged (better recall).
  5. Tesseract word boxes -> rows (clustered by vertical position).
  6. Each row: identify the student by roll number (exact, OCR-confusion
     tolerant e.g. O/0 S/5 B/8, or 1 edit away) or by fuzzy name match.
  7. Read the mark on that row:
       * register grids (day-number header like 01 02 03 ...): the cell in
         the column for the session's date;
       * daily sheets: the P / A / Present / Absent / L / OD mark after the name;
       * sign-in sheets: something written in the row but no P/A = signed = present
         (low confidence, flagged for review); blank = absent (flagged).

Nothing here invents data: a student who can't be found on the sheet is
reported as "unseen" and left for the teacher to decide.
"""
import os
import re
import statistics
import time
from dataclasses import dataclass, field
from difflib import SequenceMatcher

import cv2
import numpy as np

try:
    import pytesseract
except ImportError:  # pragma: no cover
    pytesseract = None

from app import config

_tesseract_cmd = os.environ.get("TESSERACT_CMD")
if pytesseract and _tesseract_cmd:
    pytesseract.pytesseract.tesseract_cmd = _tesseract_cmd


class OcrUnavailable(RuntimeError):
    pass


class BadImage(ValueError):
    pass


_ENGINE_OK = None


def engine_available() -> bool:
    global _ENGINE_OK
    if _ENGINE_OK is None:
        try:
            pytesseract.get_tesseract_version()
            _ENGINE_OK = True
        except Exception:
            _ENGINE_OK = False
    return _ENGINE_OK


# =================================================================== 1. decode
_MAGIC = [(b"\xff\xd8\xff", "jpeg"), (b"\x89PNG\r\n\x1a\n", "png"), (b"RIFF", "webp"), (b"BM", "bmp"),
          (b"II*\x00", "tiff"), (b"MM\x00*", "tiff")]


def load_image(data: bytes) -> np.ndarray:
    if not data:
        raise BadImage("The uploaded file is empty.")
    if len(data) > config.MAX_UPLOAD_MB * 1024 * 1024:
        raise BadImage(f"Photo is larger than {config.MAX_UPLOAD_MB} MB.")
    kind = next((k for sig, k in _MAGIC if data.startswith(sig)), None)
    if kind == "webp" and data[8:12] != b"WEBP":
        kind = None
    if kind is None:
        if data[4:12] in (b"ftypheic", b"ftypheix", b"ftypmif1", b"ftyphevc"):
            raise BadImage("HEIC photos aren't supported — set your camera to 'Most Compatible' (JPEG) or take the photo from the browser.")
        raise BadImage("Unsupported file type — upload a JPEG, PNG or WebP photo.")
    buf = np.frombuffer(data, dtype=np.uint8)
    # Read the header dimensions first (cheap) to refuse decompression bombs.
    probe = cv2.imdecode(buf, cv2.IMREAD_REDUCED_GRAYSCALE_8)
    if probe is None:
        raise BadImage("That file couldn't be read as an image — it may be corrupt.")
    if probe.shape[0] * probe.shape[1] * 64 > config.MAX_IMAGE_PIXELS:
        raise BadImage("Image resolution is too large.")
    img = cv2.imdecode(buf, cv2.IMREAD_COLOR)  # applies EXIF orientation
    if img is None:
        raise BadImage("That file couldn't be read as an image — it may be corrupt.")
    return img


# ============================================================== 2. quality
def glyph_height(gray):
    """Median height (px) of character-sized blobs — how big the text is."""
    small_scale = 1.0
    if max(gray.shape) > 2400:
        small_scale = 2400 / max(gray.shape)
        gray = cv2.resize(gray, None, fx=small_scale, fy=small_scale, interpolation=cv2.INTER_AREA)
    bw = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
    _, _, stats, _ = cv2.connectedComponentsWithStats(bw, 8)
    hs = [s[3] for s in stats[1:] if 4 <= s[3] <= 120 and 2 <= s[2] <= 120 and s[4] >= 8 and s[2] <= 3 * s[3]]
    if len(hs) < 20:
        return None
    return float(np.median(hs)) / small_scale


MIN_READABLE_GLYPH = 11  # px; below this OCR of names/roll numbers is unreliable


def quality_warnings(img) -> list:
    warnings = []
    h, w = img.shape[:2]
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gh = glyph_height(gray)
    if gh is not None and gh < MIN_READABLE_GLYPH:
        warnings.append(f"Text in this photo is very small (about {gh:.0f} px tall) — move closer so the sheet fills the frame, "
                        "or photograph half the sheet at a time. Screenshots of videos are usually too low-resolution.")
    elif max(h, w) < 900:
        warnings.append("Low resolution — move closer or use the full camera resolution.")
    small = cv2.resize(gray, (1000, int(1000 * h / w))) if w > 1000 else gray
    if cv2.Laplacian(small, cv2.CV_64F).var() < 60:
        warnings.append("Photo looks blurry — hold the phone steady and tap to focus.")
    mean = float(gray.mean())
    if mean < 70:
        warnings.append("Photo is too dark — add light or turn on flash.")
    if float((gray > 250).mean()) > 0.25:
        warnings.append("Strong glare detected — tilt the sheet away from the light.")
    return warnings


# ============================================================= 3. geometry
def _order_quad(pts):
    pts = pts.reshape(4, 2).astype("float32")
    s, d = pts.sum(1), np.diff(pts, axis=1).ravel()
    return np.array([pts[np.argmin(s)], pts[np.argmin(d)], pts[np.argmax(s)], pts[np.argmax(d)]], dtype="float32")


def _flatten_page(gray):
    """If the paper's outline is clearly visible, warp it to a flat rectangle."""
    h, w = gray.shape
    edges = cv2.Canny(cv2.GaussianBlur(gray, (5, 5), 0), 50, 150)
    edges = cv2.dilate(edges, np.ones((3, 3), np.uint8))
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for c in sorted(contours, key=cv2.contourArea, reverse=True)[:5]:
        area = cv2.contourArea(c)
        if area < 0.35 * h * w:
            break
        approx = cv2.approxPolyDP(c, 0.02 * cv2.arcLength(c, True), True)
        if len(approx) == 4 and area < 0.98 * h * w:
            tl, tr, br, bl = quad = _order_quad(approx)
            width = int(max(np.linalg.norm(br - bl), np.linalg.norm(tr - tl)))
            height = int(max(np.linalg.norm(tr - br), np.linalg.norm(tl - bl)))
            if width < 200 or height < 200:
                break
            dst = np.array([[0, 0], [width - 1, 0], [width - 1, height - 1], [0, height - 1]], dtype="float32")
            return cv2.warpPerspective(gray, cv2.getPerspectiveTransform(quad, dst), (width, height),
                                       flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
    return gray


def _skew_angle(gray) -> float:
    h, w = gray.shape
    edges = cv2.Canny(gray, 50, 150)
    lines = cv2.HoughLinesP(edges, 1, np.pi / 720, threshold=120, minLineLength=w // 5, maxLineGap=15)
    angles = []
    if lines is not None:
        for x1, y1, x2, y2 in lines[:, 0]:
            if x2 != x1:
                a = np.degrees(np.arctan2(y2 - y1, x2 - x1))
                if abs(a) < 20:
                    angles.append(a)
    if len(angles) >= 3:
        return float(np.median(angles))
    # No ruled lines: estimate from text blobs.
    bw = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
    bw = cv2.morphologyEx(bw, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT, (25, 3)))
    cnts, _ = cv2.findContours(bw, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for c in cnts:
        (_, _), (cw, ch), a = cv2.minAreaRect(c)
        if cw < ch:
            cw, ch, a = ch, cw, a - 90
        if cw > w * 0.08 and cw > 4 * ch and abs(a) < 20:
            angles.append(a)
    return float(np.median(angles)) if len(angles) >= 3 else 0.0


def _rotate(gray, angle):
    h, w = gray.shape
    m = cv2.getRotationMatrix2D((w / 2, h / 2), angle, 1.0)
    return cv2.warpAffine(gray, m, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)


def normalize_geometry(img):
    h, w = img.shape[:2]
    longest = max(h, w)
    scale = 1.0
    if longest < 2000:
        scale = min(3.0, 2000 / longest)
    elif longest > 3200:
        scale = 3200 / longest
    gh = glyph_height(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY))
    if gh and gh * scale < 18:  # tiny text: enlarge letters to ~22 px (Tesseract's comfort zone)
        scale = max(scale, min(4.0, 22 / gh, 4200 / longest))
    if scale != 1.0:
        img = cv2.resize(img, (int(w * scale), int(h * scale)),
                         interpolation=cv2.INTER_CUBIC if scale > 1 else cv2.INTER_AREA)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = _flatten_page(gray)
    angle = _skew_angle(gray)
    if abs(angle) > 0.3:
        gray = _rotate(gray, angle)
    return gray


# ============================================================== 4. clean-up
def _flatten_lighting(gray):
    k = max(31, (min(gray.shape) // 20) | 1)
    bg = cv2.morphologyEx(gray, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_RECT, (k, k)))
    return cv2.divide(gray, bg, scale=255)


def _remove_rules(binary_inv):
    """binary_inv: text/lines white on black. Returns it with long ruled lines removed."""
    h, w = binary_inv.shape
    horiz = cv2.morphologyEx(binary_inv, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (max(40, w // 25), 1)))
    vert = cv2.morphologyEx(binary_inv, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (1, max(40, h // 25))))
    lines = cv2.dilate(cv2.bitwise_or(horiz, vert), np.ones((3, 3), np.uint8))
    return cv2.bitwise_and(binary_inv, cv2.bitwise_not(lines))


def binarize_variants(gray):
    flat = _flatten_lighting(gray)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(flat)
    adaptive = cv2.adaptiveThreshold(clahe, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 31, 15)
    adaptive = cv2.medianBlur(_remove_rules(adaptive), 3)
    otsu = cv2.threshold(cv2.GaussianBlur(flat, (3, 3), 0), 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
    otsu = _remove_rules(otsu)
    return [("adaptive", cv2.bitwise_not(adaptive)), ("otsu", cv2.bitwise_not(otsu))]


# ================================================================ 5. words
@dataclass
class Word:
    text: str
    conf: float
    x: int
    y: int
    w: int
    h: int

    @property
    def xc(self):
        return self.x + self.w / 2

    @property
    def yc(self):
        return self.y + self.h / 2

    @property
    def right(self):
        return self.x + self.w


def ocr_words(binary, psm: int = 6):
    data = pytesseract.image_to_data(
        binary, lang="eng", config=f"--oem 1 --psm {psm} -c preserve_interword_spaces=1",
        output_type=pytesseract.Output.DICT, timeout=40,
    )
    words = []
    for i, text in enumerate(data["text"]):
        text = (text or "").strip()
        try:
            conf = float(data["conf"][i])
        except (TypeError, ValueError):
            conf = -1
        if not text or conf < 0:
            continue
        words.append(Word(text, conf, data["left"][i], data["top"][i], data["width"][i], data["height"][i]))
    return words


def group_rows(words):
    if not words:
        return []
    med_h = statistics.median(w.h for w in words) or 10
    rows = []
    for wd in sorted(words, key=lambda w: w.yc):
        if rows and abs(wd.yc - rows[-1]["yc"]) <= 0.55 * med_h:
            r = rows[-1]
            r["words"].append(wd)
            r["yc"] = sum(x.yc for x in r["words"]) / len(r["words"])
        else:
            rows.append({"yc": wd.yc, "words": [wd]})
    return [sorted(r["words"], key=lambda w: w.x) for r in rows]


# ========================================================= 6. roster match
_CONFUSABLE = str.maketrans({"O": "0", "Q": "0", "D": "0", "I": "1", "L": "1", "|": "1", "!": "1",
                             "Z": "2", "S": "5", "B": "8", "G": "6", "T": "7"})
_TITLES = {"dr", "prof", "mr", "mrs", "ms", "miss", "shri", "smt", "kumari"}


def _clean(t):
    return re.sub(r"[^A-Za-z0-9]", "", t).upper()


def _canon(t):
    return _clean(t).translate(_CONFUSABLE)


def _lev1(a, b) -> bool:
    """True if a and b are within one edit."""
    if a == b:
        return True
    la, lb = len(a), len(b)
    if abs(la - lb) > 1:
        return False
    if la == lb:
        return sum(x != y for x, y in zip(a, b)) == 1
    if la > lb:
        a, b = b, a
    i = 0
    while i < len(a) and a[i] == b[i]:
        i += 1
    return a[i:] == b[i + 1:]


_NAME_CONFUSIONS = (("rn", "m"), ("cl", "d"), ("vv", "w"), ("ii", "u"), ("0", "o"), ("1", "l"))


def _name_canon(t):
    for a, b in _NAME_CONFUSIONS:
        t = t.replace(a, b)
    return t


def _ratio(a, b):
    r = SequenceMatcher(None, a, b).ratio()
    if r < 0.95:  # classic OCR merges: "Arnav" -> "Amav", "Claire" -> "Daire"
        r = max(r, SequenceMatcher(None, _name_canon(a), _name_canon(b)).ratio() - 0.02)
    return r


class RosterMatcher:
    def __init__(self, roster):
        """roster: [{"studentId": "u_3", "name": "...", "idLabel": "CS21B045"}]"""
        self.students = roster
        self.by_exact, self.by_canon = {}, {}
        canon_count = {}
        for s in roster:
            roll = _clean(s.get("idLabel") or "")
            if roll:
                self.by_exact[roll] = s
                c = roll.translate(_CONFUSABLE)
                canon_count[c] = canon_count.get(c, 0) + 1
                self.by_canon[c] = s
        # A canonical form shared by two students is ambiguous: don't use it.
        for c, n in canon_count.items():
            if n > 1:
                self.by_canon.pop(c, None)
        self.name_tokens = {}
        first_counts = {}
        for s in roster:
            toks = [t for t in re.findall(r"[a-z]+", (s.get("name") or "").lower()) if t not in _TITLES and len(t) > 1]
            self.name_tokens[s["studentId"]] = toks
            if toks:
                first_counts[toks[0]] = first_counts.get(toks[0], 0) + 1
        self.unique_first = {sid: toks[0] for sid, toks in self.name_tokens.items() if toks and first_counts[toks[0]] == 1}

    # ---- roll numbers
    def _roll_lookup(self, token):
        t = _clean(token)
        if len(t) < 3:
            return None, 0
        if t in self.by_exact:
            return self.by_exact[t], 1.0
        c = t.translate(_CONFUSABLE)
        if c in self.by_canon:
            return self.by_canon[c], 0.95
        if len(c) >= 6:
            hits = [s for k, s in self.by_canon.items() if _lev1(c, k)]
            if len(hits) == 1:
                return hits[0], 0.85
        return None, 0

    def find_rolls(self, row):
        """All roll-number hits in a row: [(student, score, first_word_idx, last_word_idx)]."""
        hits, i = [], 0
        while i < len(row):
            best = None
            for span in (3, 2, 1):  # "CS21 B045" may be split into several words
                if i + span > len(row):
                    continue
                joined = "".join(w.text for w in row[i:i + span])
                if len(_clean(joined)) > 14:
                    continue
                s, score = self._roll_lookup(joined)
                if s and (best is None or score > best[1]):
                    best = (s, score, i, i + span - 1)
            if best:
                hits.append(best)
                i = best[3] + 1
            else:
                i += 1
        return hits

    # ---- names
    def match_name(self, row):
        alpha = [(i, w.text.lower()) for i, w in enumerate(row) if re.fullmatch(r"[A-Za-z][A-Za-z.'-]+", w.text)]
        alpha = [(i, re.sub(r"[^a-z]", "", t)) for i, t in alpha]
        alpha = [(i, t) for i, t in alpha if len(t) > 1 and t not in _TITLES]
        if not alpha:
            return None
        scored = []
        for s in self.students:
            toks = self.name_tokens[s["studentId"]]
            if not toks:
                continue
            used, ratios = set(), []
            for nt in toks:
                best_r, best_i = 0, None
                for i, t in alpha:
                    if i in used:
                        continue
                    r = _ratio(nt, t)
                    if r > best_r:
                        best_r, best_i = r, i
                if best_i is not None and best_r >= 0.7:
                    used.add(best_i)
                ratios.append(best_r)
            full = sum(ratios) / len(ratios)
            if len(toks) > 1 and sum(r >= 0.7 for r in ratios) == 1:
                # Only one name part matched: accept only for a unique, near-exact first name.
                if self.unique_first.get(s["studentId"]) == toks[0] and ratios[0] >= 0.88:
                    full = ratios[0] * 0.85
                else:
                    full *= 0.6
            scored.append((full, s, used))
        if not scored:
            return None
        scored.sort(key=lambda x: x[0], reverse=True)
        best = scored[0]
        second = scored[1][0] if len(scored) > 1 else 0
        if best[0] >= 0.74 and best[0] - second >= 0.06:
            return best[1], round(best[0], 3), max(best[2]) if best[2] else alpha[-1][0]
        return None


# =================================================================== 7. marks
_PRESENT = {"P", "PR", "PRE", "PRES", "PRESENT", "PP", "PRSNT"}
_ABSENT = {"A", "AB", "ABS", "ABSENT", "AA", "ABSNT"}
_LEAVE = {"L", "LV", "LEAVE", "ML", "CL"}
_ONDUTY = {"OD", "0D"}
_WEAK_PRESENT = {"V", "✓", "√"}  # tick marks often OCR as V
_WEAK_ABSENT = {"X"}


def classify_mark(text):
    t = re.sub(r"[^A-Za-z0-9✓√]", "", text).upper()
    if not t:
        return None
    if t in _PRESENT:
        return "present", 1.0, "P"
    if t in _ABSENT:
        return "absent", 1.0, "A"
    if t in _LEAVE:
        return "absent", 0.9, "Leave"
    if t in _ONDUTY:
        return "present", 0.85, "On duty"
    if t in _WEAK_PRESENT:
        return "present", 0.7, "tick"
    if t in _WEAK_ABSENT:
        return "absent", 0.7, "cross"
    return None


def detect_day_header(rows):
    """Finds a register header row of day numbers (01 02 03 ...). Returns {day: x_center} or None."""
    best = None
    for row in rows:
        days = {}
        for w in row:
            t = _clean(w.text)
            if t.isdigit() and 1 <= int(t) <= 31 and len(t) <= 2:
                days.setdefault(int(t), w.xc)
        if len(days) >= 6:
            ordered = sorted(days.items())
            increasing = sum(1 for (d1, x1), (d2, x2) in zip(ordered, ordered[1:]) if x2 > x1)
            if increasing >= 0.8 * (len(ordered) - 1) and (best is None or len(days) > len(best)):
                best = days
    return best


@dataclass
class Reading:
    status: object          # "present" | "absent" | None (row found, mark unreadable)
    confidence: float       # 0-100
    matched_by: str
    evidence: str


@dataclass
class PhotoAnalysis:
    readings: dict = field(default_factory=dict)  # studentId -> Reading
    unrecognized: list = field(default_factory=list)
    warnings: list = field(default_factory=list)
    mode: str = "daily"
    rows_read: int = 0
    ms: int = 0


def _split_mark_runs(words):
    """Tesseract often reads adjacent register cells "P | A | P" as one word
    "PAP". Cells are equal width, so split such runs evenly into single marks."""
    out = []
    for w in words:
        t = re.sub(r"[^A-Za-z]", "", w.text).upper()
        if len(t) >= 2 and set(t) <= set("PAL") and t not in _PRESENT | _ABSENT | _LEAVE:
            step = w.w / len(t)
            for i, ch in enumerate(t):
                out.append(Word(ch, w.conf, int(w.x + i * step), w.y, max(1, int(step)), w.h))
        else:
            out.append(w)
    return out


def _row_ink(binary, id_words, x_start):
    """Fraction of dark pixels in the row band to the right of x_start."""
    if binary is None or not id_words:
        return None
    h_img, w_img = binary.shape[:2]
    # Band from the *median* word geometry: stray specks OCR'd as ":" or "."
    # must not stretch the band into the neighbouring row's signature.
    words = [w for w in id_words if len(_clean(w.text)) >= 2] or id_words
    yc = statistics.median(w.yc for w in words)
    half = 0.75 * statistics.median(w.h for w in words)
    y0, y1 = max(0, int(yc - half)), min(h_img, int(yc + half))
    x0, x1 = int(x_start), int(w_img * 0.97)
    if x1 - x0 < 20 or y1 - y0 < 5:
        return None
    dark = binary[y0:y1, x0:x1] < 128
    # Ruled lines that survived clean-up run the full height/width of the
    # band; writing doesn't. Drop near-solid columns and rows before counting.
    keep_cols = dark.mean(axis=0) < 0.6
    keep_rows = dark.mean(axis=1) < 0.6
    dark = dark[np.ix_(keep_rows, keep_cols)]
    return float(dark.mean()) if dark.size else 0.0


def _analyze_rows(rows, matcher, target_day, binary=None):
    header = detect_day_header(rows)
    sign_words = [w for row in rows[:10] for w in row if _clean(w.text) in ("SIGN", "SIGNATURE", "SIGNATURES", "SIGNED")]
    signin = bool(sign_words) and header is None
    sign_col_x = max(w.x for w in sign_words) - 10 if signin else None
    column_x, tol, mode = None, None, "daily"
    if header:
        mode = "register"
        xs = [x for _, x in sorted(header.items())]
        spacing = statistics.median([b - a for a, b in zip(xs, xs[1:])]) if len(xs) > 1 else 40
        tol = max(12, spacing * 0.6)
        if target_day in header:
            column_x = header[target_day]
        elif target_day and len(header) >= 2:
            # Header partly unreadable: interpolate the column from its neighbours.
            (d1, x1), (d2, x2) = sorted(header.items())[0], sorted(header.items())[-1]
            if d2 != d1 and d1 <= target_day <= d2:
                column_x = x1 + (x2 - x1) * (target_day - d1) / (d2 - d1)
    readings, unrecognized = {}, []

    def put(sid, reading):
        cur = readings.get(sid)
        if cur is None or reading.confidence > cur.confidence:
            readings[sid] = reading

    for row in rows:
        text = " ".join(w.text for w in row)
        roll_hits = matcher.find_rolls(row)
        segments = []
        if roll_hits:
            for k, (s, score, i0, i1) in enumerate(roll_hits):
                end = roll_hits[k + 1][2] if k + 1 < len(roll_hits) else len(row)
                seg = row[i0:end]
                nm = matcher.match_name(seg)
                # Roll and name agree -> stronger; disagree -> trust roll, lower confidence.
                if nm and nm[0]["studentId"] == s["studentId"]:
                    score = min(1.0, score + 0.05)
                    id_end = max(i1, i0 + nm[2])
                elif nm:
                    score *= 0.8
                    id_end = i1
                else:
                    id_end = i1
                segments.append((s, score, "roll", row[id_end + 1:end] if id_end + 1 <= end else []))
        else:
            nm = matcher.match_name(row)
            if nm:
                s, score, last_idx = nm
                segments.append((s, score, "name", row[last_idx + 1:]))
        if not segments:
            # Report rows that look like a student entry we couldn't match
            # (a roll-number-like token AND an attendance mark) — e.g. a
            # student missing from this course's roster. Titles/headers don't
            # qualify, so they never show up as noise.
            roll_like = any(re.fullmatch(r"(?=.*\d.*\d.*\d)[A-Z0-9]{6,14}", _clean(w.text)) for w in row)
            if roll_like and any(classify_mark(w.text) for w in row):
                unrecognized.append(text[:80])
            continue
        for s, id_score, how, tail in segments:
            sid = s["studentId"]
            if mode == "register":
                tail = _split_mark_runs(tail)
                if column_x is None:
                    put(sid, Reading(None, round(id_score * 60), how, "Found on register, but this date's column wasn't located"))
                    continue
                # Per-row alignment: perspective/skew shifts columns slightly
                # row to row, so snap this row's cells onto the header grid.
                offs = []
                for w in tail:
                    if classify_mark(w.text):
                        nearest = min(xs, key=lambda hx: abs(hx - w.xc))
                        if abs(w.xc - nearest) < spacing / 2:
                            offs.append(w.xc - nearest)
                shift = statistics.median(offs) if len(offs) >= 3 else 0
                col = column_x + shift
                cands = [(abs(w.xc - col), w, classify_mark(w.text)) for w in tail]
                cands = [c for c in cands if c[0] <= tol and c[2]]
                if cands:
                    _, w, (status, strength, label) = min(cands, key=lambda c: c[0])
                    conf = id_score * strength * (0.6 + 0.4 * max(0.0, min(1.0, w.conf / 100))) * 100
                    put(sid, Reading(status, round(conf), how, f"{label} in day-{target_day} column"))
                else:
                    put(sid, Reading(None, round(id_score * 50), how, f"Day-{target_day} cell empty or unreadable"))
                continue
            marks = [(w, classify_mark(w.text)) for w in tail]
            marks = [(w, m) for w, m in marks if m]
            if signin:  # scribbles OCR as random letters: only trust spelled-out words
                marks = [(w, m) for w, m in marks if len(_clean(w.text)) >= 4]
            if marks:
                w, (status, strength, label) = marks[-1]
                conf = id_score * strength * (0.6 + 0.4 * max(0.0, min(1.0, w.conf / 100))) * 100
                put(sid, Reading(status, round(conf), how, f'"{w.text}" ({label})'))
            else:
                id_words = [w for w in row if w not in tail] or row
                if sign_col_x is not None:
                    x_start = sign_col_x
                else:  # no header: start after the last word that looks like part of the name
                    named = [w for w in row if re.search(r"[A-Za-z]{3,}", w.text) and w not in tail[1:]] or id_words
                    x_start = max(w.right for w in named) + 2 * statistics.median(w.h for w in id_words)
                ink = _row_ink(binary, id_words, x_start)
                if ink is None:
                    other = "".join(_clean(w.text) for w in tail)
                    signed = len(other) >= 3
                    strength = 0.6
                else:
                    signed = ink >= INK_SIGNED
                    clear = ink >= 2 * INK_SIGNED or ink <= INK_SIGNED / 3
                    # On a sign-in sheet, clear ink / clear blank is strong evidence.
                    # On a P/A sheet a "blank" row may just be a mark OCR missed, so
                    # it always goes to the teacher for review.
                    strength = (0.85 if clear else 0.6) if signin else 0.55
                if signed:
                    put(sid, Reading("present", round(id_score * strength * 100), how, "Signature/writing in row (no P/A mark)"))
                else:
                    put(sid, Reading("absent", round(id_score * strength * 100), how, "Row blank (no mark or signature)"))
    return readings, unrecognized, ("signin" if signin else mode)


INK_SIGNED = 0.012  # dark-pixel fraction that counts as "something written"


def analyze_photo(data: bytes, roster: list, target_day: int = None) -> PhotoAnalysis:
    if not engine_available():
        raise OcrUnavailable("The OCR engine (Tesseract) isn't installed on the server.")
    t0 = time.monotonic()
    img = load_image(data)
    result = PhotoAnalysis(warnings=quality_warnings(img))
    gray = normalize_geometry(img)
    matcher = RosterMatcher(roster)
    unrecognized_all = []
    for name, binary in binarize_variants(gray):
        rows = group_rows(ocr_words(binary, psm=6))
        readings, unrec, mode = _analyze_rows(rows, matcher, target_day, binary)
        result.rows_read = max(result.rows_read, len(rows))
        if mode != "daily":
            result.mode = mode
        for sid, r in readings.items():
            cur = result.readings.get(sid)
            if cur is None or (r.status is not None and (cur.status is None or r.confidence > cur.confidence)):
                result.readings[sid] = r
        unrecognized_all.extend(unrec)
        # Good first pass (most of the roster found with confident marks) -> skip the second variant.
        found = sum(1 for r in result.readings.values() if r.status)
        confident = sum(1 for r in result.readings.values() if r.status and r.confidence >= 75)
        if roster and found == len(roster) and confident >= 0.9 * len(roster):
            break
    seen, uniq = set(), []
    for u in unrecognized_all:
        k = _clean(u)
        if k not in seen:
            seen.add(k)
            uniq.append(u)
    result.unrecognized = uniq[:25]
    if not result.readings:
        result.warnings.append("No students from this class were recognised — check the photo shows roll numbers or names clearly.")
    result.ms = int((time.monotonic() - t0) * 1000)
    return result


# ====================================================== Merging into a draft
REVIEW_THRESHOLD = 70


def new_draft_state(roster):
    return {
        "students": {s["studentId"]: {**s, "status": "unseen", "confidence": 0, "matchedBy": None, "evidence": "",
                                      "photo": None, "conflict": False, "manual": False, "needsReview": True, "readings": 0}
                     for s in roster},
        "photos": [],
    }


def _refresh_review(st):
    st["needsReview"] = (not st["manual"]) and (st["status"] == "unseen" or st["conflict"] or st["confidence"] < REVIEW_THRESHOLD)


def merge_photo(state, analysis: PhotoAnalysis, filename: str):
    idx = len(state["photos"]) + 1
    matched = 0
    for sid, r in analysis.readings.items():
        st = state["students"].get(sid)
        if st is None:
            continue
        matched += 1
        st["readings"] += 1
        if st["manual"]:
            continue
        if r.status is None:
            if st["status"] == "unseen" and not st["evidence"]:
                st.update(evidence=r.evidence, matchedBy=r.matched_by, photo=idx)
            continue
        if st["status"] == "unseen":
            st.update(status=r.status, confidence=r.confidence, matchedBy=r.matched_by, evidence=r.evidence, photo=idx)
        elif r.status != st["status"]:
            if min(r.confidence, st["confidence"]) >= 50:
                st["conflict"] = True
            if r.confidence > st["confidence"]:
                st.update(status=r.status, confidence=r.confidence, matchedBy=r.matched_by, evidence=r.evidence, photo=idx)
        elif r.confidence > st["confidence"]:
            st.update(confidence=r.confidence, evidence=r.evidence, photo=idx)
        _refresh_review(st)
    state["photos"].append({"index": idx, "filename": (filename or f"photo-{idx}")[:80], "mode": analysis.mode,
                            "rowsRead": analysis.rows_read, "matched": matched, "unrecognized": analysis.unrecognized,
                            "warnings": analysis.warnings, "ms": analysis.ms})
    return state


def override(state, sid, present: bool):
    st = state["students"][sid]
    st.update(status="present" if present else "absent", manual=True, conflict=False, confidence=100, matchedBy="manual",
              evidence="Set by teacher")
    _refresh_review(st)


def summarize(state):
    s = list(state["students"].values())
    return {"total": len(s), "present": sum(x["status"] == "present" for x in s),
            "absent": sum(x["status"] == "absent" for x in s), "unseen": sum(x["status"] == "unseen" for x in s),
            "needsReview": sum(x["needsReview"] for x in s), "photos": len(state["photos"])}
