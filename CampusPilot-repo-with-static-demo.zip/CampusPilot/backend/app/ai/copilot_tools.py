"""
Tools the AI copilot may call — the ONLY way it can see data.

Security design
  * Every tool runs as the signed-in user by calling the same route
    functions the app itself uses, so the same role + ownership checks apply:
    a student's copilot can only ever read that student's records.
  * Read-only. The AI cannot change anything. "Action" tools only *propose*
    an action; the user sees a confirm card, and the browser then calls the
    normal API endpoint (with its own validation + CSRF) if they approve.
    So a malicious instruction hidden in some text (prompt injection) can't
    make the copilot do anything on its own.
  * Results are trimmed so large lists don't leak more than needed or blow
    up the token bill.
"""
import json
import re
from datetime import date
from difflib import SequenceMatcher

from fastapi import HTTPException

from app.common import STUDENT_CATEGORIES, TEACHER_CATEGORIES

MAX_ITEMS = 25
MAX_RESULT_CHARS = 6000


def _trim(obj, max_items=MAX_ITEMS):
    if isinstance(obj, list):
        out = [_trim(x, max_items) for x in obj[:max_items]]
        if len(obj) > max_items:
            out.append(f"... {len(obj) - max_items} more not shown")
        return out
    if isinstance(obj, dict):
        return {k: _trim(v, max_items) for k, v in obj.items()}
    return obj


def _pick(rows, keys):
    return [{k: r.get(k) for k in keys if k in r} for r in rows]


def to_json(obj, max_chars=MAX_RESULT_CHARS) -> str:
    s = json.dumps(_trim(obj), default=str, ensure_ascii=False)
    return s if len(s) <= max_chars else s[:max_chars] + '..."(truncated)"'


def _similar(a, b):
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()


# ============================================================= STUDENT TOOLS
def _student_tools():
    from app.routers import placements_router as pr
    from app.routers import student_router as sr

    def overview(db, cu, a):
        s = sr.summary(db=db, current_user=cu)
        return {**{k: s[k] for k in ("attendancePct", "present", "totalLectures", "cgpa", "feeDue", "feeStatus")},
                "riskLevel": s["risk"]["riskLevel"], "riskReasons": s["risk"]["reasons"]}

    def attendance(db, cu, a):
        return sr.my_attendance(db=db, current_user=cu)

    def grades(db, cu, a):
        return sr.my_grades(db=db, current_user=cu)

    def assignments(db, cu, a):
        return _pick(sr.assignments(db=db, current_user=cu), ["title", "course", "due", "status"])

    def fees(db, cu, a):
        return sr.my_fees(db=db, current_user=cu)

    def timetable(db, cu, a):
        return sr.timetable(db=db, current_user=cu)

    def notices(db, cu, a):
        return _pick(sr.notices(db=db, current_user=cu), ["course", "title", "sentBy"])

    def placements(db, cu, a):
        rows = pr.list_placements(db=db, current_user=cu)
        applied = {x["placementId"]: x["status"] for x in pr.my_applications(db=db, current_user=cu)}
        return [{**{k: p[k] for k in ("company", "role", "package", "location", "minCGPA", "minAttendance", "deadline", "status", "eligible", "ineligibleReasons")},
                 "myApplication": applied.get(p["id"])} for p in rows]

    def grievances(db, cu, a):
        return _pick(sr.my_grievances(db=db, current_user=cu), ["category", "priority", "status", "routedTo", "assignedTo", "resolution", "description"])

    def library(db, cu, a):
        q = (a.get("query") or "").lower()
        books = sr.library_catalog(db=db, current_user=cu)
        if q:
            books = [b for b in books if q in f"{b['title']} {b['author']} {b['category']}".lower()] or \
                    sorted(books, key=lambda b: -_similar(q, b["title"]))[:5]
        mine = _pick(sr.my_library_requests(db=db, current_user=cu), ["title", "status"])
        return {"books": _pick(books, ["title", "author", "category", "copies"]), "myRequests": mine}

    # ---- action proposals (never executed here)
    def propose_grievance(db, cu, a):
        desc = (a.get("description") or "").strip()
        if len(desc) < 10:
            return {"error": "Ask the user to describe the problem in a bit more detail first."}
        cat = a.get("category") if a.get("category") in STUDENT_CATEGORIES else "Other"
        return {"proposal": {"type": "raise_grievance", "params": {"category": cat, "description": desc[:4000]},
                             "summary": f"Raise a grievance ({cat}): \"{desc[:140]}\""}}

    def propose_book(db, cu, a):
        title = (a.get("title") or "").strip()
        books = sr.library_catalog(db=db, current_user=cu)
        best = max(books, key=lambda b: _similar(title, b["title"]), default=None)
        if not best or _similar(title, best["title"]) < 0.5:
            return {"error": f"No book matching '{title}' in the catalog."}
        return {"proposal": {"type": "request_book", "params": {"bookId": best["id"], "title": best["title"]},
                             "summary": f"Request \"{best['title']}\" from the library ({best['copies']} available)"}}

    def propose_placement(db, cu, a):
        company = (a.get("company") or "").strip()
        rows = [p for p in pr.list_placements(db=db, current_user=cu) if p["status"] == "open"]
        best = max(rows, key=lambda p: _similar(company, p["company"]), default=None)
        if not best or _similar(company, best["company"]) < 0.5:
            return {"error": f"No open placement drive for '{company}'."}
        if not best["eligible"]:
            return {"error": f"Not eligible for {best['company']}: {', '.join(best['ineligibleReasons'])}."}
        return {"proposal": {"type": "apply_placement", "params": {"placementId": best["id"], "company": best["company"]},
                             "summary": f"Apply to {best['company']} — {best['role']} ({best['package']})"}}

    return [
        ("get_my_overview", "Attendance %, CGPA, fee status and early-warning risk level for the student.", {}, overview),
        ("get_my_attendance", "Per-subject attendance with how many classes can be missed / must be attended to stay at 75%, plus weekly trend.", {}, attendance),
        ("get_my_grades", "All published marks per subject with averages, grade points and CGPA.", {}, grades),
        ("get_my_assignments", "Assignments for the student's subjects with due dates and submitted/pending status.", {}, assignments),
        ("get_my_fees", "Fee total, paid, balance due and due date.", {}, fees),
        ("get_my_timetable", "Weekly class timetable (day -> time, course, room).", {}, timetable),
        ("get_my_notices", "Recent notices from the student's teachers.", {}, notices),
        ("get_placements", "Placement drives with eligibility for this student and application status.", {}, placements),
        ("get_my_grievances", "Grievances the student raised and their status.", {}, grievances),
        ("search_library", "Search the library catalog and see the student's book requests.",
         {"query": {"type": "string", "description": "title/author/topic words"}}, library),
        ("propose_raise_grievance", "PROPOSE raising a grievance for the student. Does not submit — the user must confirm.",
         {"category": {"type": "string", "enum": STUDENT_CATEGORIES}, "description": {"type": "string"}}, propose_grievance),
        ("propose_request_book", "PROPOSE requesting a library book by title. The user must confirm.",
         {"title": {"type": "string"}}, propose_book),
        ("propose_apply_placement", "PROPOSE applying to an open placement drive by company name. The user must confirm.",
         {"company": {"type": "string"}}, propose_placement),
    ]


# ============================================================= TEACHER TOOLS
def _teacher_tools():
    from app.routers import teacher_router as tr

    def courses(db, cu, a):
        return _pick(tr.my_subjects(db=db, current_user=cu), ["id", "code", "name", "students", "classesHeld", "progress"])

    def _course_id(db, cu, code):
        if not code:
            return None
        for c in tr.my_courses(db=db, current_user=cu):
            if c["code"].lower() == code.strip().lower() or c["name"].lower() == code.strip().lower():
                return c["id"]
        raise HTTPException(status_code=404, detail=f"'{code}' is not one of your courses.")

    def report(db, cu, a):
        return tr.reports_summary(db=db, current_user=cu)

    def students(db, cu, a):
        cid = _course_id(db, cu, a.get("course_code"))
        rows = tr.risk_scores(course_ids=cid or "", db=db, current_user=cu)
        level = a.get("risk_level")
        if level in ("high", "medium", "low"):
            rows = [r for r in rows if r["riskLevel"] == level]
        rows = sorted(rows, key=lambda r: r["healthScore"])
        return _pick(rows, ["name", "idLabel", "attendancePct", "avgScore", "feeStatus", "healthScore", "riskLevel", "reasons"])

    def sessions(db, cu, a):
        cid = _course_id(db, cu, a.get("course_code"))
        if not cid:
            return {"error": "Which course? Give a course code."}
        return _pick(tr.attendance_sessions(course_id=cid, db=db, current_user=cu), ["date", "present", "total", "method"])

    def assignments(db, cu, a):
        return _pick(tr.list_assignments(db=db, current_user=cu, courses=""), ["title", "course", "due", "submittedCount", "totalStudents"])

    def leave(db, cu, a):
        return _pick(tr.list_my_leave(db=db, current_user=cu), ["type", "from", "to", "status", "decidedBy"])

    def grievances(db, cu, a):
        return _pick(tr.my_grievances(db=db, current_user=cu), ["category", "priority", "status", "assignedTo", "resolution"])

    def timetable(db, cu, a):
        return tr.timetable(db=db, current_user=cu)

    def propose_leave(db, cu, a):
        try:
            f, t = date.fromisoformat(a.get("from", "")), date.fromisoformat(a.get("to", ""))
        except ValueError:
            return {"error": "Dates must be YYYY-MM-DD. Ask the user for exact dates."}
        if t < f:
            return {"error": "End date is before start date."}
        typ = a.get("type") if a.get("type") in ("Casual", "Medical", "Conference", "Earned") else "Casual"
        reason = (a.get("reason") or "").strip()[:1000] or "—"
        return {"proposal": {"type": "apply_leave", "params": {"type": typ, "from": f.isoformat(), "to": t.isoformat(), "reason": reason},
                             "summary": f"Apply for {typ} leave {f:%d %b} → {t:%d %b %Y}: {reason[:100]}"}}

    def propose_notice(db, cu, a):
        cid = _course_id(db, cu, a.get("course_code"))
        msg = (a.get("message") or "").strip()
        if not cid or len(msg) < 3:
            return {"error": "Need a course code and the notice text."}
        return {"proposal": {"type": "send_notice", "params": {"courseId": cid, "title": msg[:150]},
                             "summary": f"Send notice to {a.get('course_code').upper()}: \"{msg[:150]}\""}}

    def propose_grievance(db, cu, a):
        desc = (a.get("description") or "").strip()
        if len(desc) < 10:
            return {"error": "Ask for more detail first."}
        cat = a.get("category") if a.get("category") in TEACHER_CATEGORIES else "Other"
        return {"proposal": {"type": "raise_grievance", "params": {"category": cat, "description": desc[:4000]},
                             "summary": f"Raise a grievance ({cat}): \"{desc[:140]}\""}}

    course_arg = {"course_code": {"type": "string", "description": "e.g. CS301 (optional = all my courses)"}}
    return [
        ("get_my_courses", "The teacher's courses with enrolment and classes held.", {}, courses),
        ("get_class_report", "Average attendance and score, classes held, grade distribution across the teacher's courses.", {}, report),
        ("get_students", "Students in the teacher's courses with attendance, average score, fee status and risk; filter by course and risk level.",
         {**course_arg, "risk_level": {"type": "string", "enum": ["high", "medium", "low"]}}, students),
        ("get_attendance_history", "Past attendance sessions for one course (date, present/total, method).", course_arg, sessions),
        ("get_assignments", "Assignments posted with submission counts.", {}, assignments),
        ("get_my_leave", "The teacher's leave requests and status.", {}, leave),
        ("get_my_grievances", "Grievances the teacher raised.", {}, grievances),
        ("get_my_timetable", "Weekly teaching timetable.", {}, timetable),
        ("propose_apply_leave", "PROPOSE a leave application. The user must confirm.",
         {"type": {"type": "string", "enum": ["Casual", "Medical", "Conference", "Earned"]}, "from": {"type": "string", "description": "YYYY-MM-DD"},
          "to": {"type": "string", "description": "YYYY-MM-DD"}, "reason": {"type": "string"}}, propose_leave),
        ("propose_send_notice", "PROPOSE sending a notice to one course's students. The user must confirm.",
         {"course_code": {"type": "string"}, "message": {"type": "string"}}, propose_notice),
        ("propose_raise_grievance", "PROPOSE raising a grievance. The user must confirm.",
         {"category": {"type": "string", "enum": TEACHER_CATEGORIES}, "description": {"type": "string"}}, propose_grievance),
    ]


# =============================================================== ADMIN TOOLS
def _admin_tools():
    from app.routers import admin_router as ar
    from app.routers import placements_router as pr

    def summary(db, cu, a):
        return ar.reports_summary(db=db, current_user=cu)

    def risk(db, cu, a):
        rows = ar.risk_scores(db=db, current_user=cu)
        level = a.get("risk_level")
        if level in ("high", "medium", "low"):
            rows = [r for r in rows if r["riskLevel"] == level]
        if a.get("department"):
            rows = [r for r in rows if (r.get("department") or "").lower().startswith(a["department"].lower())]
        return _pick(sorted(rows, key=lambda r: r["healthScore"]), ["name", "idLabel", "department", "attendancePct", "avgScore", "cgpa", "feeStatus", "riskLevel", "reasons"])

    def grievances(db, cu, a):
        rows = ar.list_grievances(db=db, current_user=cu)
        status = a.get("status") or "active"
        rows = [g for g in rows if (g["status"] != "resolved" if status == "active" else g["status"] == status or status == "all")]
        # Free text written by other users: returned as data, clearly labelled.
        return _pick(rows, ["priority", "category", "routedTo", "status", "raisedBy", "role", "assignedTo", "description"])

    def fees(db, cu, a):
        rows = [f for f in ar.list_fees(db=db, current_user=cu) if f["status"] != "paid" or a.get("include_paid")]
        return _pick(sorted(rows, key=lambda f: -f["due"]), ["student", "idLabel", "total", "paid", "due", "status", "dueDate"])

    def leave(db, cu, a):
        return _pick([x for x in ar.list_leave(db=db, current_user=cu) if x["status"] == "pending" or a.get("include_decided")],
                     ["applicant", "type", "from", "to", "reason", "status"])

    def courses(db, cu, a):
        return _pick(ar.list_courses(db=db, current_user=cu), ["code", "name", "dept", "faculty", "students"])

    def placements(db, cu, a):
        return _pick(pr.list_placements(db=db, current_user=cu), ["company", "role", "package", "minCGPA", "minAttendance", "deadline", "status", "applicants"])

    return [
        ("get_campus_summary", "Headcounts, average attendance and CGPA, fee collection, attendance by department and trend, open grievances.", {}, summary),
        ("get_at_risk_students", "Students with early-warning risk scores; filter by risk level and department.",
         {"risk_level": {"type": "string", "enum": ["high", "medium", "low"]}, "department": {"type": "string"}}, risk),
        ("get_grievances", "Grievance queue sorted by urgency.",
         {"status": {"type": "string", "enum": ["active", "open", "in-review", "resolved", "all"]}}, grievances),
        ("get_fee_dues", "Students with unpaid or partially paid fees, largest dues first.", {"include_paid": {"type": "boolean"}}, fees),
        ("get_leave_requests", "Pending faculty leave requests.", {"include_decided": {"type": "boolean"}}, leave),
        ("get_courses", "All courses with faculty and enrolment.", {}, courses),
        ("get_placements", "Placement drives with applicant counts.", {}, placements),
    ]


_BUILDERS = {"student": _student_tools, "teacher": _teacher_tools, "admin": _admin_tools}
_CACHE = {}


def tools_for(role):
    if role not in _CACHE:
        _CACHE[role] = {name: {"description": desc, "properties": props, "fn": fn}
                        for name, desc, props, fn in _BUILDERS[role]()}
    return _CACHE[role]


def run_tool(db, cu, name, args, max_chars=MAX_RESULT_CHARS):
    """Execute one tool as the current user. Returns (json_text, proposal|None)."""
    tools = tools_for(cu["role"])
    if name not in tools:  # the model can only call tools for its user's role
        return to_json({"error": f"Unknown tool {name}"}), None
    if not isinstance(args, dict):
        args = {}
    args = {k: (v[:4000] if isinstance(v, str) else v) for k, v in list(args.items())[:10] if isinstance(k, str) and re.fullmatch(r"[a-z_]{1,40}", k)}
    try:
        result = tools[name]["fn"](db, cu, args)
    except HTTPException as e:
        return to_json({"error": e.detail}), None
    except Exception:  # noqa: BLE001 — never leak internals to the model
        return to_json({"error": "That data couldn't be loaded right now."}), None
    proposal = result.pop("proposal", None) if isinstance(result, dict) else None
    if proposal:
        return to_json({"status": "Shown to the user as a confirm card. It is NOT done until they press Confirm."}), proposal
    return to_json(result, max_chars), None
