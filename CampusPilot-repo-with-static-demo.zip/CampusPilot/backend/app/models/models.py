"""
Database schema.

Every relationship is a real foreign key on a numeric id (the old schema
joined fees, grievances and applications to users by *display name*, which
broke as soon as two people shared a name). `to_dict()` still produces the
camelCase JSON shapes the React frontend expects, with the same "u_12" /
"c_3" prefixed ids.
"""
from datetime import datetime, timezone

from sqlalchemy import (
    Boolean, Column, DateTime, Float, ForeignKey, Index, Integer, String, Text, UniqueConstraint,
)
from sqlalchemy.orm import relationship

from app.database.db import Base


def utcnow():
    return datetime.now(timezone.utc).replace(tzinfo=None)


def ms(dt):
    if not dt:
        return None
    return int(dt.replace(tzinfo=timezone.utc).timestamp() * 1000)


# ============================================================ Users & auth
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    name = Column(String(150), nullable=False)
    email = Column(String(254), unique=True, index=True, nullable=False)  # always stored lower-case
    password_hash = Column(String(255), nullable=False)
    role = Column(String(20), nullable=False, index=True)  # student | teacher | admin | parent
    id_label = Column(String(50), index=True)               # roll number / staff id
    status = Column(String(20), default="active", nullable=False)  # active | inactive
    must_change_password = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=utcnow)
    last_login_at = Column(DateTime, nullable=True)

    # student academic placement
    year = Column(Integer, nullable=True)
    section = Column(String(10), nullable=True)

    # profile (mostly faculty)
    phone = Column(String(30))
    department = Column(String(120), index=True)
    designation = Column(String(120))
    qualification = Column(String(255))
    joined = Column(String(50))
    office = Column(String(120))
    bio = Column(Text)

    def to_dict(self):
        d = {"id": f"u_{self.id}", "name": self.name, "email": self.email, "role": self.role,
             "idLabel": self.id_label, "status": self.status, "department": self.department,
             "mustChangePassword": bool(self.must_change_password)}
        if self.role == "student":
            d.update({"year": self.year, "section": self.section})
        if self.role == "parent":
            d.update({"phone": self.phone})
        if self.role == "teacher":
            d.update({"phone": self.phone, "designation": self.designation, "qualification": self.qualification,
                      "joined": self.joined, "office": self.office, "bio": self.bio})
        return d


class UserSession(Base):
    """One row per login. Lets us revoke a single device (logout) or every
    device at once (password change, deactivation) — a bare JWT can't be
    revoked before it expires."""
    __tablename__ = "user_sessions"
    jti = Column(String(64), primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True, nullable=False)
    created_at = Column(DateTime, default=utcnow)
    expires_at = Column(DateTime, nullable=False)
    revoked = Column(Boolean, default=False, nullable=False)
    ip = Column(String(64))
    user_agent = Column(String(255))


# ================================================================ Academics
class Course(Base):
    __tablename__ = "courses"
    id = Column(Integer, primary_key=True)
    code = Column(String(30), nullable=False, index=True)
    name = Column(String(150), nullable=False)
    dept = Column(String(120))
    faculty_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), index=True, nullable=True)
    faculty_user = relationship("User", lazy="joined")

    @property
    def faculty(self):
        return self.faculty_user.name if self.faculty_user else "Unassigned"

    def to_dict(self, students=None):
        return {"id": f"c_{self.id}", "code": self.code, "name": self.name, "dept": self.dept,
                "faculty": self.faculty, "facultyId": f"u_{self.faculty_id}" if self.faculty_id else None,
                "students": students if students is not None else 0}


class Enrollment(Base):
    __tablename__ = "enrollments"
    id = Column(Integer, primary_key=True)
    course_id = Column(Integer, ForeignKey("courses.id", ondelete="CASCADE"), nullable=False, index=True)
    student_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    __table_args__ = (UniqueConstraint("course_id", "student_id", name="uq_enrollment"),)


class SubjectRequest(Base):
    __tablename__ = "subject_requests"
    id = Column(Integer, primary_key=True)
    teacher_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True)
    teacher_name = Column(String(150))
    code = Column(String(30))
    name = Column(String(150))
    dept = Column(String(120))
    notes = Column(Text)
    status = Column(String(20), default="pending", index=True)
    reject_reason = Column(Text)
    ts = Column(DateTime, default=utcnow)

    def to_dict(self):
        return {"id": f"sr_{self.id}", "teacherName": self.teacher_name, "code": self.code, "name": self.name,
                "dept": self.dept, "notes": self.notes or "", "status": self.status,
                "rejectReason": self.reject_reason or "", "ts": ms(self.ts)}


class Fee(Base):
    __tablename__ = "fees"
    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), unique=True, index=True)
    student_user = relationship("User", lazy="joined")
    total = Column(Float, default=0)
    paid = Column(Float, default=0)
    due_date = Column(String(20))

    @property
    def status(self):
        if self.paid >= self.total:
            return "paid"
        return "partial" if self.paid > 0 else "overdue"

    def to_dict(self):
        return {"id": f"f_{self.id}", "studentId": f"u_{self.student_id}",
                "student": self.student_user.name if self.student_user else "",
                "idLabel": self.student_user.id_label if self.student_user else "",
                "total": self.total, "paid": self.paid, "due": max(0, self.total - self.paid),
                "dueDate": self.due_date, "status": self.status}


# =============================================================== Attendance
class AttendanceSession(Base):
    __tablename__ = "attendance_sessions"
    id = Column(Integer, primary_key=True)
    course_id = Column(Integer, ForeignKey("courses.id", ondelete="CASCADE"), index=True, nullable=False)
    course_label = Column(String(200))
    date = Column(String(10), index=True)  # ISO yyyy-mm-dd
    marked_by_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"))
    marked_by = Column(String(150))
    method = Column(String(20), default="manual")  # manual | ocr
    ts = Column(DateTime, default=utcnow)
    records = relationship("AttendanceRecord", backref="session", cascade="all, delete-orphan")

    def to_dict(self, with_records=True):
        d = {"id": f"att_{self.id}", "courseId": f"c_{self.course_id}", "courseLabel": self.course_label,
             "date": self.date, "markedBy": self.marked_by, "method": self.method, "ts": ms(self.ts)}
        if with_records:
            d["records"] = [r.to_dict() for r in self.records]
        return d


class AttendanceRecord(Base):
    __tablename__ = "attendance_records"
    id = Column(Integer, primary_key=True)
    session_id = Column(Integer, ForeignKey("attendance_sessions.id", ondelete="CASCADE"), nullable=False, index=True)
    student_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    present = Column(Boolean, default=False, nullable=False)
    confidence = Column(Float)
    __table_args__ = (UniqueConstraint("session_id", "student_id", name="uq_att_record"),)

    def to_dict(self):
        return {"studentId": f"u_{self.student_id}", "present": bool(self.present), "confidence": self.confidence}


class AttendanceDraft(Base):
    """Work-in-progress OCR attendance: photos are added one at a time (from
    any of the teacher's devices), each merges into `state_json`, and nothing
    touches real attendance until the teacher reviews and publishes."""
    __tablename__ = "attendance_drafts"
    id = Column(String(36), primary_key=True)
    teacher_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True, nullable=False)
    course_id = Column(Integer, ForeignKey("courses.id", ondelete="CASCADE"), nullable=False)
    date = Column(String(10), nullable=False)
    status = Column(String(20), default="open", index=True)  # open | published | discarded
    state_json = Column(Text, nullable=False)
    created_at = Column(DateTime, default=utcnow)
    updated_at = Column(DateTime, default=utcnow, onupdate=utcnow)


# =================================================================== Grades
class GradeRecord(Base):
    __tablename__ = "grade_records"
    id = Column(Integer, primary_key=True)
    course_id = Column(Integer, ForeignKey("courses.id", ondelete="CASCADE"), index=True, nullable=False)
    course_label = Column(String(200))
    assessment = Column(String(120))
    published_by = Column(String(150))
    ts = Column(DateTime, default=utcnow)
    entries = relationship("GradeEntry", backref="grade", cascade="all, delete-orphan")

    def to_dict(self):
        return {"id": f"grd_{self.id}", "courseId": f"c_{self.course_id}", "courseLabel": self.course_label,
                "assessment": self.assessment, "publishedBy": self.published_by, "ts": ms(self.ts),
                "entries": [e.to_dict() for e in self.entries]}


class GradeEntry(Base):
    __tablename__ = "grade_entries"
    id = Column(Integer, primary_key=True)
    grade_id = Column(Integer, ForeignKey("grade_records.id", ondelete="CASCADE"), nullable=False, index=True)
    student_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    score = Column(Float, nullable=False)
    __table_args__ = (UniqueConstraint("grade_id", "student_id", name="uq_grade_entry"),)

    def to_dict(self):
        return {"studentId": f"u_{self.student_id}", "score": self.score}


# ========================================================= Coursework & misc
class Assignment(Base):
    __tablename__ = "assignments"
    id = Column(Integer, primary_key=True)
    course_id = Column(Integer, ForeignKey("courses.id", ondelete="CASCADE"), index=True, nullable=False)
    course = Column(String(150))  # course name, for display
    title = Column(String(200), nullable=False)
    due = Column(String(50))
    created_by = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"))
    ts = Column(DateTime, default=utcnow)

    def to_dict(self, submitted_count=0, total_students=0, my_status=None):
        d = {"id": f"a_{self.id}", "title": self.title, "course": self.course, "courseId": f"c_{self.course_id}",
             "due": self.due, "submittedCount": submitted_count, "totalStudents": total_students}
        d["status"] = my_status if my_status else ("submitted" if total_students and submitted_count >= total_students else "pending")
        return d


class AssignmentSubmission(Base):
    """Per-student submission — the old schema flipped one global status
    column, so one student submitting marked it done for everyone."""
    __tablename__ = "assignment_submissions"
    id = Column(Integer, primary_key=True)
    assignment_id = Column(Integer, ForeignKey("assignments.id", ondelete="CASCADE"), nullable=False, index=True)
    student_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    submitted_at = Column(DateTime, default=utcnow)
    __table_args__ = (UniqueConstraint("assignment_id", "student_id", name="uq_submission"),)


class StudyMaterial(Base):
    __tablename__ = "study_materials"
    id = Column(Integer, primary_key=True)
    course_id = Column(Integer, ForeignKey("courses.id", ondelete="CASCADE"), index=True)
    course = Column(String(150))
    title = Column(String(200))
    type = Column(String(20))
    uploaded_by = Column(String(150))
    size = Column(String(30))
    ts = Column(DateTime, default=utcnow)

    def to_dict(self):
        return {"id": f"mat_{self.id}", "title": self.title, "course": self.course, "type": self.type,
                "uploadedBy": self.uploaded_by, "ts": ms(self.ts), "size": self.size}


class ClassNotice(Base):
    __tablename__ = "class_notices"
    id = Column(Integer, primary_key=True)
    course_id = Column(Integer, ForeignKey("courses.id", ondelete="CASCADE"), index=True)
    course = Column(String(150))
    title = Column(String(255))
    sent_by = Column(String(150))
    sent_by_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), index=True)
    ts = Column(DateTime, default=utcnow)

    def to_dict(self):
        return {"id": f"cn_{self.id}", "title": self.title, "course": self.course, "sentBy": self.sent_by, "ts": ms(self.ts)}


class LeaveRequest(Base):
    __tablename__ = "leave_requests"
    id = Column(Integer, primary_key=True)
    applicant_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True)
    applicant = Column(String(150))
    role = Column(String(20))
    type = Column(String(50))
    from_date = Column(String(10))
    to_date = Column(String(10))
    reason = Column(Text)
    status = Column(String(20), default="pending", index=True)
    decided_by = Column(String(150))
    ts = Column(DateTime, default=utcnow)

    def to_dict(self):
        return {"id": f"lv_{self.id}", "applicant": self.applicant, "role": self.role, "type": self.type,
                "from": self.from_date, "to": self.to_date, "reason": self.reason or "",
                "status": self.status, "decidedBy": self.decided_by, "ts": ms(self.ts)}


class Grievance(Base):
    __tablename__ = "grievances"
    id = Column(Integer, primary_key=True)
    raised_by_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True)
    raised_by = Column(String(150))
    role = Column(String(20))
    category = Column(String(100))
    priority = Column(String(10), default="medium", index=True)  # low | medium | high
    routed_to = Column(String(120))                              # office the category routes to
    description = Column(Text)
    status = Column(String(20), default="open", index=True)     # open | in-review | resolved
    assigned_to = Column(String(150))
    resolution = Column(Text)
    contact_email = Column(String(254))
    ts = Column(DateTime, default=utcnow)
    updated_at = Column(DateTime, default=utcnow, onupdate=utcnow)

    def to_dict(self):
        return {"id": f"grv_{self.id}", "raisedBy": self.raised_by, "role": self.role, "category": self.category,
                "priority": self.priority, "routedTo": self.routed_to, "description": self.description,
                "status": self.status, "assignedTo": self.assigned_to, "resolution": self.resolution or "",
                "contactEmail": self.contact_email, "ts": ms(self.ts), "updatedAt": ms(self.updated_at)}


class AuditLogEntry(Base):
    __tablename__ = "audit_log"
    id = Column(Integer, primary_key=True)
    actor_id = Column(Integer, index=True)
    actor = Column(String(150))
    actor_role = Column(String(20))
    action = Column(String(150))
    detail = Column(Text)
    ip = Column(String(64))
    ts = Column(DateTime, default=utcnow, index=True)

    def to_dict(self):
        return {"id": f"log_{self.id}", "actor": self.actor, "actorRole": self.actor_role, "action": self.action,
                "detail": self.detail or "", "ts": ms(self.ts)}


class Notification(Base):
    """One row per recipient, so 'read' is per person and private updates
    ("your application was rejected") only reach the person they're about."""
    __tablename__ = "notifications"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True, nullable=False)
    title = Column(String(200))
    body = Column(Text)
    read = Column(Boolean, default=False)
    ts = Column(DateTime, default=utcnow, index=True)

    def to_dict(self):
        return {"id": f"ntf_{self.id}", "title": self.title, "body": self.body, "ts": ms(self.ts), "read": bool(self.read)}


# =============================================================== Placements
class Placement(Base):
    __tablename__ = "placements"
    id = Column(Integer, primary_key=True)
    company = Column(String(150))
    role = Column(String(150))
    package = Column(String(50))
    location = Column(String(120))
    min_cgpa = Column(Float, default=0)
    min_attendance = Column(Float, default=0)
    deadline = Column(String(50))
    posted_by = Column(String(150))
    status = Column(String(20), default="open", index=True)
    ts = Column(DateTime, default=utcnow)

    def to_dict(self):
        return {"id": f"pl_{self.id}", "company": self.company, "role": self.role, "package": self.package,
                "location": self.location, "minCGPA": self.min_cgpa, "minAttendance": self.min_attendance,
                "deadline": self.deadline, "postedBy": self.posted_by, "status": self.status, "ts": ms(self.ts)}


class PlacementApplication(Base):
    __tablename__ = "placement_applications"
    id = Column(Integer, primary_key=True)
    placement_id = Column(Integer, ForeignKey("placements.id", ondelete="CASCADE"), index=True, nullable=False)
    student_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True, nullable=False)
    student_name = Column(String(150))
    id_label = Column(String(50))
    cgpa_at_apply = Column(Float)
    attendance_at_apply = Column(Float)
    status = Column(String(30), default="applied")
    ts = Column(DateTime, default=utcnow)
    __table_args__ = (UniqueConstraint("placement_id", "student_id", name="uq_application"),)

    def to_dict(self):
        return {"id": f"papp_{self.id}", "placementId": f"pl_{self.placement_id}", "studentId": f"u_{self.student_id}",
                "studentName": self.student_name, "idLabel": self.id_label, "status": self.status,
                "cgpa": self.cgpa_at_apply, "attendancePct": self.attendance_at_apply, "ts": ms(self.ts)}


# ================================================================== Library
class LibraryBook(Base):
    __tablename__ = "library_books"
    id = Column(Integer, primary_key=True)
    title = Column(String(200))
    author = Column(String(150))
    category = Column(String(120))
    isbn = Column(String(50))
    copies = Column(Integer, default=1)

    def to_dict(self):
        return {"id": f"bk_{self.id}", "title": self.title, "author": self.author, "category": self.category,
                "isbn": self.isbn, "copies": self.copies}


class LibraryRequest(Base):
    __tablename__ = "library_requests"
    id = Column(Integer, primary_key=True)
    student_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True)
    book_id = Column(Integer, ForeignKey("library_books.id", ondelete="CASCADE"))
    title = Column(String(200))
    status = Column(String(30), default="pending")  # pending | ready-for-pickup | waitlisted | returned
    ts = Column(DateTime, default=utcnow)

    def to_dict(self):
        return {"id": f"lib_{self.id}", "bookId": f"bk_{self.book_id}", "title": self.title,
                "status": self.status, "ts": ms(self.ts)}


# ============================================================ Parents & alerts
class ParentLink(Base):
    """A parent/guardian account (role='parent') linked to one or more students."""
    __tablename__ = "parent_links"
    id = Column(Integer, primary_key=True)
    parent_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True, nullable=False)
    student_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True, nullable=False)
    relation = Column(String(30), default="Parent")
    created_at = Column(DateTime, default=utcnow)
    __table_args__ = (UniqueConstraint("parent_id", "student_id", name="uq_parent_link"),)


class OutboundMessage(Base):
    """Outbox for SMS / WhatsApp alerts. Rows are written in the same
    transaction as the event that caused them; a background worker sends
    them, so a slow or failing SMS gateway never slows down the app."""
    __tablename__ = "outbound_messages"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), index=True, nullable=True)
    student_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), index=True, nullable=True)
    to_name = Column(String(150))
    phone = Column(String(30))
    channel = Column(String(20))            # whatsapp | sms
    kind = Column(String(30), index=True)   # low_attendance | absent | fee_due | fee_paid | results | exam | test
    body = Column(Text)
    status = Column(String(20), default="queued", index=True)  # queued | sent | logged | failed | skipped
    provider = Column(String(20))
    provider_ref = Column(String(120))
    error = Column(String(300))
    attempts = Column(Integer, default=0)
    ts = Column(DateTime, default=utcnow, index=True)
    sent_at = Column(DateTime, nullable=True)

    def to_dict(self):
        phone = self.phone or ""
        masked = (phone[:3] + "•" * max(0, len(phone) - 6) + phone[-3:]) if len(phone) > 6 else phone
        return {"id": f"msg_{self.id}", "toName": self.to_name, "phone": masked, "channel": self.channel, "kind": self.kind,
                "body": self.body, "status": self.status, "provider": self.provider, "error": self.error or "",
                "studentId": f"u_{self.student_id}" if self.student_id else None, "ts": ms(self.ts), "sentAt": ms(self.sent_at)}


class DepartmentHead(Base):
    """Which faculty member heads a department (HOD) — set by admins only,
    so a teacher can't give themselves HOD analytics by editing a profile."""
    __tablename__ = "department_heads"
    id = Column(Integer, primary_key=True)
    dept = Column(String(120), unique=True, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True, nullable=False)


# ==================================================================== Exams
class Exam(Base):
    __tablename__ = "exams"
    id = Column(Integer, primary_key=True)
    course_id = Column(Integer, ForeignKey("courses.id", ondelete="CASCADE"), index=True, nullable=False)
    title = Column(String(120), nullable=False)          # e.g. "Mid-Semester Exam"
    kind = Column(String(20), default="midsem")          # midsem | endsem | practical | quiz
    date = Column(String(10), index=True, nullable=False)  # yyyy-mm-dd
    start_time = Column(String(5), default="10:00")      # HH:MM (24h)
    duration_min = Column(Integer, default=180)
    room = Column(String(60))
    max_marks = Column(Float, default=100)
    results_published = Column(Boolean, default=False, nullable=False)
    published_at = Column(DateTime, nullable=True)
    created_by = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"))
    ts = Column(DateTime, default=utcnow)
    course = relationship("Course", lazy="joined")

    def to_dict(self, with_counts=None):
        d = {"id": f"ex_{self.id}", "courseId": f"c_{self.course_id}",
             "courseCode": self.course.code if self.course else "", "courseName": self.course.name if self.course else "",
             "dept": self.course.dept if self.course else "", "title": self.title, "kind": self.kind, "date": self.date,
             "startTime": self.start_time, "durationMin": self.duration_min, "room": self.room or "",
             "maxMarks": self.max_marks, "resultsPublished": bool(self.results_published), "publishedAt": ms(self.published_at)}
        if with_counts is not None:
            d["resultsEntered"] = with_counts
        return d


class ExamResult(Base):
    __tablename__ = "exam_results"
    id = Column(Integer, primary_key=True)
    exam_id = Column(Integer, ForeignKey("exams.id", ondelete="CASCADE"), index=True, nullable=False)
    student_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True, nullable=False)
    marks = Column(Float, nullable=True)
    absent = Column(Boolean, default=False, nullable=False)
    __table_args__ = (UniqueConstraint("exam_id", "student_id", name="uq_exam_result"),)


# ============================================================ QR attendance
class QrSession(Base):
    """A live QR check-in for one class. The QR/code shown on the teacher's
    screen changes every few seconds (HMAC of `secret` + time window)."""
    __tablename__ = "qr_sessions"
    id = Column(String(32), primary_key=True)   # random, url-safe
    course_id = Column(Integer, ForeignKey("courses.id", ondelete="CASCADE"), index=True, nullable=False)
    teacher_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True, nullable=False)
    date = Column(String(10), nullable=False)
    secret = Column(String(64), nullable=False)
    status = Column(String(20), default="open", index=True)  # open | published | cancelled
    created_at = Column(DateTime, default=utcnow)
    expires_at = Column(DateTime, nullable=False)
    attendance_session_id = Column(Integer, ForeignKey("attendance_sessions.id", ondelete="SET NULL"), nullable=True)


class QrCheckin(Base):
    __tablename__ = "qr_checkins"
    id = Column(Integer, primary_key=True)
    qr_session_id = Column(String(32), ForeignKey("qr_sessions.id", ondelete="CASCADE"), index=True, nullable=False)
    student_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True, nullable=False)
    method = Column(String(10), default="scan")   # scan | code | teacher
    device = Column(String(64))                   # hashed device id (flags one phone checking in many students)
    ip = Column(String(64))
    ts = Column(DateTime, default=utcnow)
    __table_args__ = (UniqueConstraint("qr_session_id", "student_id", name="uq_qr_checkin"),)


# ================================================================ Calendar
class CalendarEvent(Base):
    __tablename__ = "calendar_events"
    id = Column(Integer, primary_key=True)
    title = Column(String(150), nullable=False)
    date = Column(String(10), index=True, nullable=False)
    end_date = Column(String(10), nullable=True)
    kind = Column(String(20), default="event")   # holiday | event | exam-week | deadline
    description = Column(Text)
    created_by = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"))
    ts = Column(DateTime, default=utcnow)

    def to_dict(self):
        return {"id": f"ev_{self.id}", "title": self.title, "date": self.date, "endDate": self.end_date or self.date,
                "kind": self.kind, "description": self.description or "", "source": "event"}


class IssuedDocument(Base):
    """Register of certificates issued (bonafide etc.) — gives each a reference
    number that the QR verification page can confirm."""
    __tablename__ = "issued_documents"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True, nullable=False)
    kind = Column(String(30), nullable=False)    # bonafide | id-card | hall-ticket | grade-card
    purpose = Column(String(150))
    ts = Column(DateTime, default=utcnow)


Index("ix_att_sessions_course_date", AttendanceSession.course_id, AttendanceSession.date)
Index("ix_notifications_user_ts", Notification.user_id, Notification.ts)
