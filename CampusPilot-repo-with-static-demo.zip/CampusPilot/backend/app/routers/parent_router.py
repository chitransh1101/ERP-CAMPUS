"""
Parent / guardian portal (read-only). A parent sees only the students an
admin has linked to their account — every endpoint checks the link.
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.auth.auth import require_role
from app.common import build_timetable, parse_pk
from app.database.db import get_db
from app.models.models import OutboundMessage, ParentLink, User
from app.routers.exams_router import student_exam_view
from app.routers.student_router import (
    _my_courses, attendance_for, fees_for, grades_for, notices_for, summary_for,
)

router = APIRouter(prefix="/parent", tags=["parent"])
parent_only = require_role(["parent"])


def linked_student(db, parent_id: int, student_ref: str) -> User:
    sid = parse_pk(student_ref, "u")
    link = db.query(ParentLink).filter_by(parent_id=parent_id, student_id=sid).first()
    st = db.get(User, sid) if link else None
    if not st or st.role != "student":
        raise HTTPException(status_code=404, detail="Student not found among your children.")
    return st


@router.get("/children")
def children(db: Session = Depends(get_db), current_user=Depends(parent_only)):
    rows = (db.query(User, ParentLink.relation).join(ParentLink, ParentLink.student_id == User.id)
            .filter(ParentLink.parent_id == current_user["user_id"]).order_by(User.name).all())
    out = []
    for st, relation in rows:
        s = summary_for(db, st.id)
        out.append({"id": f"u_{st.id}", "name": st.name, "idLabel": st.id_label, "department": st.department,
                    "year": st.year, "section": st.section, "relation": relation, "status": st.status, "summary": s})
    return out


@router.get("/children/{student_id}/summary")
def child_summary(student_id: str, db: Session = Depends(get_db), current_user=Depends(parent_only)):
    return summary_for(db, linked_student(db, current_user["user_id"], student_id).id)


@router.get("/children/{student_id}/attendance")
def child_attendance(student_id: str, db: Session = Depends(get_db), current_user=Depends(parent_only)):
    return attendance_for(db, linked_student(db, current_user["user_id"], student_id).id)


@router.get("/children/{student_id}/grades")
def child_grades(student_id: str, db: Session = Depends(get_db), current_user=Depends(parent_only)):
    return grades_for(db, linked_student(db, current_user["user_id"], student_id).id)


@router.get("/children/{student_id}/fees")
def child_fees(student_id: str, db: Session = Depends(get_db), current_user=Depends(parent_only)):
    return fees_for(db, linked_student(db, current_user["user_id"], student_id).id)


@router.get("/children/{student_id}/notices")
def child_notices(student_id: str, db: Session = Depends(get_db), current_user=Depends(parent_only)):
    return notices_for(db, linked_student(db, current_user["user_id"], student_id).id)


@router.get("/children/{student_id}/exams")
def child_exams(student_id: str, db: Session = Depends(get_db), current_user=Depends(parent_only)):
    return student_exam_view(db, linked_student(db, current_user["user_id"], student_id).id)


@router.get("/children/{student_id}/timetable")
def child_timetable(student_id: str, db: Session = Depends(get_db), current_user=Depends(parent_only)):
    st = linked_student(db, current_user["user_id"], student_id)
    return build_timetable([c.to_dict() for c in _my_courses(db, st.id)])


@router.get("/messages")
def my_messages(db: Session = Depends(get_db), current_user=Depends(parent_only)):
    rows = (db.query(OutboundMessage).filter(OutboundMessage.user_id == current_user["user_id"])
            .order_by(OutboundMessage.ts.desc()).limit(100).all())
    return [m.to_dict() for m in rows]
