import json
import threading
import uuid
from datetime import date, datetime, timedelta

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile
from sqlalchemy import case, func
from sqlalchemy.orm import Session

from app import config
from app.ai import attendance_ocr as ocr
from app.auth.auth import require_role
from app.common import (
    attendance_stats, build_timetable, classify_grievance, cohort_risk, enrolled_student_ids, enrollment_counts, grade_distribution,
    is_valid_gmail, log_audit, notify_course, notify_role, parse_pk,
)
from app.database.db import get_db
from app.models.models import (
    Assignment, AssignmentSubmission, AttendanceDraft, AttendanceRecord, AttendanceSession, AuditLogEntry, ClassNotice,
    Course, Enrollment, GradeEntry, GradeRecord, Grievance, LeaveRequest, StudyMaterial, SubjectRequest, User,
)
from app.messaging import alert_parents
from app.realtime import queue_event
from app.schemas.student_schema import GrievanceCreate
from app.schemas.teacher_schema import (
    AssignmentCreate, DraftCreate, DraftOverride, LeaveRequestCreate, MarkAttendanceRequest, MaterialUpload,
    NoticeCreate, PublishGradesRequest, SubjectRequestCreate,
)
from app.schemas.user_schema import ProfileUpdate
from app.security import ocr_user_limiter

router = APIRouter(prefix="/teacher", tags=["teacher"])
teacher_only = require_role(["teacher"])

PRESENT_INT = case((AttendanceRecord.present.is_(True), 1), else_=0)

# OCR is CPU-heavy: cap concurrent jobs so a burst of uploads can't starve the server.
_OCR_SLOTS = threading.BoundedSemaphore(2)


# ------------------------------------------------------------------ helpers
def _my_courses(db, teacher_id):
    return db.query(Course).filter(Course.faculty_id == teacher_id).order_by(Course.code).all()


def _own_course(db, course_ref, teacher_id) -> Course:
    """Resolve a course id and make sure it belongs to this teacher (IDOR guard)."""
    course = db.get(Course, parse_pk(course_ref, "c"))
    if not course or course.faculty_id != teacher_id:
        raise HTTPException(status_code=404, detail="Course not found among your subjects.")
    return course


def _course_by_ref_or_name(db, teacher_id, course_id=None, course_name=None) -> Course:
    if course_id:
        return _own_course(db, course_id, teacher_id)
    course = db.query(Course).filter(Course.faculty_id == teacher_id, Course.name == (course_name or "")).first()
    if not course:
        raise HTTPException(status_code=404, detail="Pick one of your own subjects.")
    return course


def _roster(db, course_id):
    students = (db.query(User).join(Enrollment, Enrollment.student_id == User.id)
                .filter(Enrollment.course_id == course_id, User.status == "active").order_by(User.id_label).all())
    return [{"studentId": f"u_{s.id}", "id": f"u_{s.id}", "name": s.name, "idLabel": s.id_label} for s in students]


def _label(course):
    return f"{course.code} — {course.name}"


# --------------------------------------------------------------- My courses
@router.get("/courses")
def my_courses(db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    counts = enrollment_counts(db)
    return [c.to_dict(counts.get(c.id, 0)) for c in _my_courses(db, current_user["user_id"])]


@router.get("/roster")
def roster(course_id: str = Query("", alias="courseId"), db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    """Students enrolled in one of my courses (or across all my courses)."""
    if course_id:
        return _roster(db, _own_course(db, course_id, current_user["user_id"]).id)
    ids = [c.id for c in _my_courses(db, current_user["user_id"])]
    students = (db.query(User).join(Enrollment, Enrollment.student_id == User.id)
                .filter(Enrollment.course_id.in_(ids or [-1]), User.status == "active").distinct().order_by(User.id_label).all())
    return [{"id": f"u_{s.id}", "studentId": f"u_{s.id}", "name": s.name, "idLabel": s.id_label} for s in students]


# ================================================================ Attendance
def alert_parents_after_attendance(db, course, day, present_by_student: dict):
    """Parent alerts: 'absent today' for each absentee, and a low-attendance
    warning (at most once a week per student) when overall attendance < threshold."""
    ids = list(present_by_student)
    if not ids:
        return
    students = {u.id: u for u in db.query(User).filter(User.id.in_(ids))}
    stats = attendance_stats(db, ids)
    nice_day = date.fromisoformat(day).strftime("%d %b %Y")
    threshold = config.LOW_ATTENDANCE_THRESHOLD
    for sid, present in present_by_student.items():
        st = students.get(sid)
        if not st:
            continue
        if not present:
            alert_parents(db, st, "absent", f"{st.name} was marked ABSENT in {_label(course)} on {nice_day}.",
                          title=f"{st.name.split()[0]} was absent today")
        pct = (stats.get(sid) or {}).get("pct")
        if pct is not None and pct < threshold:
            alert_parents(db, st, "low_attendance",
                          f"{st.name}'s overall attendance is {pct:.0f}%, below the required {threshold}%. "
                          "Regular attendance is needed to be eligible for exams.",
                          title="Low attendance warning", dedupe_days=7)


def _publish_session(db, me, course, day, records, method):
    enrolled = set(enrolled_student_ids(db, course.id))
    seen = set()
    session = AttendanceSession(course_id=course.id, course_label=_label(course), date=day, marked_by_id=me.id,
                                marked_by=me.name, method=method)
    db.add(session)
    db.flush()
    for sid, present, conf in records:
        if sid not in enrolled:
            raise HTTPException(status_code=400, detail="Attendance can only be marked for students enrolled in this course.")
        if sid in seen:
            continue
        seen.add(sid)
        db.add(AttendanceRecord(session_id=session.id, student_id=sid, present=bool(present), confidence=conf))
    present_count = sum(1 for _, p, _ in records if p)
    log_audit(db, me, "Attendance published", f"{_label(course)} · {day} · {present_count}/{len(seen)} present ({method})")
    alert_parents_after_attendance(db, course, day, {sid: bool(p) for sid, p, _ in records if sid in seen})
    notify_course(db, course.id, "Attendance updated", f"{_label(course)} attendance for {day} was marked.")
    queue_event(db, "attendance:update", {"courseId": f"c_{course.id}", "date": day},
                users=list(enrolled) + [me.id], roles=["admin"])
    return session


@router.post("/attendance")
def mark_attendance(payload: MarkAttendanceRequest, db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    me = current_user.user
    course = _own_course(db, payload.course_id, me.id)
    day = payload.date or date.today().isoformat()
    if day > date.today().isoformat():
        raise HTTPException(status_code=400, detail="Attendance can't be marked for a future date.")
    records = [(parse_pk(r.student_id, "u"), r.present, r.confidence) for r in payload.records]
    session = _publish_session(db, me, course, day, records, "manual")
    db.commit()
    return session.to_dict()


@router.get("/attendance/sessions")
def attendance_sessions(course_id: str = Query(..., alias="courseId"), db: Session = Depends(get_db),
                        current_user=Depends(teacher_only)):
    course = _own_course(db, course_id, current_user["user_id"])
    rows = (db.query(AttendanceSession, func.count(AttendanceRecord.id), func.sum(PRESENT_INT))
            .outerjoin(AttendanceRecord, AttendanceRecord.session_id == AttendanceSession.id)
            .filter(AttendanceSession.course_id == course.id).group_by(AttendanceSession.id)
            .order_by(AttendanceSession.date.desc(), AttendanceSession.id.desc()).limit(60).all())
    return [{**s.to_dict(with_records=False), "total": int(total or 0), "present": int(present or 0)} for s, total, present in rows]


# --------------------------------------------------------- OCR (live drafts)
def _draft_or_404(db, draft_id, teacher_id) -> AttendanceDraft:
    try:
        uuid.UUID(str(draft_id))
    except ValueError:
        raise HTTPException(status_code=404, detail="Draft not found")
    d = db.get(AttendanceDraft, str(draft_id))
    if not d or d.teacher_id != teacher_id:
        raise HTTPException(status_code=404, detail="Draft not found")
    return d


def _draft_dict(d: AttendanceDraft, course: Course = None):
    state = json.loads(d.state_json)
    students = sorted(state["students"].values(), key=lambda s: (not s["needsReview"], s.get("idLabel") or ""))
    return {"id": d.id, "courseId": f"c_{d.course_id}", "courseLabel": _label(course) if course else None, "date": d.date,
            "status": d.status, "students": students, "photos": state["photos"], "summary": ocr.summarize(state),
            "engineAvailable": ocr.engine_available()}


def _emit_draft(db, d, course):
    queue_event(db, "draft:update", _draft_dict(d, course), users=[d.teacher_id])


@router.post("/attendance/drafts")
def create_draft(payload: DraftCreate, db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    me = current_user.user
    course = _own_course(db, payload.course_id, me.id)
    day = payload.date or date.today().isoformat()
    if day > date.today().isoformat():
        raise HTTPException(status_code=400, detail="Attendance can't be marked for a future date.")
    roster_ = _roster(db, course.id)
    if not roster_:
        raise HTTPException(status_code=400, detail="No students are enrolled in this course yet — ask the admin to enroll them.")
    # One open draft per course+date: reopen it instead of starting over (e.g. on another device).
    existing = (db.query(AttendanceDraft).filter(AttendanceDraft.teacher_id == me.id, AttendanceDraft.course_id == course.id,
                                                  AttendanceDraft.date == day, AttendanceDraft.status == "open").first())
    if existing:
        return _draft_dict(existing, course)
    d = AttendanceDraft(id=str(uuid.uuid4()), teacher_id=me.id, course_id=course.id, date=day,
                        state_json=json.dumps(ocr.new_draft_state([{k: s[k] for k in ("studentId", "name", "idLabel")} for s in roster_])))
    db.add(d)
    db.commit()
    return _draft_dict(d, course)


@router.get("/attendance/drafts")
def list_drafts(db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    ds = (db.query(AttendanceDraft).filter(AttendanceDraft.teacher_id == current_user["user_id"], AttendanceDraft.status == "open")
          .order_by(AttendanceDraft.updated_at.desc()).limit(20).all())
    courses = {c.id: c for c in _my_courses(db, current_user["user_id"])}
    return [_draft_dict(d, courses.get(d.course_id)) for d in ds]


@router.get("/attendance/drafts/{draft_id}")
def get_draft(draft_id: str, db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    d = _draft_or_404(db, draft_id, current_user["user_id"])
    return _draft_dict(d, db.get(Course, d.course_id))


async def _read_uploads(files):
    if not files:
        raise HTTPException(status_code=400, detail="Attach at least one photo.")
    if len(files) > config.MAX_PHOTOS_PER_REQUEST:
        raise HTTPException(status_code=400, detail=f"Upload at most {config.MAX_PHOTOS_PER_REQUEST} photos at a time.")
    limit = config.MAX_UPLOAD_MB * 1024 * 1024
    out = []
    for f in files:
        data = await f.read(limit + 1)
        if len(data) > limit:
            raise HTTPException(status_code=413, detail=f"{f.filename or 'Photo'} is larger than {config.MAX_UPLOAD_MB} MB.")
        out.append(((f.filename or "photo")[:80], data))
    return out


def _run_ocr(photos, roster_, day):
    if not ocr.engine_available():
        raise HTTPException(status_code=503, detail="The OCR engine (Tesseract) isn't installed on the server — use the Manual tab, or ask your admin to install it.")
    if not _OCR_SLOTS.acquire(timeout=60):
        raise HTTPException(status_code=503, detail="The server is busy reading other sheets — try again in a moment.")
    try:
        results = []
        for name, data in photos:
            try:
                results.append((name, ocr.analyze_photo(data, roster_, target_day=int(day[-2:]))))
            except ocr.BadImage as e:
                raise HTTPException(status_code=415, detail=f"{name}: {e}")
        return results
    finally:
        _OCR_SLOTS.release()


@router.post("/attendance/drafts/{draft_id}/photos")
async def add_draft_photos(draft_id: str, files: list[UploadFile] = File(...), db: Session = Depends(get_db),
                           current_user=Depends(teacher_only)):
    """Add one or more sheet photos to a draft. Each is OCR'd and merged; the
    updated draft is pushed live to all the teacher's open devices."""
    from starlette.concurrency import run_in_threadpool
    ocr_user_limiter.check(f"u{current_user['user_id']}", "You're uploading photos too quickly — wait a moment.")
    d = _draft_or_404(db, draft_id, current_user["user_id"])
    if d.status != "open":
        raise HTTPException(status_code=409, detail="This attendance draft was already published or discarded.")
    photos = await _read_uploads(files)
    state = json.loads(d.state_json)
    roster_ = [{k: s[k] for k in ("studentId", "name", "idLabel")} for s in state["students"].values()]
    results = await run_in_threadpool(_run_ocr, photos, roster_, d.date)  # never block the event loop
    db.refresh(d)  # another device may have added photos meanwhile
    state = json.loads(d.state_json)
    for name, analysis in results:
        ocr.merge_photo(state, analysis, name)
    d.state_json = json.dumps(state)
    course = db.get(Course, d.course_id)
    _emit_draft(db, d, course)
    db.commit()
    return _draft_dict(d, course)


@router.patch("/attendance/drafts/{draft_id}/students/{student_id}")
def override_draft_student(draft_id: str, student_id: str, payload: DraftOverride, db: Session = Depends(get_db),
                           current_user=Depends(teacher_only)):
    d = _draft_or_404(db, draft_id, current_user["user_id"])
    if d.status != "open":
        raise HTTPException(status_code=409, detail="This draft is closed.")
    state = json.loads(d.state_json)
    sid = f"u_{parse_pk(student_id, 'u')}"
    if sid not in state["students"]:
        raise HTTPException(status_code=404, detail="Student not in this class.")
    ocr.override(state, sid, payload.present)
    d.state_json = json.dumps(state)
    course = db.get(Course, d.course_id)
    _emit_draft(db, d, course)
    db.commit()
    return _draft_dict(d, course)


@router.post("/attendance/drafts/{draft_id}/publish")
def publish_draft(draft_id: str, db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    me = current_user.user
    d = _draft_or_404(db, draft_id, me.id)
    if d.status != "open":
        raise HTTPException(status_code=409, detail="This draft was already published or discarded.")
    course = _own_course(db, f"c_{d.course_id}", me.id)
    state = json.loads(d.state_json)
    # Anyone not found on any sheet is recorded absent (the teacher saw them flagged before publishing).
    records = [(parse_pk(sid, "u"), st["status"] == "present", st["confidence"]) for sid, st in state["students"].items()]
    session = _publish_session(db, me, course, d.date, records, "ocr" if state["photos"] else "manual")
    d.status = "published"
    _emit_draft(db, d, course)
    db.commit()
    return session.to_dict()


@router.delete("/attendance/drafts/{draft_id}")
def discard_draft(draft_id: str, db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    d = _draft_or_404(db, draft_id, current_user["user_id"])
    d.status = "discarded"
    _emit_draft(db, d, db.get(Course, d.course_id))
    db.commit()
    return {"message": "Draft discarded"}


@router.post("/attendance/ocr")
async def ocr_process_attendance(files: list[UploadFile] = File(default=None), file: UploadFile = File(default=None),
                                 course_id: str = Form(default="", alias="courseId"), day: str = Form(default="", alias="date"),
                                 db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    """One-shot OCR (no draft): upload 1+ photos, get merged detections back.
    Kept for API clients; the web app uses the live draft endpoints above."""
    from starlette.concurrency import run_in_threadpool
    ocr_user_limiter.check(f"u{current_user['user_id']}", "You're uploading photos too quickly — wait a moment.")
    uploads = [f for f in (files or []) if f] + ([file] if file else [])
    courses = _my_courses(db, current_user["user_id"])
    course = _own_course(db, course_id, current_user["user_id"]) if course_id else (courses[0] if courses else None)
    if not course:
        raise HTTPException(status_code=400, detail="You have no courses assigned.")
    day = day if (len(day) == 10 and day[4] == "-") else date.today().isoformat()
    photos = await _read_uploads(uploads)
    roster_ = [{k: s[k] for k in ("studentId", "name", "idLabel")} for s in _roster(db, course.id)]
    results = await run_in_threadpool(_run_ocr, photos, roster_, day)
    state = ocr.new_draft_state(roster_)
    for name, analysis in results:
        ocr.merge_photo(state, analysis, name)
    detections = [{"studentId": s["studentId"], "name": s["name"], "idLabel": s["idLabel"], "present": s["status"] == "present",
                   "status": s["status"], "confidence": s["confidence"], "needsReview": s["needsReview"], "evidence": s["evidence"]}
                  for s in state["students"].values()]
    summ = ocr.summarize(state)
    return {"source": "ocr", "courseId": f"c_{course.id}", "date": day, "detections": detections, "photos": state["photos"],
            "summary": summ, "note": f"Read {summ['total'] - summ['unseen']} of {summ['total']} students from {len(photos)} photo(s). "
                                     f"{summ['needsReview']} need your review."}


# ==================================================================== Grades
@router.post("/grades")
def publish_grades(payload: PublishGradesRequest, db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    me = current_user.user
    course = _own_course(db, payload.course_id, me.id)
    enrolled = set(enrolled_student_ids(db, course.id))
    record = GradeRecord(course_id=course.id, course_label=_label(course), assessment=payload.assessment, published_by=me.name)
    db.add(record)
    db.flush()
    seen = set()
    for e in payload.entries:
        sid = parse_pk(e.student_id, "u")
        if sid not in enrolled:
            raise HTTPException(status_code=400, detail="Grades can only be published for students enrolled in this course.")
        if sid in seen:
            continue
        seen.add(sid)
        db.add(GradeEntry(grade_id=record.id, student_id=sid, score=e.score))
    log_audit(db, me, "Grades published", f"{_label(course)} · {payload.assessment} · {len(seen)} students")
    scores = {parse_pk(e.student_id, "u"): e.score for e in payload.entries}
    for st in db.query(User).filter(User.id.in_(list(seen) or [-1])):
        alert_parents(db, st, "results", f"{st.name} scored {scores[st.id]:g}/100 in {payload.assessment} — {_label(course)}.",
                      title="Marks published")
    notify_course(db, course.id, "Grades published", f"{payload.assessment} results for {_label(course)} are out.")
    queue_event(db, "grades:update", {"courseId": f"c_{course.id}"}, users=list(enrolled) + [me.id], roles=["admin"])
    db.commit()
    db.refresh(record)
    return record.to_dict()


@router.get("/grades")
def grade_history(course_id: str = Query(..., alias="courseId"), db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    course = _own_course(db, course_id, current_user["user_id"])
    rows = db.query(GradeRecord).filter(GradeRecord.course_id == course.id).order_by(GradeRecord.ts.desc()).all()
    return [r.to_dict() for r in rows]


# =================================================================== Profile
@router.get("/profile")
def get_profile(current_user=Depends(teacher_only)):
    return current_user.user.to_dict()


@router.patch("/profile")
def update_profile(payload: ProfileUpdate, db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    me = current_user.user
    patch = payload.model_dump(exclude_unset=True)
    for k, v in patch.items():  # only whitelisted schema fields can ever reach here
        setattr(me, k, v)
    log_audit(db, me, "Profile updated", ", ".join(patch.keys()))
    db.commit()
    return me.to_dict()


# ================================================================ Subjects
@router.get("/subjects")
def my_subjects(db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    courses = _my_courses(db, current_user["user_id"])
    counts = enrollment_counts(db)
    sessions = dict(db.query(AttendanceSession.course_id, func.count(AttendanceSession.id))
                    .filter(AttendanceSession.course_id.in_([c.id for c in courses] or [-1])).group_by(AttendanceSession.course_id).all())
    TERM_SESSIONS = 40
    return [{**c.to_dict(counts.get(c.id, 0)), "classesHeld": sessions.get(c.id, 0),
             "progress": min(100, round(sessions.get(c.id, 0) / TERM_SESSIONS * 100)), "nextTopic": ""} for c in courses]


@router.post("/subject-requests")
def request_subject(payload: SubjectRequestCreate, db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    me = current_user.user
    if db.query(SubjectRequest.id).filter(SubjectRequest.teacher_id == me.id, SubjectRequest.code == payload.code.upper(),
                                          SubjectRequest.status == "pending").first():
        raise HTTPException(status_code=400, detail="You already have a pending request for this subject code.")
    req = SubjectRequest(teacher_id=me.id, teacher_name=me.name, code=payload.code.upper(), name=payload.name,
                         dept=payload.dept or "General", notes=payload.notes or "", status="pending")
    db.add(req)
    db.flush()
    log_audit(db, me, "Subject requested", f"{req.code} — {req.name}")
    notify_role(db, "admin", "New subject request", f"{me.name} requested to add {req.code} — {req.name}.")
    queue_event(db, "subjectRequest:update", req.to_dict(), roles=["admin"], users=[me.id])
    db.commit()
    return req.to_dict()


@router.get("/subject-requests/mine")
def my_subject_requests(db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    reqs = db.query(SubjectRequest).filter(SubjectRequest.teacher_id == current_user["user_id"]).order_by(SubjectRequest.ts.desc()).all()
    return [r.to_dict() for r in reqs]


# ========================================================= Students & risk
def _course_ids_for(db, teacher_id, course_ids: str):
    mine = {c.id for c in _my_courses(db, teacher_id)}
    if course_ids:
        wanted = {parse_pk(c, "c") for c in course_ids.split(",") if c.strip()}
        return sorted(wanted & mine)
    return sorted(mine)


def _my_students(db, cids):
    return (db.query(User).join(Enrollment, Enrollment.student_id == User.id)
            .filter(Enrollment.course_id.in_(cids or [-1]), User.role == "student").distinct().order_by(User.id_label).all())


@router.get("/students")
def students_with_stats(course_ids: str = Query("", alias="courseIds"), db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    cids = _course_ids_for(db, current_user["user_id"], course_ids)
    return cohort_risk(db, _my_students(db, cids), cids)


@router.get("/risk-scores")
def risk_scores(course_ids: str = Query("", alias="courseIds"), db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    cids = _course_ids_for(db, current_user["user_id"], course_ids)
    return cohort_risk(db, _my_students(db, cids), cids)


# ============================================================== Assignments
@router.get("/assignments")
def list_assignments(db: Session = Depends(get_db), current_user=Depends(teacher_only), courses: str = Query("")):
    cids = [c.id for c in _my_courses(db, current_user["user_id"])]
    items = db.query(Assignment).filter(Assignment.course_id.in_(cids or [-1])).order_by(Assignment.ts.desc()).all()
    subs = dict(db.query(AssignmentSubmission.assignment_id, func.count(AssignmentSubmission.id))
                .filter(AssignmentSubmission.assignment_id.in_([a.id for a in items] or [-1])).group_by(AssignmentSubmission.assignment_id).all())
    counts = enrollment_counts(db)
    return [a.to_dict(subs.get(a.id, 0), counts.get(a.course_id, 0)) for a in items]


@router.post("/assignments")
def create_assignment(payload: AssignmentCreate, db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    me = current_user.user
    course = _course_by_ref_or_name(db, me.id, payload.course_id, payload.course)
    a = Assignment(title=payload.title, course_id=course.id, course=course.name, due=payload.due, created_by=me.id)
    db.add(a)
    db.flush()
    log_audit(db, me, "Assignment created", f"{a.title} · {course.name}")
    notify_course(db, course.id, "New assignment posted", f"{a.title} ({course.name}) — due {a.due}.")
    db.commit()
    return a.to_dict(0, enrollment_counts(db).get(course.id, 0))


# ============================================================ Study material
@router.get("/materials")
def list_material(db: Session = Depends(get_db), current_user=Depends(teacher_only), courses: str = Query("")):
    cids = [c.id for c in _my_courses(db, current_user["user_id"])]
    return [m.to_dict() for m in db.query(StudyMaterial).filter(StudyMaterial.course_id.in_(cids or [-1])).order_by(StudyMaterial.ts.desc())]


@router.post("/materials")
def upload_material(payload: MaterialUpload, db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    me = current_user.user
    course = _course_by_ref_or_name(db, me.id, payload.course_id, payload.course)
    m = StudyMaterial(title=payload.title, course_id=course.id, course=course.name, type=payload.type, size=payload.size, uploaded_by=me.name)
    db.add(m)
    db.flush()
    log_audit(db, me, "Study material uploaded", f"{m.title} · {course.name}")
    notify_course(db, course.id, "New study material", f"{m.title} was added for {course.name}.")
    db.commit()
    return m.to_dict()


# ================================================================ Timetable
@router.get("/timetable")
def timetable(db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    return build_timetable([c.to_dict() for c in _my_courses(db, current_user["user_id"])])


# ============================================================ Class notices
@router.get("/notices")
def list_notices(db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    ns = db.query(ClassNotice).filter(ClassNotice.sent_by_id == current_user["user_id"]).order_by(ClassNotice.ts.desc()).all()
    return [n.to_dict() for n in ns]


@router.post("/notices")
def send_notice(payload: NoticeCreate, db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    me = current_user.user
    course = _course_by_ref_or_name(db, me.id, payload.course_id, payload.course)
    n = ClassNotice(title=payload.title, course_id=course.id, course=course.name, sent_by=me.name, sent_by_id=me.id)
    db.add(n)
    db.flush()
    log_audit(db, me, "Class notice sent", f"{n.title} · {course.name}")
    notify_course(db, course.id, f"Notice · {course.code}", n.title)
    queue_event(db, "notice:new", n.to_dict(), users=enrolled_student_ids(db, course.id))
    db.commit()
    return n.to_dict()


# ==================================================================== Leave
@router.get("/leave")
def list_my_leave(db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    ls = db.query(LeaveRequest).filter(LeaveRequest.applicant_id == current_user["user_id"]).order_by(LeaveRequest.ts.desc()).all()
    return [x.to_dict() for x in ls]


@router.post("/leave")
def apply_leave(payload: LeaveRequestCreate, db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    me = current_user.user
    if payload.to_date < payload.from_date:
        raise HTTPException(status_code=400, detail="The end date must be on or after the start date.")
    lv = LeaveRequest(applicant_id=me.id, applicant=me.name, role="teacher", type=payload.type, from_date=payload.from_date,
                      to_date=payload.to_date, reason=payload.reason, status="pending")
    db.add(lv)
    db.flush()
    log_audit(db, me, "Leave applied", f"{lv.type} · {lv.from_date} to {lv.to_date}")
    notify_role(db, "admin", "New leave request", f"{me.name} applied for {lv.type} leave ({lv.from_date} → {lv.to_date}).")
    queue_event(db, "leave:update", lv.to_dict(), roles=["admin"], users=[me.id])
    db.commit()
    return lv.to_dict()


# =============================================================== Grievances
def raise_grievance_for(db, me, payload: GrievanceCreate):
    contact_email = (payload.contact_email or "").strip()
    if contact_email and not is_valid_gmail(contact_email):
        raise HTTPException(status_code=400, detail="Enter a valid Gmail address (e.g. name@gmail.com) so admin can reply, or leave it blank.")
    recent = (db.query(func.count(Grievance.id))
              .filter(Grievance.raised_by_id == me.id, Grievance.ts >= datetime.utcnow() - timedelta(hours=1)).scalar())
    if recent >= 5:  # simple anti-spam
        raise HTTPException(status_code=429, detail="You've raised several grievances in the last hour — please wait before raising another.")
    triage = classify_grievance(payload.description, me.role, payload.category)
    g = Grievance(raised_by_id=me.id, raised_by=me.name, role=me.role, category=triage["category"], priority=triage["priority"],
                  routed_to=triage["routedTo"], description=payload.description, status="open", contact_email=contact_email or None)
    db.add(g)
    db.flush()
    log_audit(db, me, "Grievance raised", f"{g.category} [{g.priority}] — {g.description[:60]}{'…' if len(g.description) > 60 else ''}")
    notify_role(db, "admin", f"New {g.priority}-priority grievance", f"{me.name} raised a {g.category.lower()} grievance → {g.routed_to}.")
    queue_event(db, "grievance:update", g.to_dict(), roles=["admin"], users=[me.id])
    db.commit()
    return g.to_dict()


@router.post("/grievances")
def raise_grievance(payload: GrievanceCreate, db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    return raise_grievance_for(db, current_user.user, payload)


@router.get("/grievances/mine")
def my_grievances(db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    gs = db.query(Grievance).filter(Grievance.raised_by_id == current_user["user_id"]).order_by(Grievance.ts.desc()).all()
    return [g.to_dict() for g in gs]


# ================================================================== Reports
@router.get("/reports/summary")
def reports_summary(db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    me = current_user.user
    courses = _my_courses(db, me.id)
    cids = [c.id for c in courses]
    per_session = (db.query(AttendanceSession.date, func.count(AttendanceRecord.id), func.sum(PRESENT_INT))
                   .join(AttendanceRecord, AttendanceRecord.session_id == AttendanceSession.id)
                   .filter(AttendanceSession.course_id.in_(cids or [-1]))
                   .group_by(AttendanceSession.id, AttendanceSession.date).order_by(AttendanceSession.date).all())
    pcts = [round(int(p or 0) / t * 100) for _, t, p in per_session if t]
    avg_attendance = round(sum(pcts) / len(pcts)) if pcts else None
    scores = [s for (s,) in db.query(GradeEntry.score).join(GradeRecord, GradeRecord.id == GradeEntry.grade_id)
              .filter(GradeRecord.course_id.in_(cids or [-1]))]
    grades_published = db.query(func.count(GradeRecord.id)).filter(GradeRecord.course_id.in_(cids or [-1])).scalar()
    assignments_posted = db.query(func.count(Assignment.id)).filter(Assignment.course_id.in_(cids or [-1])).scalar()
    return {
        "avgAttendance": avg_attendance if avg_attendance is not None else 0,
        "avgScore": round(sum(scores) / len(scores)) if scores else 0,
        "classesHeld": len(per_session), "assignmentsPosted": assignments_posted, "gradesPublished": grades_published,
        "trend": pcts[-10:] if pcts else [],
        "distribution": grade_distribution(scores),
    }


@router.get("/activity")
def my_activity(db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    rows = (db.query(AuditLogEntry).filter(AuditLogEntry.actor_id == current_user["user_id"])
            .order_by(AuditLogEntry.ts.desc()).limit(10).all())
    return [r.to_dict() for r in rows]
