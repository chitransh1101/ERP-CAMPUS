import csv
import io
from datetime import date, timedelta

from fastapi import APIRouter, Depends, File, HTTPException, Query, Request, UploadFile
from sqlalchemy import case, func
from sqlalchemy.orm import Session, aliased
from typing import Optional
from pydantic import Field
from app.schemas.base import Email, Id, In, Name, Short

from app.auth.auth import generate_temp_password, hash_password, require_role, revoke_all_sessions
from app.common import (
    cohort_risk, enrollment_counts, is_valid_email, log_audit, normalize_email, notify_users, parse_pk,
    score_stats,
)
from app.database.db import get_db
from app.models.models import (
    AttendanceRecord, AttendanceSession, AuditLogEntry, Course, Enrollment, Fee, Grievance, LeaveRequest,
    OutboundMessage, ParentLink, SubjectRequest, User,
)
from app.documents import fmt_date
from app.messaging import alert_parents, normalize_phone, provider_status
from app.realtime import queue_event
from app.schemas.admin_schema import (
    CourseCreate, EnrollRequest, FeePayment, GrievanceAssignRequest, GrievanceResolveRequest, LeaveDecision,
    SubjectRejectRequest,
)
from app.schemas.user_schema import UserCreateByAdmin, UserStatusUpdate
from app.security import client_ip

router = APIRouter(prefix="/admin", tags=["admin"])
admin_only = require_role(["admin"])


# ===================================================================== Users
@router.get("/users")
def list_users(role: str = Query(""), q: str = Query("", max_length=100), db: Session = Depends(get_db),
               current_user=Depends(admin_only)):
    query = db.query(User)
    if role in ("student", "teacher", "admin", "parent"):
        query = query.filter(User.role == role)
    if q:
        like = f"%{q.lower().replace('%', '').replace('_', '')}%"
        query = query.filter(func.lower(User.name).like(like) | User.email.like(like) | func.lower(User.id_label).like(like))
    return [u.to_dict() for u in query.order_by(User.role, User.name).limit(2000)]


def _create_user(db, data: dict, allowed_roles=("student", "teacher", "admin")):
    email = normalize_email(data.get("email"))
    if not is_valid_email(email):
        raise ValueError("invalid email")
    role = (data.get("role") or "").strip().lower()
    if role not in allowed_roles:
        raise ValueError("role must be " + ", ".join(allowed_roles[:-1]) + " or " + allowed_roles[-1])
    name = (data.get("name") or "").strip()
    if not name or len(name) > 150:
        raise ValueError("name is required")
    if db.query(User.id).filter(User.email == email).first():
        raise ValueError("email already exists")
    id_label = (data.get("id_label") or data.get("idLabel") or "").strip().upper() or None
    if id_label and db.query(User.id).filter(User.id_label == id_label).first():
        raise ValueError(f"ID {id_label} already exists")
    temp = generate_temp_password()
    year = data.get("year")
    user = User(name=name, email=email, role=role, id_label=id_label, department=(data.get("department") or None),
                designation=data.get("designation") or None, phone=data.get("phone") or None,
                year=int(year) if str(year or "").isdigit() else None, section=(data.get("section") or None),
                status="active", must_change_password=True, password_hash=hash_password(temp))
    db.add(user)
    db.flush()
    return user, temp


@router.post("/users")
def create_user(payload: UserCreateByAdmin, request: Request, db: Session = Depends(get_db), current_user=Depends(admin_only)):
    try:
        user, temp = _create_user(db, payload.model_dump())
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e).capitalize() + ".")
    log_audit(db, current_user, "User created", f"{user.name} ({user.role})", ip=client_ip(request))
    db.commit()
    # A unique one-time password (shown once to the admin) replaces the old
    # shared default "changeme123"; the user must change it at first login.
    return {**user.to_dict(), "tempPassword": temp}


@router.patch("/users/{user_id}/status")
def set_user_status(user_id: str, payload: UserStatusUpdate, request: Request, db: Session = Depends(get_db),
                    current_user=Depends(admin_only)):
    u = db.get(User, parse_pk(user_id, "u"))
    if not u:
        raise HTTPException(status_code=404, detail="User not found")
    if u.id == current_user["user_id"]:
        raise HTTPException(status_code=400, detail="You can't deactivate your own account.")
    if payload.status == "inactive" and u.role == "admin":
        active_admins = db.query(func.count(User.id)).filter(User.role == "admin", User.status == "active").scalar()
        if active_admins <= 1:
            raise HTTPException(status_code=400, detail="At least one active admin is required.")
    u.status = payload.status
    if payload.status == "inactive":
        revoke_all_sessions(db, u.id)  # kicks them out everywhere, immediately
    log_audit(db, current_user, "User reactivated" if payload.status == "active" else "User deactivated", u.name, ip=client_ip(request))
    db.commit()
    return u.to_dict()


@router.post("/users/{user_id}/reset-password")
def reset_password(user_id: str, request: Request, db: Session = Depends(get_db), current_user=Depends(admin_only)):
    u = db.get(User, parse_pk(user_id, "u"))
    if not u:
        raise HTTPException(status_code=404, detail="User not found")
    temp = generate_temp_password()
    u.password_hash = hash_password(temp)
    u.must_change_password = True
    revoke_all_sessions(db, u.id)
    log_audit(db, current_user, "Password reset", u.name, ip=client_ip(request))
    db.commit()
    return {"tempPassword": temp, "user": u.to_dict()}


# =================================================================== Courses
def _faculty_for(db, faculty_id=None, faculty_name=None):
    if faculty_id:
        t = db.get(User, parse_pk(faculty_id, "u"))
    elif faculty_name:
        t = db.query(User).filter(User.role == "teacher", func.lower(User.name) == faculty_name.strip().lower()).first()
    else:
        return None
    if not t or t.role != "teacher":
        raise HTTPException(status_code=400, detail="Faculty member not found — pick an existing teacher account.")
    return t


@router.get("/courses")
def list_courses(db: Session = Depends(get_db), current_user=Depends(admin_only)):
    counts = enrollment_counts(db)
    return [c.to_dict(counts.get(c.id, 0)) for c in db.query(Course).order_by(Course.code)]


@router.post("/courses")
def create_course(payload: CourseCreate, db: Session = Depends(get_db), current_user=Depends(admin_only)):
    teacher = _faculty_for(db, payload.faculty_id, payload.faculty)
    code = payload.code.upper()
    if db.query(Course.id).filter(Course.code == code).first():
        raise HTTPException(status_code=400, detail=f"A course with code {code} already exists.")
    course = Course(code=code, name=payload.name, dept=payload.dept or "", faculty_id=teacher.id if teacher else None)
    db.add(course)
    db.flush()
    log_audit(db, current_user, "Course created", f"{course.code} — {course.name}")
    if teacher:
        notify_users(db, [teacher.id], "New course assigned", f"You've been assigned {course.code} — {course.name}.")
    db.commit()
    return course.to_dict(0)


@router.get("/courses/{course_id}/students")
def course_students(course_id: str, db: Session = Depends(get_db), current_user=Depends(admin_only)):
    cid = parse_pk(course_id, "c")
    rows = (db.query(User).join(Enrollment, Enrollment.student_id == User.id).filter(Enrollment.course_id == cid)
            .order_by(User.id_label).all())
    return [u.to_dict() for u in rows]


@router.post("/courses/{course_id}/enroll")
def enroll_students(course_id: str, payload: EnrollRequest, db: Session = Depends(get_db), current_user=Depends(admin_only)):
    course = db.get(Course, parse_pk(course_id, "c"))
    if not course:
        raise HTTPException(status_code=404, detail="Course not found")
    ids = {parse_pk(s, "u") for s in payload.student_ids}
    valid = {uid for (uid,) in db.query(User.id).filter(User.id.in_(ids or [-1]), User.role == "student")}
    existing = {sid for (sid,) in db.query(Enrollment.student_id).filter(Enrollment.course_id == course.id)}
    new = valid - existing
    db.add_all([Enrollment(course_id=course.id, student_id=sid) for sid in new])
    log_audit(db, current_user, "Students enrolled", f"{course.code}: +{len(new)}")
    db.commit()
    return {"enrolled": len(new), "alreadyEnrolled": len(valid & existing), "invalid": len(ids - valid)}


@router.delete("/courses/{course_id}/students/{student_id}")
def unenroll(course_id: str, student_id: str, db: Session = Depends(get_db), current_user=Depends(admin_only)):
    n = (db.query(Enrollment).filter(Enrollment.course_id == parse_pk(course_id, "c"), Enrollment.student_id == parse_pk(student_id, "u"))
         .delete(synchronize_session=False))
    log_audit(db, current_user, "Student unenrolled", f"{course_id} / {student_id}")
    db.commit()
    return {"removed": n}


# ========================================================= Subject requests
@router.get("/subject-requests")
def list_subject_requests(db: Session = Depends(get_db), current_user=Depends(admin_only)):
    return [r.to_dict() for r in db.query(SubjectRequest).order_by(SubjectRequest.ts.desc())]


def _pending_request(db, req_id):
    req = db.get(SubjectRequest, parse_pk(req_id, "sr"))
    if not req:
        raise HTTPException(status_code=404, detail="Subject request not found")
    if req.status != "pending":
        raise HTTPException(status_code=409, detail=f"This request was already {req.status}.")
    return req


@router.post("/subject-requests/{req_id}/approve")
def approve_subject_request(req_id: str, db: Session = Depends(get_db), current_user=Depends(admin_only)):
    req = _pending_request(db, req_id)
    req.status = "approved"
    existing = db.query(Course).filter(Course.code == req.code).first()
    if existing:
        existing.faculty_id = req.teacher_id
    else:
        db.add(Course(code=req.code, name=req.name, dept=req.dept, faculty_id=req.teacher_id))
    log_audit(db, current_user, "Subject request approved", f"{req.code} — {req.name} → {req.teacher_name}")
    notify_users(db, [req.teacher_id], "Subject request approved", f"{req.code} — {req.name} was added to your subjects.")
    queue_event(db, "subjectRequest:update", req.to_dict(), users=[req.teacher_id], roles=["admin"])
    db.commit()
    return req.to_dict()


@router.post("/subject-requests/{req_id}/reject")
def reject_subject_request(req_id: str, payload: SubjectRejectRequest, db: Session = Depends(get_db), current_user=Depends(admin_only)):
    req = _pending_request(db, req_id)
    req.status = "rejected"
    req.reject_reason = payload.reason or ""
    log_audit(db, current_user, "Subject request rejected", f"{req.code} — {req.name}")
    body = f"{req.code} — {req.name}: {payload.reason}" if payload.reason else f"{req.code} — {req.name} was not approved."
    notify_users(db, [req.teacher_id], "Subject request declined", body)
    queue_event(db, "subjectRequest:update", req.to_dict(), users=[req.teacher_id], roles=["admin"])
    db.commit()
    return req.to_dict()


# ====================================================================== Fees
@router.get("/fees")
def list_fees(db: Session = Depends(get_db), current_user=Depends(admin_only)):
    return [f.to_dict() for f in db.query(Fee).join(User, User.id == Fee.student_id).order_by(User.name)]


@router.post("/fees/{fee_id}/mark-paid")
def mark_fee_paid(fee_id: str, payload: FeePayment = None, db: Session = Depends(get_db), current_user=Depends(admin_only)):
    f = db.get(Fee, parse_pk(fee_id, "f"))
    if not f:
        raise HTTPException(status_code=404, detail="Fee record not found")
    amount = payload.amount if payload and payload.amount else (f.total - f.paid)
    f.paid = min(f.total, f.paid + amount)
    log_audit(db, current_user, "Fee payment recorded", f"{f.to_dict()['student']}: ₹{amount:,.0f} ({f.status})")
    notify_users(db, [f.student_id], "Fee payment recorded", f"₹{amount:,.0f} received. Balance due: ₹{max(0, f.total - f.paid):,.0f}.")
    queue_event(db, "fees:update", f.to_dict(), users=[f.student_id], roles=["admin"])
    if f.student_user:
        alert_parents(db, f.student_user, "fee_paid",
                      f"Payment of Rs. {amount:,.0f} received for {f.student_user.name}. Balance due: Rs. {max(0, f.total - f.paid):,.0f}.",
                      title="Fee payment received")
    db.commit()
    return f.to_dict()


# =================================================================== Reports
@router.get("/reports/summary")
def reports_summary(db: Session = Depends(get_db), current_user=Depends(admin_only)):
    total_students = db.query(func.count(User.id)).filter(User.role == "student", User.status == "active").scalar()
    total_teachers = db.query(func.count(User.id)).filter(User.role == "teacher", User.status == "active").scalar()
    total_courses = db.query(func.count(Course.id)).scalar()
    billed, collected = db.query(func.coalesce(func.sum(Fee.total), 0), func.coalesce(func.sum(Fee.paid), 0)).one()
    present_int = case((AttendanceRecord.present.is_(True), 1), else_=0)
    total, present = db.query(func.count(AttendanceRecord.id), func.sum(present_int)).one()
    by_dept = (db.query(Course.dept, func.count(AttendanceRecord.id), func.sum(present_int))
               .join(AttendanceSession, AttendanceSession.course_id == Course.id)
               .join(AttendanceRecord, AttendanceRecord.session_id == AttendanceSession.id)
               .group_by(Course.dept).all())
    cgpas = [v["cgpa"] for v in score_stats(db).values() if v.get("cgpa") is not None]
    since = (date.today() - timedelta(days=13)).isoformat()
    daily = (db.query(AttendanceSession.date, func.count(AttendanceRecord.id), func.sum(present_int))
             .join(AttendanceRecord, AttendanceRecord.session_id == AttendanceSession.id)
             .filter(AttendanceSession.date >= since).group_by(AttendanceSession.date).order_by(AttendanceSession.date).all())
    open_grv = db.query(func.count(Grievance.id)).filter(Grievance.status != "resolved").scalar()
    high_grv = db.query(func.count(Grievance.id)).filter(Grievance.status != "resolved", Grievance.priority == "high").scalar()
    return {
        "totalStudents": total_students, "totalTeachers": total_teachers, "totalCourses": total_courses,
        "feeCollectedPct": round(collected / billed * 100) if billed else 0,
        "feeCollected": collected, "feeBilled": billed,
        "avgAttendance": round(int(present or 0) / total * 100) if total else 0,
        "avgCGPA": round(sum(cgpas) / len(cgpas), 2) if cgpas else 0,
        "attendanceByDept": [{"label": (d or "Other")[:14], "value": round(int(p or 0) / t * 100)} for d, t, p in by_dept if t],
        "attendanceTrend": [{"date": d, "value": round(int(p or 0) / t * 100)} for d, t, p in daily if t],
        "openGrievances": open_grv, "highPriorityGrievances": high_grv,
    }


@router.get("/audit-log")
def audit_log(limit: int = Query(60, ge=1, le=500), offset: int = Query(0, ge=0), db: Session = Depends(get_db),
              current_user=Depends(admin_only)):
    rows = db.query(AuditLogEntry).order_by(AuditLogEntry.ts.desc(), AuditLogEntry.id.desc()).offset(offset).limit(limit)
    return [e.to_dict() for e in rows]


# ================================================================ Grievances
@router.get("/grievances")
def list_grievances(db: Session = Depends(get_db), current_user=Depends(admin_only)):
    prio = case((Grievance.priority == "high", 0), (Grievance.priority == "medium", 1), else_=2)
    status = case((Grievance.status == "open", 0), (Grievance.status == "in-review", 1), else_=2)
    return [g.to_dict() for g in db.query(Grievance).order_by(status, prio, Grievance.ts.desc())]


def _grievance(db, grv_id):
    g = db.get(Grievance, parse_pk(grv_id, "grv"))
    if not g:
        raise HTTPException(status_code=404, detail="Grievance not found")
    return g


@router.post("/grievances/{grv_id}/assign")
def assign_grievance(grv_id: str, payload: GrievanceAssignRequest, db: Session = Depends(get_db), current_user=Depends(admin_only)):
    g = _grievance(db, grv_id)
    g.assigned_to = payload.assignee
    if g.status == "open":
        g.status = "in-review"
    log_audit(db, current_user, "Grievance assigned", f"{g.category} → {payload.assignee}")
    notify_users(db, [g.raised_by_id], "Grievance update", f"Your {g.category.lower()} grievance is now being reviewed by {payload.assignee}.")
    queue_event(db, "grievance:update", g.to_dict(), users=[g.raised_by_id], roles=["admin"])
    db.commit()
    return g.to_dict()


@router.post("/grievances/{grv_id}/resolve")
def resolve_grievance(grv_id: str, payload: GrievanceResolveRequest = None, db: Session = Depends(get_db),
                      current_user=Depends(admin_only)):
    g = _grievance(db, grv_id)
    g.status = "resolved"
    g.resolution = (payload.resolution if payload else "") or g.resolution
    log_audit(db, current_user, "Grievance resolved", g.category)
    note = f" Note: {g.resolution}" if g.resolution else ""
    notify_users(db, [g.raised_by_id], "Grievance resolved", f"Your {g.category.lower()} grievance has been resolved.{note}")
    queue_event(db, "grievance:update", g.to_dict(), users=[g.raised_by_id], roles=["admin"])
    db.commit()
    return g.to_dict()


# ===================================================================== Leave
@router.get("/leave-requests")
def list_leave(db: Session = Depends(get_db), current_user=Depends(admin_only)):
    order = case((LeaveRequest.status == "pending", 0), else_=1)
    return [x.to_dict() for x in db.query(LeaveRequest).order_by(order, LeaveRequest.ts.desc()).limit(300)]


@router.post("/leave-requests/{leave_id}/decide")
def decide_leave(leave_id: str, payload: LeaveDecision, db: Session = Depends(get_db), current_user=Depends(admin_only)):
    lv = db.get(LeaveRequest, parse_pk(leave_id, "lv"))
    if not lv:
        raise HTTPException(status_code=404, detail="Leave request not found")
    if lv.status != "pending":
        raise HTTPException(status_code=409, detail=f"Already {lv.status}.")
    lv.status = payload.status
    lv.decided_by = current_user["name"]
    log_audit(db, current_user, f"Leave {payload.status}", f"{lv.applicant} · {lv.type} · {lv.from_date}→{lv.to_date}")
    notify_users(db, [lv.applicant_id], f"Leave {payload.status}", f"Your {lv.type} leave ({lv.from_date} → {lv.to_date}) was {payload.status}.")
    queue_event(db, "leave:update", lv.to_dict(), users=[lv.applicant_id], roles=["admin"])
    db.commit()
    return lv.to_dict()


# ================================================================ Risk scores
@router.get("/risk-scores")
def risk_scores(db: Session = Depends(get_db), current_user=Depends(admin_only)):
    students = db.query(User).filter(User.role == "student", User.status == "active").order_by(User.id_label).all()
    return cohort_risk(db, students)


# ================================================================ CSV import
IMPORT_KINDS = {
    "users": ["name", "email", "role", "id_label", "department", "year", "section"],
    "courses": ["code", "name", "dept", "faculty_email"],
    "enrollments": ["course_code", "student_id_label"],
    "fees": ["student_id_label", "total", "paid", "due_date"],
    "parents": ["name", "email", "phone", "student_id_label", "relation"],
}


@router.get("/import/templates")
def import_templates(current_user=Depends(admin_only)):
    return {k: ",".join(v) for k, v in IMPORT_KINDS.items()}


@router.post("/import/{kind}")
async def import_csv(kind: str, request: Request, file: UploadFile = File(...), db: Session = Depends(get_db),
                     current_user=Depends(admin_only)):
    """Bulk-load your college's real data. Each row is validated; bad rows
    are reported back with the reason and skipped, good rows are saved."""
    if kind not in IMPORT_KINDS:
        raise HTTPException(status_code=404, detail="Unknown import type")
    raw = await file.read(2 * 1024 * 1024 + 1)
    if len(raw) > 2 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="CSV must be under 2 MB (split larger files).")
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise HTTPException(status_code=400, detail="Save the CSV as UTF-8.")
    reader = csv.DictReader(io.StringIO(text))
    headers = [h.strip().lower() for h in (reader.fieldnames or [])]
    missing = [h for h in IMPORT_KINDS[kind] if h not in headers and h not in ("department", "year", "section", "dept", "due_date", "paid", "faculty_email", "relation")]
    if missing:
        raise HTTPException(status_code=400, detail=f"CSV is missing columns: {', '.join(missing)}. Expected: {','.join(IMPORT_KINDS[kind])}")
    created, errors, credentials = 0, [], []
    for i, row in enumerate(reader, start=2):
        if i > 5001:
            errors.append({"row": i, "error": "Row limit (5000) reached — split the file."})
            break
        row = {(k or "").strip().lower(): (v or "").strip() for k, v in row.items()}
        try:
            with db.begin_nested():
                if kind == "users":
                    user, temp = _create_user(db, row)
                    credentials.append({"email": user.email, "tempPassword": temp})
                elif kind == "courses":
                    code = row["code"].upper()
                    if not code or not row.get("name"):
                        raise ValueError("code and name are required")
                    if db.query(Course.id).filter(Course.code == code).first():
                        raise ValueError(f"course {code} already exists")
                    t = None
                    if row.get("faculty_email"):
                        t = db.query(User).filter(User.email == normalize_email(row["faculty_email"]), User.role == "teacher").first()
                        if not t:
                            raise ValueError(f"no teacher with email {row['faculty_email']}")
                    db.add(Course(code=code, name=row["name"], dept=row.get("dept", ""), faculty_id=t.id if t else None))
                elif kind == "enrollments":
                    c = db.query(Course).filter(Course.code == row["course_code"].upper()).first()
                    s = db.query(User).filter(User.id_label == row["student_id_label"].upper(), User.role == "student").first()
                    if not c or not s:
                        raise ValueError("unknown course code" if not c else "unknown student roll number")
                    if db.query(Enrollment.id).filter_by(course_id=c.id, student_id=s.id).first():
                        raise ValueError("already enrolled")
                    db.add(Enrollment(course_id=c.id, student_id=s.id))
                elif kind == "fees":
                    s = db.query(User).filter(User.id_label == row["student_id_label"].upper(), User.role == "student").first()
                    if not s:
                        raise ValueError("unknown student roll number")
                    total, paid = float(row["total"]), float(row.get("paid") or 0)
                    if total < 0 or paid < 0 or paid > total:
                        raise ValueError("amounts must satisfy 0 <= paid <= total")
                    fee = db.query(Fee).filter(Fee.student_id == s.id).first() or Fee(student_id=s.id)
                    fee.total, fee.paid, fee.due_date = total, paid, row.get("due_date") or None
                    db.add(fee)
                elif kind == "parents":
                    s = db.query(User).filter(User.id_label == row["student_id_label"].upper(), User.role == "student").first()
                    if not s:
                        raise ValueError("unknown student roll number")
                    _, temp = link_parent(db, row.get("name"), row.get("email"), row.get("phone"), s, row.get("relation"))
                    if temp:
                        credentials.append({"email": normalize_email(row.get("email")), "tempPassword": temp})
                db.flush()
            created += 1
        except (ValueError, KeyError) as e:
            errors.append({"row": i, "error": str(e)})
    log_audit(db, current_user, f"CSV import ({kind})", f"{created} rows imported, {len(errors)} errors", ip=client_ip(request))
    db.commit()
    return {"imported": created, "errors": errors[:200], "credentials": credentials}


# ============================================================ Parents & alerts
RELATIONS = ("Father", "Mother", "Guardian", "Parent")


def link_parent(db, name, email, phone, student, relation=None):
    """Create the parent account if needed and link it to `student`.
    Returns (link, temp_password or None). Raises ValueError with a readable reason."""
    email = normalize_email(email)
    relation = (relation or "Parent").strip().title()
    if relation not in RELATIONS:
        relation = "Guardian"
    mobile = normalize_phone(phone)
    if phone and not mobile:
        raise ValueError("phone must be a mobile number like +91 98765 43210")
    user = db.query(User).filter(User.email == email).first()
    temp = None
    if user:
        if user.role != "parent":
            raise ValueError(f"{email} already belongs to a {user.role} account")
        if mobile and not user.phone:
            user.phone = mobile
    else:
        user, temp = _create_user(db, {"name": name, "email": email, "role": "parent", "phone": mobile or None},
                                  allowed_roles=("parent",))
    if db.query(ParentLink.id).filter_by(parent_id=user.id, student_id=student.id).first():
        raise ValueError(f"{email} is already linked to {student.name}")
    link = ParentLink(parent_id=user.id, student_id=student.id, relation=relation)
    db.add(link)
    db.flush()
    return link, temp


class ParentCreate(In):
    name: Name
    email: Email
    phone: Optional[Short] = None
    student_id: Id = Field(alias="studentId")
    relation: Optional[Short] = None


class TestMessage(In):
    phone: Short


@router.get("/parents")
def list_parents(db: Session = Depends(get_db), current_user=Depends(admin_only)):
    P = aliased(User)
    S = aliased(User)
    rows = (db.query(ParentLink, P, S).join(P, P.id == ParentLink.parent_id).join(S, S.id == ParentLink.student_id)
            .order_by(S.id_label).all())
    return [{"linkId": f"pl_{l.id}", "relation": l.relation,
             "parent": {"id": f"u_{p.id}", "name": p.name, "email": p.email, "phone": p.phone or "", "status": p.status},
             "student": {"id": f"u_{s.id}", "name": s.name, "idLabel": s.id_label, "department": s.department}} for l, p, s in rows]


@router.post("/parents")
def add_parent(payload: ParentCreate, request: Request, db: Session = Depends(get_db), current_user=Depends(admin_only)):
    student = db.get(User, parse_pk(payload.student_id, "u"))
    if not student or student.role != "student":
        raise HTTPException(status_code=404, detail="Student not found")
    try:
        link, temp = link_parent(db, payload.name, payload.email, payload.phone, student, payload.relation)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)[:1].upper() + str(e)[1:] + ".")
    log_audit(db, current_user, "Parent linked", f"{payload.email} → {student.name}", ip=client_ip(request))
    db.commit()
    return {"linkId": f"pl_{link.id}", "email": normalize_email(payload.email), "tempPassword": temp}


@router.delete("/parents/links/{link_id}")
def remove_parent_link(link_id: str, db: Session = Depends(get_db), current_user=Depends(admin_only)):
    link = db.get(ParentLink, parse_pk(link_id, "pl"))
    if not link:
        raise HTTPException(status_code=404, detail="Link not found")
    log_audit(db, current_user, "Parent unlinked", f"parent u_{link.parent_id} ↛ student u_{link.student_id}")
    db.delete(link)
    db.commit()
    return {"ok": True}


@router.get("/messages")
def list_messages(status: str = Query("", max_length=20), kind: str = Query("", max_length=30),
                  db: Session = Depends(get_db), current_user=Depends(admin_only)):
    q = db.query(OutboundMessage)
    if status:
        q = q.filter(OutboundMessage.status == status)
    if kind:
        q = q.filter(OutboundMessage.kind == kind)
    rows = q.order_by(OutboundMessage.id.desc()).limit(300).all()
    counts = dict(db.query(OutboundMessage.status, func.count(OutboundMessage.id)).group_by(OutboundMessage.status).all())
    return {"messages": [m.to_dict() for m in rows], "counts": counts, "provider": provider_status()}


@router.post("/messages/fee-reminders")
def send_fee_reminders(db: Session = Depends(get_db), current_user=Depends(admin_only)):
    fees = (db.query(Fee).join(User, User.id == Fee.student_id)
            .filter(User.status == "active", User.role == "student", Fee.paid < Fee.total).all())
    alerted = 0
    for f in fees:
        st = f.student_user
        due = f.total - f.paid
        when = f" by {fmt_date(f.due_date)}" if f.due_date else ""
        notify_users(db, [st.id], "Fee reminder", f"Rs. {due:,.0f} is due{when}.")
        alerted += alert_parents(db, st, "fee_due", f"Fee reminder: Rs. {due:,.0f} is due for {st.name}{when}.",
                                 title="Fee reminder", dedupe_days=1)
    log_audit(db, current_user, "Fee reminders sent", f"{len(fees)} students with dues, {alerted} parent alerts")
    db.commit()
    return {"students": len(fees), "parentsAlerted": alerted}


@router.post("/messages/test")
def send_test_message(payload: TestMessage, db: Session = Depends(get_db), current_user=Depends(admin_only)):
    mobile = normalize_phone(payload.phone)
    if not mobile:
        raise HTTPException(status_code=400, detail="Enter a mobile number like +91 98765 43210.")
    from app import config
    msg = OutboundMessage(user_id=None, to_name="Test recipient", phone=mobile, kind="test",
                          channel="whatsapp" if config.MESSAGING_PROVIDER == "meta" else config.MESSAGING_CHANNEL,
                          body=f"{config.INSTITUTION_NAME}: test message from CampusPilot. Parent alerts are working.")
    db.add(msg)
    log_audit(db, current_user, "Test message queued", mobile[:4] + "…")
    db.commit()
    return msg.to_dict()


@router.post("/messages/{message_id}/retry")
def retry_message(message_id: str, db: Session = Depends(get_db), current_user=Depends(admin_only)):
    m = db.get(OutboundMessage, parse_pk(message_id, "msg"))
    if not m:
        raise HTTPException(status_code=404, detail="Message not found")
    if m.status in ("failed", "skipped") and normalize_phone(m.phone):
        m.status, m.attempts, m.error = "queued", 0, None
        db.commit()
    return m.to_dict()
