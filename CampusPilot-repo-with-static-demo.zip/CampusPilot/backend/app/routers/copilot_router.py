from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.ai.copilot import detect_intent
from app.auth.auth import require_role
from app.common import attendance_stats, compute_risk_score, score_stats
from app.database.db import get_db
from app.models.models import Fee, Grievance, Placement, PlacementApplication
from app.schemas.copilot_schema import CopilotChat, CopilotQuestion
from app.ai import copilot_llm
from app.auth.auth import get_current_user
from app.security import SlidingWindowLimiter
from fastapi import HTTPException

router = APIRouter(prefix="/copilot", tags=["copilot"])
student_only = require_role(["student"])
chat_limiter = SlidingWindowLimiter(12, 60)


@router.get("/status")
def copilot_status(current_user=Depends(get_current_user)):
    """Whether the AI copilot is configured (otherwise the app uses its built-in assistant)."""
    return copilot_llm.status()


@router.post("/chat")
def copilot_chat(data: CopilotChat, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    """AI copilot for every role. Reads data only through role-scoped tools as
    the signed-in user; actions come back as proposals the user must confirm."""
    if current_user["role"] not in ("student", "teacher", "admin"):
        raise HTTPException(status_code=403, detail="The copilot isn't available for this account type.")
    if not copilot_llm.enabled():
        return {"mode": "offline"}
    chat_limiter.check(f"u{current_user['user_id']}", "You're sending messages too quickly — wait a few seconds.")
    history = [t.model_dump() for t in data.history]
    # Conversations must alternate user/assistant and start with the user.
    while history and history[0]["role"] != "user":
        history.pop(0)
    clean = []
    for t in history:
        if clean and clean[-1]["role"] == t["role"]:
            clean[-1] = t
        else:
            clean.append(t)
    if clean and clean[-1]["role"] == "user":
        clean.pop()
    try:
        return {"mode": "ai", **copilot_llm.chat(db, current_user, clean, data.question)}
    except copilot_llm.CopilotError as e:
        raise HTTPException(status_code=503, detail=str(e))


@router.post("/ask")
def ask_copilot(data: CopilotQuestion, db: Session = Depends(get_db), current_user=Depends(student_only)):
    sid = current_user["user_id"]
    intent = detect_intent(data.question)
    att = attendance_stats(db, [sid]).get(sid, {})
    sc = score_stats(db, [sid]).get(sid, {})
    if intent == "attendance":
        if not att:
            return {"answer": "I couldn't find any attendance records for you yet."}
        return {"answer": f"Your attendance is {att['pct']}% ({att['present']} of {att['total']} classes)."}
    if intent == "risk":
        fee = db.query(Fee).filter(Fee.student_id == sid).first()
        r = compute_risk_score(att.get("pct"), sc.get("avgScore"), fee.status if fee else "unknown")
        return {"answer": f"Your current risk level is {r['riskLevel']} (health score {r['healthScore']}). {'; '.join(r['reasons'])}."}
    if intent == "placement":
        applied = {a for (a,) in db.query(PlacementApplication.placement_id).filter(PlacementApplication.student_id == sid)}
        cgpa, pct = sc.get("cgpa") or 0, att.get("pct") or 0
        eligible = [p for p in db.query(Placement).filter(Placement.status == "open")
                    if p.id not in applied and cgpa >= p.min_cgpa and pct >= p.min_attendance]
        if not eligible:
            return {"answer": "There are no open drives you're eligible for that you haven't already applied to."}
        return {"answer": "You're eligible to apply for: " + "; ".join(f"{p.role} at {p.company}" for p in eligible[:5])}
    if intent == "grievance":
        gs = db.query(Grievance).filter(Grievance.raised_by_id == sid).all()
        if not gs:
            return {"answer": "You haven't submitted any grievances yet."}
        return {"answer": f"You have {len(gs)} grievance(s), {sum(g.status != 'resolved' for g in gs)} still open."}
    return {"answer": "I can help with your attendance, risk status, placement eligibility, or grievances."}
