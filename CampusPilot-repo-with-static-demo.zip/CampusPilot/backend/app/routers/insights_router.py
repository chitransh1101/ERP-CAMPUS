"""
Analytics for the principal (admin) and heads of department, and the
NAAC / NBA accreditation data report.

HODs are assigned by an admin (DepartmentHead table) and only ever see
their own department.
"""
from collections import defaultdict
from datetime import date, datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import case, func
from sqlalchemy.orm import Session

from app import documents
from app.auth.auth import get_current_user, require_role
from app.common import attendance_stats, cohort_risk, score_stats
from app.database.db import get_db
from app.models.models import (
    AttendanceRecord, AttendanceSession, Course, DepartmentHead, Enrollment, Exam, ExamResult, Fee, GradeEntry,
    GradeRecord, Grievance, LibraryBook, LibraryRequest, Placement, PlacementApplication, User,
)
from app.routers.exams_router import pdf_response
from app.schemas.base import Id, In, Short
from typing import Optional
from pydantic import Field


class HodSet(In):
    dept: Short
    user_id: Optional[Id] = Field(default=None, alias="userId")

router = APIRouter(tags=["insights"])
admin_only = require_role(["admin"])
PRESENT_INT = case((AttendanceRecord.present.is_(True), 1), else_=0)


def _scope(db, cu, dept: str):
    """(dept or None for all, label). Admins pick any; HODs are pinned to their department."""
    if cu["role"] == "admin":
        return (dept or None), (dept or "Whole campus")
    if cu["role"] == "teacher":
        head = db.query(DepartmentHead).filter(DepartmentHead.user_id == cu["user_id"]).first()
        if head:
            return head.dept, f"{head.dept} department"
    raise HTTPException(status_code=403, detail="Analytics are available to the principal/admin and heads of department.")


@router.get("/analytics/access")
def analytics_access(db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    if current_user["role"] == "admin":
        return {"allowed": True, "dept": None}
    head = db.query(DepartmentHead).filter(DepartmentHead.user_id == current_user["user_id"]).first() \
        if current_user["role"] == "teacher" else None
    return {"allowed": bool(head), "dept": head.dept if head else None}


def _pct(a, b):
    return round(a / b * 100) if b else 0


def build_analytics(db, dept=None) -> dict:
    sq = db.query(User).filter(User.role == "student", User.status == "active")
    cq = db.query(Course)
    if dept:
        sq, cq = sq.filter(User.department == dept), cq.filter(Course.dept == dept)
    students, courses = sq.all(), cq.order_by(Course.code).all()
    sids, cids = [s.id for s in students], [c.id for c in courses]
    risk = cohort_risk(db, students)
    sc = score_stats(db, sids)
    fees = {f.student_id: f for f in db.query(Fee).filter(Fee.student_id.in_(sids or [-1]))}

    # ---- per department
    by_dept = defaultdict(list)
    for s in students:
        by_dept[s.department or "—"].append(s)
    risk_by_id = {r["id"]: r for r in risk}
    dept_att = dict((d, (int(p or 0), int(t))) for d, t, p in
                    db.query(Course.dept, func.count(AttendanceRecord.id), func.sum(PRESENT_INT))
                    .join(AttendanceSession, AttendanceSession.course_id == Course.id)
                    .join(AttendanceRecord, AttendanceRecord.session_id == AttendanceSession.id)
                    .filter(Course.id.in_(cids or [-1])).group_by(Course.dept))
    departments = []
    for d, members in sorted(by_dept.items()):
        scores = [sc[s.id]["avgScore"] for s in members if s.id in sc]
        billed = sum(fees[s.id].total for s in members if s.id in fees)
        paid = sum(fees[s.id].paid for s in members if s.id in fees)
        p, t = dept_att.get(d, (0, 0))
        departments.append({"dept": d, "students": len(members), "attendance": _pct(p, t),
                            "avgScore": round(sum(scores) / len(scores), 1) if scores else 0,
                            "passRate": _pct(sum(1 for x in scores if x >= 40), len(scores)),
                            "atRisk": sum(1 for s in members if risk_by_id.get(f"u_{s.id}", {}).get("riskLevel") == "high"),
                            "feeCollectedPct": _pct(paid, billed)})

    # ---- per course
    c_att = dict((cid, (int(p or 0), int(t))) for cid, t, p in
                 db.query(AttendanceSession.course_id, func.count(AttendanceRecord.id), func.sum(PRESENT_INT))
                 .join(AttendanceRecord, AttendanceRecord.session_id == AttendanceSession.id)
                 .filter(AttendanceSession.course_id.in_(cids or [-1])).group_by(AttendanceSession.course_id))
    c_scores = defaultdict(list)
    for cid, sid, avg in (db.query(GradeRecord.course_id, GradeEntry.student_id, func.avg(GradeEntry.score))
                          .join(GradeEntry, GradeEntry.grade_id == GradeRecord.id)
                          .filter(GradeRecord.course_id.in_(cids or [-1])).group_by(GradeRecord.course_id, GradeEntry.student_id)):
        c_scores[cid].append(float(avg))
    enrolled = dict(db.query(Enrollment.course_id, func.count(Enrollment.id)).filter(Enrollment.course_id.in_(cids or [-1]))
                    .group_by(Enrollment.course_id).all())
    course_rows = []
    for c in courses:
        p, t = c_att.get(c.id, (0, 0))
        s = c_scores.get(c.id, [])
        course_rows.append({"id": f"c_{c.id}", "code": c.code, "name": c.name, "dept": c.dept, "faculty": c.faculty,
                            "students": enrolled.get(c.id, 0), "attendance": _pct(p, t),
                            "avgScore": round(sum(s) / len(s), 1) if s else 0, "passRate": _pct(sum(1 for x in s if x >= 40), len(s))})

    # ---- weekly trend per department + course x week heat-map (last 8 weeks)
    since = (date.today() - timedelta(weeks=8)).isoformat()
    week_keys, trend, heat = [], defaultdict(lambda: defaultdict(lambda: [0, 0])), defaultdict(lambda: defaultdict(lambda: [0, 0]))
    weekday = defaultdict(lambda: defaultdict(lambda: [0, 0]))
    rows = (db.query(Course.dept, Course.id, AttendanceSession.date, func.count(AttendanceRecord.id), func.sum(PRESENT_INT))
            .join(AttendanceSession, AttendanceSession.course_id == Course.id)
            .join(AttendanceRecord, AttendanceRecord.session_id == AttendanceSession.id)
            .filter(Course.id.in_(cids or [-1]), AttendanceSession.date >= since)
            .group_by(Course.dept, Course.id, AttendanceSession.date).all())
    for d, cid, day, t, p in rows:
        dd = date.fromisoformat(day)
        wk = (dd - timedelta(days=dd.weekday())).isoformat()   # Monday of that week
        for bucket in (trend[d][wk], heat[cid][wk], weekday[d][dd.strftime("%a")]):
            bucket[0] += int(p or 0)
            bucket[1] += int(t)
    week_keys = sorted({wk for d in trend.values() for wk in d})[-8:]
    labels = [date.fromisoformat(w).strftime("%d %b") for w in week_keys]
    trend_out = [{"dept": d, "values": [_pct(*trend[d][w]) if trend[d][w][1] else None for w in week_keys]} for d in sorted(trend)]
    code_of = {c.id: c for c in courses}
    heat_out = [{"label": f"{code_of[cid].code}", "name": code_of[cid].name,
                 "values": [_pct(*heat[cid][w]) if heat[cid][w][1] else None for w in week_keys]}
                for cid in sorted(heat, key=lambda i: code_of[i].code)]
    days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
    weekday_out = [{"label": d, "values": [_pct(*weekday[d][x]) if weekday[d][x][1] else None for x in days]} for d in sorted(weekday)]

    at_risk = sorted([r for r in risk if r["riskLevel"] in ("high", "medium")], key=lambda r: r["healthScore"])
    total_p = sum(p for p, _ in dept_att.values())
    total_t = sum(t for _, t in dept_att.values())
    all_scores = [v["avgScore"] for v in sc.values()]
    billed = sum(f.total for f in fees.values())
    paid = sum(f.paid for f in fees.values())
    return {
        "scope": dept or "all",
        "kpis": {"students": len(students), "courses": len(courses), "avgAttendance": _pct(total_p, total_t),
                 "passRate": _pct(sum(1 for x in all_scores if x >= 40), len(all_scores)),
                 "atRisk": sum(1 for r in risk if r["riskLevel"] == "high"), "feeCollectedPct": _pct(paid, billed),
                 "below75": sum(1 for r in risk if r["attendancePct"] is not None and r["attendancePct"] < 75)},
        "departments": departments, "courses": course_rows,
        "weeks": labels, "trend": trend_out, "heatmap": heat_out, "weekdayDays": days, "weekdayHeatmap": weekday_out,
        "atRiskStudents": at_risk[:60],
        "deptOptions": sorted({d for (d,) in db.query(Course.dept).distinct() if d}),
    }


@router.get("/analytics")
def analytics(dept: str = Query("", max_length=120), db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    scope, _ = _scope(db, current_user, dept)
    return build_analytics(db, scope)


@router.get("/analytics/report.pdf")
def analytics_pdf(dept: str = Query("", max_length=120), db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    scope, label = _scope(db, current_user, dept)
    return pdf_response(documents.analytics_pdf(build_analytics(db, scope), label),
                        f"analytics-{(scope or 'campus').lower().replace(' ', '-').replace('&', 'and')}.pdf")


# ============================================================ HOD admin
@router.get("/admin/department-heads")
def department_heads(db: Session = Depends(get_db), current_user=Depends(admin_only)):
    heads = {h.dept: h for h in db.query(DepartmentHead)}
    depts = sorted({d for (d,) in db.query(Course.dept).distinct() if d} |
                   {d for (d,) in db.query(User.department).filter(User.role == "teacher").distinct() if d})
    out = []
    for d in depts:
        h = heads.get(d)
        u = db.get(User, h.user_id) if h else None
        out.append({"dept": d, "userId": f"u_{u.id}" if u else None, "name": u.name if u else None})
    return out


@router.put("/admin/department-heads")
def set_department_head(payload: HodSet, db: Session = Depends(get_db), current_user=Depends(admin_only)):
    from app.common import log_audit, notify_users, parse_pk
    dept = payload.dept.strip()
    if not dept:
        raise HTTPException(status_code=400, detail="Pick a department.")
    head = db.query(DepartmentHead).filter(DepartmentHead.dept == dept).first()
    ref = payload.user_id
    if not ref:
        if head:
            db.delete(head)
        log_audit(db, current_user, "HOD removed", dept)
        db.commit()
        return {"dept": dept, "userId": None}
    u = db.get(User, parse_pk(str(ref), "u"))
    if not u or u.role != "teacher" or u.status != "active":
        raise HTTPException(status_code=400, detail="The head of department must be an active faculty member.")
    db.query(DepartmentHead).filter(DepartmentHead.user_id == u.id, DepartmentHead.dept != dept).delete()
    if head:
        head.user_id = u.id
    else:
        db.add(DepartmentHead(dept=dept, user_id=u.id))
    log_audit(db, current_user, "HOD assigned", f"{u.name} → {dept}")
    notify_users(db, [u.id], "You're now Head of Department", f"You can now see analytics for {dept} under “Department Analytics”.")
    db.commit()
    return {"dept": dept, "userId": f"u_{u.id}", "name": u.name}


# ======================================================= accreditation
def _academic_year():
    y = date.today().year
    return f"{y}-{str(y + 1)[-2:]}" if date.today().month >= 6 else f"{y - 1}-{str(y)[-2:]}"


def attainment_level(pct_students: float) -> int:
    """Common NBA practice: % of students reaching the target mark -> level 3/2/1."""
    return 3 if pct_students >= 70 else 2 if pct_students >= 60 else 1 if pct_students >= 50 else 0


def build_accreditation(db, target: int = 60) -> dict:
    students = db.query(User).filter(User.role == "student", User.status == "active").all()
    teachers = db.query(User).filter(User.role == "teacher", User.status == "active").all()
    courses = db.query(Course).order_by(Course.code).all()
    sections = []

    # ---------------- Criterion 2
    dept_s, dept_t = defaultdict(int), defaultdict(int)
    for s in students:
        dept_s[s.department or "—"] += 1
    for t in teachers:
        dept_t[t.department or "—"] += 1
    ratio_rows = [[d, dept_s[d], dept_t[d], f"{round(dept_s[d] / dept_t[d], 1)} : 1" if dept_t[d] else "—"]
                  for d in sorted(set(dept_s) | set(dept_t))]
    ratio_rows.append(["All departments", len(students), len(teachers),
                       f"{round(len(students) / len(teachers), 1)} : 1" if teachers else "—"])
    att = dict((cid, (int(p or 0), int(t), int(n))) for cid, t, p, n in
               db.query(AttendanceSession.course_id, func.count(AttendanceRecord.id), func.sum(PRESENT_INT),
                        func.count(func.distinct(AttendanceSession.id)))
               .join(AttendanceRecord, AttendanceRecord.session_id == AttendanceSession.id).group_by(AttendanceSession.course_id))
    att_rows = [[f"{c.code} {c.name}", c.faculty, att.get(c.id, (0, 0, 0))[2], f"{_pct(*att.get(c.id, (0, 0, 0))[:2])}%"] for c in courses]

    # pass % and CO attainment: prefer published exam results, else sessional marks
    exam_pct = defaultdict(dict)   # course -> student -> pct
    exam_obt = defaultdict(lambda: defaultdict(lambda: [0.0, 0.0]))
    for e, r in (db.query(Exam, ExamResult).join(ExamResult, ExamResult.exam_id == Exam.id).filter(Exam.results_published.is_(True))):
        b = exam_obt[e.course_id][r.student_id]
        b[0] += 0 if r.absent else (r.marks or 0)
        b[1] += e.max_marks
    for cid, per in exam_obt.items():
        for sid, (o, m) in per.items():
            exam_pct[cid][sid] = o / m * 100 if m else 0
    sessional = defaultdict(dict)
    for cid, sid, avg in (db.query(GradeRecord.course_id, GradeEntry.student_id, func.avg(GradeEntry.score))
                          .join(GradeEntry, GradeEntry.grade_id == GradeRecord.id).group_by(GradeRecord.course_id, GradeEntry.student_id)):
        sessional[cid][sid] = float(avg)
    pass_rows, co_rows = [], []
    for c in courses:
        src, data = ("End/Mid-sem exams", exam_pct[c.id]) if exam_pct.get(c.id) else ("Sessional marks", sessional.get(c.id, {}))
        vals = list(data.values())
        if not vals:
            continue
        passed = sum(1 for v in vals if v >= 40)
        pass_rows.append([f"{c.code} {c.name}", len(vals), passed, f"{_pct(passed, len(vals))}%", src])
        reached = _pct(sum(1 for v in vals if v >= target), len(vals))
        co_rows.append([f"{c.code} {c.name}", len(vals), f"{reached}%", attainment_level(reached), src])
    sections.append({"key": "c2", "title": "Criterion 2 — Teaching-Learning and Evaluation", "tables": [
        {"key": "ratio", "title": "Student enrolment and student–teacher ratio", "columns": ["Department", "Students", "Full-time faculty", "Student : teacher"], "rows": ratio_rows},
        {"key": "attendance", "title": "Course-wise classes held and attendance", "columns": ["Course", "Faculty", "Classes held", "Average attendance"], "rows": att_rows},
        {"key": "pass", "title": "Pass percentage by course", "columns": ["Course", "Students appeared", "Passed (40%+)", "Pass %", "Source"], "rows": pass_rows},
    ]})

    # ---------------- Criterion 4
    cat = defaultdict(lambda: [0, 0])
    for b in db.query(LibraryBook):
        cat[b.category or "General"][0] += 1
        cat[b.category or "General"][1] += b.copies or 0
    usage = dict(db.query(LibraryRequest.status, func.count(LibraryRequest.id)).group_by(LibraryRequest.status).all())
    sections.append({"key": "c4", "title": "Criterion 4 — Infrastructure and Learning Resources", "tables": [
        {"key": "library", "title": "Library holdings by subject", "columns": ["Subject", "Titles", "Copies available"],
         "rows": [[k, v[0], v[1]] for k, v in sorted(cat.items())]},
        {"key": "libuse", "title": "Library usage (requests through CampusPilot)", "columns": ["Status", "Requests"],
         "rows": [[k, v] for k, v in sorted(usage.items())]},
    ]})

    # ---------------- Criterion 5
    drives = db.query(Placement).all()
    apps = db.query(PlacementApplication).all()
    selected = {a.student_id for a in apps if a.status == "selected"}
    final_year = [s for s in students if (s.year or 0) >= 4]
    placement_rows = [["Placement drives conducted", len(drives)], ["Applications received", len(apps)],
                      ["Students selected", len(selected)], ["Final-year students", len(final_year)],
                      ["Final-year students placed", f"{_pct(len(selected & {s.id for s in final_year}), len(final_year))}%"]]
    g_rows = []
    by_cat = defaultdict(list)
    for g in db.query(Grievance):
        by_cat[g.category or "Other"].append(g)
    for k, gs in sorted(by_cat.items()):
        res = [g for g in gs if g.status == "resolved"]
        days = [max(0, (g.updated_at - g.ts).days) for g in res if g.updated_at and g.ts]
        g_rows.append([k, len(gs), len(res), len(gs) - len(res), round(sum(days) / len(days), 1) if days else "—"])
    sections.append({"key": "c5", "title": "Criterion 5 — Student Support and Progression", "tables": [
        {"key": "placement", "title": "Placement", "columns": ["Measure", "Value"], "rows": placement_rows},
        {"key": "grievance", "title": "Grievance redressal", "columns": ["Category", "Received", "Resolved", "Pending", "Avg. days to resolve"], "rows": g_rows},
    ]})

    # ---------------- Criterion 6
    n_fees = db.query(func.count(Fee.id)).scalar()
    n_exams = db.query(func.count(Exam.id)).scalar()
    sections.append({"key": "c6", "title": "Criterion 6 — Governance, Leadership and Management", "tables": [
        {"key": "egov", "title": "e-Governance: areas run through CampusPilot", "columns": ["Area", "Module", "Records"], "rows": [
            ["Administration", "Users, roles, audit log", len(students) + len(teachers)],
            ["Finance and Accounts", "Fee billing and collection", n_fees],
            ["Student Admission and Support", "Grievances, placements, parent portal", len(apps) + sum(len(v) for v in by_cat.values())],
            ["Examination", "Exam timetable, hall tickets, results", n_exams],
        ]},
    ]})

    # ---------------- NBA
    sections.append({"key": "nba", "title": "NBA — Course outcome attainment (direct method)",
                     "note": f"Target: {target}% marks. Attainment level 3 = 70%+ of students reach the target, 2 = 60%+, 1 = 50%+. "
                             "Map each course's outcomes (COs) to programme outcomes (POs) in your SAR using these levels.",
                     "tables": [{"key": "co", "title": "Course attainment levels", "columns": ["Course", "Students assessed",
                                 f"Students scoring {target}%+", "Attainment level", "Source"], "rows": co_rows}]})
    return {"academicYear": _academic_year(), "generatedAt": datetime.utcnow().isoformat(), "target": target, "sections": sections}


@router.get("/admin/accreditation")
def accreditation(target: int = Query(60, ge=30, le=90), db: Session = Depends(get_db), current_user=Depends(admin_only)):
    return build_accreditation(db, target)


@router.get("/admin/accreditation/report.pdf")
def accreditation_pdf(target: int = Query(60, ge=30, le=90), db: Session = Depends(get_db), current_user=Depends(admin_only)):
    rep = build_accreditation(db, target)
    return pdf_response(documents.accreditation_pdf(rep), f"accreditation-data-{rep['academicYear']}.pdf")
