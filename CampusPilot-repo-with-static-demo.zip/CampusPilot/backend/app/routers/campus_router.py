"""
Academic calendar, ID cards / certificates, and the public QR verification
endpoint used by every printed document.
"""
import re
from datetime import date, datetime, timedelta
from typing import Literal, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import Field
from sqlalchemy.orm import Session

from app import documents
from app.auth.auth import get_current_user, require_role
from app.common import log_audit, notify_role, parse_pk
from app.database.db import get_db
from app.models.models import (
    Assignment, CalendarEvent, Course, Enrollment, Exam, Fee, IssuedDocument, ParentLink, User, ms,
)
from app.routers.exams_router import pdf_response
from app.schemas.base import In, IsoDate, Short, Text
from app.security import SlidingWindowLimiter, client_ip

router = APIRouter(tags=["campus"])
admin_only = require_role(["admin"])
verify_limiter = SlidingWindowLimiter(limit=30, window=60)
MONTHS = {m: i for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}


class EventCreate(In):
    title: Short
    date: IsoDate
    end_date: Optional[IsoDate] = Field(default=None, alias="endDate")
    kind: Literal["holiday", "event", "exam-week", "deadline"] = "event"
    description: Optional[Text] = None


class BonafideRequest(In):
    purpose: str = Field(min_length=3, max_length=120)


# ================================================================ calendar
def _parse_due(due: str):
    """Assignment 'due' is free text like '05 Oct'; best-effort to a date in the current academic year."""
    m = re.match(r"^\s*(\d{1,2})\s+([A-Za-z]{3})", due or "")
    if not m or m.group(2).lower() not in MONTHS:
        return None
    today = date.today()
    try:
        d = date(today.year, MONTHS[m.group(2).lower()], int(m.group(1)))
    except ValueError:
        return None
    if (d - today).days < -180:
        d = d.replace(year=today.year + 1)
    return d


def _course_ids_for(db, cu, student_ref=None):
    """Which courses' exams/deadlines this viewer should see (None = all)."""
    role = cu["role"]
    if role == "admin":
        return None, None
    if role == "teacher":
        return [c for (c,) in db.query(Course.id).filter(Course.faculty_id == cu["user_id"])], None
    sid = cu["user_id"]
    if role == "parent":
        if not student_ref:
            return [], None
        sid = parse_pk(student_ref, "u")
        if not db.query(ParentLink.id).filter_by(parent_id=cu["user_id"], student_id=sid).first():
            raise HTTPException(status_code=404, detail="Student not found among your children.")
    return [c for (c,) in db.query(Enrollment.course_id).filter(Enrollment.student_id == sid)], sid


@router.get("/calendar")
def calendar(month: str = Query(..., pattern=r"^\d{4}-\d{2}$"), student_id: str = Query("", alias="studentId", max_length=20),
             db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    y, m = map(int, month.split("-"))
    if not (2000 <= y <= 2100 and 1 <= m <= 12):
        raise HTTPException(status_code=400, detail="Invalid month")
    first = date(y, m, 1)
    last = (first.replace(day=28) + timedelta(days=4)).replace(day=1) - timedelta(days=1)
    lo, hi = first.isoformat(), last.isoformat()
    items = [e.to_dict() for e in db.query(CalendarEvent).filter(CalendarEvent.date <= hi)
             .filter((CalendarEvent.end_date >= lo) | ((CalendarEvent.end_date.is_(None)) & (CalendarEvent.date >= lo)))
             .order_by(CalendarEvent.date)]
    cids, sid = _course_ids_for(db, current_user, student_id or None)
    eq = db.query(Exam).filter(Exam.date >= lo, Exam.date <= hi)
    if cids is not None:
        eq = eq.filter(Exam.course_id.in_(cids or [-1]))
    for e in eq.order_by(Exam.date, Exam.start_time):
        items.append({"id": f"ex_{e.id}", "title": f"{e.course.code if e.course else ''} {e.title}", "date": e.date,
                      "endDate": e.date, "kind": "exam", "source": "exam",
                      "description": f"{e.start_time} · {e.duration_min} min{' · ' + e.room if e.room else ''}"})
    if current_user["role"] != "admin":
        aq = db.query(Assignment)
        if cids is not None:
            aq = aq.filter(Assignment.course_id.in_(cids or [-1]))
        for a in aq:
            d = _parse_due(a.due)
            if d and first <= d <= last:
                items.append({"id": f"a_{a.id}", "title": f"Due: {a.title}", "date": d.isoformat(), "endDate": d.isoformat(),
                              "kind": "deadline", "source": "assignment", "description": a.course or ""})
    if sid:
        fee = db.query(Fee).filter(Fee.student_id == sid).first()
        if fee and fee.paid < fee.total and fee.due_date and lo <= fee.due_date[:10] <= hi:
            items.append({"id": f"f_{fee.id}", "title": f"Fee due (Rs. {fee.total - fee.paid:,.0f})", "date": fee.due_date[:10],
                          "endDate": fee.due_date[:10], "kind": "deadline", "source": "fee", "description": ""})
    items.sort(key=lambda x: (x["date"], x["kind"] != "holiday"))
    return {"month": month, "items": items}


@router.post("/admin/calendar")
def add_event(payload: EventCreate, db: Session = Depends(get_db), current_user=Depends(admin_only)):
    if payload.end_date and payload.end_date < payload.date:
        raise HTTPException(status_code=400, detail="The end date is before the start date.")
    ev = CalendarEvent(title=payload.title, date=payload.date, end_date=payload.end_date, kind=payload.kind,
                       description=payload.description, created_by=current_user["user_id"])
    db.add(ev)
    db.flush()
    log_audit(db, current_user, "Calendar event added", f"{ev.title} · {ev.date}")
    if payload.kind in ("holiday", "exam-week"):
        when = documents.fmt_date(ev.date) + (f" to {documents.fmt_date(ev.end_date)}" if ev.end_date and ev.end_date != ev.date else "")
        for role in ("student", "teacher", "parent"):
            notify_role(db, role, "Holiday announced" if payload.kind == "holiday" else "Exam week announced", f"{ev.title}: {when}.")
    db.commit()
    return ev.to_dict()


@router.delete("/admin/calendar/{event_id}")
def delete_event(event_id: str, db: Session = Depends(get_db), current_user=Depends(admin_only)):
    ev = db.get(CalendarEvent, parse_pk(event_id, "ev"))
    if not ev:
        raise HTTPException(status_code=404, detail="Event not found")
    log_audit(db, current_user, "Calendar event removed", f"{ev.title} · {ev.date}")
    db.delete(ev)
    db.commit()
    return {"ok": True}


# =============================================================== documents
@router.get("/documents/id-card.pdf")
def id_card(db: Session = Depends(get_db), current_user=Depends(require_role(["student", "teacher", "admin"]))):
    me = current_user.user
    today = date.today()
    valid = date(today.year + 1 if today.month >= 6 else today.year, 5, 31).strftime("%b %Y")
    if me.role == "student":
        extra = {"Roll No.": me.id_label or "—", "Department": me.department or "—",
                 "Year / Sec.": f"{me.year or '—'} / {me.section or '—'}", "Valid till": valid}
        label = "Student"
    else:
        extra = {"Staff ID": me.id_label or "—", "Department": me.department or "Administration",
                 "Designation": me.designation or ("Administrator" if me.role == "admin" else "Faculty"), "Valid till": valid}
        label = "Staff"
    db.add(IssuedDocument(user_id=me.id, kind="id-card"))
    db.commit()
    return pdf_response(documents.id_card_pdf(me, label, extra), f"id-card-{me.id_label or me.id}.pdf")


@router.post("/documents/bonafide")
def bonafide(payload: BonafideRequest, db: Session = Depends(get_db), current_user=Depends(require_role(["student"]))):
    me = current_user.user
    doc = IssuedDocument(user_id=me.id, kind="bonafide", purpose=payload.purpose)
    db.add(doc)
    db.flush()
    ref = f"CP/BON/{date.today().year}/{doc.id:05d}"
    log_audit(db, me, "Bonafide certificate issued", f"{ref} · {payload.purpose}")
    db.commit()
    return pdf_response(documents.bonafide_pdf(me, ref, payload.purpose, doc.id), f"bonafide-{me.id_label or me.id}.pdf")


@router.get("/documents/mine")
def my_documents(db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    rows = (db.query(IssuedDocument).filter(IssuedDocument.user_id == current_user["user_id"])
            .order_by(IssuedDocument.ts.desc()).limit(50).all())
    return [{"id": f"doc_{d.id}", "kind": d.kind, "purpose": d.purpose or "", "ts": ms(d.ts),
             "ref": f"CP/BON/{d.ts.year}/{d.id:05d}" if d.kind == "bonafide" else None} for d in rows]


# ============================================================ verification
KIND_LABELS = {"id": "Identity card", "hallticket": "Hall ticket", "gradecard": "Grade card", "bonafide": "Bonafide certificate"}


@router.get("/verify/{token}")
def verify(token: str, request: Request, db: Session = Depends(get_db)):
    """Public: confirms a printed document is genuine. Shows only minimal details."""
    verify_limiter.check(f"v:{client_ip(request)}")
    data = documents.read_token(token[:400])
    if not data or data.get("k") not in KIND_LABELS:
        return {"valid": False, "reason": "This QR code was not issued by CampusPilot, or it has been altered."}
    user = db.get(User, int(data["u"])) if str(data["u"]).isdigit() else None
    if not user:
        return {"valid": False, "reason": "The person on this document is no longer on record."}
    out = {"valid": user.status == "active", "document": KIND_LABELS[data["k"]], "name": user.name,
           "idLabel": user.id_label, "role": {"student": "Student", "teacher": "Faculty", "admin": "Staff"}.get(user.role, user.role),
           "department": user.department, "issuedAt": int(data.get("t", 0)) * 1000,
           "institution": documents.config.INSTITUTION_NAME}
    if user.status != "active":
        out["reason"] = "This account is no longer active at the institute."
    if data["k"] == "bonafide":
        doc = db.get(IssuedDocument, int(data.get("r") or 0))
        if not doc or doc.user_id != user.id or doc.kind != "bonafide":
            return {"valid": False, "reason": "No matching certificate is on record."}
        out["reference"] = f"CP/BON/{doc.ts.year}/{doc.id:05d}"
        out["purpose"] = doc.purpose
    return out
