from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.auth.auth import get_current_user, require_role
from app.common import attendance_stats, log_audit, notify_role, notify_users, parse_pk, score_stats
from app.database.db import get_db
from app.models.models import Placement, PlacementApplication
from app.realtime import queue_event
from app.schemas.placement_schema import ApplicationStatusUpdate, PlacementCreate, PlacementStatusUpdate

router = APIRouter(prefix="/placements", tags=["placements"])
admin_only = require_role(["admin"])
student_only = require_role(["student"])


def student_eligibility(db, sid):
    att = attendance_stats(db, [sid]).get(sid, {})
    sc = score_stats(db, [sid]).get(sid, {})
    return (sc.get("cgpa") or 0.0), (att.get("pct") or 0.0)


def _eligible(p, cgpa, att):
    reasons = []
    if cgpa < p.min_cgpa:
        reasons.append(f"CGPA {cgpa:.2f} < {p.min_cgpa}")
    if att < p.min_attendance:
        reasons.append(f"attendance {att:.0f}% < {p.min_attendance:.0f}%")
    return not reasons, reasons


@router.get("/")
def list_placements(db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    rows = db.query(Placement).order_by(Placement.status.desc(), Placement.ts.desc()).all()
    counts = dict(db.query(PlacementApplication.placement_id, func.count(PlacementApplication.id)).group_by(PlacementApplication.placement_id).all())
    if current_user["role"] == "student":
        cgpa, att = student_eligibility(db, current_user["user_id"])
        out = []
        for p in rows:
            ok, reasons = _eligible(p, cgpa, att)
            out.append({**p.to_dict(), "eligible": ok, "ineligibleReasons": reasons})
        return out
    return [{**p.to_dict(), "applicants": counts.get(p.id, 0)} for p in rows]


@router.get("/eligibility")
def my_eligibility(db: Session = Depends(get_db), current_user=Depends(student_only)):
    cgpa, att = student_eligibility(db, current_user["user_id"])
    return {"cgpa": cgpa, "attendancePct": round(att, 1)}


@router.post("/")
def create_placement(payload: PlacementCreate, db: Session = Depends(get_db), current_user=Depends(admin_only)):
    p = Placement(company=payload.company, role=payload.role, package=payload.package, location=payload.location,
                  min_cgpa=payload.min_cgpa, min_attendance=payload.min_attendance, deadline=payload.deadline,
                  posted_by=current_user["name"], status="open")
    db.add(p)
    db.flush()
    log_audit(db, current_user, "Placement posted", f"{p.company} — {p.role}")
    notify_role(db, "student", "New placement drive", f"{p.company} is hiring for {p.role} (min CGPA {p.min_cgpa}).")
    queue_event(db, "placement:new", p.to_dict(), roles=["student", "admin"])
    db.commit()
    return p.to_dict()


@router.patch("/{placement_id}/status")
def set_placement_status(placement_id: str, payload: PlacementStatusUpdate, db: Session = Depends(get_db), current_user=Depends(admin_only)):
    p = db.get(Placement, parse_pk(placement_id, "pl"))
    if not p:
        raise HTTPException(status_code=404, detail="Posting not found")
    p.status = payload.status
    log_audit(db, current_user, f"Placement {payload.status}", f"{p.company} — {p.role}")
    queue_event(db, "placement:new", p.to_dict(), roles=["student", "admin"])
    db.commit()
    return p.to_dict()


@router.post("/{placement_id}/apply")
def apply(placement_id: str, db: Session = Depends(get_db), current_user=Depends(student_only)):
    me = current_user.user
    posting = db.get(Placement, parse_pk(placement_id, "pl"))
    if not posting:
        raise HTTPException(status_code=404, detail="This posting is no longer available.")
    if posting.status != "open":
        raise HTTPException(status_code=400, detail="Applications for this drive are closed.")
    # Eligibility is enforced HERE, from real records — the old version only
    # greyed out the button in the browser, so anyone could apply via the API.
    cgpa, att = student_eligibility(db, me.id)
    ok, reasons = _eligible(posting, cgpa, att)
    if not ok:
        raise HTTPException(status_code=403, detail="You're not eligible for this drive: " + "; ".join(reasons) + ".")
    if db.query(PlacementApplication.id).filter_by(placement_id=posting.id, student_id=me.id).first():
        raise HTTPException(status_code=400, detail="You've already applied to this posting.")
    app_ = PlacementApplication(placement_id=posting.id, student_id=me.id, student_name=me.name, id_label=me.id_label,
                                cgpa_at_apply=cgpa, attendance_at_apply=round(att, 1), status="applied")
    db.add(app_)
    db.flush()
    log_audit(db, me, "Placement application submitted", f"{me.name} → {posting.company} ({posting.role})")
    notify_role(db, "admin", "New placement application", f"{me.name} applied to {posting.company}.")
    queue_event(db, "placement:application", app_.to_dict(), roles=["admin"], users=[me.id])
    db.commit()
    return app_.to_dict()


@router.get("/mine")
def my_applications(db: Session = Depends(get_db), current_user=Depends(student_only)):
    return [a.to_dict() for a in db.query(PlacementApplication).filter(PlacementApplication.student_id == current_user["user_id"])]


@router.get("/{placement_id}/applicants")
def list_applicants(placement_id: str, db: Session = Depends(get_db), current_user=Depends(admin_only)):
    pid = parse_pk(placement_id, "pl")
    return [a.to_dict() for a in db.query(PlacementApplication).filter(PlacementApplication.placement_id == pid).order_by(PlacementApplication.cgpa_at_apply.desc())]


@router.patch("/applications/{app_id}")
def set_application_status(app_id: str, payload: ApplicationStatusUpdate, db: Session = Depends(get_db), current_user=Depends(admin_only)):
    app_ = db.get(PlacementApplication, parse_pk(app_id, "papp"))
    if not app_:
        raise HTTPException(status_code=404, detail="Application not found")
    app_.status = payload.status
    posting = db.get(Placement, app_.placement_id)
    log_audit(db, current_user, "Application status updated", f"{app_.student_name} → {payload.status}")
    # Only the applicant hears about their own result (was broadcast to every student).
    notify_users(db, [app_.student_id], "Placement update", f'{posting.company if posting else "Your application"}: status changed to "{payload.status}".')
    queue_event(db, "placement:application", app_.to_dict(), users=[app_.student_id], roles=["admin"])
    db.commit()
    return app_.to_dict()
