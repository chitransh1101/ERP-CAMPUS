"""WebSocket endpoint for live updates.

Auth: the same httpOnly session cookie the REST API uses (browsers send it
on the WebSocket handshake). The Origin header is checked against the
allow-list to stop cross-site WebSocket hijacking.
"""
import asyncio

from fastapi import APIRouter, HTTPException, WebSocket, WebSocketDisconnect

from app import config
from app.auth.auth import authenticate_token
from app.database.db import SessionLocal
from app.realtime import manager

router = APIRouter()


def _origin_allowed(ws: WebSocket) -> bool:
    origin = ws.headers.get("origin")
    if not origin:
        return True  # non-browser client
    host = ws.headers.get("host", "")
    same_origin = origin.split("://", 1)[-1] == host
    return same_origin or origin in config.CORS_ORIGINS


def _auth(token):
    db = SessionLocal()
    try:
        user, sess = authenticate_token(db, token)
        return user.id, user.role, sess.jti
    finally:
        db.close()


@router.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    if not _origin_allowed(ws):
        await ws.close(code=4403)
        return
    token = ws.cookies.get(config.COOKIE_NAME)
    if not token:
        await ws.close(code=4401)
        return
    try:
        user_id, role, jti = await asyncio.get_running_loop().run_in_executor(None, _auth, token)
    except HTTPException:
        await ws.close(code=4401)
        return
    await ws.accept()
    await manager.connect(ws, user_id, role)
    try:
        await ws.send_json({"type": "hello", "data": {"userId": f"u_{user_id}", "role": role}})
        loop = asyncio.get_running_loop()
        last_check = loop.time()
        while True:
            # Clients only send pings. Re-validate the session every few
            # minutes so a revoked/expired session can't keep listening.
            try:
                msg = await asyncio.wait_for(ws.receive_text(), timeout=120)
                if len(msg) > 200:
                    break
                if msg == "ping":
                    await ws.send_text('{"type":"pong"}')
            except asyncio.TimeoutError:
                pass
            if loop.time() - last_check > 240:
                try:
                    await loop.run_in_executor(None, _auth, token)
                except HTTPException:
                    break
                last_check = loop.time()
    except WebSocketDisconnect:
        pass
    finally:
        manager.disconnect(ws, user_id)
        try:
            await ws.close()
        except Exception:
            pass
