"""
QR attendance.

The teacher opens a live check-in for a class. Their screen shows a QR code
and a 6-digit code that both change every QR_WINDOW_SECONDS (derived with
HMAC from a per-session secret, so they can't be predicted). Students either
scan the QR with their phone camera (it opens  <site>/checkin?s=..&t=..) or
type the code in the app. A photo of the QR forwarded to a friend stops
working within seconds. When the class is done the teacher publishes it like
any other attendance (checked-in = present, everyone else = absent).
"""
import hashlib
import hmac
import re
import secrets
import time
from datetime import date, datetime, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import Field
from sqlalchemy.orm import Session

from app import config, documents
from app.auth.auth import require_role
from app.common import enrolled_student_ids, log_audit, notify_users, parse_pk
from app.database.db import get_db
from app.models.models import Course, Enrollment, QrCheckin, QrSession, User
from app.realtime import queue_event
from app.routers.teacher_router import _label, _own_course, _publish_session, _roster
from app.schemas.base import Id, In, IsoDate
from app.security import SlidingWindowLimiter, client_ip

router = APIRouter(tags=["qr-attendance"])
teacher_only = require_role(["teacher"])
student_only = require_role(["student"])
checkin_limiter = SlidingWindowLimiter(limit=12, window=60)   # per student: stops guessing 6-digit codes
SESSION_HOURS = 2
ORIGIN_RE = re.compile(r"^https?://[A-Za-z0-9.\-]+(:\d{1,5})?$")


class QrStart(In):
    course_id: Id = Field(alias="courseId")
    date: Optional[IsoDate] = None


class QrMark(In):
    student_id: Id = Field(alias="studentId")
    present: bool


class CheckinRequest(In):
    s: Optional[str] = Field(default=None, max_length=40)
    t: Optional[str] = Field(default=None, max_length=20)
    code: Optional[str] = Field(default=None, max_length=10)
    device: Optional[str] = Field(default=None, max_length=80)


# ------------------------------------------------------------ rotating codes
def _window(ts=None) -> int:
    return int((ts or time.time()) // config.QR_WINDOW_SECONDS)


def token_for(secret: str, w: int) -> str:
    return hmac.new(secret.encode(), f"t:{w}".encode(), hashlib.sha256).hexdigest()[:10]


def code_for(secret: str, w: int) -> str:
    return f"{int(hmac.new(secret.encode(), f'c:{w}'.encode(), hashlib.sha256).hexdigest()[:8], 16) % 1_000_000:06d}"


def _valid(secret: str, value: str, fn, windows: int) -> bool:
    now = _window()
    return any(hmac.compare_digest(fn(secret, now - k), value) for k in range(windows))


# ----------------------------------------------------------------- teacher
def _session_or_404(db, sid: str, teacher_id: int) -> QrSession:
    s = db.get(QrSession, str(sid)[:40])
    if not s or s.teacher_id != teacher_id:
        raise HTTPException(status_code=404, detail="Check-in session not found")
    return s


def _is_live(s: QrSession) -> bool:
    return s.status == "open" and s.expires_at > datetime.utcnow()


def _session_view(db, s: QrSession, origin: str = None, with_code=True):
    course = db.get(Course, s.course_id)
    roster = _roster(db, s.course_id)
    checks = {c.student_id: c for c in db.query(QrCheckin).filter(QrCheckin.qr_session_id == s.id)}
    device_use = {}
    for c in checks.values():
        if c.device:
            device_use[c.device] = device_use.get(c.device, 0) + 1
    students = []
    for r in roster:
        sid = parse_pk(r["id"], "u")
        c = checks.get(sid)
        students.append({**r, "present": bool(c), "method": c.method if c else None, "ts": documents_ms(c.ts) if c else None,
                         "sharedDevice": bool(c and c.device and device_use.get(c.device, 0) > 1)})
    out = {"id": s.id, "courseId": f"c_{s.course_id}", "courseLabel": _label(course) if course else "", "date": s.date,
           "status": s.status if _is_live(s) or s.status != "open" else "expired",
           "expiresAt": documents_ms(s.expires_at), "windowSeconds": config.QR_WINDOW_SECONDS,
           "present": len(checks), "total": len(roster), "students": students}
    if with_code and _is_live(s):
        w = _window()
        base = origin if origin and ORIGIN_RE.match(origin) else config.PUBLIC_URL
        url = f"{base}/checkin?s={s.id}&t={token_for(s.secret, w)}"
        out.update({"code": code_for(s.secret, w), "url": url, "qr": documents.qr_matrix(url, "L"),
                    "refreshIn": round(config.QR_WINDOW_SECONDS - (time.time() % config.QR_WINDOW_SECONDS), 1)})
    return out


def documents_ms(dt):
    from app.models.models import ms
    return ms(dt)


@router.post("/teacher/qr-sessions")
def start_session(payload: QrStart, db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    me = current_user.user
    course = _own_course(db, payload.course_id, me.id)
    day = payload.date or date.today().isoformat()
    if day > date.today().isoformat():
        raise HTTPException(status_code=400, detail="Attendance can't be taken for a future date.")
    existing = (db.query(QrSession).filter(QrSession.teacher_id == me.id, QrSession.course_id == course.id,
                                           QrSession.status == "open", QrSession.expires_at > datetime.utcnow()).first())
    if existing:
        return _session_view(db, existing, with_code=False)
    s = QrSession(id=secrets.token_urlsafe(12), course_id=course.id, teacher_id=me.id, date=day,
                  secret=secrets.token_hex(32), expires_at=datetime.utcnow() + timedelta(hours=SESSION_HOURS))
    db.add(s)
    log_audit(db, me, "QR check-in opened", f"{_label(course)} · {day}")
    notify_users(db, enrolled_student_ids(db, course.id), "Attendance check-in is open",
                 f"Scan the QR code on the screen or enter the 6-digit code for {_label(course)}.")
    db.commit()
    return _session_view(db, s, with_code=False)


@router.get("/teacher/qr-sessions")
def open_sessions(db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    rows = (db.query(QrSession).filter(QrSession.teacher_id == current_user["user_id"], QrSession.status == "open",
                                       QrSession.expires_at > datetime.utcnow()).all())
    return [_session_view(db, s, with_code=False) for s in rows]


@router.get("/teacher/qr-sessions/{session_id}")
def session_live(session_id: str, origin: str = Query("", max_length=200), db: Session = Depends(get_db),
                 current_user=Depends(teacher_only)):
    return _session_view(db, _session_or_404(db, session_id, current_user["user_id"]), origin=origin)


@router.post("/teacher/qr-sessions/{session_id}/mark")
def teacher_mark(session_id: str, payload: QrMark, db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    s = _session_or_404(db, session_id, current_user["user_id"])
    if s.status != "open":
        raise HTTPException(status_code=400, detail="This check-in is already closed.")
    sid = parse_pk(payload.student_id, "u")
    if sid not in set(enrolled_student_ids(db, s.course_id)):
        raise HTTPException(status_code=400, detail="That student isn't enrolled in this course.")
    row = db.query(QrCheckin).filter_by(qr_session_id=s.id, student_id=sid).first()
    if payload.present and not row:
        db.add(QrCheckin(qr_session_id=s.id, student_id=sid, method="teacher"))
    elif not payload.present and row:
        db.delete(row)
    db.commit()
    return _session_view(db, s, with_code=False)


@router.post("/teacher/qr-sessions/{session_id}/publish")
def publish_session(session_id: str, db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    me = current_user.user
    s = _session_or_404(db, session_id, me.id)
    if s.status != "open":
        raise HTTPException(status_code=400, detail="This check-in was already published or cancelled.")
    course = _own_course(db, f"c_{s.course_id}", me.id)
    present = {c.student_id for c in db.query(QrCheckin).filter(QrCheckin.qr_session_id == s.id)}
    records = [(parse_pk(r["id"], "u"), parse_pk(r["id"], "u") in present, 100.0) for r in _roster(db, course.id)]
    if not records:
        raise HTTPException(status_code=400, detail="No students are enrolled in this course.")
    att = _publish_session(db, me, course, s.date, records, "qr")
    s.status, s.attendance_session_id = "published", att.id
    db.commit()
    return {"published": True, "present": sum(1 for _, p, _ in records if p), "total": len(records), "sessionId": f"att_{att.id}"}


@router.delete("/teacher/qr-sessions/{session_id}")
def cancel_session(session_id: str, db: Session = Depends(get_db), current_user=Depends(teacher_only)):
    s = _session_or_404(db, session_id, current_user["user_id"])
    if s.status == "open":
        s.status = "cancelled"
        db.commit()
    return {"ok": True}


# ----------------------------------------------------------------- student
@router.post("/student/qr-checkin")
def checkin(payload: CheckinRequest, request: Request, db: Session = Depends(get_db), current_user=Depends(student_only)):
    me = current_user.user
    checkin_limiter.check(f"qr:{me.id}", "Too many check-in attempts — wait a minute and try again.")
    my_courses = {c for (c,) in db.query(Enrollment.course_id).filter(Enrollment.student_id == me.id)}
    now = datetime.utcnow()
    session, method = None, None
    if payload.s and payload.t:
        s = db.get(QrSession, payload.s)
        if not s or s.status != "open" or s.expires_at <= now:
            raise HTTPException(status_code=400, detail="This check-in has closed. Ask your teacher.")
        if not _valid(s.secret, payload.t.lower(), token_for, windows=3):
            raise HTTPException(status_code=400, detail="This QR code has expired — scan the one on the screen now.")
        session, method = s, "scan"
    elif payload.code and re.fullmatch(r"\d{6}", payload.code):
        for s in db.query(QrSession).filter(QrSession.status == "open", QrSession.expires_at > now,
                                            QrSession.course_id.in_(my_courses or [-1])):
            if _valid(s.secret, payload.code, code_for, windows=4):
                session, method = s, "code"
                break
        if not session:
            raise HTTPException(status_code=400, detail="That code isn't valid (it changes every few seconds) — try the current one.")
    else:
        raise HTTPException(status_code=400, detail="Scan the QR code or enter the 6-digit code.")
    if session.course_id not in my_courses:
        raise HTTPException(status_code=403, detail="You're not enrolled in this course.")
    course = db.get(Course, session.course_id)
    label = _label(course) if course else "class"
    if db.query(QrCheckin.id).filter_by(qr_session_id=session.id, student_id=me.id).first():
        return {"ok": True, "already": True, "course": label, "date": session.date}
    device = hashlib.sha256(f"dev:{payload.device}".encode()).hexdigest()[:24] if payload.device else None
    db.add(QrCheckin(qr_session_id=session.id, student_id=me.id, method=method, device=device, ip=client_ip(request)))
    queue_event(db, "qr:checkin", {"sessionId": session.id, "studentId": f"u_{me.id}", "name": me.name},
                users=[session.teacher_id])
    db.commit()
    return {"ok": True, "already": False, "course": label, "date": session.date}
