"""
Exams: timetable (admin / exam cell), marks entry + publishing (faculty),
hall tickets and grade cards (students, parents).
"""
from datetime import date, datetime
from typing import List, Literal, Optional

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from pydantic import Field
from sqlalchemy import case, func
from sqlalchemy.orm import Session

from app import config, documents
from app.auth.auth import require_role
from app.common import enrolled_student_ids, log_audit, notify_users, parse_pk
from app.database.db import get_db
from app.messaging import alert_parents
from app.models.models import (
    AttendanceRecord, AttendanceSession, Course, Enrollment, Exam, ExamResult, IssuedDocument, User,
)
from app.realtime import queue_event
from app.schemas.base import Id, In, IsoDate, Short

router = APIRouter(prefix="/exams", tags=["exams"])
admin_only = require_role(["admin"])
staff = require_role(["admin", "teacher"])
student_only = require_role(["student"])

KIND_TITLES = {"midsem": "Mid-Semester Exam", "endsem": "End-Semester Exam", "practical": "Practical Exam", "quiz": "Class Test"}


class ExamCreate(In):
    course_id: Id = Field(alias="courseId")
    kind: Literal["midsem", "endsem", "practical", "quiz"] = "midsem"
    title: Optional[Short] = None
    date: IsoDate
    start_time: str = Field(default="10:00", alias="startTime", pattern=r"^([01]\d|2[0-3]):[0-5]\d$")
    duration_min: int = Field(default=180, alias="durationMin", ge=15, le=480)
    room: Optional[Short] = None
    max_marks: float = Field(default=100, alias="maxMarks", gt=0, le=1000)


class ResultEntry(In):
    student_id: Id = Field(alias="studentId")
    marks: Optional[float] = Field(default=None, ge=0, le=1000)
    absent: bool = False


class ResultsSave(In):
    entries: List[ResultEntry] = Field(max_length=2000)


def _exam_or_404(db, exam_id) -> Exam:
    e = db.get(Exam, parse_pk(exam_id, "ex"))
    if not e:
        raise HTTPException(status_code=404, detail="Exam not found")
    return e


def _can_manage(cu, exam: Exam):
    if cu["role"] == "admin":
        return
    if not exam.course or exam.course.faculty_id != cu["user_id"]:
        raise HTTPException(status_code=404, detail="Exam not found")


def _fmt_time(hhmm: str) -> str:
    try:
        return datetime.strptime(hhmm, "%H:%M").strftime("%I:%M %p").lstrip("0")
    except Exception:
        return hhmm


def _entered_counts(db, exam_ids):
    return dict(db.query(ExamResult.exam_id, func.count(ExamResult.id)).filter(ExamResult.exam_id.in_(exam_ids or [-1]))
                .group_by(ExamResult.exam_id).all())


# ============================================================== timetable
@router.get("/admin")
def all_exams(db: Session = Depends(get_db), current_user=Depends(admin_only)):
    exams = db.query(Exam).order_by(Exam.date, Exam.start_time).all()
    counts = _entered_counts(db, [e.id for e in exams])
    return [e.to_dict(counts.get(e.id, 0)) for e in exams]


@router.post("")
def create_exam(payload: ExamCreate, db: Session = Depends(get_db), current_user=Depends(admin_only)):
    course = db.get(Course, parse_pk(payload.course_id, "c"))
    if not course:
        raise HTTPException(status_code=404, detail="Course not found")
    clash = (db.query(Exam).filter(Exam.course_id == course.id, Exam.date == payload.date,
                                   Exam.start_time == payload.start_time).first())
    if clash:
        raise HTTPException(status_code=400, detail=f"{course.code} already has an exam at that time.")
    exam = Exam(course_id=course.id, kind=payload.kind, title=payload.title or KIND_TITLES[payload.kind], date=payload.date,
                start_time=payload.start_time, duration_min=payload.duration_min, room=payload.room,
                max_marks=payload.max_marks, created_by=current_user["user_id"])
    db.add(exam)
    db.flush()
    db.refresh(exam)
    when = f"{documents.fmt_date(exam.date)} at {_fmt_time(exam.start_time)}"
    text = f"{course.code} {exam.title} is scheduled on {when}{', room ' + exam.room if exam.room else ''}."
    sids = enrolled_student_ids(db, course.id)
    notify_users(db, sids + ([course.faculty_id] if course.faculty_id else []), "Exam scheduled", text)
    for st in db.query(User).filter(User.id.in_(sids or [-1]), User.status == "active"):
        alert_parents(db, st, "exam", f"{st.name}: {text}", title="Exam scheduled")
    log_audit(db, current_user, "Exam scheduled", f"{course.code} · {exam.title} · {exam.date}")
    queue_event(db, "exams:update", exam.to_dict(), users=sids + ([course.faculty_id] if course.faculty_id else []), roles=["admin"])
    db.commit()
    return exam.to_dict(0)


@router.delete("/{exam_id}")
def delete_exam(exam_id: str, db: Session = Depends(get_db), current_user=Depends(admin_only)):
    exam = _exam_or_404(db, exam_id)
    if exam.results_published:
        raise HTTPException(status_code=400, detail="Results for this exam are already published — it can't be deleted.")
    log_audit(db, current_user, "Exam cancelled", f"{exam.course.code if exam.course else ''} · {exam.title} · {exam.date}")
    sids = enrolled_student_ids(db, exam.course_id)
    notify_users(db, sids, "Exam cancelled", f"{exam.course.code if exam.course else ''} {exam.title} on {documents.fmt_date(exam.date)} was cancelled.")
    queue_event(db, "exams:update", {"id": f"ex_{exam.id}", "deleted": True}, users=sids, roles=["admin"])
    db.delete(exam)
    db.commit()
    return {"ok": True}


@router.get("/teacher")
def teacher_exams(db: Session = Depends(get_db), current_user=Depends(require_role(["teacher"]))):
    exams = (db.query(Exam).join(Course, Course.id == Exam.course_id).filter(Course.faculty_id == current_user["user_id"])
             .order_by(Exam.date, Exam.start_time).all())
    counts = _entered_counts(db, [e.id for e in exams])
    return [e.to_dict(counts.get(e.id, 0)) for e in exams]


# ================================================================ results
@router.get("/{exam_id}/results")
def exam_results(exam_id: str, db: Session = Depends(get_db), current_user=Depends(staff)):
    exam = _exam_or_404(db, exam_id)
    _can_manage(current_user, exam)
    students = (db.query(User).join(Enrollment, Enrollment.student_id == User.id)
                .filter(Enrollment.course_id == exam.course_id, User.status == "active").order_by(User.id_label).all())
    res = {r.student_id: r for r in db.query(ExamResult).filter(ExamResult.exam_id == exam.id)}
    rows = []
    for s in students:
        r = res.get(s.id)
        rows.append({"studentId": f"u_{s.id}", "name": s.name, "idLabel": s.id_label,
                     "marks": r.marks if r else None, "absent": bool(r.absent) if r else False})
    return {"exam": exam.to_dict(len(res)), "rows": rows}


@router.put("/{exam_id}/results")
def save_results(exam_id: str, payload: ResultsSave, db: Session = Depends(get_db), current_user=Depends(staff)):
    exam = _exam_or_404(db, exam_id)
    _can_manage(current_user, exam)
    if exam.results_published and current_user["role"] != "admin":
        raise HTTPException(status_code=400, detail="Results are already published. Ask the exam cell (admin) to make corrections.")
    enrolled = set(enrolled_student_ids(db, exam.course_id))
    existing = {r.student_id: r for r in db.query(ExamResult).filter(ExamResult.exam_id == exam.id)}
    saved = 0
    for e in payload.entries:
        sid = parse_pk(e.student_id, "u")
        if sid not in enrolled:
            raise HTTPException(status_code=400, detail="Marks can only be entered for students enrolled in this course.")
        if e.marks is not None and e.marks > exam.max_marks:
            raise HTTPException(status_code=400, detail=f"Marks can't be more than the maximum ({exam.max_marks:g}).")
        if e.marks is None and not e.absent:
            continue
        r = existing.get(sid) or ExamResult(exam_id=exam.id, student_id=sid)
        r.marks, r.absent = (None, True) if e.absent else (e.marks, False)
        db.add(r)
        existing[sid] = r
        saved += 1
    log_audit(db, current_user, "Exam marks saved", f"{exam.course.code if exam.course else ''} · {exam.title} · {saved} students")
    db.commit()
    return {"saved": saved, "exam": exam.to_dict(len(existing))}


@router.post("/{exam_id}/publish")
def publish_results(exam_id: str, db: Session = Depends(get_db), current_user=Depends(staff)):
    exam = _exam_or_404(db, exam_id)
    _can_manage(current_user, exam)
    if exam.results_published:
        raise HTTPException(status_code=400, detail="Results are already published.")
    results = db.query(ExamResult).filter(ExamResult.exam_id == exam.id).all()
    enrolled = enrolled_student_ids(db, exam.course_id)
    if not results:
        raise HTTPException(status_code=400, detail="Enter marks before publishing.")
    exam.results_published, exam.published_at = True, datetime.utcnow()
    code = exam.course.code if exam.course else ""
    users = {u.id: u for u in db.query(User).filter(User.id.in_([r.student_id for r in results]))}
    for r in results:
        st = users.get(r.student_id)
        if not st:
            continue
        score = "absent" if r.absent else f"{r.marks:g}/{exam.max_marks:g}"
        notify_users(db, [st.id], "Result published", f"{code} {exam.title}: {score}.")
        alert_parents(db, st, "results", f"{st.name}'s result for {code} {exam.title}: {score}.", title="Exam result published")
    log_audit(db, current_user, "Exam results published", f"{code} · {exam.title} · {len(results)}/{len(enrolled)} students")
    queue_event(db, "exams:update", exam.to_dict(len(results)), users=enrolled, roles=["admin"])
    db.commit()
    return exam.to_dict(len(results))


# ============================================================ student view
def course_attendance_pct(db, sid) -> dict:
    present_int = case((AttendanceRecord.present.is_(True), 1), else_=0)
    rows = (db.query(AttendanceSession.course_id, func.count(AttendanceRecord.id), func.sum(present_int))
            .join(AttendanceRecord, AttendanceRecord.session_id == AttendanceSession.id)
            .filter(AttendanceRecord.student_id == sid).group_by(AttendanceSession.course_id).all())
    return {cid: round(int(p or 0) / t * 100) for cid, t, p in rows if t}


def student_exam_view(db, sid) -> dict:
    cids = [c for (c,) in db.query(Enrollment.course_id).filter(Enrollment.student_id == sid)]
    exams = db.query(Exam).filter(Exam.course_id.in_(cids or [-1])).order_by(Exam.date, Exam.start_time).all()
    att = course_attendance_pct(db, sid)
    today = date.today().isoformat()
    res = {r.exam_id: r for r in db.query(ExamResult).filter(ExamResult.student_id == sid)}
    upcoming, results = [], []
    for e in exams:
        pct = att.get(e.course_id)
        eligible = not config.EXAM_MIN_ATTENDANCE or pct is None or pct >= config.EXAM_MIN_ATTENDANCE
        d = {**e.to_dict(), "time": _fmt_time(e.start_time), "attendancePct": pct, "eligible": eligible}
        if e.date >= today:
            upcoming.append(d)
        if e.results_published and e.id in res:
            r = res[e.id]
            d.update({"marks": r.marks, "absent": bool(r.absent),
                      "pct": 0 if r.absent else round((r.marks or 0) / e.max_marks * 100, 1)})
            results.append(d)
    return {"upcoming": upcoming, "results": results, "minAttendance": config.EXAM_MIN_ATTENDANCE, "gradeCard": grade_card_data(db, sid)}


def grade_card_data(db, sid) -> dict:
    rows = (db.query(Exam, ExamResult).join(ExamResult, ExamResult.exam_id == Exam.id)
            .filter(ExamResult.student_id == sid, Exam.results_published.is_(True)).all())
    per = {}
    for e, r in rows:
        c = per.setdefault(e.course_id, {"code": e.course.code, "name": e.course.name, "obtained": 0.0, "max": 0.0})
        c["obtained"] += 0 if r.absent else (r.marks or 0)
        c["max"] += e.max_marks
    courses = []
    for c in sorted(per.values(), key=lambda x: x["code"]):
        pct = c["obtained"] / c["max"] * 100 if c["max"] else 0
        letter, gp = documents.letter_grade(pct)
        courses.append({**c, "pct": round(pct, 1), "letter": letter, "gp": gp, "result": "Pass" if gp >= 4 else "Fail"})
    sgpa = round(sum(c["gp"] for c in courses) / len(courses), 2) if courses else 0
    return {"courses": courses, "sgpa": sgpa}


def _term_label():
    y = date.today().year
    return f"Academic year {y}-{str(y + 1)[-2:]}" if date.today().month >= 6 else f"Academic year {y - 1}-{str(y)[-2:]}"


def hall_ticket_bytes(db, student) -> bytes:
    view = student_exam_view(db, student.id)
    exams = [{"code": e["courseCode"], "name": e["courseName"], "title": e["title"], "date": e["date"], "time": e["time"],
              "durationMin": e["durationMin"], "room": e["room"], "attendancePct": e["attendancePct"], "eligible": e["eligible"]}
             for e in view["upcoming"]]
    return documents.hall_ticket_pdf(student, exams, config.EXAM_MIN_ATTENDANCE)


def grade_card_bytes(db, student) -> bytes:
    gc = grade_card_data(db, student.id)
    return documents.grade_card_pdf(student, gc["courses"], gc["sgpa"], _term_label())


def pdf_response(data: bytes, filename: str) -> Response:
    return Response(content=data, media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{filename}"', "Cache-Control": "no-store"})


@router.get("/mine")
def my_exams(db: Session = Depends(get_db), current_user=Depends(student_only)):
    return student_exam_view(db, current_user["user_id"])


@router.get("/hall-ticket.pdf")
def my_hall_ticket(db: Session = Depends(get_db), current_user=Depends(student_only)):
    me = current_user.user
    db.add(IssuedDocument(user_id=me.id, kind="hall-ticket"))
    db.commit()
    return pdf_response(hall_ticket_bytes(db, me), f"hall-ticket-{me.id_label or me.id}.pdf")


@router.get("/grade-card.pdf")
def my_grade_card(db: Session = Depends(get_db), current_user=Depends(student_only)):
    me = current_user.user
    return pdf_response(grade_card_bytes(db, me), f"grade-card-{me.id_label or me.id}.pdf")
