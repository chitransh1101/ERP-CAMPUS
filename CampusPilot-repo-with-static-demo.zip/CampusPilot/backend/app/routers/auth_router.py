from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from sqlalchemy.orm import Session

from app import config
from app.auth.auth import (
    burn_password_check, clear_session_cookies, create_session, get_current_user, hash_password, login_guard,
    needs_rehash, revoke_all_sessions, set_session_cookies, validate_new_password, verify_password,
)
from app.common import is_valid_email, log_audit, normalize_email
from app.database.db import get_db
from app.models.models import User, UserSession
from app.schemas.user_schema import ChangePasswordRequest, LoginRequest, SignupRequest
from app.security import client_ip, login_ip_limiter, signup_ip_limiter

router = APIRouter(prefix="/auth", tags=["auth"])
ROLE_LABELS = {"student": "Student", "teacher": "Faculty", "admin": "Admin", "parent": "Parent"}
GENERIC_LOGIN_ERROR = "Incorrect email or password."


def _session_response(request: Request, response: Response, db: Session, user: User):
    token = create_session(db, user, client_ip(request), request.headers.get("user-agent", ""))
    set_session_cookies(response, token)
    body = {"user": user.to_dict()}
    # Browsers get the token only as an httpOnly cookie (unreadable by JS).
    # Scripts/CLI tools (no Origin header) also receive it for Bearer use.
    if not request.headers.get("origin"):
        body["token"] = token
    return body


@router.post("/login")
def login(credentials: LoginRequest, request: Request, response: Response, db: Session = Depends(get_db)):
    ip = client_ip(request)
    login_ip_limiter.check(ip, "Too many login attempts from your network. Wait a minute and try again.")
    email = normalize_email(credentials.email)
    login_guard.check(email)

    # Exact, case-insensitive match on a normalised column. (The old code used
    # ILIKE with the raw input, so an "email" of "%" matched the first account.)
    user = db.query(User).filter(User.email == email).first()
    if user is None:
        burn_password_check(credentials.password)  # equalise timing: don't reveal which emails exist
        ok = False
    else:
        ok = verify_password(credentials.password, user.password_hash)
    if not ok:
        locked = login_guard.fail(email)
        if user is not None:
            log_audit(db, user, "Failed login", f"from {ip}", ip=ip)
            db.commit()
        if locked:
            raise HTTPException(status_code=429, detail="Too many failed attempts. This account is temporarily locked — try again in a few minutes.")
        raise HTTPException(status_code=401, detail=GENERIC_LOGIN_ERROR)

    if user.status != "active":
        raise HTTPException(status_code=403, detail="This account has been deactivated. Contact your campus admin.")
    if credentials.role and user.role != credentials.role:
        raise HTTPException(status_code=403, detail=(
            f"This account is registered as {ROLE_LABELS.get(user.role, user.role)}, not "
            f"{ROLE_LABELS.get(credentials.role, credentials.role)}. Switch portals above and try again."))

    login_guard.clear(email)
    if needs_rehash(user.password_hash):
        user.password_hash = hash_password(credentials.password)
    user.last_login_at = datetime.utcnow()
    body = _session_response(request, response, db, user)
    log_audit(db, user, "Signed in", f"from {ip}", ip=ip)
    db.commit()
    return body


@router.post("/logout")
def logout(request: Request, response: Response, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    sess = db.get(UserSession, current_user["jti"])
    if sess:
        sess.revoked = True
        db.commit()
    clear_session_cookies(response)
    return {"message": "Signed out"}


@router.post("/logout-all")
def logout_all(response: Response, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    revoke_all_sessions(db, current_user["user_id"])
    log_audit(db, current_user, "Signed out of all devices")
    db.commit()
    clear_session_cookies(response)
    return {"message": "Signed out everywhere"}


@router.get("/me")
def me(current_user=Depends(get_current_user)):
    return current_user.user.to_dict()


@router.post("/change-password")
def change_password(payload: ChangePasswordRequest, request: Request, response: Response,
                    db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    user = current_user.user
    if not verify_password(payload.current_password, user.password_hash):
        if login_guard.fail(user.email):
            raise HTTPException(status_code=429, detail="Too many failed attempts. Try again in a few minutes.")
        raise HTTPException(status_code=400, detail="Your current password is incorrect.")
    if payload.new_password == payload.current_password:
        raise HTTPException(status_code=400, detail="Choose a password different from your current one.")
    validate_new_password(payload.new_password, user.email, user.name)
    user.password_hash = hash_password(payload.new_password)
    user.must_change_password = False
    revoke_all_sessions(db, user.id, except_jti=current_user["jti"])  # sign out other devices
    log_audit(db, user, "Password changed", ip=client_ip(request))
    db.commit()
    return {"message": "Password updated. Other devices have been signed out.", "user": user.to_dict()}


@router.post("/signup")
def signup(record: SignupRequest, request: Request, response: Response, db: Session = Depends(get_db)):
    """Self-service signup: students only by default. Faculty and admin
    accounts are created by an admin (Users & Roles) — otherwise anyone on
    the internet could make themselves a teacher and publish grades."""
    if not config.ALLOW_SELF_SIGNUP:
        raise HTTPException(status_code=403, detail="Self-registration is disabled. Ask your campus admin for an account.")
    if record.role == "admin":
        raise HTTPException(status_code=403, detail="Admin accounts can't be self-registered. Ask an existing campus admin to create your account from Users & Roles.")
    if record.role == "teacher" and config.IS_PROD:
        raise HTTPException(status_code=403, detail="Faculty accounts are created by the campus admin. Ask them to add you from Users & Roles.")
    signup_ip_limiter.check(client_ip(request), "Too many sign-ups from your network. Try again later.")
    email = normalize_email(record.email)
    if not is_valid_email(email):
        raise HTTPException(status_code=400, detail="Enter a valid email address.")
    validate_new_password(record.password, email, record.name)
    if db.query(User.id).filter(User.email == email).first():
        raise HTTPException(status_code=400, detail="An account with that email already exists.")
    id_label = (record.id_label or "").strip().upper() or None
    if id_label and db.query(User.id).filter(User.id_label == id_label).first():
        # Roll numbers identify students on attendance sheets — never allow duplicates.
        raise HTTPException(status_code=400, detail="That roll number / staff ID is already registered. Contact your admin if this is a mistake.")
    user = User(name=record.name, email=email, password_hash=hash_password(record.password), role=record.role,
                id_label=id_label, status="active")
    db.add(user)
    db.flush()
    log_audit(db, user, "Account created", f"Signed up as {user.role}", ip=client_ip(request))
    body = _session_response(request, response, db, user)
    db.commit()
    return body
