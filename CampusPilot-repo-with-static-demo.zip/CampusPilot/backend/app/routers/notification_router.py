from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.auth.auth import get_current_user
from app.common import parse_pk
from app.database.db import get_db
from app.models.models import Notification

router = APIRouter(prefix="/notifications", tags=["notifications"])


@router.get("/")
def my_notifications(db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    rows = (db.query(Notification).filter(Notification.user_id == current_user["user_id"])
            .order_by(Notification.ts.desc(), Notification.id.desc()).limit(50).all())
    return [n.to_dict() for n in rows]


@router.patch("/{notification_id}/read")
def mark_as_read(notification_id: str, db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    n = db.get(Notification, parse_pk(notification_id, "ntf"))
    if not n or n.user_id != current_user["user_id"]:
        raise HTTPException(status_code=404, detail="Notification not found")
    n.read = True
    db.commit()
    return {"message": "Marked as read"}


@router.post("/read-all")
def mark_all_read(db: Session = Depends(get_db), current_user=Depends(get_current_user)):
    db.query(Notification).filter(Notification.user_id == current_user["user_id"], Notification.read.is_(False)) \
      .update({Notification.read: True}, synchronize_session=False)
    db.commit()
    return {"message": "All read"}
