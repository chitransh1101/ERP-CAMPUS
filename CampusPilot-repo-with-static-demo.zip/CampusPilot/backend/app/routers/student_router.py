import asyncio
from collections import defaultdict

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from sqlalchemy import case, func
from sqlalchemy.orm import Session

from app.auth.auth import require_role
from app.common import (
    attendance_stats, build_timetable, compute_risk_score, grade_point, log_audit, notify_users, parse_pk, score_stats,
)
from app.database.db import SessionLocal, get_db
from app.models.models import (
    Assignment, AssignmentSubmission, AttendanceRecord, AttendanceSession, ClassNotice, Course, Enrollment, Fee,
    GradeEntry, GradeRecord, Grievance, LibraryBook, LibraryRequest,
)
from app.realtime import queue_event
from app.routers.teacher_router import raise_grievance_for
from app.schemas.student_schema import BookRequestCreate, GrievanceCreate

router = APIRouter(prefix="/student", tags=["student"])
student_only = require_role(["student"])


def _my_course_ids(db, sid):
    return [cid for (cid,) in db.query(Enrollment.course_id).filter(Enrollment.student_id == sid)]


def _my_courses(db, sid):
    return db.query(Course).join(Enrollment, Enrollment.course_id == Course.id).filter(Enrollment.student_id == sid).order_by(Course.code).all()


def student_snapshot(db, sid):
    att = attendance_stats(db, [sid]).get(sid, {})
    sc = score_stats(db, [sid]).get(sid, {})
    fee = db.query(Fee).filter(Fee.student_id == sid).first()
    return att, sc, fee


def summary_for(db, sid):
    att, sc, fee = student_snapshot(db, sid)
    pct = att.get("pct")
    risk = compute_risk_score(pct, sc.get("avgScore"), fee.status if fee else "unknown")
    return {"attendancePct": round(pct) if pct is not None else 0, "hasAttendance": pct is not None,
            "totalLectures": att.get("total", 0), "present": att.get("present", 0),
            "cgpa": sc.get("cgpa") or 0, "avgScore": sc.get("avgScore"),
            "feeDue": max(0, fee.total - fee.paid) if fee else 0, "feeStatus": fee.status if fee else "unknown",
            "risk": risk}


@router.get("/summary")
def summary(db: Session = Depends(get_db), current_user=Depends(student_only)):
    return summary_for(db, current_user["user_id"])


@router.get("/courses")
def my_courses(db: Session = Depends(get_db), current_user=Depends(student_only)):
    return [c.to_dict() for c in _my_courses(db, current_user["user_id"])]


def attendance_for(db, sid):
    """Per-course breakdown + a weekly trend, straight from attendance records."""
    present_int = case((AttendanceRecord.present.is_(True), 1), else_=0)
    rows = (db.query(AttendanceSession.course_id, func.count(AttendanceRecord.id), func.sum(present_int))
            .join(AttendanceRecord, AttendanceRecord.session_id == AttendanceSession.id)
            .filter(AttendanceRecord.student_id == sid).group_by(AttendanceSession.course_id).all())
    courses = {c.id: c for c in _my_courses(db, sid)}
    per_course = []
    for cid, total, present in rows:
        c = courses.get(cid) or db.get(Course, cid)
        present = int(present or 0)
        pct = round(present / total * 100) if total else 0
        # Classes they can still miss and stay >= 75%, or must attend to get back there.
        can_miss = max(0, int((present - 0.75 * total) / 0.75)) if pct >= 75 else 0
        need = max(0, int(-(-(0.75 * total - present) // 0.25))) if pct < 75 else 0
        per_course.append({"courseId": f"c_{cid}", "code": c.code if c else "", "name": c.name if c else "",
                           "present": present, "total": int(total), "pct": pct, "canMiss": can_miss, "mustAttend": need})
    per_course.sort(key=lambda x: x["pct"])
    weekly = defaultdict(lambda: [0, 0])
    for day, present in (db.query(AttendanceSession.date, AttendanceRecord.present)
                         .join(AttendanceRecord, AttendanceRecord.session_id == AttendanceSession.id)
                         .filter(AttendanceRecord.student_id == sid)):
        from datetime import date as _d
        y, w, _ = _d.fromisoformat(day).isocalendar()
        weekly[(y, w)][0] += 1 if present else 0
        weekly[(y, w)][1] += 1
    trend = [round(p / t * 100) for _, (p, t) in sorted(weekly.items())][-8:]
    return {"perCourse": per_course, "weeklyTrend": trend}


@router.get("/attendance")
def my_attendance(db: Session = Depends(get_db), current_user=Depends(student_only)):
    return attendance_for(db, current_user["user_id"])


def grades_for(db, sid):
    rows = (db.query(GradeRecord, GradeEntry.score).join(GradeEntry, GradeEntry.grade_id == GradeRecord.id)
            .filter(GradeEntry.student_id == sid).order_by(GradeRecord.ts.desc()).all())
    by_course = defaultdict(list)
    for rec, score in rows:
        by_course[rec.course_id].append({"assessment": rec.assessment, "score": score, "ts": rec.to_dict()["ts"]})
    out = []
    for cid, items in by_course.items():
        c = db.get(Course, cid)
        avg = sum(i["score"] for i in items) / len(items)
        out.append({"courseId": f"c_{cid}", "code": c.code if c else "", "name": c.name if c else "",
                    "average": round(avg, 1), "gradePoint": grade_point(avg), "assessments": items})
    sc = score_stats(db, [sid]).get(sid, {})
    return {"cgpa": sc.get("cgpa") or 0, "courses": sorted(out, key=lambda x: x["code"])}


@router.get("/grades")
def my_grades(db: Session = Depends(get_db), current_user=Depends(student_only)):
    return grades_for(db, current_user["user_id"])


def fees_for(db, sid):
    fee = db.query(Fee).filter(Fee.student_id == sid).first()
    return fee.to_dict() if fee else {"total": 0, "paid": 0, "due": 0, "status": "unknown"}


@router.get("/fees")
def my_fees(db: Session = Depends(get_db), current_user=Depends(student_only)):
    return fees_for(db, current_user["user_id"])


# ----------------------------------------------------------- Assignments
@router.get("/assignments")
def assignments(db: Session = Depends(get_db), current_user=Depends(student_only)):
    sid = current_user["user_id"]
    items = (db.query(Assignment).filter(Assignment.course_id.in_(_my_course_ids(db, sid) or [-1]))
             .order_by(Assignment.ts.desc()).all())
    done = {aid for (aid,) in db.query(AssignmentSubmission.assignment_id).filter(AssignmentSubmission.student_id == sid)}
    return [a.to_dict(my_status="submitted" if a.id in done else "pending") for a in items]


@router.post("/assignments/{assignment_id}/submit")
def submit_assignment(assignment_id: str, db: Session = Depends(get_db), current_user=Depends(student_only)):
    me = current_user.user
    a = db.get(Assignment, parse_pk(assignment_id, "a"))
    if not a or a.course_id not in _my_course_ids(db, me.id):
        raise HTTPException(status_code=404, detail="Assignment not found")
    if not db.query(AssignmentSubmission.id).filter_by(assignment_id=a.id, student_id=me.id).first():
        db.add(AssignmentSubmission(assignment_id=a.id, student_id=me.id))
        log_audit(db, me, "Assignment submitted", a.title)
        if a.created_by:
            queue_event(db, "assignment:submitted", {"assignmentId": f"a_{a.id}"}, users=[a.created_by])
        db.commit()
    return a.to_dict(my_status="submitted")


# ---------------------------------------------------------------- Notices
def notices_for(db, sid):
    cids = _my_course_ids(db, sid)
    rows = db.query(ClassNotice).filter(ClassNotice.course_id.in_(cids or [-1])).order_by(ClassNotice.ts.desc()).limit(20).all()
    return [n.to_dict() for n in rows]


@router.get("/notices")
def notices(db: Session = Depends(get_db), current_user=Depends(student_only)):
    return notices_for(db, current_user["user_id"])


# ------------------------------------------------------------- Grievances
@router.post("/grievances")
def raise_grievance(payload: GrievanceCreate, db: Session = Depends(get_db), current_user=Depends(student_only)):
    return raise_grievance_for(db, current_user.user, payload)


@router.get("/grievances/mine")
def my_grievances(db: Session = Depends(get_db), current_user=Depends(student_only)):
    gs = db.query(Grievance).filter(Grievance.raised_by_id == current_user["user_id"]).order_by(Grievance.ts.desc()).all()
    return [g.to_dict() for g in gs]


# ----------------------------------------------------------------- Library
@router.get("/library/catalog")
def library_catalog(db: Session = Depends(get_db), current_user=Depends(student_only)):
    return [b.to_dict() for b in db.query(LibraryBook).order_by(LibraryBook.title)]


@router.get("/library/requests/mine")
def my_library_requests(db: Session = Depends(get_db), current_user=Depends(student_only)):
    reqs = db.query(LibraryRequest).filter(LibraryRequest.student_id == current_user["user_id"]).order_by(LibraryRequest.ts.desc())
    return [r.to_dict() for r in reqs]


def _resolve_library_request(request_id: int):
    """The circulation desk's automatic check: reserve a copy if one is free
    (atomically decrementing stock), otherwise waitlist."""
    db = SessionLocal()
    try:
        req = db.get(LibraryRequest, request_id)
        if not req or req.status != "pending":
            return
        updated = (db.query(LibraryBook).filter(LibraryBook.id == req.book_id, LibraryBook.copies > 0)
                   .update({LibraryBook.copies: LibraryBook.copies - 1}, synchronize_session=False))
        req.status = "ready-for-pickup" if updated else "waitlisted"
        body = (f"{req.title} — collect it from the circulation desk." if updated else f"{req.title} — all copies are currently out.")
        notify_users(db, [req.student_id], "Book ready for pickup" if updated else "Added to waitlist", body)
        queue_event(db, "library:update", req.to_dict(), users=[req.student_id])
        db.commit()
    finally:
        db.close()


async def _delayed_resolve(request_id: int):
    await asyncio.sleep(3)
    await asyncio.get_running_loop().run_in_executor(None, _resolve_library_request, request_id)


@router.post("/library/requests")
def request_book(payload: BookRequestCreate, background_tasks: BackgroundTasks, db: Session = Depends(get_db),
                 current_user=Depends(student_only)):
    me = current_user.user
    book = db.get(LibraryBook, parse_pk(payload.book_id, "bk"))
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")
    active = (db.query(LibraryRequest.id).filter(LibraryRequest.student_id == me.id, LibraryRequest.book_id == book.id,
                                                LibraryRequest.status.in_(["pending", "ready-for-pickup", "waitlisted"])).first())
    if active:
        raise HTTPException(status_code=400, detail="You already have an active request for this book.")
    open_count = (db.query(func.count(LibraryRequest.id)).filter(LibraryRequest.student_id == me.id,
                  LibraryRequest.status.in_(["pending", "ready-for-pickup"])).scalar())
    if open_count >= 5:
        raise HTTPException(status_code=400, detail="You can hold at most 5 books at a time.")
    req = LibraryRequest(student_id=me.id, book_id=book.id, title=book.title, status="pending")
    db.add(req)
    db.flush()
    log_audit(db, me, "Library request", book.title)
    db.commit()
    background_tasks.add_task(_delayed_resolve, req.id)
    return req.to_dict()


# --------------------------------------------------------------- Timetable
@router.get("/timetable")
def timetable(db: Session = Depends(get_db), current_user=Depends(student_only)):
    return build_timetable([c.to_dict() for c in _my_courses(db, current_user["user_id"])])
