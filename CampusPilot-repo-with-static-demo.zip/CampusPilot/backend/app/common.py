"""
Shared helpers: audit + notifications (with real-time push), id parsing,
and the aggregated academic statistics every portal reads from.

Performance: all per-student statistics are computed with a handful of
GROUP BY queries for the whole cohort at once. The old code ran several
queries *per student* inside a loop (N+1), which gets slow fast with a
real college's roster.
"""
import re
from collections import defaultdict

from fastapi import HTTPException
from sqlalchemy import case, func
from sqlalchemy.orm import Session

from app.models.models import (
    AttendanceRecord, AttendanceSession, AuditLogEntry, Enrollment, Fee, GradeEntry, GradeRecord,
    Notification, User,
)
from app.realtime import queue_event

# ----------------------------------------------------------------- Emails
EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]{1,64}@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$")
GMAIL_RE = re.compile(r"^[A-Za-z0-9._%+-]{1,64}@gmail\.com$", re.IGNORECASE)


def normalize_email(email) -> str:
    return (email or "").strip().lower()


def is_valid_email(email) -> bool:
    e = (email or "").strip()
    return 3 <= len(e) <= 254 and bool(EMAIL_RE.match(e))


def is_valid_gmail(email) -> bool:
    return bool(email) and bool(GMAIL_RE.match(email.strip()))


# -------------------------------------------------------------------- Ids
def parse_pk(prefixed_id, prefix: str = None) -> int:
    """'u_5' -> 5. Anything malformed is a 404, never a 500."""
    s = str(prefixed_id or "")
    if prefix and not s.startswith(prefix + "_"):
        raise HTTPException(status_code=404, detail="Not found")
    tail = s.rsplit("_", 1)[-1]
    if not tail.isdigit() or len(tail) > 12:
        raise HTTPException(status_code=404, detail="Not found")
    return int(tail)


# ---------------------------------------------------- Audit + notifications
def log_audit(db: Session, actor, action: str, detail: str = "", ip: str = None, actor_role: str = None):
    """actor: a User row or the CurrentUser dict. Added to the session; the
    caller's commit saves it, and admins see it live via WebSocket."""
    if isinstance(actor, User):
        actor_id, name, role = actor.id, actor.name, actor.role
    elif isinstance(actor, dict):
        actor_id, name, role = actor.get("user_id"), actor.get("name"), actor.get("role")
    else:
        actor_id, name, role = None, str(actor), actor_role or "system"
    entry = AuditLogEntry(actor_id=actor_id, actor=name, actor_role=actor_role or role, action=action,
                          detail=(detail or "")[:2000], ip=ip)
    db.add(entry)
    db.flush()
    queue_event(db, "audit:new", entry.to_dict(), roles=["admin"])
    return entry


def notify_users(db: Session, user_ids, title: str, body: str):
    user_ids = sorted({int(u) for u in user_ids if u})
    if not user_ids:
        return
    rows = [Notification(user_id=uid, title=title[:200], body=body) for uid in user_ids]
    db.add_all(rows)
    db.flush()
    for n in rows:
        queue_event(db, "notification:new", n.to_dict(), users=[n.user_id])


def notify_role(db: Session, role: str, title: str, body: str):
    ids = [uid for (uid,) in db.query(User.id).filter(User.role == role, User.status == "active")]
    notify_users(db, ids, title, body)


def enrolled_student_ids(db: Session, course_id: int) -> list:
    return [sid for (sid,) in db.query(Enrollment.student_id).filter(Enrollment.course_id == course_id)]


def notify_course(db: Session, course_id: int, title: str, body: str):
    notify_users(db, enrolled_student_ids(db, course_id), title, body)


def enrollment_counts(db: Session) -> dict:
    return dict(db.query(Enrollment.course_id, func.count(Enrollment.id)).group_by(Enrollment.course_id).all())


# ----------------------------------------------------------- Grade points
# 10-point scale commonly used by Indian universities (equal credits assumed).
GRADE_BANDS = [(90, 10), (80, 9), (70, 8), (60, 7), (50, 6), (45, 5), (40, 4)]


def grade_point(score: float) -> int:
    for minimum, gp in GRADE_BANDS:
        if score >= minimum:
            return gp
    return 0


def grade_distribution(scores):
    bands = [("A", 85), ("B", 70), ("C", 55), ("D", 40), ("F", 0)]
    counts = [{"label": label, "value": 0} for label, _ in bands]
    for score in scores:
        for idx, (_, minimum) in enumerate(bands):
            if score >= minimum:
                counts[idx]["value"] += 1
                break
    return counts


# ------------------------------------------------------ Cohort statistics
def attendance_stats(db: Session, student_ids=None, course_ids=None) -> dict:
    """{student_id: {"present": n, "total": n, "pct": float|None}} in one query."""
    q = (db.query(AttendanceRecord.student_id, func.count(AttendanceRecord.id),
                  func.sum(case((AttendanceRecord.present.is_(True), 1), else_=0)))
         .join(AttendanceSession, AttendanceSession.id == AttendanceRecord.session_id))
    if course_ids is not None:
        q = q.filter(AttendanceSession.course_id.in_(course_ids or [-1]))
    if student_ids is not None:
        q = q.filter(AttendanceRecord.student_id.in_(student_ids or [-1]))
    out = {}
    for sid, total, present in q.group_by(AttendanceRecord.student_id):
        present = int(present or 0)
        out[sid] = {"present": present, "total": int(total), "pct": round(present / total * 100, 1) if total else None}
    return out


def score_stats(db: Session, student_ids=None, course_ids=None) -> dict:
    """{student_id: {"avgScore": float|None, "cgpa": float|None, "perCourse": {course_id: avg}}}."""
    q = (db.query(GradeEntry.student_id, GradeRecord.course_id, func.avg(GradeEntry.score))
         .join(GradeRecord, GradeRecord.id == GradeEntry.grade_id))
    if course_ids is not None:
        q = q.filter(GradeRecord.course_id.in_(course_ids or [-1]))
    if student_ids is not None:
        q = q.filter(GradeEntry.student_id.in_(student_ids or [-1]))
    per = defaultdict(dict)
    for sid, cid, avg in q.group_by(GradeEntry.student_id, GradeRecord.course_id):
        per[sid][cid] = float(avg)
    out = {}
    for sid, courses in per.items():
        avgs = list(courses.values())
        out[sid] = {"avgScore": round(sum(avgs) / len(avgs), 1),
                    "cgpa": round(sum(grade_point(a) for a in avgs) / len(avgs), 2),
                    "perCourse": courses}
    return out


def fee_status_map(db: Session, student_ids=None) -> dict:
    q = db.query(Fee)
    if student_ids is not None:
        q = q.filter(Fee.student_id.in_(student_ids or [-1]))
    return {f.student_id: f.status for f in q}


# ----------------------------------------------------------- Risk scoring
RISK_WEIGHTS = {"attendance": 0.45, "score": 0.35, "fee": 0.20}
RISK_THRESHOLDS = {"low": 75, "medium": 50}
FEE_COMPONENT = {"paid": 100, "partial": 50, "overdue": 0}


def compute_risk_score(attendance_pct, avg_score, fee_status):
    """Early-warning health score (0-100, higher is healthier). Components
    with no data yet are left out and the remaining weights re-normalised,
    instead of inventing a number."""
    parts = []
    if attendance_pct is not None:
        parts.append((RISK_WEIGHTS["attendance"], attendance_pct))
    if avg_score is not None:
        parts.append((RISK_WEIGHTS["score"], avg_score))
    if fee_status in FEE_COMPONENT:
        parts.append((RISK_WEIGHTS["fee"], FEE_COMPONENT[fee_status]))
    weight = sum(w for w, _ in parts)
    health = round(sum(w * v for w, v in parts) / weight) if weight else None

    if health is None:
        level = "low"
    else:
        level = "low" if health >= RISK_THRESHOLDS["low"] else ("medium" if health >= RISK_THRESHOLDS["medium"] else "high")

    reasons = []
    if attendance_pct is not None and attendance_pct < 75:
        reasons.append(f"Attendance {round(attendance_pct)}% (below 75%)")
    if avg_score is not None and avg_score < 50:
        reasons.append(f"Avg. score {round(avg_score)}/100 (below 50)")
    if fee_status == "overdue":
        reasons.append("Fee overdue")
    elif fee_status == "partial":
        reasons.append("Fee partially paid")
    if attendance_pct is None and avg_score is None:
        reasons.append("Not enough data yet")
    if not reasons:
        reasons.append("No risk factors flagged")
    return {"healthScore": health if health is not None else 0, "riskLevel": level, "reasons": reasons,
            "feeComponent": FEE_COMPONENT.get(fee_status)}


def cohort_risk(db: Session, students, course_ids=None) -> list:
    ids = [s.id for s in students]
    att = attendance_stats(db, ids, course_ids)
    sc = score_stats(db, ids, course_ids)
    fees = fee_status_map(db, ids)
    out = []
    for s in students:
        a = att.get(s.id, {})
        g = sc.get(s.id, {})
        pct, avg = a.get("pct"), g.get("avgScore")
        fee = fees.get(s.id, "unknown")
        out.append({"id": f"u_{s.id}", "name": s.name, "idLabel": s.id_label, "department": s.department,
                    "attendancePct": round(pct) if pct is not None else None,
                    "avgScore": round(avg) if avg is not None else None,
                    "cgpa": g.get("cgpa"), "feeStatus": fee, **compute_risk_score(pct, avg, fee)})
    return out


# -------------------------------------------------------------- Timetable
WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
DAY_SLOTS = ["9:00 AM", "10:00 AM", "11:15 AM", "12:30 PM", "2:00 PM", "3:15 PM"]
ROOMS = ["B-204", "Lab 3", "A-102", "B-118", "C-210", "Lab 1"]


def build_timetable(courses):
    """Deterministic weekly grid derived from a course list (no timetable table yet).
    Slots are keyed on course id so a course keeps its slot for every viewer."""
    grid = {d: [] for d in WEEKDAYS}
    for course in sorted(courses, key=lambda c: c["id"]):
        cid = int(str(course["id"]).rsplit("_", 1)[-1])
        for s in range(3):
            day = WEEKDAYS[(cid * 2 + s * 2 + 1) % len(WEEKDAYS)]
            slot = DAY_SLOTS[(cid + s * 2) % len(DAY_SLOTS)]
            grid[day].append({"time": slot, "course": course["name"], "code": course["code"],
                              "room": ROOMS[(cid + s) % len(ROOMS)]})
    for d in WEEKDAYS:
        grid[d].sort(key=lambda a: DAY_SLOTS.index(a["time"]))
    return grid


# ------------------------------------------------------ Grievance triage
STUDENT_CATEGORIES = ["Academic", "Hostel", "Fees & Finance", "Ragging / Harassment", "Infrastructure", "Other"]
TEACHER_CATEGORIES = ["Academic / Curriculum", "Timetable & Workload", "Payroll & HR", "Infrastructure & Labs",
                      "Harassment / Workplace Conduct", "Administrative Support", "Other"]

_RULES = {
    "student": [
        ("Ragging / Harassment", ["harass", "bully", "ragging", "misconduct", "discriminat", "abuse", "threat", "unsafe", "stalk"]),
        ("Hostel", ["hostel", "warden", "roommate", "mess", "dormitory", "room heater"]),
        ("Fees & Finance", ["fee", "payment", "refund", "scholarship", "invoice", "overdue", "installment"]),
        ("Infrastructure", ["wifi", "wi-fi", "internet", "projector", "washroom", "toilet", "electricity", " ac ",
                            "classroom", "lab equipment", "fan", "water"]),
        ("Academic", ["exam", "marks", "grade", "attendance", "lecture", "syllabus", "assignment", "faculty", "professor", "result"]),
    ],
    "teacher": [
        ("Harassment / Workplace Conduct", ["harass", "bully", "misconduct", "discriminat", "abuse", "threat", "unsafe"]),
        ("Payroll & HR", ["salary", "payroll", "payslip", "reimbursement", "provident fund", " pf ", "leave balance", "increment"]),
        ("Timetable & Workload", ["timetable", "schedule", "workload", "overloaded", "clash", "back-to-back", "substitution"]),
        ("Infrastructure & Labs", ["wifi", "wi-fi", "internet", "projector", "lab equipment", "staffroom", "electricity", "classroom", " ac "]),
        ("Academic / Curriculum", ["syllabus", "curriculum", "exam duty", "invigilation", "grading policy", "academic calendar"]),
        ("Administrative Support", ["admin", "paperwork", "approval", "hr department"]),
    ],
}
ROUTING = {
    "Academic": "Academic Office", "Academic / Curriculum": "Academic Office", "Hostel": "Hostel Administration",
    "Fees & Finance": "Accounts Office", "Payroll & HR": "HR & Payroll", "Ragging / Harassment": "Anti-Ragging Committee",
    "Harassment / Workplace Conduct": "Internal Complaints Committee", "Infrastructure": "Estate & Maintenance",
    "Infrastructure & Labs": "Estate & Maintenance", "Timetable & Workload": "Dean (Academics)",
    "Administrative Support": "Registrar's Office", "Other": "Admin Office",
}
_HIGH_CATEGORIES = {"Ragging / Harassment", "Harassment / Workplace Conduct"}
_URGENT = ["urgent", "immediately", "emergency", "asap", "unsafe", "danger", "injur", "not working for", "since last", "for a week",
           "for two weeks", "for three days", "days"]


def classify_grievance(text: str, role: str, chosen_category: str = None) -> dict:
    t = f" {text.lower()} "
    categories = TEACHER_CATEGORIES if role == "teacher" else STUDENT_CATEGORIES
    auto = "Other"
    for category, keywords in _RULES["teacher" if role == "teacher" else "student"]:
        if any(k in t for k in keywords):
            auto = category
            break
    category = chosen_category if chosen_category in categories and chosen_category != "Other" else auto
    if category in _HIGH_CATEGORIES or auto in _HIGH_CATEGORIES:
        priority = "high"
    elif any(w in t for w in _URGENT):
        priority = "high" if category in ("Hostel", "Infrastructure", "Infrastructure & Labs") else "medium"
    elif category in ("Other", "Administrative Support"):
        priority = "low"
    else:
        priority = "medium"
    return {"category": category, "suggestedCategory": auto, "priority": priority, "routedTo": ROUTING.get(category, "Admin Office")}
