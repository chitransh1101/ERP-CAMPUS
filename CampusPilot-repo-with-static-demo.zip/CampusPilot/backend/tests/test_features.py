"""
Tests for: parent portal + alerts, exams (hall tickets, grade cards), QR
attendance, analytics (principal / HOD), accreditation report, academic
calendar, ID cards / certificates and QR verification.

    python -m tests.test_features
"""
import os
import sys
import tempfile
import traceback

_DB = os.path.join(tempfile.gettempdir(), "campuspilot_features_test.db")
for suffix in ("", "-wal", "-shm"):
    try:
        os.remove(_DB + suffix)
    except FileNotFoundError:
        pass
os.environ.update(DATABASE_URL=f"sqlite:///{_DB}", SEED_DEMO="true", RATE_LIMIT_PER_MINUTE="100000",
                  LOGIN_RATE_PER_MINUTE="100000", SIGNUP_RATE_PER_HOUR="100000", PUBLIC_URL="https://campus.example.edu")

from fastapi.testclient import TestClient  # noqa: E402

import seed  # noqa: E402
from app import messaging  # noqa: E402
from app.auth.auth import login_guard  # noqa: E402
from app.database.db import SessionLocal  # noqa: E402
from app.main import app  # noqa: E402
from app.models.models import AttendanceSession, Course, Enrollment, OutboundMessage, User  # noqa: E402
from app.routers import qr_router  # noqa: E402

seed.main()
ORIGIN = {"Origin": "http://localhost:8080"}


def login(email, password, role=None):
    login_guard.reset_all()
    c = TestClient(app)
    r = c.post("/auth/login", json={"email": email, "password": password, "role": role}, headers=ORIGIN)
    assert r.status_code == 200, r.text
    c.headers.update({"X-CSRF-Token": c.cookies.get("cp_csrf"), **ORIGIN})
    return c


def uid(email):
    db = SessionLocal()
    try:
        return f"u_{db.query(User).filter(User.email == email).one().id}"
    finally:
        db.close()


def course_id(code):
    db = SessionLocal()
    try:
        return f"c_{db.query(Course).filter(Course.code == code).one().id}"
    finally:
        db.close()


ADMIN = ("admin@campuspilot.edu", "admin123")
PARENT = ("parent@campuspilot.edu", "parent123")
ROHAN = ("rohan@campuspilot.edu", "student123")
PRIYA = ("priya@campuspilot.edu", "teach123")      # teaches CS301, HOD of Computer Science
ARJUN = ("arjun@campuspilot.edu", "teach123")      # teaches CS315/CS420, not an HOD


# ============================================================ parent portal
def test_parent_sees_only_linked_child():
    p = login(*PARENT, role="parent")
    kids = p.get("/parent/children").json()
    assert [k["name"] for k in kids] == ["Rohan Mehta"], kids
    rid = kids[0]["id"]
    for part in ("summary", "attendance", "grades", "fees", "notices", "exams", "timetable"):
        assert p.get(f"/parent/children/{rid}/{part}").status_code == 200, part
    other = uid("ananya@campuspilot.edu")
    assert p.get(f"/parent/children/{other}/grades").status_code == 404        # IDOR guard
    assert p.get("/student/summary").status_code == 403                         # not a student
    assert p.get("/admin/users").status_code == 403
    assert p.post("/copilot/chat", json={"question": "hi", "history": []}).status_code == 403


def test_parent_role_cannot_self_signup():
    r = TestClient(app).post("/auth/signup", json={"name": "X", "email": "x1@gmail.com", "password": "Str0ngPass!word", "role": "parent"})
    assert r.status_code == 422


def test_absence_alerts_parent_and_is_sent_by_worker():
    t = login(*PRIYA)
    cid = course_id("CS301")
    roster = t.get("/teacher/roster", params={"courseId": cid}).json()
    rohan = uid(ROHAN[0])
    records = [{"studentId": s["id"], "present": s["id"] != rohan} for s in roster]
    assert t.post("/teacher/attendance", json={"courseId": cid, "records": records}).status_code == 200
    db = SessionLocal()
    msgs = db.query(OutboundMessage).filter(OutboundMessage.kind == "absent").all()
    assert msgs and msgs[-1].status == "queued" and "ABSENT" in msgs[-1].body and msgs[-1].phone == "+919820012345"
    db.close()
    messaging.process_outbox()
    db = SessionLocal()
    assert db.query(OutboundMessage).filter(OutboundMessage.kind == "absent").first().status == "logged"
    db.close()
    p = login(*PARENT, role="parent")
    assert any("absent" in n["title"].lower() for n in p.get("/notifications/").json())
    assert any(m["kind"] == "absent" for m in p.get("/parent/messages").json())


def test_fee_payment_and_reminders_alert_parents():
    a = login(*ADMIN)
    fees = a.get("/admin/fees").json()
    rohan_fee = next(f for f in fees if f["idLabel"] == "CS21B045")
    if rohan_fee["due"] > 0:
        a.post(f"/admin/fees/{rohan_fee['id']}/mark-paid", json={"amount": 1000})
        db = SessionLocal()
        assert db.query(OutboundMessage).filter(OutboundMessage.kind == "fee_paid").count() >= 1
        db.close()
    r = a.post("/admin/messages/fee-reminders").json()
    assert r["students"] > 0
    out = a.get("/admin/messages").json()
    assert out["provider"]["provider"] == "log" and out["messages"]
    assert "•" in out["messages"][0]["phone"]                                  # phone masked in the admin list


def test_admin_links_parents():
    a = login(*ADMIN)
    ananya = uid("ananya@campuspilot.edu")
    r = a.post("/admin/parents", json={"name": "Kiran Rao", "email": "kiran.rao@example.com", "phone": "98765 43210",
                                       "studentId": ananya, "relation": "father"})
    assert r.status_code == 200 and r.json()["tempPassword"], r.text
    # linking the same parent to a second child reuses the account (no new password)
    diya = uid("diya@campuspilot.edu")
    r2 = a.post("/admin/parents", json={"name": "Kiran Rao", "email": "kiran.rao@example.com", "studentId": diya})
    assert r2.status_code == 200 and r2.json()["tempPassword"] is None
    assert a.post("/admin/parents", json={"name": "X", "email": "kiran.rao@example.com", "studentId": diya}).status_code == 400
    assert a.post("/admin/parents", json={"name": "X", "email": "priya@campuspilot.edu", "studentId": diya}).status_code == 400
    assert a.post("/admin/parents", json={"name": "X", "email": "y@example.com", "phone": "12", "studentId": diya}).status_code == 400
    links = a.get("/admin/parents").json()
    assert sum(1 for l in links if l["parent"]["email"] == "kiran.rao@example.com") == 2
    csv = "name,email,phone,student_id_label,relation\nMeena Singh,meena@example.com,+919811100000,CS21B078,Mother\nBad,bad@example.com,,XX000,\n"
    r = a.post("/admin/import/parents", files=[("file", ("p.csv", csv.encode(), "text/csv"))]).json()
    assert r["imported"] == 1 and len(r["errors"]) == 1 and r["credentials"]
    assert messaging.normalize_phone("098765 43210") == "+919876543210"
    assert messaging.normalize_phone("+1 (415) 555-0100") == "+14155550100"
    assert messaging.normalize_phone("12345") == ""


# ================================================================== exams
def test_exam_lifecycle_hall_ticket_and_grade_card():
    a, t, s = login(*ADMIN), login(*PRIYA), login(*ROHAN)
    cid = course_id("CS301")
    ex = a.post("/exams", json={"courseId": cid, "kind": "quiz", "date": "2099-01-15", "startTime": "09:30",
                                "durationMin": 60, "room": "Lab 3", "maxMarks": 20})
    assert ex.status_code == 200, ex.text
    ex = ex.json()
    assert t.get("/exams/teacher").status_code == 200 and any(e["id"] == ex["id"] for e in t.get("/exams/teacher").json())
    assert login(*ARJUN).get(f"/exams/{ex['id']}/results").status_code == 404     # not his course
    rows = t.get(f"/exams/{ex['id']}/results").json()["rows"]
    assert t.put(f"/exams/{ex['id']}/results", json={"entries": [{"studentId": rows[0]["studentId"], "marks": 25}]}).status_code == 400
    entries = [{"studentId": r["studentId"], "marks": 15 + i % 5} for i, r in enumerate(rows)]
    entries[0] = {"studentId": rows[0]["studentId"], "absent": True}
    assert t.put(f"/exams/{ex['id']}/results", json={"entries": entries}).json()["saved"] == len(rows)
    assert s.get("/exams/mine").json()["upcoming"]
    assert not any(r["id"] == ex["id"] for r in s.get("/exams/mine").json()["results"])   # not published yet
    assert t.post(f"/exams/{ex['id']}/publish").status_code == 200
    assert t.post(f"/exams/{ex['id']}/publish").status_code == 400
    mine = s.get("/exams/mine").json()
    assert any(r["id"] == ex["id"] for r in mine["results"]) and mine["gradeCard"]["courses"]
    for path in ("/exams/hall-ticket.pdf", "/exams/grade-card.pdf"):
        r = s.get(path)
        assert r.status_code == 200 and r.content[:4] == b"%PDF" and r.headers["content-type"] == "application/pdf", path
    assert t.get("/exams/hall-ticket.pdf").status_code == 403
    assert s.post("/exams", json={"courseId": cid, "date": "2099-01-16"}).status_code == 403
    assert a.delete(f"/exams/{ex['id']}").status_code == 400                     # published results can't be deleted


# ============================================================ QR attendance
def test_qr_checkin_flow():
    t, s = login(*PRIYA), login(*ROHAN)
    cid = course_id("CS301")
    sess = t.post("/teacher/qr-sessions", json={"courseId": cid}).json()
    live = t.get(f"/teacher/qr-sessions/{sess['id']}", params={"origin": "https://campus.example.edu"}).json()
    assert live["url"].startswith("https://campus.example.edu/checkin?s=") and len(live["code"]) == 6 and live["qr"]
    token = live["url"].split("t=")[1]
    assert s.post("/student/qr-checkin", json={"s": sess["id"], "t": "0000000000"}).status_code == 400
    r = s.post("/student/qr-checkin", json={"s": sess["id"], "t": token, "device": "dev-1"}).json()
    assert r["ok"] and not r["already"] and "CS301" in r["course"]
    assert s.post("/student/qr-checkin", json={"s": sess["id"], "t": token}).json()["already"]
    ananya = login("ananya@campuspilot.edu", "student123")
    code = t.get(f"/teacher/qr-sessions/{sess['id']}").json()["code"]
    assert ananya.post("/student/qr-checkin", json={"code": code, "device": "dev-1"}).json()["ok"]
    outsider = login("apillai@campuspilot.edu", "student123")                   # Maths student, not in CS301
    assert outsider.post("/student/qr-checkin", json={"s": sess["id"], "t": token}).status_code == 403
    view = t.get(f"/teacher/qr-sessions/{sess['id']}").json()
    assert view["present"] == 2 and all(x["sharedDevice"] for x in view["students"] if x["present"])
    assert login(*ARJUN).get(f"/teacher/qr-sessions/{sess['id']}").status_code == 404
    pub = t.post(f"/teacher/qr-sessions/{sess['id']}/publish").json()
    assert pub["present"] == 2 and pub["total"] == view["total"]
    db = SessionLocal()
    last = db.query(AttendanceSession).order_by(AttendanceSession.id.desc()).first()
    assert last.method == "qr" and sum(r.present for r in last.records) == 2
    db.close()
    assert s.post("/student/qr-checkin", json={"s": sess["id"], "t": token}).status_code == 400   # closed


def test_qr_code_guessing_is_rate_limited():
    qr_router.checkin_limiter.reset()
    s = login("kabir@campuspilot.edu", "student123")
    codes = [s.post("/student/qr-checkin", json={"code": f"{i:06d}"}).status_code for i in range(14)]
    assert codes[-1] == 429 and 400 in codes


# ================================================================ analytics
def test_analytics_scoping():
    a = login(*ADMIN)
    full = a.get("/analytics").json()
    assert full["kpis"]["students"] > 0 and len(full["departments"]) >= 3 and full["heatmap"]
    hod = login(*PRIYA)
    assert hod.get("/analytics/access").json() == {"allowed": True, "dept": "Computer Science"}
    mine = hod.get("/analytics", params={"dept": "Physics"}).json()          # asking for another dept is ignored
    assert [d["dept"] for d in mine["departments"]] == ["Computer Science"]
    assert login(*ARJUN).get("/analytics").status_code == 403
    assert login(*ROHAN).get("/analytics").status_code == 403
    r = hod.get("/analytics/report.pdf")
    assert r.status_code == 200 and r.content[:4] == b"%PDF"
    # admin re-assigns the CS HOD -> access moves with it
    arjun = uid(ARJUN[0])
    assert a.put("/admin/department-heads", json={"dept": "Computer Science", "userId": arjun}).status_code == 200
    assert login(*ARJUN).get("/analytics").status_code == 200
    assert login(*PRIYA).get("/analytics").status_code == 403
    assert a.put("/admin/department-heads", json={"dept": "Computer Science", "userId": uid(ROHAN[0])}).status_code == 400
    a.put("/admin/department-heads", json={"dept": "Computer Science", "userId": uid(PRIYA[0])})


def test_accreditation_report():
    a = login(*ADMIN)
    rep = a.get("/admin/accreditation").json()
    keys = [s["key"] for s in rep["sections"]]
    assert keys == ["c2", "c4", "c5", "c6", "nba"]
    co = rep["sections"][-1]["tables"][0]["rows"]
    assert co and all(r[3] in (0, 1, 2, 3) for r in co)
    r = a.get("/admin/accreditation/report.pdf")
    assert r.status_code == 200 and r.content[:4] == b"%PDF"
    assert login(*PRIYA).get("/admin/accreditation").status_code == 403


# ================================================================= calendar
def test_calendar_views():
    from datetime import date, timedelta
    a, s, p = login(*ADMIN), login(*ROHAN), login(*PARENT, role="parent")
    month = (date.today() + timedelta(days=14)).strftime("%Y-%m")
    items = s.get("/calendar", params={"month": month}).json()["items"]
    assert any(i["kind"] == "exam" for i in items) and any(i["kind"] == "exam-week" for i in items)
    rid = uid(ROHAN[0])
    assert p.get("/calendar", params={"month": month, "studentId": rid}).status_code == 200
    assert p.get("/calendar", params={"month": month, "studentId": uid("ananya@campuspilot.edu")}).status_code == 404
    ev = a.post("/admin/calendar", json={"title": "Founders' Day", "date": f"{month}-20", "kind": "holiday"})
    assert ev.status_code == 200
    assert any(i["title"] == "Founders' Day" for i in s.get("/calendar", params={"month": month}).json()["items"])
    assert s.post("/admin/calendar", json={"title": "x", "date": f"{month}-21"}).status_code == 403
    assert a.post("/admin/calendar", json={"title": "x", "date": f"{month}-21", "endDate": f"{month}-01"}).status_code == 400
    assert a.delete(f"/admin/calendar/{ev.json()['id']}").status_code == 200
    assert s.get("/calendar", params={"month": "2026-13"}).status_code in (400, 422)


# ======================================================= documents & verify
def test_id_cards_certificates_and_verification():
    s, t, p = login(*ROHAN), login(*PRIYA), login(*PARENT, role="parent")
    for c in (s, t):
        r = c.get("/documents/id-card.pdf")
        assert r.status_code == 200 and r.content[:4] == b"%PDF"
    assert p.get("/documents/id-card.pdf").status_code == 403
    r = s.post("/documents/bonafide", json={"purpose": "Opening a bank account"})
    assert r.status_code == 200 and r.content[:4] == b"%PDF"
    assert s.post("/documents/bonafide", json={"purpose": "x"}).status_code == 422
    docs = s.get("/documents/mine").json()
    bon = next(d for d in docs if d["kind"] == "bonafide")
    from app import documents
    db = SessionLocal()
    rohan = db.query(User).filter(User.email == ROHAN[0]).one()
    good = documents.sign_token("bonafide", rohan.id, int(bon["id"].split("_")[1]))
    db.close()
    anon = TestClient(app)
    v = anon.get(f"/verify/{good}").json()
    assert v["valid"] and v["name"] == "Rohan Mehta" and v["reference"] == bon["ref"] and "email" not in v
    forged = good[:-3] + ("AAA" if good[-3:] != "AAA" else "BBB")
    assert anon.get(f"/verify/{forged}").json()["valid"] is False
    wrong_doc = documents.sign_token("bonafide", rohan.id, 999999)
    assert anon.get(f"/verify/{wrong_doc}").json()["valid"] is False


# ================================================================== runner
def main():
    tests = [(n, f) for n, f in globals().items() if n.startswith("test_") and callable(f)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"PASS  {name}")
        except Exception:
            failed += 1
            print(f"FAIL  {name}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
