"""
Generates realistic test photos of attendance sheets (printed, then
"photographed": perspective, tilt, uneven light, blur, noise, JPEG) so the
OCR pipeline can be measured against known ground truth.

    python -m tests.make_sheets  -> writes tests/sheets/*.jpg + truth.json
"""
import json
import math
import os
import random

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FONT_B = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
if not os.path.exists(FONT):  # pragma: no cover
    FONT = FONT_B = None


def _font(size, bold=False):
    path = FONT_B if bold else FONT
    return ImageFont.truetype(path, size) if path else ImageFont.load_default()


def _scribble(draw, x, y, w, h, rng):
    pts = []
    for i in range(18):
        pts.append((x + w * i / 17, y + h / 2 + math.sin(i * rng.uniform(0.8, 1.6)) * h * 0.35 + rng.uniform(-3, 3)))
    draw.line(pts, fill=(20, 30, 90), width=3)


def render_daily(students, marks, title, signature=False, rng=None):
    rng = rng or random.Random(1)
    W, row_h = 1700, 62
    H = 260 + row_h * (len(students) + 1)
    img = Image.new("RGB", (W, H), "white")
    d = ImageDraw.Draw(img)
    d.text((80, 60), title, font=_font(44, True), fill="black")
    cols = [80, 200, 520, 1150, 1600]
    heads = ["S.No", "Roll No", "Student Name", "Signature" if signature else "Status"]
    y0 = 170
    for i, h in enumerate(heads):
        d.text((cols[i] + 14, y0 + 14), h, font=_font(30, True), fill="black")
    for r in range(len(students) + 2):
        d.line([(cols[0], y0 + r * row_h), (cols[-1], y0 + r * row_h)], fill="black", width=2)
    for c in cols:
        d.line([(c, y0), (c, y0 + (len(students) + 1) * row_h)], fill="black", width=2)
    for i, (s, m) in enumerate(zip(students, marks)):
        y = y0 + (i + 1) * row_h + 14
        d.text((cols[0] + 14, y), str(i + 1), font=_font(30), fill="black")
        d.text((cols[1] + 14, y), s["idLabel"], font=_font(30), fill="black")
        d.text((cols[2] + 14, y), s["name"], font=_font(30), fill="black")
        if signature:
            if m == "present":
                _scribble(d, cols[3] + 40, y - 6, 260, 40, rng)
        else:
            d.text((cols[3] + 60, y), "P" if m == "present" else "A", font=_font(32, True),
                   fill=(10, 60, 10) if m == "present" else (150, 0, 0))
    return img


def render_register(students, day_marks, days=30, title="Attendance Register — September"):
    W = 380 + days * 52 + 60
    row_h = 52
    H = 240 + row_h * (len(students) + 1)
    img = Image.new("RGB", (W, H), "white")
    d = ImageDraw.Draw(img)
    d.text((60, 50), title, font=_font(44, True), fill=(20, 40, 110))
    y0, x_name, x0 = 150, 60, 380
    d.text((x_name + 10, y0 + 12), "Name", font=_font(26, True), fill="black")
    for k in range(days):
        d.text((x0 + k * 52 + 10, y0 + 12), f"{k + 1:02d}", font=_font(24, True), fill="black")
    for r in range(len(students) + 2):
        d.line([(x_name, y0 + r * row_h), (x0 + days * 52, y0 + r * row_h)], fill=(90, 90, 90), width=2)
    for k in range(days + 1):
        d.line([(x0 + k * 52, y0), (x0 + k * 52, y0 + (len(students) + 1) * row_h)], fill=(90, 90, 90), width=1)
    for i, s in enumerate(students):
        y = y0 + (i + 1) * row_h
        if i % 2 == 0:
            d.rectangle([x0 + 1, y + 1, x0 + days * 52 - 1, y + row_h - 1], fill=(220, 240, 220))
        d.text((x_name + 10, y + 12), s["name"], font=_font(26), fill="black")
        for k in range(days):
            m = day_marks[i][k]
            if m:
                d.text((x0 + k * 52 + 16, y + 12), m, font=_font(26, True), fill=(160, 0, 0) if m == "A" else "black")
    return img


def photograph(img: Image.Image, rng: random.Random, strength=1.0):
    """Simulates a handheld phone photo of the printed page."""
    page = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
    h, w = page.shape[:2]
    pad = int(0.12 * max(h, w))
    canvas = np.full((h + 2 * pad, w + 2 * pad, 3), (70, 95, 120), np.uint8)  # desk
    src = np.float32([[0, 0], [w, 0], [w, h], [0, h]])
    j = lambda: rng.uniform(-0.035, 0.035) * max(w, h) * strength
    dst = np.float32([[pad + j(), pad + j()], [pad + w + j(), pad + j()], [pad + w + j(), pad + h + j()], [pad + j(), pad + h + j()]])
    M = cv2.getPerspectiveTransform(src, dst)
    canvas = cv2.warpPerspective(page, M, (canvas.shape[1], canvas.shape[0]), dst=canvas, borderMode=cv2.BORDER_TRANSPARENT)
    ch, cw = canvas.shape[:2]
    rot = cv2.getRotationMatrix2D((cw / 2, ch / 2), rng.uniform(-4, 4) * strength, 1.0)
    canvas = cv2.warpAffine(canvas, rot, (cw, ch), borderValue=(70, 95, 120))
    yy, xx = np.mgrid[0:ch, 0:cw].astype(np.float32)
    light = 0.72 + 0.28 * (xx / cw) * (1 - 0.4 * yy / ch)  # shadow on one side
    canvas = np.clip(canvas.astype(np.float32) * light[..., None], 0, 255).astype(np.uint8)
    canvas = cv2.GaussianBlur(canvas, (0, 0), 1.1 * strength)
    noise = np.random.default_rng(rng.randint(0, 9999)).normal(0, 7 * strength, canvas.shape)
    canvas = np.clip(canvas + noise, 0, 255).astype(np.uint8)
    scale = 1600 / max(ch, cw)  # typical phone upload after browser resize
    canvas = cv2.resize(canvas, (int(cw * scale), int(ch * scale)), interpolation=cv2.INTER_AREA)
    ok, buf = cv2.imencode(".jpg", canvas, [cv2.IMWRITE_JPEG_QUALITY, 72])
    return buf.tobytes()


def default_roster():
    names = [("Rohan Mehta", "CS21B045"), ("Ananya Rao", "CS21B012"), ("Kabir Singh", "CS21B078"), ("Diya Nair", "CS21B033"),
             ("Zoya Khan", "CS21B061"), ("Arnav Gupta", "CS22B019"), ("Ishita Verma", "CS22B027"), ("Vivaan Joshi", "CS22B054"),
             ("Myra Kapoor", "CS20B008"), ("Aarav Malhotra", "CS20B071"), ("Saanvi Reddy", "CS23B003"), ("Reyansh Iyer", "CS23B041"),
             ("Ananya Pillai", "MA21B014"), ("Krishna Bhat", "MA22B022"), ("Advika Menon", "MA20B009"), ("Vihaan Chatterjee", "MA23B017"),
             ("Riya Desai", "EC21B028"), ("Aryan Kulkarni", "EC22B036"), ("Navya Sharma", "EC20B015"), ("Dhruv Agarwal", "EC23B052")]
    return [{"studentId": f"u_{i + 100}", "name": n, "idLabel": r} for i, (n, r) in enumerate(names)]


def main(out_dir=os.path.join(os.path.dirname(__file__), "sheets")):
    os.makedirs(out_dir, exist_ok=True)
    rng = random.Random(7)
    roster = default_roster()
    truth = {}

    marks = ["present" if rng.random() > 0.25 else "absent" for _ in roster]
    # Two-page daily sheet: page 1 = first 12 students, page 2 = the rest.
    for page, (a, b) in enumerate([(0, 12), (12, 20)], start=1):
        img = render_daily(roster[a:b], marks[a:b], f"CS301 Data Structures — 26 Sep 2026 (page {page})")
        name = f"daily_p{page}.jpg"
        open(os.path.join(out_dir, name), "wb").write(photograph(img, rng))
        truth[name] = {s["studentId"]: m for s, m in zip(roster[a:b], marks[a:b])}

    sig_marks = ["present" if rng.random() > 0.3 else "absent" for _ in roster]
    img = render_daily(roster, sig_marks, "Sign-in sheet — MA201 — 26 Sep 2026", signature=True, rng=rng)
    open(os.path.join(out_dir, "signin.jpg"), "wb").write(photograph(img, rng))
    truth["signin.jpg"] = {s["studentId"]: m for s, m in zip(roster, sig_marks)}

    days = 30
    grid = [[("P" if rng.random() > 0.2 else "A") if (k + 1) % 7 != 0 else "" for k in range(days)] for _ in roster]
    img = render_register(roster, grid, days)
    open(os.path.join(out_dir, "register.jpg"), "wb").write(photograph(img, rng, strength=0.7))
    truth["register.jpg"] = {"day": 26, "marks": {s["studentId"]: ("present" if grid[i][25] == "P" else "absent")
                                                   for i, s in enumerate(roster)}}
    json.dump({"roster": roster, "truth": truth}, open(os.path.join(out_dir, "truth.json"), "w"), indent=1)
    print("wrote", sorted(os.listdir(out_dir)))


if __name__ == "__main__":
    main()
