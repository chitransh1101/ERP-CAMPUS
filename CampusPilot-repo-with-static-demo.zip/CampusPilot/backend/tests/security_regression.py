"""
Replays every security bug found in the original CampusPilot against a
running server and reports whether the attack still works.

    python -m tests.security_regression http://localhost:8000
    python -m tests.security_regression http://localhost:8001 --old   # original code

"EXPLOITABLE" = the bug is present, "BLOCKED" = fixed.
"""
import io
import sys
import threading
import time

import httpx

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8000"
OLD = "--old" in sys.argv
c = httpx.Client(base_url=BASE, timeout=120)
results = []


def login(email, pw, role=None):
    r = c.post("/auth/login", json={"email": email, "password": pw, "role": role})
    return {"Authorization": f"Bearer {r.json()['token']}"} if r.status_code == 200 else None


def report(name, exploitable, evidence):
    results.append((name, exploitable, evidence))


admin = login("admin@campuspilot.edu", "admin123")
priya = login("priya@campuspilot.edu", "teach123")
rohan = login("rohan@campuspilot.edu", "student123")
ananya = login("ananya@campuspilot.edu", "student123")
users = c.get("/admin/users", headers=admin).json()
uid = {u["email"]: u["id"] for u in users}
courses = c.get("/admin/courses", headers=admin).json()
cs315 = next(x for x in courses if x["code"] == "CS315")          # Prof. Arjun's course, not Priya's

# 1. Wildcard email login
r = c.post("/auth/login", json={"email": "%", "password": "admin123"})
report("1. Log in as admin with email '%'", r.status_code == 200,
       f"HTTP {r.status_code}" + (f", logged in as {r.json()['user']['name']} ({r.json()['user']['role']})" if r.status_code == 200 else ""))

# 2. Deactivated user keeps access
kabir = login("kabir@campuspilot.edu", "student123")
c.patch(f"/admin/users/{uid['kabir@campuspilot.edu']}/status", json={"status": "inactive"}, headers=admin)
r = c.get("/student/summary", headers=kabir)
report("2. Deactivated student still uses old token", r.status_code == 200, f"HTTP {r.status_code}")
c.patch(f"/admin/users/{uid['kabir@campuspilot.edu']}/status", json={"status": "active"}, headers=admin)

# 3. Logout doesn't revoke the token
tok = login("diya@campuspilot.edu", "student123")
c.post("/auth/logout", headers=tok)
r = c.get("/student/summary", headers=tok)
report("3. Token still works after logout", r.status_code == 200, f"HTTP {r.status_code}")

# 4. Teacher marks attendance / grades in someone else's course
some_student = uid["rohan@campuspilot.edu"]
r1 = c.post("/teacher/attendance", headers=priya, json={"courseId": cs315["id"], "courseLabel": "x", "records": [{"studentId": some_student, "present": False}]})
r2 = c.post("/teacher/grades", headers=priya, json={"courseId": cs315["id"], "courseLabel": "x", "assessment": "Hack", "entries": [{"studentId": some_student, "score": 0}]})
report("4. Teacher edits another teacher's course", r1.status_code == 200 or r2.status_code == 200, f"attendance HTTP {r1.status_code}, grades HTTP {r2.status_code}")

# 5. One student's submission marks it done for everyone
mine = c.get("/student/assignments", headers=rohan).json()
hers = {a["id"]: a["status"] for a in c.get("/student/assignments", headers=ananya).json()}
target = next((a for a in mine if a["status"] == "pending" and hers.get(a["id"]) == "pending"), None)
if target:
    c.post(f"/student/assignments/{target['id']}/submit", headers=rohan)
    after = {a["id"]: a["status"] for a in c.get("/student/assignments", headers=ananya).json()}
    report("5. One student's submit marks it done for all", after.get(target["id"]) == "submitted", f"other student's status became '{after.get(target['id'])}'")

# 6. Private notification leaks to every student
before = len(c.get("/notifications/", headers=rohan).json())
apps = []
for p in c.get("/placements/", headers=admin).json():
    apps += c.get(f"/placements/{p['id']}/applicants", headers=admin).json()
other_app = next(a for a in apps if a["studentName"] != "Rohan Mehta")
c.patch(f"/placements/applications/{other_app['id']}", json={"status": "rejected"}, headers=admin)
leaked = [n for n in c.get("/notifications/", headers=rohan).json()[: max(0, len(c.get("/notifications/", headers=rohan).json()) - before) or 0]
          if "Placement" in n["title"]]
report("6. Rohan sees another student's rejection notice", bool(leaked), f"{len(leaked)} leaked notification(s)")

# 7. Ineligible student applies to a placement drive
drive = c.post("/placements/", headers=admin, json={"company": "SecTest", "role": "SDE", "package": "1", "location": "x", "minCGPA": 9.99, "minAttendance": 100, "deadline": "1 Jan"}).json()
r = c.post(f"/placements/{drive['id']}/apply", headers=rohan)
report("7. Ineligible student applies anyway (via API)", r.status_code == 200, f"HTTP {r.status_code}")

# 8. Non-image upload accepted / fake attendance returned
r = c.post("/teacher/attendance/ocr", headers=priya, files=[("file", ("evil.jpg", b"<?php system($_GET['c']); ?>", "image/jpeg"))])
fake = r.status_code == 200 and r.json().get("source") == "simulated"
report("8. Garbage 'photo' accepted; random fake attendance returned", r.status_code == 200,
       f"HTTP {r.status_code}" + (" — returned RANDOM attendance for every student" if fake else ""))

# 9. OCR blocks the whole server
photo = open("tests/sheets/register.jpg", "rb").read()
t = threading.Thread(target=lambda: c.post("/teacher/attendance/ocr", headers=priya, files=[("file", ("r.jpg", photo, "image/jpeg"))]))
t.start()
time.sleep(0.8)
t0 = time.time()
httpx.get(BASE + "/health", timeout=120)
lag = time.time() - t0
t.join()
report("9. Server frozen while a photo is being read", lag > 1.0, f"/health took {lag:.2f}s during OCR")

# 10. Weak passwords
r = c.post("/auth/signup", json={"name": "Weak", "email": "weak@campuspilot.edu", "password": "abcd", "role": "student"})
report("10. Sign up with password 'abcd'", r.status_code == 200, f"HTTP {r.status_code}")

# 11. Same default password for every admin-created user
c.post("/admin/users", headers=admin, json={"name": "New Teacher", "email": "newt@campuspilot.edu", "role": "teacher"})
r = c.post("/auth/login", json={"email": "newt@campuspilot.edu", "password": "changeme123"})
report("11. New account opens with shared password 'changeme123'", r.status_code == 200, f"HTTP {r.status_code}")

# 12. No input length limits
r = c.post("/student/grievances", headers=rohan, json={"category": "Other", "description": "A" * 200_000})
report("12. 200,000-character grievance accepted", r.status_code == 200, f"HTTP {r.status_code}")

# 13. CORS open to any website
r = c.get("/health", headers={"Origin": "https://evil.example"})
acao = r.headers.get("access-control-allow-origin")
report("13. Any website allowed to call the API (CORS)", acao in ("*", "https://evil.example"), f"Access-Control-Allow-Origin: {acao}")

# 14. Missing security headers
missing = [h for h in ("x-content-type-options", "x-frame-options", "content-security-policy") if h not in r.headers]
report("14. Security headers missing", bool(missing), f"missing: {missing or 'none'}")

# 15. No per-IP rate limit (password spraying across many accounts)
codes = [c.post("/auth/login", json={"email": f"user{i}@campuspilot.edu", "password": "Guess1234"}).status_code for i in range(15)]
report("15. Unlimited login attempts from one IP", 429 not in codes, f"15 attempts → {'429 after ' + str(codes.index(429)) if 429 in codes else 'never limited'}")

print(f"\n{'ORIGINAL' if OLD else 'NEW'} code at {BASE}\n")
for name, bad, ev in results:
    print(f"{'EXPLOITABLE' if bad else 'BLOCKED    '}  {name:58} {ev}")
print(f"\n{sum(1 for _, b, _ in results if not b)}/{len(results)} blocked")
