"""
End-to-end API tests: security guarantees + every major feature.

Runs against a throwaway SQLite database seeded with demo data.
    python -m tests.test_api          (no extra packages needed)
    pytest tests/test_api.py          (if you have pytest)
"""
import io
import json
import os
import sys
import tempfile
import traceback

_DB = os.path.join(tempfile.gettempdir(), "campuspilot_test.db")
for suffix in ("", "-wal", "-shm"):
    try:
        os.remove(_DB + suffix)
    except FileNotFoundError:
        pass
os.environ.update(DATABASE_URL=f"sqlite:///{_DB}", SEED_DEMO="true", RATE_LIMIT_PER_MINUTE="100000",
                  LOGIN_RATE_PER_MINUTE="100000", SIGNUP_RATE_PER_HOUR="100000", OCR_RATE_PER_MINUTE="1000")

from fastapi.testclient import TestClient  # noqa: E402

import seed  # noqa: E402
from app.auth.auth import login_guard  # noqa: E402
from app.database.db import SessionLocal  # noqa: E402
from app.main import app  # noqa: E402
from app.models.models import AttendanceRecord, Course, Enrollment, User  # noqa: E402

seed.main()
ORIGIN = {"Origin": "http://localhost:8080"}


def client():
    return TestClient(app)


def login(email, password, role=None, c=None):
    c = c or client()
    r = c.post("/auth/login", json={"email": email, "password": password, "role": role}, headers=ORIGIN)
    assert r.status_code == 200, r.text
    c.headers.update({"X-CSRF-Token": c.cookies.get("cp_csrf"), **ORIGIN})
    return c


def bearer(email, password):
    r = client().post("/auth/login", json={"email": email, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['token']}"}


def db_():
    return SessionLocal()


# ================================================================ SECURITY
def test_wildcard_email_cannot_log_in():
    login_guard.reset_all()
    for pattern in ("%", "%@campuspilot.edu", "admin@campuspilot.ed_", "ADMIN@CAMPUSPILOT.EDU%"):
        r = client().post("/auth/login", json={"email": pattern, "password": "admin123"})
        assert r.status_code in (401, 422), (pattern, r.status_code, r.text)  # never 200


def test_login_is_case_insensitive_but_exact():
    assert client().post("/auth/login", json={"email": " Admin@CampusPilot.edu ", "password": "admin123"}).status_code == 200


def test_unknown_email_and_wrong_password_look_identical():
    login_guard.reset_all()
    a = client().post("/auth/login", json={"email": "nobody@campuspilot.edu", "password": "x1234567"})
    b = client().post("/auth/login", json={"email": "rohan@campuspilot.edu", "password": "wrongpass1"})
    assert a.status_code == b.status_code == 401 and a.json() == b.json()


def test_lockout_after_repeated_failures():
    login_guard.reset_all()
    codes = [client().post("/auth/login", json={"email": "diya@campuspilot.edu", "password": f"bad{i}xxxx"}).status_code for i in range(6)]
    assert codes[:4] == [401] * 4 and 429 in codes[4:], codes
    # even the right password is refused while locked
    assert client().post("/auth/login", json={"email": "diya@campuspilot.edu", "password": "student123"}).status_code == 429
    login_guard.reset_all()


def test_session_cookie_is_httponly_and_token_hidden_from_browsers():
    c = client()
    r = c.post("/auth/login", json={"email": "rohan@campuspilot.edu", "password": "student123"}, headers=ORIGIN)
    assert "token" not in r.json()
    set_cookie = r.headers.get("set-cookie", "")
    assert "cp_session=" in set_cookie and "HttpOnly" in set_cookie and "SameSite=lax" in set_cookie


def test_csrf_required_for_cookie_writes():
    c = login("rohan@campuspilot.edu", "student123")
    token = c.headers.pop("X-CSRF-Token")
    r = c.post("/student/grievances", json={"category": "Academic", "description": "Testing CSRF protection here."})
    assert r.status_code == 403 and "CSRF" in r.json()["detail"]
    r = c.post("/student/grievances", json={"category": "Academic", "description": "Testing CSRF protection here."},
               headers={"X-CSRF-Token": "forged-value"})
    assert r.status_code == 403
    r = c.post("/student/grievances", json={"category": "Academic", "description": "Testing CSRF protection here."},
               headers={"X-CSRF-Token": token})
    assert r.status_code == 200, r.text


def test_logout_revokes_the_token():
    h = bearer("ananya@campuspilot.edu", "student123")
    c = client()
    assert c.get("/auth/me", headers=h).status_code == 200
    assert c.post("/auth/logout", headers=h).status_code == 200
    assert c.get("/auth/me", headers=h).status_code == 401


def test_deactivated_user_is_locked_out_immediately():
    victim = bearer("kabir@campuspilot.edu", "student123")
    assert client().get("/student/summary", headers=victim).status_code == 200
    admin = login("admin@campuspilot.edu", "admin123")
    db = db_()
    uid = db.query(User).filter_by(email="kabir@campuspilot.edu").one().id
    db.close()
    assert admin.patch(f"/admin/users/u_{uid}/status", json={"status": "inactive"}).status_code == 200
    assert client().get("/student/summary", headers=victim).status_code == 401  # old token no longer works
    admin.patch(f"/admin/users/u_{uid}/status", json={"status": "active"})


def test_admin_cannot_deactivate_self():
    admin = login("admin@campuspilot.edu", "admin123")
    me = admin.get("/auth/me").json()
    assert admin.patch(f"/admin/users/{me['id']}/status", json={"status": "inactive"}).status_code == 400


def test_role_isolation():
    s = bearer("rohan@campuspilot.edu", "student123")
    t = bearer("priya@campuspilot.edu", "teach123")
    c = client()
    assert c.get("/admin/users", headers=s).status_code == 403
    assert c.get("/admin/users", headers=t).status_code == 403
    assert c.get("/teacher/roster", headers=s).status_code == 403
    assert c.get("/admin/users").status_code == 401


def test_teacher_cannot_touch_another_teachers_course():
    t = login("priya@campuspilot.edu", "teach123")
    db = db_()
    other = db.query(Course).filter_by(code="CS315").one()  # Prof. Arjun's course
    sid = db.query(Enrollment).filter_by(course_id=other.id).first().student_id
    db.close()
    rec = [{"studentId": f"u_{sid}", "present": True}]
    assert t.post("/teacher/attendance", json={"courseId": f"c_{other.id}", "records": rec}).status_code == 404
    assert t.post("/teacher/grades", json={"courseId": f"c_{other.id}", "assessment": "Hack", "entries": [{"studentId": f"u_{sid}", "score": 100}]}).status_code == 404
    assert t.get(f"/teacher/roster?courseId=c_{other.id}").status_code == 404


def test_teacher_cannot_grade_unenrolled_students():
    t = login("priya@campuspilot.edu", "teach123")
    db = db_()
    cs301 = db.query(Course).filter_by(code="CS301").one()
    outsider = db.query(User).filter_by(id_label="PH21B006").one()
    db.close()
    r = t.post("/teacher/grades", json={"courseId": f"c_{cs301.id}", "assessment": "Quiz", "entries": [{"studentId": f"u_{outsider.id}", "score": 90}]})
    assert r.status_code == 400


def test_scores_are_range_checked():
    t = login("priya@campuspilot.edu", "teach123")
    r = t.post("/teacher/grades", json={"courseId": "c_1", "assessment": "Quiz", "entries": [{"studentId": "u_20", "score": 1000}]})
    assert r.status_code == 422


def test_malformed_ids_are_404_not_500():
    admin = login("admin@campuspilot.edu", "admin123")
    for path in ("/admin/fees/f_abc/mark-paid", "/admin/fees/x/mark-paid", "/admin/grievances/grv_99999999/resolve"):
        assert admin.post(path, json={}).status_code == 404, path


def test_input_limits():
    s = login("rohan@campuspilot.edu", "student123")
    assert s.post("/student/grievances", json={"category": "Other", "description": "x" * 5000}).status_code == 422
    assert s.post("/student/grievances", json={"category": "Other", "description": "short"}).status_code == 422


def test_password_policy_and_signup_rules():
    c = client()
    weak = c.post("/auth/signup", json={"name": "New Kid", "email": "newkid@campuspilot.edu", "password": "abc", "role": "student"})
    assert weak.status_code == 400
    common = c.post("/auth/signup", json={"name": "New Kid", "email": "newkid@campuspilot.edu", "password": "password123", "role": "student"})
    assert common.status_code == 400
    admin = c.post("/auth/signup", json={"name": "Evil", "email": "evil@campuspilot.edu", "password": "Str0ngPassw0rd", "role": "admin"})
    assert admin.status_code == 403
    dup_roll = c.post("/auth/signup", json={"name": "Imposter", "email": "imp@campuspilot.edu", "password": "Str0ngPassw0rd",
                                             "role": "student", "idLabel": "cs21b045"})
    assert dup_roll.status_code == 400  # can't claim someone else's roll number (OCR identity)
    ok = c.post("/auth/signup", json={"name": "New Kid", "email": "newkid@campuspilot.edu", "password": "Str0ngPassw0rd", "role": "student"})
    assert ok.status_code == 200, ok.text


def test_admin_created_users_get_unique_temp_passwords():
    admin = login("admin@campuspilot.edu", "admin123")
    a = admin.post("/admin/users", json={"name": "T One", "email": "tone@campuspilot.edu", "role": "teacher"}).json()
    b = admin.post("/admin/users", json={"name": "T Two", "email": "ttwo@campuspilot.edu", "role": "teacher"}).json()
    assert a["tempPassword"] != b["tempPassword"] and a["mustChangePassword"]
    c = login("tone@campuspilot.edu", a["tempPassword"])
    r = c.post("/auth/change-password", json={"currentPassword": a["tempPassword"], "newPassword": "BrandNew2026x"})
    assert r.status_code == 200 and not r.json()["user"]["mustChangePassword"]


def test_security_headers_and_cors():
    r = client().get("/health", headers={"Origin": "https://evil.example"})
    assert r.headers["x-content-type-options"] == "nosniff" and r.headers["x-frame-options"] == "DENY"
    assert "access-control-allow-origin" not in r.headers
    r = client().get("/health", headers=ORIGIN)
    assert r.headers.get("access-control-allow-origin") == ORIGIN["Origin"]


def test_uploads_are_validated():
    t = login("priya@campuspilot.edu", "teach123")
    d = t.post("/teacher/attendance/drafts", json={"courseId": _course_id("CS301")}).json()
    r = t.post(f"/teacher/attendance/drafts/{d['id']}/photos", files=[("files", ("evil.jpg", b"<?php system($_GET['c']); ?>", "image/jpeg"))])
    assert r.status_code == 415, r.text
    big = b"\xff\xd8\xff" + b"0" * (13 * 1024 * 1024)
    r = t.post(f"/teacher/attendance/drafts/{d['id']}/photos", files=[("files", ("big.jpg", big, "image/jpeg"))])
    assert r.status_code == 413
    t.delete(f"/teacher/attendance/drafts/{d['id']}")


# ================================================================ FEATURES
def _course_id(code):
    db = db_()
    cid = db.query(Course).filter_by(code=code).one().id
    db.close()
    return f"c_{cid}"


def test_ocr_multi_photo_draft_publish_and_realtime_push():
    import random
    from tests.make_sheets import photograph, render_daily
    t = login("priya@campuspilot.edu", "teach123")
    cid = _course_id("CS301")
    roster = t.get(f"/teacher/roster?courseId={cid}").json()
    rng = random.Random(3)
    truth = {s["studentId"]: ("present" if rng.random() > 0.3 else "absent") for s in roster}
    half = len(roster) // 2
    pages = [roster[:half], roster[half:]]
    photos = [photograph(render_daily(p, [truth[s["studentId"]] for s in p], f"CS301 page {i + 1}"), rng)
              for i, p in enumerate(pages)]

    with t.websocket_connect("/ws") as ws:
        assert ws.receive_json()["type"] == "hello"
        draft = t.post("/teacher/attendance/drafts", json={"courseId": cid}).json()
        assert draft["summary"]["unseen"] == len(roster)
        # page 1, then page 2 (as if snapped one after another on a phone)
        r1 = t.post(f"/teacher/attendance/drafts/{draft['id']}/photos", files=[("files", ("p1.jpg", photos[0], "image/jpeg"))])
        assert r1.status_code == 200, r1.text
        pushed = ws.receive_json()
        assert pushed["type"] == "draft:update" and pushed["data"]["summary"]["photos"] == 1
        r2 = t.post(f"/teacher/attendance/drafts/{draft['id']}/photos", files=[("files", ("p2.jpg", photos[1], "image/jpeg"))]).json()
    got = {s["studentId"]: s["status"] for s in r2["students"]}
    correct = sum(got[k] == v for k, v in truth.items())
    print(f"      OCR draft: {correct}/{len(truth)} correct, summary={r2['summary']}")
    assert correct >= len(truth) - 1
    # teacher corrects anything flagged, then publishes
    for s in r2["students"]:
        if s["needsReview"] or got[s["studentId"]] != truth[s["studentId"]]:
            t.patch(f"/teacher/attendance/drafts/{draft['id']}/students/{s['studentId']}", json={"present": truth[s["studentId"]] == "present"})
    pub = t.post(f"/teacher/attendance/drafts/{draft['id']}/publish")
    assert pub.status_code == 200, pub.text
    session_id = int(pub.json()["id"].split("_")[1])
    db = db_()
    recs = {f"u_{r.student_id}": r.present for r in db.query(AttendanceRecord).filter_by(session_id=session_id)}
    db.close()
    assert all(recs[k] == (v == "present") for k, v in truth.items())
    assert t.post(f"/teacher/attendance/drafts/{draft['id']}/publish").status_code == 409  # no double publish


def test_student_gets_live_notification_only_for_self():
    admin = login("admin@campuspilot.edu", "admin123")
    rohan = login("rohan@campuspilot.edu", "student123")
    ananya = login("ananya@campuspilot.edu", "student123")
    apps = admin.get("/placements/").json()
    pl = next(p for p in apps if p["company"] == "Vantage Analytics")
    applicant = admin.get(f"/placements/{pl['id']}/applicants").json()[0]  # Ananya's application
    before_rohan = len(rohan.get("/notifications/").json())
    with ananya.websocket_connect("/ws") as ws:
        ws.receive_json()
        assert admin.patch(f"/placements/applications/{applicant['id']}", json={"status": "selected"}).status_code == 200
        msgs = [ws.receive_json() for _ in range(2)]
        assert any(m["type"] == "notification:new" and "selected" in m["data"]["body"] for m in msgs), msgs
    assert len(rohan.get("/notifications/").json()) == before_rohan  # private news didn't leak


def test_placement_eligibility_enforced_server_side():
    admin = login("admin@campuspilot.edu", "admin123")
    p = admin.post("/placements/", json={"company": "Ultra Corp", "role": "SDE", "package": "₹40 LPA", "location": "Remote",
                                         "minCGPA": 9.9, "minAttendance": 99, "deadline": "30 Oct"}).json()
    s = login("rohan@campuspilot.edu", "student123")
    listed = next(x for x in s.get("/placements/").json() if x["id"] == p["id"])
    assert listed["eligible"] is False and listed["ineligibleReasons"]
    r = s.post(f"/placements/{p['id']}/apply")
    assert r.status_code == 403 and "not eligible" in r.json()["detail"]


def test_assignment_submission_is_per_student():
    rohan = login("rohan@campuspilot.edu", "student123")
    ananya = login("ananya@campuspilot.edu", "student123")
    pending = next(a for a in rohan.get("/student/assignments").json() if a["status"] == "pending"
                   and any(b["id"] == a["id"] and b["status"] == "pending" for b in ananya.get("/student/assignments").json()))
    assert rohan.post(f"/student/assignments/{pending['id']}/submit").json()["status"] == "submitted"
    mine = {a["id"]: a["status"] for a in rohan.get("/student/assignments").json()}
    hers = {a["id"]: a["status"] for a in ananya.get("/student/assignments").json()}
    assert mine[pending["id"]] == "submitted" and hers[pending["id"]] == "pending"


def test_grievance_auto_triage():
    s = login("rohan@campuspilot.edu", "student123")
    g = s.post("/student/grievances", json={"category": "Other", "description": "A senior keeps harassing me near the hostel and I feel unsafe."}).json()
    assert g["priority"] == "high" and g["category"] == "Ragging / Harassment" and g["routedTo"] == "Anti-Ragging Committee"
    g2 = s.post("/student/grievances", json={"category": "Other", "description": "Projector in B-204 has not been working for a week."}).json()
    assert g2["category"] == "Infrastructure" and g2["priority"] == "high"
    admin = login("admin@campuspilot.edu", "admin123")
    first = admin.get("/admin/grievances").json()[0]
    assert first["priority"] == "high" and first["status"] == "open"  # queue sorted by urgency


def test_real_analytics():
    admin = login("admin@campuspilot.edu", "admin123")
    rep = admin.get("/admin/reports/summary").json()
    assert 30 < rep["avgAttendance"] < 100 and 0 < rep["avgCGPA"] <= 10 and rep["attendanceByDept"]
    risk = admin.get("/admin/risk-scores").json()
    assert {r["riskLevel"] for r in risk} <= {"low", "medium", "high"} and len(risk) >= 20
    s = login("rohan@campuspilot.edu", "student123")
    summ = s.get("/student/summary").json()
    assert summ["cgpa"] != 8.74 and summ["totalLectures"] > 0
    att = s.get("/student/attendance").json()
    assert att["perCourse"] and all(0 <= c["pct"] <= 100 for c in att["perCourse"])
    t = login("priya@campuspilot.edu", "teach123")
    assert t.get("/teacher/reports/summary").json()["classesHeld"] > 0


def test_csv_import():
    admin = login("admin@campuspilot.edu", "admin123")
    users_csv = "name,email,role,id_label,department,year,section\nNew Student,newstud@campuspilot.edu,student,CS25B001,Computer Science,1,A\nBad Row,not-an-email,student,CS25B002,,,\n"
    r = admin.post("/admin/import/users", files=[("file", ("u.csv", users_csv.encode(), "text/csv"))]).json()
    assert r["imported"] == 1 and len(r["errors"]) == 1 and r["credentials"][0]["tempPassword"]
    enr = "course_code,student_id_label\nCS301,CS25B001\nXX999,CS25B001\n"
    r = admin.post("/admin/import/enrollments", files=[("file", ("e.csv", enr.encode(), "text/csv"))]).json()
    assert r["imported"] == 1 and r["errors"][0]["error"] == "unknown course code"


def test_leave_approval_flow():
    t = login("priya@campuspilot.edu", "teach123")
    lv = t.post("/teacher/leave", json={"type": "Casual", "from": "2026-10-01", "to": "2026-10-02", "reason": "Family function"}).json()
    admin = login("admin@campuspilot.edu", "admin123")
    assert admin.post(f"/admin/leave-requests/{lv['id']}/decide", json={"status": "approved"}).json()["status"] == "approved"
    assert admin.post(f"/admin/leave-requests/{lv['id']}/decide", json={"status": "rejected"}).status_code == 409


def test_websocket_rejects_unauthenticated_and_foreign_origin():
    from starlette.websockets import WebSocketDisconnect
    for kwargs in ({}, {"headers": {"Origin": "https://evil.example"}}):
        c = client() if not kwargs else login("rohan@campuspilot.edu", "student123")
        try:
            with c.websocket_connect("/ws", **kwargs) as ws:
                ws.receive_json()
            raise AssertionError("websocket should have been refused")
        except WebSocketDisconnect:
            pass


# ================================================================== runner
def main():
    tests = [(n, f) for n, f in globals().items() if n.startswith("test_") and callable(f)]
    failed = 0
    for name, fn in tests:
        try:
            fn()
            print(f"PASS  {name}")
        except Exception:
            failed += 1
            print(f"FAIL  {name}")
            traceback.print_exc()
    print(f"\n{len(tests) - failed}/{len(tests)} passed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
