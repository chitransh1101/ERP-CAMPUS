"""
Measures OCR attendance accuracy on the generated sheets.

    python -m tests.make_sheets && python -m tests.ocr_benchmark
"""
import json
import os
import sys

from app.ai.attendance_ocr import analyze_photo, merge_photo, new_draft_state, summarize

HERE = os.path.join(os.path.dirname(__file__), "sheets")


def score(readings, truth):
    right = wrong = missing = 0
    wrong_list = []
    for sid, expected in truth.items():
        r = readings.get(sid)
        status = r.status if r else None
        if status == expected:
            right += 1
        elif status is None:
            missing += 1
        else:
            wrong += 1
            wrong_list.append((sid, expected, status, r.evidence))
    return right, wrong, missing, wrong_list


def main():
    data = json.load(open(os.path.join(HERE, "truth.json")))
    roster, truth = data["roster"], data["truth"]
    total_right = total = total_wrong = 0
    for name, t in truth.items():
        day = t.get("day") if "day" in t else 26
        expected = t["marks"] if "marks" in t else t
        res = analyze_photo(open(os.path.join(HERE, name), "rb").read(), roster, target_day=day)
        right, wrong, missing, wl = score(res.readings, expected)
        total_right += right
        total_wrong += wrong
        total += len(expected)
        print(f"{name:14} mode={res.mode:8} {right}/{len(expected)} correct, {wrong} wrong, {missing} not found, "
              f"{res.ms} ms, warnings={res.warnings}")
        for w in wl:
            print("    WRONG", w)
    # multi-photo merge: the two daily pages together should cover the whole roster
    state = new_draft_state(roster)
    for name in ("daily_p1.jpg", "daily_p2.jpg"):
        merge_photo(state, analyze_photo(open(os.path.join(HERE, name), "rb").read(), roster, 26), name)
    print("merged 2-page draft:", summarize(state))
    acc = total_right / total
    print(f"\nOVERALL: {total_right}/{total} = {acc:.1%} correct, {total_wrong} wrong")
    return 0 if total_wrong == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
