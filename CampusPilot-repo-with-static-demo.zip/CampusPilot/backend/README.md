# CampusPilot API

FastAPI + SQLAlchemy 2 + Tesseract OCR. See the top-level README for the feature
overview, `../docs/SECURITY.md` for the security model and `../docs/DATABASE.md`
for databases.

```
app/
├── main.py            app, middleware (security headers, CORS, rate limit, body limits), error handlers
├── config.py          every setting (env vars); refuses unsafe production config
├── auth/auth.py       hashing, sessions (revocable), cookie+CSRF, role checks, lockout
├── security.py        rate limiters, security headers, body-size limit
├── realtime.py        WebSocket hub; events are published only after a DB commit succeeds
├── common.py          audit, targeted notifications, cohort statistics, risk, grievance triage
├── ai/attendance_ocr.py   the OCR pipeline (decode → quality → geometry → clean → OCR → match → marks → merge)
├── models/models.py   schema (real foreign keys, enrollments, drafts, sessions, per-user notifications)
├── schemas/           validated request bodies
└── routers/           auth, admin, teacher, student, placements, notifications, copilot, ws
seed.py                demo data (SEED_DEMO=true) or first admin (ADMIN_EMAIL/ADMIN_PASSWORD)
test_ocr.py            try OCR on your own sheet photo
smoke_test.py          quick checks against a running server
tests/                 test_api.py (28 tests), OCR sheet generator + benchmark
```

## Settings (environment variables)

| Variable | Default | Notes |
|---|---|---|
| `ENV` | `development` | `production` enables strict checks, secure cookies and hides `/docs` |
| `SECRET_KEY` | random per start | **required** in production (32+ chars) |
| `DATABASE_URL` | `sqlite:///./campuspilot.db` | `postgresql://…` recommended |
| `SEED_DEMO` | true in dev, false in prod | demo data when the DB is empty |
| `ADMIN_EMAIL` / `ADMIN_PASSWORD` | – | first admin when not seeding demo |
| `CORS_ORIGINS` | localhost:8080,5173 | comma-separated allow-list |
| `COOKIE_SECURE` | true in prod | set true behind HTTPS |
| `COOKIE_SAMESITE` | `lax` | `none` only for cross-site setups (needs HTTPS) |
| `SESSION_HOURS` | 12 | login lifetime |
| `ALLOW_SELF_SIGNUP` | true | student self-registration |
| `MAX_UPLOAD_MB` / `MAX_PHOTOS_PER_REQUEST` | 12 / 10 | OCR upload limits |
| `RATE_LIMIT_PER_MINUTE` / `LOGIN_RATE_PER_MINUTE` | 300 / 10 | per IP |
| `TESSERACT_CMD` | – | path to tesseract if it isn't on PATH (Windows) |
| `COPILOT_PROVIDER` | `ollama` in docker-compose | `ollama` (local), `anthropic` (Claude), `openai` (compatible APIs), `off` |
| `COPILOT_MODEL` | qwen2.5:3b / claude-haiku-4-5-20251001 | model for the chosen provider |
| `COPILOT_FALLBACK` | – | second provider if the first fails, e.g. `ollama` |
| `OLLAMA_URL` | `http://ollama:11434` | local AI server (`http://localhost:11434` outside Docker) |
| `ANTHROPIC_API_KEY` | – | needed for `anthropic` |
| `COPILOT_DAILY_LIMIT` | 60 | AI questions per user per day |

## Key endpoints (all under `/api` behind nginx)

- **Auth:** `POST /auth/login`, `/auth/logout`, `/auth/logout-all`, `/auth/change-password`, `/auth/signup`; `GET /auth/me`
- **OCR attendance:** `POST /teacher/attendance/drafts` → `POST /teacher/attendance/drafts/{id}/photos` (multipart `files`, repeatable) → `PATCH …/students/{sid}` (override) → `POST …/publish`; one-shot `POST /teacher/attendance/ocr`
- **Live:** `GET /ws` (WebSocket, cookie auth); `GET /notifications/`
- **Admin:** users (create → one-time password, status, reset-password), courses + enrollments, leave decisions, grievances (assign/resolve), fees (payments), reports, risk scores, `POST /admin/import/{users|courses|enrollments|fees}`
