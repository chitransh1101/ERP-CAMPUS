"""
Database bootstrap.

  * SEED_DEMO=true (default outside production): if the database is empty,
    load a full demo campus (known demo passwords — never use in production).
  * Production (SEED_DEMO=false): if there are no users yet and
    ADMIN_EMAIL + ADMIN_PASSWORD are set, create that single admin account.
    Everything else is loaded by the admin (CSV import in the Admin console).

Safe to run on every start: it does nothing if users already exist.
"""
import os
import random
import sys

from sqlalchemy import func
from datetime import datetime, timedelta

from app import config
from app.auth.auth import hash_password, password_problems
from app.common import classify_grievance
from app.database.db import Base, SessionLocal, engine
from app.models.models import (
    Assignment, AssignmentSubmission, AttendanceRecord, AttendanceSession, AuditLogEntry, CalendarEvent, ClassNotice,
    Course, DepartmentHead, Enrollment, Exam, ExamResult, Fee, GradeEntry, GradeRecord, Grievance, LeaveRequest,
    LibraryBook, LibraryRequest, Notification, OutboundMessage, ParentLink, Placement, PlacementApplication,
    StudyMaterial, SubjectRequest, User,
)


def days_ago(n):
    return datetime.utcnow() - timedelta(days=n)


_hash_cache = {}


def demo_hash(pw):
    # Demo only: reuse one hash per demo password so seeding is fast.
    if pw not in _hash_cache:
        _hash_cache[pw] = hash_password(pw)
    return _hash_cache[pw]


def bootstrap_admin(db):
    email = (os.environ.get("ADMIN_EMAIL") or "").strip().lower()
    password = os.environ.get("ADMIN_PASSWORD") or ""
    if not email or not password:
        print("No users yet. Set ADMIN_EMAIL and ADMIN_PASSWORD to create the first admin account.")
        return
    problems = password_problems(password, email)
    if problems or len(password) < 12:
        sys.exit("ADMIN_PASSWORD is too weak: use 12+ characters with letters and numbers.")
    db.add(User(name=os.environ.get("ADMIN_NAME", "Campus Admin"), email=email, role="admin", id_label="ADM-001",
                status="active", password_hash=hash_password(password)))
    db.commit()
    print(f"Created admin account {email}. Remove ADMIN_PASSWORD from the environment now.")


def seed_demo(db):
    rng = random.Random(42)
    admins = [User(name="Meera Iyer", email="admin@campuspilot.edu", role="admin", id_label="ADM-001"),
              User(name="Rakesh Verma", email="rakesh@campuspilot.edu", role="admin", id_label="ADM-002")]
    for a in admins:
        a.password_hash = demo_hash("admin123")
    teacher_specs = [
        ("Dr. Priya Sharma", "priya", "STF-114", "Computer Science", "Associate Professor", "Ph.D. in Computer Science, IIT Delhi", "12 Jul 2018", "Block B, Room 214",
         "Teaches data structures & algorithms; research interests in graph theory."),
        ("Prof. Arjun Kapoor", "arjun", "STF-092", "Computer Science", "Assistant Professor", "M.Tech in Database Systems, IIT Bombay", "3 Jan 2021", "Block B, Room 118",
         "Handles database systems and networks labs."),
        ("Dr. Ritu Nair", "ritu", "STF-058", "Mathematics", "Professor", "Ph.D. in Applied Mathematics, ISI Kolkata", "14 Aug 2012", "Block A, Room 301",
         "Teaches discrete mathematics, linear algebra and numerical methods."),
        ("Dr. Aditya Menon", "aditya", "STF-133", "Computer Science", "Assistant Professor", "Ph.D. in Systems, IIT Madras", "21 Jun 2022", "Block B, Room 220",
         "Teaches operating systems; research in distributed systems."),
        ("Dr. Vikram Rao", "vikram", "STF-076", "Electronics & Communication", "Associate Professor", "Ph.D. in VLSI Design, IISc Bangalore", "9 Feb 2016", "Block C, Room 112",
         "Teaches digital electronics and signals & systems."),
        ("Prof. Sneha Joshi", "sneha", "STF-101", "Physics", "Assistant Professor", "M.Sc. Physics, Delhi University", "5 Jul 2023", "Block A, Room 205",
         "Teaches engineering physics for first-year students."),
    ]
    teachers = [User(name=n, email=f"{e}@campuspilot.edu", role="teacher", id_label=i, department=d, designation=des,
                     qualification=q, joined=j, office=o, bio=b, phone=f"+91 98{rng.randint(100, 999)} {rng.randint(10000, 99999)}",
                     password_hash=demo_hash("teach123"))
                for (n, e, i, d, des, q, j, o, b) in teacher_specs]
    student_specs = [
        ("Rohan Mehta", "rohan", "CS21B045", "Computer Science", 3, "A"), ("Ananya Rao", "ananya", "CS21B012", "Computer Science", 3, "A"),
        ("Kabir Singh", "kabir", "CS21B078", "Computer Science", 3, "B"), ("Diya Nair", "diya", "CS21B033", "Computer Science", 3, "A"),
        ("Zoya Khan", "zoya", "CS21B061", "Computer Science", 3, "B"), ("Arnav Gupta", "arnav", "CS22B019", "Computer Science", 2, "A"),
        ("Ishita Verma", "ishita", "CS22B027", "Computer Science", 2, "A"), ("Vivaan Joshi", "vivaan", "CS22B054", "Computer Science", 2, "B"),
        ("Myra Kapoor", "myra", "CS20B008", "Computer Science", 4, "A"), ("Aarav Malhotra", "aarav", "CS20B071", "Computer Science", 4, "B"),
        ("Saanvi Reddy", "saanvi", "CS23B003", "Computer Science", 1, "A"), ("Reyansh Iyer", "reyansh", "CS23B041", "Computer Science", 1, "B"),
        ("Ananya Pillai", "apillai", "MA21B014", "Mathematics", 3, "A"), ("Krishna Bhat", "krishna", "MA22B022", "Mathematics", 2, "A"),
        ("Advika Menon", "advika", "MA20B009", "Mathematics", 4, "A"), ("Vihaan Chatterjee", "vihaan", "MA23B017", "Mathematics", 1, "A"),
        ("Riya Desai", "riya", "EC21B028", "Electronics & Communication", 3, "A"), ("Aryan Kulkarni", "aryan", "EC22B036", "Electronics & Communication", 2, "A"),
        ("Navya Sharma", "navya", "EC20B015", "Electronics & Communication", 4, "A"), ("Dhruv Agarwal", "dhruv", "EC23B052", "Electronics & Communication", 1, "A"),
        ("Kiara Bose", "kiara", "PH21B006", "Physics", 3, "A"), ("Yuvraj Sinha", "yuvraj", "PH22B011", "Physics", 2, "A"),
        ("Anika Trivedi", "anika", "PH20B004", "Physics", 4, "A"), ("Rudra Nambiar", "rudra", "PH23B009", "Physics", 1, "A"),
    ]
    students = [User(name=n, email=f"{e}@campuspilot.edu", role="student", id_label=i, department=d, year=y, section=s,
                     password_hash=demo_hash("student123")) for (n, e, i, d, y, s) in student_specs]
    students[-1].status = "inactive"  # demo the admin "reactivate" flow
    db.add_all(admins + teachers + students)
    db.flush()
    t_by_name = {t.name: t for t in teachers}

    course_specs = [
        ("CS301", "Data Structures", "Computer Science", "Dr. Priya Sharma"), ("CS315", "Database Systems", "Computer Science", "Prof. Arjun Kapoor"),
        ("CS410", "Operating Systems", "Computer Science", "Dr. Aditya Menon"), ("CS420", "Computer Networks", "Computer Science", "Prof. Arjun Kapoor"),
        ("MA201", "Discrete Mathematics", "Mathematics", "Dr. Ritu Nair"), ("MA305", "Linear Algebra", "Mathematics", "Dr. Ritu Nair"),
        ("MA410", "Numerical Methods", "Mathematics", "Dr. Ritu Nair"), ("EC220", "Digital Electronics", "Electronics & Communication", "Dr. Vikram Rao"),
        ("EC330", "Signals & Systems", "Electronics & Communication", "Dr. Vikram Rao"), ("PH101", "Engineering Physics", "Physics", "Prof. Sneha Joshi"),
    ]
    courses = [Course(code=c, name=n, dept=d, faculty_id=t_by_name[f].id) for (c, n, d, f) in course_specs]
    db.add_all(courses)
    db.flush()

    # Enrollment: every course of the student's department, plus MA201 for CS
    # students and PH101 for first-years.
    enroll = {c.id: [] for c in courses}
    for s in students:
        for c in courses:
            if c.dept == s.department or (c.code == "MA201" and s.department == "Computer Science") or (c.code == "PH101" and s.year == 1):
                enroll[c.id].append(s)
                db.add(Enrollment(course_id=c.id, student_id=s.id))
    db.flush()

    db.add_all([
        SubjectRequest(teacher_id=t_by_name["Dr. Aditya Menon"].id, teacher_name="Dr. Aditya Menon", code="CS450", name="Distributed Systems",
                       dept="Computer Science", notes="Elective for 4th-years, builds on CS410.", status="pending", ts=days_ago(2)),
        SubjectRequest(teacher_id=t_by_name["Dr. Vikram Rao"].id, teacher_name="Dr. Vikram Rao", code="EC440", name="VLSI Design",
                       dept="Electronics & Communication", notes="Requires EC220.", status="pending", ts=days_ago(1)),
        SubjectRequest(teacher_id=t_by_name["Prof. Sneha Joshi"].id, teacher_name="Prof. Sneha Joshi", code="PH210", name="Quantum Mechanics I",
                       dept="Physics", status="rejected", reject_reason="Insufficient projected enrollment — resubmit next term.", ts=days_ago(10)),
    ])

    cycle = ["paid", "paid", "partial", "overdue", "paid", "partial"]
    for i, s in enumerate(students):
        total = 78000 if s.department == "Physics" else 85000
        st = cycle[i % len(cycle)]
        paid = total if st == "paid" else (round(total * rng.uniform(0.35, 0.65) / 500) * 500 if st == "partial" else 0)
        db.add(Fee(student_id=s.id, total=total, paid=paid, due_date="2026-10-15"))

    tendency = {s.id: (rng.uniform(0.55, 0.98), rng.uniform(40, 96)) for s in students}
    today = datetime.utcnow().date()
    for c in courses:
        n_sessions = rng.randint(10, 16)
        for k in range(n_sessions):
            day = today - timedelta(days=(n_sessions - k) * 2 + 1)
            sess = AttendanceSession(course_id=c.id, course_label=f"{c.code} — {c.name}", date=day.isoformat(),
                                     marked_by_id=c.faculty_id, marked_by=c.faculty, method=rng.choice(["manual", "ocr"]),
                                     ts=datetime.combine(day, datetime.min.time()) + timedelta(hours=10))
            db.add(sess)
            db.flush()
            db.add_all([AttendanceRecord(session_id=sess.id, student_id=s.id, present=rng.random() < tendency[s.id][0],
                                         confidence=round(rng.uniform(82, 99), 1)) for s in enroll[c.id]])
        for a, assessment in enumerate(["Quiz 1", "Midterm", "Assignment 1"][: rng.randint(2, 3)]):
            g = GradeRecord(course_id=c.id, course_label=f"{c.code} — {c.name}", assessment=assessment, published_by=c.faculty,
                            ts=days_ago(20 - a * 6))
            db.add(g)
            db.flush()
            db.add_all([GradeEntry(grade_id=g.id, student_id=s.id,
                                   score=max(0, min(100, round(tendency[s.id][1] + rng.uniform(-12, 12))))) for s in enroll[c.id]])
        for title in [f"{c.name} — Problem Set 1", f"{c.name} — Lab Report"]:
            a = Assignment(title=title, course_id=c.id, course=c.name, due=(today + timedelta(days=rng.randint(-3, 14))).strftime("%d %b"),
                           created_by=c.faculty_id, ts=days_ago(rng.randint(1, 12)))
            db.add(a)
            db.flush()
            db.add_all([AssignmentSubmission(assignment_id=a.id, student_id=s.id) for s in enroll[c.id] if rng.random() < 0.55])
        db.add(StudyMaterial(title=f"Unit 1 — {c.name} notes", course_id=c.id, course=c.name, type="PDF", uploaded_by=c.faculty,
                             size="2.1 MB", ts=days_ago(rng.randint(3, 20))))
        db.add(ClassNotice(title=f"Practical exam schedule for {c.code} has been posted", course_id=c.id, course=c.name,
                           sent_by=c.faculty, sent_by_id=c.faculty_id, ts=days_ago(rng.randint(1, 8))))

    for t in teachers:
        for _ in range(rng.randint(1, 2)):
            start = today + timedelta(days=rng.randint(-30, 20))
            db.add(LeaveRequest(applicant_id=t.id, applicant=t.name, role="teacher", type=rng.choice(["Casual", "Medical", "Conference"]),
                                from_date=start.isoformat(), to_date=(start + timedelta(days=rng.randint(0, 2))).isoformat(),
                                reason="Personal / academic commitment.", status=rng.choice(["pending", "approved", "pending"]),
                                ts=days_ago(rng.randint(1, 30))))

    grievances = [
        (students[0], "Infrastructure", "Wi-Fi has been down in Block B library for three days, can't access online course material.", "open"),
        (students[1], "Academic", "My CS315 lab attendance for 14 Aug was marked absent even though I attended — please recheck.", "in-review"),
        (students[2], "Fees & Finance", "Paid the partial fee installment on 10 Aug but the portal still shows it as overdue.", "resolved"),
        (students[3], "Hostel", "Room heater has been broken for a week, warden hasn't responded to two requests.", "open"),
        (students[4], "Other", "A senior student has been making threatening comments in the hostel common room.", "open"),
        (teachers[4], "Timetable & Workload", "Back-to-back sections with no gap between EC220 and EC330 this semester, requesting a review.", "open"),
        (teachers[1], "Payroll & HR", "October payslip shows an incorrect deduction, please investigate.", "in-review"),
    ]
    for who, cat, text, status in grievances:
        tri = classify_grievance(text, who.role, cat)
        db.add(Grievance(raised_by_id=who.id, raised_by=who.name, role=who.role, category=tri["category"], priority=tri["priority"],
                         routed_to=tri["routedTo"], description=text, status=status,
                         assigned_to="Meera Iyer" if status != "open" else None, ts=days_ago(rng.randint(1, 9))))

    specs = [("Nexora Systems", "Software Engineer Intern", "₹8 LPA", "Bengaluru", 7.5, 75, "15 Oct", "open"),
             ("Vantage Analytics", "Data Analyst", "₹6.5 LPA", "Pune", 7.0, 70, "20 Oct", "open"),
             ("Orbit Cloud", "Backend Developer", "₹9.2 LPA", "Hyderabad", 8.0, 80, "10 Oct", "open"),
             ("Bluepeak Semiconductors", "VLSI Design Intern", "₹6 LPA", "Noida", 7.0, 70, "18 Oct", "open"),
             ("Meridian Analytics", "Data Scientist", "₹11 LPA", "Bengaluru", 8.5, 80, "18 Aug", "closed")]
    pls = [Placement(company=c, role=r, package=p, location=l, min_cgpa=mc, min_attendance=ma, deadline=d, posted_by="Meera Iyer",
                     status=st, ts=days_ago(rng.randint(1, 25))) for (c, r, p, l, mc, ma, d, st) in specs]
    db.add_all(pls)
    db.flush()
    for s, pl, st in [(students[1], pls[1], "shortlisted"), (students[3], pls[0], "applied"), (students[8], pls[4], "selected")]:
        db.add(PlacementApplication(placement_id=pl.id, student_id=s.id, student_name=s.name, id_label=s.id_label, status=st,
                                    cgpa_at_apply=8.2, attendance_at_apply=81))

    books = [("Introduction to Algorithms", "Cormen, Leiserson, Rivest, Stein", "Computer Science", 4),
             ("Database System Concepts", "Silberschatz, Korth, Sudarshan", "Computer Science", 2),
             ("Discrete Mathematics and Its Applications", "Kenneth Rosen", "Mathematics", 3),
             ("Operating System Concepts", "Silberschatz, Galvin, Gagne", "Computer Science", 1),
             ("Computer Networking: A Top-Down Approach", "Kurose, Ross", "Computer Science", 0),
             ("Linear Algebra and Its Applications", "Gilbert Strang", "Mathematics", 5),
             ("Digital Design", "M. Morris Mano", "Electronics & Communication", 2),
             ("Signals and Systems", "Oppenheim, Willsky", "Electronics & Communication", 0),
             ("University Physics", "Young, Freedman", "Physics", 3),
             ("Numerical Methods for Engineers", "Chapra, Canale", "Mathematics", 2)]
    bks = [LibraryBook(title=t, author=a, category=c, copies=n) for (t, a, c, n) in books]
    db.add_all(bks)
    db.flush()
    db.add(LibraryRequest(student_id=students[0].id, book_id=bks[4].id, title=bks[4].title, status="waitlisted", ts=days_ago(3)))

    for s in students[:5]:
        db.add(Notification(user_id=s.id, title="Welcome to CampusPilot", body="Your attendance, marks and fees are all live here.", ts=days_ago(1)))
    db.add(AuditLogEntry(actor="System", actor_role="system", action="Demo data loaded", detail="seed.py", ts=datetime.utcnow()))
    db.commit()
    print(f"Seeded demo campus: {len(students)} students, {len(teachers)} faculty, {len(courses)} courses.")


def seed_extras(db):
    """Demo data for newer features. Idempotent: each part only runs if that
    feature has no data yet, so it also upgrades an existing demo database."""
    from datetime import date
    rng = random.Random(7)
    by_email = {u.email: u for u in db.query(User)}
    today = date.today()
    added = []

    # ---- parents (login: parent@campuspilot.edu / parent123)
    if not db.query(ParentLink.id).first():
        for name, email, phone, child, relation in [
            ("Suresh Mehta", "parent@campuspilot.edu", "+91 98200 12345", "rohan@campuspilot.edu", "Father"),
            ("Lakshmi Rao", "lakshmi.rao@campuspilot.edu", "+91 99870 54321", "ananya@campuspilot.edu", "Mother"),
        ]:
            st = by_email.get(child)
            if not st:
                continue
            p = by_email.get(email) or User(name=name, email=email, role="parent", phone=phone, status="active",
                                           password_hash=demo_hash("parent123"))
            db.add(p)
            db.flush()
            db.add(ParentLink(parent_id=p.id, student_id=st.id, relation=relation))
            db.add(OutboundMessage(user_id=p.id, student_id=st.id, to_name=p.name, phone=phone.replace(" ", ""), channel="whatsapp",
                                   kind="fee_due", status="logged", provider="log", ts=days_ago(2), sent_at=days_ago(2),
                                   body=f"{config.INSTITUTION_NAME}: Fee reminder for {st.name} — please check the parent portal."))
        added.append("parents")

    # ---- heads of department
    if not db.query(DepartmentHead.id).first():
        for email, dept in [("priya@campuspilot.edu", "Computer Science"), ("ritu@campuspilot.edu", "Mathematics")]:
            if email in by_email:
                db.add(DepartmentHead(dept=dept, user_id=by_email[email].id))
        added.append("HODs")

    # ---- exams: a past mid-sem with published results + an upcoming end-sem per course
    if not db.query(Exam.id).first():
        rooms = ["Exam Hall A", "Exam Hall B", "B-204", "A-102", "C-210"]
        for i, c in enumerate(db.query(Course).order_by(Course.code)):
            mid = Exam(course_id=c.id, kind="midsem", title="Mid-Semester Exam", date=(today - timedelta(days=12 - i % 4)).isoformat(),
                       start_time="10:00", duration_min=120, room=rooms[i % len(rooms)], max_marks=50,
                       results_published=True, published_at=days_ago(3))
            end = Exam(course_id=c.id, kind="endsem", title="End-Semester Exam", date=(today + timedelta(days=14 + i)).isoformat(),
                       start_time="10:00" if i % 2 == 0 else "14:00", duration_min=180, room=rooms[(i + 2) % len(rooms)], max_marks=100)
            db.add_all([mid, end])
            db.flush()
            avg = dict(db.query(GradeEntry.student_id, func.avg(GradeEntry.score)).join(GradeRecord, GradeRecord.id == GradeEntry.grade_id)
                       .filter(GradeRecord.course_id == c.id).group_by(GradeEntry.student_id).all())
            for (sid,) in db.query(Enrollment.student_id).filter(Enrollment.course_id == c.id):
                base = float(avg.get(sid, 65))
                absent = rng.random() < 0.04
                db.add(ExamResult(exam_id=mid.id, student_id=sid, absent=absent,
                                  marks=None if absent else max(0, min(50, round((base + rng.uniform(-10, 10)) / 2)))))
        added.append("exams")

    # ---- academic calendar
    if not db.query(CalendarEvent.id).first():
        def nxt(month, day):
            d = date(today.year, month, day)
            return d if d >= today - timedelta(days=20) else date(today.year + 1, month, day)
        events = [
            ("Gandhi Jayanti", nxt(10, 2), None, "holiday", "Institute closed."),
            ("Christmas", nxt(12, 25), None, "holiday", "Institute closed."),
            ("Republic Day", nxt(1, 26), None, "holiday", "Flag hoisting at 8:30 AM, main lawn."),
            ("End-semester examinations", today + timedelta(days=14), today + timedelta(days=24), "exam-week", "See your hall ticket for the timetable."),
            ("TechNova — annual tech fest", today + timedelta(days=6), today + timedelta(days=8), "event", "Hackathon, robotics and project expo."),
            ("Parent–teacher meeting", today + timedelta(days=3), None, "event", "10 AM – 1 PM in each department."),
            ("Last date: scholarship forms", today + timedelta(days=9), None, "deadline", "Submit at the accounts office."),
            ("Guest lecture: AI in Healthcare", today - timedelta(days=2), None, "event", "Seminar hall, 3 PM."),
        ]
        for title, d, end, kind, desc in events:
            db.add(CalendarEvent(title=title, date=d.isoformat(), end_date=end.isoformat() if end else None, kind=kind, description=desc))
        added.append("calendar")

    if added:
        db.commit()
        print("Added demo data for: " + ", ".join(added))


def main():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        if db.query(User.id).first():
            print("Database already has users — skipping the base seed.")
            if config.SEED_DEMO and db.query(User.id).filter(User.email == "admin@campuspilot.edu").first():
                seed_extras(db)
        elif config.SEED_DEMO:
            seed_demo(db)
            seed_extras(db)
        else:
            bootstrap_admin(db)
    finally:
        db.close()


if __name__ == "__main__":
    main()
