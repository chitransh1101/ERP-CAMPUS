# CampusPilot — college ERP

React front end + FastAPI back end + PostgreSQL, with **photo-based attendance (OCR)**,
**QR attendance**, a **parent portal with SMS/WhatsApp alerts**, **exams with hall tickets and grade cards**,
**principal/HOD analytics**, **NAAC/NBA reports**, an **installable app**, **Hindi**, and **live updates on every screen**.

```
campuspilot/
├── backend/            FastAPI API, OCR engine, tests
├── frontend/           React app + nginx config (serves the app, proxies /api)
├── docs/DATABASE.md    ← where the database comes from + loading your college's data
├── docs/SECURITY.md    ← the security model, item by item
├── docs/ALERTS.md      ← turning on real SMS / WhatsApp alerts for parents
├── sample_data/        example CSVs for Admin → Data Import
├── docker-compose.yml  web + API + PostgreSQL, one command
└── render.yaml         optional hosted deployment
```

## Easiest: run it in your browser with GitHub Codespaces (nothing to install)

Once this project is in a GitHub repository:
1. On the repository page, click the green **Code** button → **Codespaces** tab → **Create codespace on main**.
2. Wait about 5–10 minutes the first time (it builds everything). The app then opens in a new browser tab.
3. To let friends in: open the **Ports** tab at the bottom → right-click port **8080** → **Port Visibility → Public** → copy the address and send it.

The codespace goes to sleep after about 30 minutes of inactivity. Open it again from the same **Code → Codespaces** menu and everything (including your data) comes back.
GitHub gives personal accounts a free monthly Codespaces allowance; students get more through the GitHub Student Developer Pack.
On the default 2-core machine the local AI is skipped automatically (the copilot uses its built-in assistant). Choose a 4-core machine to include the AI.

## Run it — one command

1. Install **[Docker Desktop](https://www.docker.com/products/docker-desktop/)** and open it (wait until it says "running").
2. Get the project: unzip it, or `git clone <your-repo-url>`.
3. In the project folder, run **one command**:

| Computer | Command |
|---|---|
| **Windows** | double-click **`start.bat`** (or run `start.bat` in a terminal) |
| **macOS / Linux** | `bash start.sh` |

That's it. On the first run the script:
- creates `.env` with fresh random secrets (demo campus mode),
- builds and starts everything: website, API, PostgreSQL and the local AI,
- waits until the site is ready, then opens **http://localhost:8080**.

The first start downloads a few GB (base images plus a ~2 GB AI model), so allow 10–20 minutes. After that it starts in seconds.

Demo logins: student `rohan@campuspilot.edu` / `student123`, faculty `priya@campuspilot.edu` / `teach123`, admin `admin@campuspilot.edu` / `admin123`.

| To… | Windows | macOS / Linux |
|---|---|---|
| Stop (data is kept) | `start.bat -Stop` | `bash start.sh --stop` |
| Start again | `start.bat` | `bash start.sh` |
| Wipe everything and start fresh | `start.bat -Reset` | `bash start.sh --reset` |
| See logs | `docker compose logs -f` | `docker compose logs -f` |

**Minimum machine:** 8 GB RAM and about 10 GB free disk. Without the AI, 4 GB RAM is enough: delete the `COMPOSE_PROFILES=local-ai` line in `.env`.

## Sharing with friends

**A. Everyone runs their own copy.** Push the folder to GitHub (or send the zip). Each friend installs Docker Desktop and runs the same one command. Each copy has its own database, so what you do isn't shared.

**B. Friends use *your* running copy on the same Wi-Fi or hotspot.** Once `start` finishes it prints a line like `Friends on the same Wi-Fi: http://192.168.1.23:8080`. Friends open that address on their laptop or phone. Everyone shares one database, and the live updates reach everyone. If Windows asks whether Docker may use the network, click **Allow**. Your computer must stay on.

**C. Friends anywhere (over the internet), for a demo.** With the app running, install [cloudflared](https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/) and run:
```
cloudflared tunnel --url http://localhost:8080
```
It prints a temporary `https://….trycloudflare.com` link. Anyone with the link can open the site, so only share demo data this way (the demo passwords are public). Press Ctrl+C to stop sharing.

**For real college use**, don't use demo mode: follow [docs/DATABASE.md](docs/DATABASE.md) (real admin + CSV import) and "Going live" below.

## The five core features

### 1. Smart attendance from photos (OCR)
Teacher → **Take Attendance** → *Start* → take or upload one or more photos of the sheet.
- Each photo is flattened (perspective + tilt), cleaned of shadows and table lines, and read with Tesseract.
- Students are matched by **roll number**, tolerating OCR slips such as `O/0`, `S/5`, `B/8` and one wrong character. Otherwise they're matched by **name**, tolerating slips such as `rn/m`.
- It understands **daily P/A sheets**, **sign-in sheets** (it measures the ink in the signature cell) and **monthly registers** (it reads the column for the chosen date).
- Several photos (for example one per page) **merge into one live draft**. The same draft updates instantly on the teacher's other devices: snap on your phone, review on the laptop.
- Every reading has a confidence score and a reason. Uncertain rows, conflicting photos and students not found are **flagged for review**. Nothing is published until the teacher confirms. The system never invents attendance.
- Poor photos get specific advice ("too small", "blurry", "too dark", "glare").
- Measured accuracy: 100% on the benchmark sheets and **99.0% on 480 unseen student rows** from deliberately harsh simulated phone photos. The one wrong reading was flagged for review. Run `python -m tests.make_sheets && python -m tests.ocr_benchmark`, or try your own sheet with `python test_ocr.py photo.jpg --course CS301`.

### 2. Real-time everywhere
A WebSocket (`/api/ws`) pushes notifications, attendance, grades, grievances, placements, leave decisions, fee payments and audit entries to exactly the right people as soon as they're saved. A notification bell shows unread items. The connection reconnects automatically.

### 3. Early-warning risk analytics
Health score from **real** attendance, marks and fee status (45/35/20), computed server-side for the whole cohort in a few grouped queries. Before this, several numbers were hard-coded (CGPA 8.74, attendance 78%, the department chart). Students see per-subject attendance with "you can miss N more" or "attend the next N to reach 75%".

### 4. Placements
Eligibility (CGPA and attendance) is computed from real records and **enforced on the server**. Applications store the CGPA and attendance at the time of applying. Only the applicant is notified of their result.

### 5. Grievance triage
Each grievance is auto-classified into a category, **priority** (harassment → high; "not working for a week" → high) and the **office it routes to**. The admin queue is sorted by urgency. Resolution notes go back to the person who raised it, and only to them.

### Bonus: AI Campus Copilot
The chat button (bottom-right) is now a real AI assistant for students, faculty and admins. Ask it, for example: "how many classes can I miss?", "which of my students are at high risk?", "apply casual leave next Monday", "raise a complaint about hostel wifi". It answers in English, Hindi or Hinglish, and it keeps the conversation going across follow-up questions.
- It can see data **only through role-scoped tools** that run as the signed-in user, so a student's copilot sees only that student's records. It never touches the database directly.
- It can **prepare** actions (grievance, library request, placement application, leave, class notice), but they're shown as a **Confirm** card and saved through the normal validated API only when the user clicks.
- **Default AI: local and free.** `docker compose up` also starts **Ollama** and downloads `qwen2.5:3b` (about 2 GB, once). No API key, no per-question cost, and **no data leaves your server**. While the model downloads, the chat says so and the built-in assistant answers.
- **Switching to Claude later** is one line in `.env`: `COPILOT_PROVIDER=anthropic` plus `ANTHROPIC_API_KEY=…`, then `docker compose up -d`. Add `COPILOT_FALLBACK=ollama` to keep the local AI as an automatic backup if Claude is unreachable. Any OpenAI-compatible API also works (`COPILOT_PROVIDER=openai`).
- **Speed:** a 3B model on an ordinary CPU takes roughly 10–60 s per answer (the chat shows live progress, like "Checking attendance…"). With a GPU, or 16 GB+ RAM and `OLLAMA_MODEL=qwen2.5:7b`, it's faster and smarter. Claude answers in a few seconds.
- Cost and abuse limits: a per-user daily cap (`COPILOT_DAILY_LIMIT`), 12 messages a minute, short answers, and at most 5 tool steps per question.

## New in v3

| Feature | Who | Where |
|---|---|---|
| **Parent portal** — child's attendance, marks, exams, fees, notices, calendar; one login for several children | Parents | Log in as *Parent* (demo: `parent@campuspilot.edu` / `parent123`) |
| **SMS / WhatsApp alerts** — absent today, attendance below 75 %, fee reminders and receipts, results, exam dates | Parents | Admin → *Parents & Alerts* (outbox, fee reminders, link parents). Demo mode saves alerts without sending; see [docs/ALERTS.md](docs/ALERTS.md) |
| **QR attendance** — a QR + 6-digit code that changes every 15 s; students scan with the phone camera; names tick in live; flags one phone checking in several students | Faculty, students | Faculty → *QR Attendance*; Student → *Attendance* |
| **Exams** — timetable, marks entry, publish results, **hall tickets** (with attendance eligibility) and **grade cards** as PDFs | Admin, faculty, students, parents | *Exams* in every portal |
| **Analytics** — weekly trends by department, attendance heat-maps, pass rates, at-risk students; PDF export; **HODs** see their own department | Admin, HODs | Admin → *Analytics*; HOD → *Department Analytics* (assign HODs at the bottom of Analytics) |
| **NAAC / NBA data** — criterion-wise tables (student-teacher ratio, pass %, placements, grievance redressal, e-governance) + NBA course-attainment levels; CSV + PDF | Admin | Admin → *NAAC / NBA Reports* |
| **Installable app (PWA)** — "Install app" / Add to Home Screen; opens full-screen like a native app | Everyone | Sidebar → *Install app* (Chrome/Edge/Android), Safari → Share → Add to Home Screen |
| **ID cards & certificates** — ID card PDF, instant bonafide certificate; every document has a QR anyone can scan to verify it's genuine | Students, staff | *ID Card & Certificates* |
| **Academic calendar** — holidays, events, exam weeks, exams, assignment and fee deadlines | Everyone | *Calendar* |
| **हिंदी** — menus, headings, tables and buttons in Hindi | Everyone | *EN / हिं* switch (sidebar and login page) |
| **Guided tour**, zoom control, illustrated empty screens | Everyone | Sidebar → *Take the tour* |

Also fixed or added: per-course rosters and enrollments, per-student assignment submission, admin leave approvals, CSV bulk import, one-time passwords, forced password change, password reset, fee payments, and real reports.

## Security

In short: exact-match login (the old `%` email logged in as admin), httpOnly
cookie sessions + CSRF, sessions revoked instantly on logout or deactivation,
600k-iteration PBKDF2, lockouts and rate limits, ownership checks on every
teacher and student action, strict input schemas, safe photo uploads, a strict
CSP, non-root containers, and a full audit log. See **[docs/SECURITY.md](docs/SECURITY.md)**.

## Tests

```bash
cd backend
python -m tests.test_api          # 28 API tests: security + every feature (uses a temp SQLite DB)
python -m tests.test_copilot      # 16 AI-copilot tests (Claude, Ollama, fallback) against a mock AI server
python -m tests.test_features     # 12 tests: parents & alerts, exams, QR attendance, analytics, NAAC, calendar, documents
python -m tests.security_regression http://localhost:8080/api   # replays 15 attacks against a running server
python -m tests.make_sheets && python -m tests.ocr_benchmark   # OCR accuracy
python smoke_test.py              # against a running server
```

## Developing without Docker

```bash
# backend (needs Python 3.11+ and Tesseract installed)
cd backend && pip install -r requirements.txt
python seed.py && uvicorn app.main:app --reload --port 8000
# frontend (needs Node 20)
cd frontend && npm install && npm run dev      # http://localhost:5173 (proxies /api to :8000)
```

## Going live
**Free permanent link:** follow [docs/DEPLOY_RENDER.md](docs/DEPLOY_RENDER.md) (Render + Neon, about 15 minutes).

Use any machine that runs Docker (a college server, or a small cloud VPS):
set `ENV=production`, `PUBLIC_URL=https://erp.yourcollege.edu`, `COOKIE_SECURE=true`,
put HTTPS in front (Caddy, Nginx + Let's Encrypt, or Cloudflare Tunnel), run
`docker compose up -d`, and schedule the database backup from docs/DATABASE.md.
`render.yaml` can host a demo on Render.
