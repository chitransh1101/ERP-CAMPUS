#!/usr/bin/env bash
# CampusPilot — one-command start (macOS / Linux).
#     bash start.sh            start (first run sets everything up)
#     bash start.sh --stop     stop (your data is kept)
#     bash start.sh --reset    stop AND delete all data (fresh start)
set -euo pipefail
cd "$(dirname "$0")"

say()  { printf '\033[1;36m▶ %s\033[0m\n' "$*"; }
fail() { printf '\033[1;31m✖ %s\033[0m\n' "$*" >&2; exit 1; }

# ---- 1. Docker present and running?
command -v docker >/dev/null 2>&1 || fail "Docker isn't installed. Install Docker Desktop from https://www.docker.com/products/docker-desktop/ and run this again."
docker info >/dev/null 2>&1 || fail "Docker is installed but not running. Open Docker Desktop, wait until it says 'running', then run this again."
if docker compose version >/dev/null 2>&1; then DC="docker compose"
elif command -v docker-compose >/dev/null 2>&1; then DC="docker-compose"
else fail "Docker Compose is missing — update Docker Desktop."; fi

case "${1:-}" in
  --stop)  $DC down; say "Stopped. Your data is kept — run: bash start.sh."; exit 0 ;;
  --reset) read -r -p "Delete ALL CampusPilot data (database, AI model)? Type yes: " a
           [ "$a" = "yes" ] || exit 1; $DC --profile local-ai down -v; say "Everything deleted."; exit 0 ;;
esac

# ---- 2. First run: create .env with fresh random secrets (demo mode)
rand() { LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom | head -c "$1"; }
if [ ! -f .env ]; then
  say "First run: creating .env with new random secrets (demo campus mode)"
  awk -v sk="$(rand 64)" -v pw="$(rand 32)" '
    /^SECRET_KEY=$/        { print "SECRET_KEY=" sk; next }
    /^POSTGRES_PASSWORD=$/ { print "POSTGRES_PASSWORD=" pw; next }
    /^SEED_DEMO=/          { print "SEED_DEMO=true"; next }
    { print }' .env.example > .env
  chmod 600 .env

  # Less than ~12 GB RAM: skip the local AI (the copilot uses its built-in assistant).
  MEM_GB=$( (awk '/MemTotal/ {printf "%d", $2/1048576}' /proc/meminfo 2>/dev/null) || true)
  [ -z "$MEM_GB" ] && MEM_GB=$( (sysctl -n hw.memsize 2>/dev/null | awk '{printf "%d", $1/1073741824}') || true)
  if [ -n "$MEM_GB" ] && [ "$MEM_GB" -lt 12 ]; then
    sed -i.bak 's/^COMPOSE_PROFILES=local-ai/# COMPOSE_PROFILES=local-ai   # disabled: this machine has ~'"$MEM_GB"' GB RAM/' .env && rm -f .env.bak
    say "This machine has ~${MEM_GB} GB RAM — skipping the local AI (edit .env to turn it on)."
  fi
fi

# ---- GitHub Codespaces tweaks (safe to re-run; also fixes an older .env)
setenv() {  # setenv KEY VALUE — replace or add a line in .env
  if grep -q "^$1=" .env; then
    grep -v "^$1=" .env > .env.tmp && mv .env.tmp .env
  fi
  printf '%s=%s\n' "$1" "$2" >> .env
}
if [ "${CODESPACES:-}" = "true" ]; then
  # Containers on Docker's private network can't reach each other inside a
  # codespace, so run them on the codespace's own network instead.
  setenv COMPOSE_FILE "docker-compose.yml:docker-compose.codespaces.yml"
  # The public address people open, so live updates (WebSocket) are allowed.
  setenv PUBLIC_URL "https://${CODESPACE_NAME}-8080.${GITHUB_CODESPACES_PORT_FORWARDING_DOMAIN:-app.github.dev}"
  # Everyone comes through GitHub's proxy (one IP), so allow more logins and requests per minute.
  grep -q '^LOGIN_RATE_PER_MINUTE=' .env || setenv LOGIN_RATE_PER_MINUTE 60
  grep -q '^RATE_LIMIT_PER_MINUTE=' .env || setenv RATE_LIMIT_PER_MINUTE 3000
  chmod 600 .env
  # Clear out containers from an earlier start that used the private network.
  if $DC ps -q 2>/dev/null | grep -q . && docker network inspect "$(basename "$PWD" | tr "[:upper:]" "[:lower:]" | tr -cd "a-z0-9_-")_internal" >/dev/null 2>&1; then
    say "Switching to codespace networking (one-time)"
    COMPOSE_FILE=docker-compose.yml $DC --profile local-ai down --remove-orphans || true
  fi
fi

# ---- 3. Build and start everything in the background
say "Starting CampusPilot (the first start downloads a few GB — grab a coffee ☕)"
$DC up --build -d

# ---- 4. Wait until the site answers
say "Waiting for the app to be ready…"
for _ in $(seq 1 180); do
  if curl -fsS --max-time 5 http://localhost:8080/api/health >/dev/null 2>&1; then READY=1; break; fi
  sleep 2
done
if [ "${READY:-}" != 1 ]; then
  printf '\n'; $DC ps || true
  printf '\n--- last backend log lines ---\n'; $DC logs --tail 25 backend || true
  fail "The app didn't come up in 6 minutes (details above). Copy everything above and send it for help."
fi

IP="$( (ipconfig getifaddr en0 || ipconfig getifaddr en1 || hostname -I 2>/dev/null | awk '{print $1}') 2>/dev/null | head -n1 || true)"
if [ -n "$IP" ]; then LAN_URL="http://$IP:8080"; else LAN_URL="http://<this computer IP>:8080"; fi
if [ "${CODESPACES:-}" = "true" ]; then
  LAN_URL="https://${CODESPACE_NAME}-8080.${GITHUB_CODESPACES_PORT_FORWARDING_DOMAIN:-app.github.dev}  (Ports tab → 8080 → Port Visibility → Public, to let friends in)"
fi

printf '\n  \033[1;32m✅ CampusPilot is running!\033[0m\n\n'
printf '     On this computer:          http://localhost:8080\n'
printf '     For friends:               %s\n\n' "$LAN_URL"
printf '  Demo logins (only in demo mode):\n'
printf '     Student  rohan@campuspilot.edu  / student123\n'
printf '     Faculty  priya@campuspilot.edu  / teach123\n'
printf '     Admin    admin@campuspilot.edu  / admin123\n'
printf '     Parent   parent@campuspilot.edu / parent123\n\n'
printf '  The AI Copilot downloads its model in the background (~2 GB, first run only);\n'
printf '  until then the chat uses the built-in assistant.\n\n'
printf '  Stop: bash start.sh --stop      Live logs: %s logs -f\n\n' "$DC"

# Open the browser (macOS: open, Linux desktop: xdg-open; silently skipped on servers)
if [ "$(uname)" = "Darwin" ]; then open http://localhost:8080 >/dev/null 2>&1 || true
elif command -v xdg-open >/dev/null 2>&1 && [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ]; then xdg-open http://localhost:8080 >/dev/null 2>&1 || true; fi
