# CampusPilot — one-command start (Windows). Run via start.bat (double-click),
# or:  powershell -ExecutionPolicy Bypass -File start.ps1 [-Stop] [-Reset]
param([switch]$Stop, [switch]$Reset)
# "Continue": in Windows PowerShell 5, "Stop" turns harmless Docker progress output on stderr into crashes.
$ErrorActionPreference = "Continue"
Set-Location -Path $PSScriptRoot

function Say($m)  { Write-Host "> $m" -ForegroundColor Cyan }
function Fail($m) { Write-Host "X $m" -ForegroundColor Red; Read-Host "Press Enter to close"; exit 1 }

# ---- 1. Docker present and running?
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
  Fail "Docker isn't installed. Install Docker Desktop from https://www.docker.com/products/docker-desktop/ and run this again."
}
cmd /c "docker info >nul 2>&1"
if ($LASTEXITCODE -ne 0) { Fail "Docker is installed but not running. Open Docker Desktop, wait until it says 'running', then run this again." }

if ($Stop)  { docker compose down; Say "Stopped. Your data is kept - run start.bat to start again."; exit 0 }
if ($Reset) {
  $a = Read-Host "Delete ALL CampusPilot data (database, AI model)? Type yes"
  if ($a -ne "yes") { exit 1 }
  docker compose --profile local-ai down -v; Say "Everything deleted."; exit 0
}

# ---- 2. First run: create .env with fresh random secrets (demo mode)
function New-Secret([int]$n) {
  $chars = [char[]]"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
  $bytes = New-Object byte[] $n
  [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
  -join ($bytes | ForEach-Object { $chars[$_ % $chars.Length] })
}
if (-not (Test-Path ".env")) {
  Say "First run: creating .env with new random secrets (demo campus mode)"
  $c = [IO.File]::ReadAllText("$PSScriptRoot\.env.example")
  $c = $c -replace "(?m)^SECRET_KEY=\r?$", ("SECRET_KEY=" + (New-Secret 64))
  $c = $c -replace "(?m)^POSTGRES_PASSWORD=\r?$", ("POSTGRES_PASSWORD=" + (New-Secret 32))
  $c = $c -replace "(?m)^SEED_DEMO=.*$", "SEED_DEMO=true"
  $c = $c -replace "`r`n", "`n"
  [IO.File]::WriteAllText("$PSScriptRoot\.env", $c)   # UTF-8 without BOM
}

# ---- 3. Build and start
Say "Starting CampusPilot (the first start downloads a few GB - grab a coffee)"
docker compose up --build -d
if ($LASTEXITCODE -ne 0) { Fail "Docker couldn't start the app. Scroll up for the error." }

# ---- 4. Wait until the site answers
Say "Waiting for the app to be ready..."
$ready = $false
for ($i = 0; $i -lt 180; $i++) {
  try { Invoke-WebRequest -UseBasicParsing -TimeoutSec 3 -ErrorAction Stop http://localhost:8080/api/health | Out-Null; $ready = $true; break } catch { Start-Sleep 2 }
}
if (-not $ready) { Fail "The app didn't come up in 6 minutes. See what went wrong with:  docker compose logs backend" }

$ip = (Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
       Where-Object { $_.IPAddress -notlike "127.*" -and $_.IPAddress -notlike "169.254.*" -and $_.InterfaceAlias -notmatch "vEthernet|WSL|Docker|Loopback" } |
       Select-Object -First 1).IPAddress
Write-Host ""
Write-Host "  CampusPilot is running!" -ForegroundColor Green
Write-Host "     On this computer:          http://localhost:8080"
Write-Host "     Friends on the same Wi-Fi: http://$($ip):8080"
Write-Host ""
Write-Host "  Demo logins (only in demo mode):"
Write-Host "     Student  rohan@campuspilot.edu  / student123"
Write-Host "     Faculty  priya@campuspilot.edu  / teach123"
Write-Host "     Admin    admin@campuspilot.edu  / admin123"
Write-Host "     Parent   parent@campuspilot.edu / parent123"
Write-Host ""
Write-Host "  The AI Copilot downloads its model in the background (~2 GB, first run only)."
Write-Host "  Stop: start.bat -Stop"
Start-Process "http://localhost:8080"
