#!/bin/sh
# Starts the Ollama server and downloads the copilot model on first run
# (a few GB, once — it's kept in the "ollama" volume afterwards).
set -e
ollama serve &
SERVER=$!
until ollama list >/dev/null 2>&1; do sleep 1; done
MODEL="${OLLAMA_MODEL:-qwen2.5:3b}"
if ollama list | awk 'NR>1 {print $1}' | grep -qx "$MODEL"; then
  echo "campuspilot: model $MODEL already downloaded"
else
  echo "campuspilot: downloading $MODEL (first start only, may take several minutes)..."
  ollama pull "$MODEL"
fi
wait $SERVER
