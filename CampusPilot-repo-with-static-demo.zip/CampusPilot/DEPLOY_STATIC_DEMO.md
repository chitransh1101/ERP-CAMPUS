# Live demo on GitHub Pages (free, always on)
1. Make the repository **public**.
2. Repo **Settings → Pages → Build and deployment → Source: GitHub Actions**.
3. Push to `main` (or Actions → "Deploy static demo to GitHub Pages" → Run workflow).
4. After ~2 minutes the link is `https://<your-username>.github.io/<repo-name>/`.
Logins are on the sign-in page. It runs on recorded sample data; changes are not saved.
