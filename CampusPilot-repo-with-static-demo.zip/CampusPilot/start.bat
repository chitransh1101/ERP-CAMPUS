@echo off
REM CampusPilot - double-click to start. Stop: start.bat -Stop   Fresh start: start.bat -Reset
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0start.ps1" %*
if errorlevel 1 pause
