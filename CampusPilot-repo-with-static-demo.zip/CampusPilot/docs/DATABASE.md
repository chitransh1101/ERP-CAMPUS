# Where the database comes from (and how to put your college's data in it)

**Short version:** there's nothing to download. CampusPilot **creates its own
database** the first time it starts. What you choose is (1) *where* it lives
and (2) *what goes in it* — demo data, or your college's real records.

## 1. Where the database lives

| Setup | Database | Where the data is stored | Good for |
|---|---|---|---|
| `docker compose up` (recommended) | **PostgreSQL 16**, bundled | Docker volume `pgdata` on your server | Real use on a college server / VPS |
| `uvicorn` on a laptop (no Docker) | **SQLite** file | `backend/campuspilot.db` | Development, trying it out |
| Hosted Postgres | Any PostgreSQL 13+ | Your provider | When you don't want to run a DB server |

The app reads one setting, `DATABASE_URL`:

```
sqlite:///./campuspilot.db                                   # default, zero setup
postgresql://USER:PASSWORD@HOST:5432/campuspilot             # PostgreSQL
mysql+pymysql://USER:PASSWORD@HOST:3306/campuspilot          # MySQL / MariaDB
```

Tables are created automatically on start-up — no SQL scripts to run.

### Hosted PostgreSQL options
Any PostgreSQL works; paste its connection string into `DATABASE_URL`. A few providers with free tiers (check their pages for current limits):

- **Neon** — free plan: 0.5 GB storage per project, scales to zero when idle. <https://neon.com/docs/introduction/plans>
- **Supabase** — free projects are paused after a week of low activity, so use a paid plan for anything real. <https://supabase.com/docs/guides/platform/free-project-pausing>
- **Render Postgres** — used by `render.yaml`; the free database is temporary, so upgrade it for real data.
- **Your institution's cloud** (AWS RDS, Azure Database for PostgreSQL, Google Cloud SQL) — best for official deployments; ask your IT team.

For a single college, 0.5 GB comfortably holds several years of attendance
(roughly 60 bytes × students × classes).

## 2. What goes in it

### Option A — demo campus (to explore)
Set `SEED_DEMO=true`. On first start the app loads 24 students, 6 faculty,
10 courses, attendance, marks, fees, grievances and placements. Demo logins
appear on the sign-in screen. **Never use demo mode with real people's data** —
the demo passwords are public.

### Option B — your college's real data
1. In `.env` set `SEED_DEMO=false`, `ADMIN_EMAIL` and a strong `ADMIN_PASSWORD` (12+ characters).
2. `docker compose up --build`. The app creates an empty database plus that one admin account.
   Remove `ADMIN_PASSWORD` from `.env` afterwards.
3. Sign in as the admin → **Data Import**. Import these CSV files **in order**
   (download each template from the page, or copy the examples in `sample_data/`):

   | Step | File | Columns | Where your college usually has this |
   |---|---|---|---|
   | 1 | users | `name,email,role,id_label,department,year,section` | Admissions register / HR staff list |
   | 2 | courses | `code,name,dept,faculty_email` | Academic timetable / course catalogue |
   | 3 | enrollments | `course_code,student_id_label` | Class lists per subject |
   | 4 | fees | `student_id_label,total,paid,due_date` | Accounts office ledger |

   Export each from Excel/Google Sheets as **CSV (UTF-8)**. Bad rows are skipped
   and listed with the reason; fix them and re-upload just those rows.
4. Every imported account gets a **one-time password**, shown once after import
   (use "Copy to clipboard"). Everyone must choose their own password at first sign-in.

**Roll numbers matter:** `id_label` is what the OCR looks for on attendance
sheets. Use exactly the roll numbers printed on your sheets (letters and digits,
e.g. `CS21B045`). Each one must be unique.

## 3. Backups (do this before real use)

```bash
# PostgreSQL (docker compose)
docker compose exec db pg_dump -U campuspilot campuspilot > backup-$(date +%F).sql
# restore
cat backup.sql | docker compose exec -T db psql -U campuspilot campuspilot
```
Schedule the dump daily (cron) and keep copies off the server.
For SQLite, copy `campuspilot.db` while the app is stopped.

## 4. Upgrading from the previous CampusPilot version
The schema changed a lot (real foreign keys, enrollments, per-student
submissions, per-user notifications), so the old `campuspilot.db` is **not
compatible**. Delete it (or `docker compose down -v` for the old volume) and
start fresh, then re-import your data as above.
