# Parent alerts: SMS and WhatsApp

CampusPilot tells parents when something needs their attention:

| Alert | When it's sent |
|---|---|
| Absent today | A teacher publishes attendance (photo, QR or manual) and the student was absent |
| Low attendance | Overall attendance falls below `LOW_ATTENDANCE_THRESHOLD` (75 %) — at most once a week |
| Fee reminder | Admin → Parents & Alerts → **Send fee reminders** (everyone with a balance) |
| Payment received | Admin records a fee payment |
| Results | Sessional marks or exam results are published |
| Exam schedule | The exam cell schedules an exam |

Every alert also appears in the parent's portal (bell + *Alerts* page) and in **Admin → Parents & Alerts → Alert outbox**, with its delivery status. Choose which alerts go out with `PARENT_ALERTS` in `.env`.

## 1. Link parents to students

- One at a time: **Admin → Parents & Alerts → Parents → Link parent** (name, email, mobile, relation).
- In bulk: **Admin → Data Import → parents** with columns `name,email,phone,student_id_label,relation` (see `sample_data/5_parents.csv`).

A parent with several children uses one login — link the same email to each child. New parent accounts get a one-time password, shown to the admin once.

Mobile numbers: 10-digit Indian mobiles (`98765 43210`) are stored as `+919876543210`; other countries need the full `+<country code>` number.

## 2. Pick how messages are sent (`.env`)

### Demo mode (default, free)
```
MESSAGING_PROVIDER=log
```
Nothing leaves the server. Messages are saved in the outbox with status *logged* — perfect for demos and testing.

### Twilio — SMS or WhatsApp
1. Create an account at https://www.twilio.com/ and note the **Account SID** and **Auth Token**.
2. SMS: buy/verify a sender number. WhatsApp: start with the **WhatsApp sandbox** (Messaging → Try it out), then apply for a WhatsApp sender for production.
3. In `.env`:
```
MESSAGING_PROVIDER=twilio
MESSAGING_CHANNEL=whatsapp          # or sms
TWILIO_ACCOUNT_SID=ACxxxxxxxxxxxxxxxx
TWILIO_AUTH_TOKEN=xxxxxxxxxxxxxxxx
TWILIO_FROM_WHATSAPP=+14155238886   # the sandbox number, or your approved sender
TWILIO_FROM_SMS=+1XXXXXXXXXX        # for MESSAGING_CHANNEL=sms
```
4. `docker compose up -d`, then **Admin → Parents & Alerts → Send test** to your own phone.

With the sandbox, each parent must first send the sandbox's join code to the sandbox number once.

**India (SMS):** commercial SMS to Indian numbers must be registered on DLT (TRAI) with an approved sender ID and templates — your SMS provider guides you through it. WhatsApp avoids DLT.

### Meta WhatsApp Cloud API
1. Create an app at https://developers.facebook.com/ → add **WhatsApp** → note the **Phone number ID** and create a permanent **access token**.
2. In `.env`:
```
MESSAGING_PROVIDER=meta
META_WHATSAPP_TOKEN=EAAG...
META_WHATSAPP_PHONE_ID=1234567890
```
WhatsApp only allows free-form text within 24 hours of the parent last messaging you. For alerts that start a conversation, create approved **message templates** in WhatsApp Manager. The sending code is in `backend/app/messaging.py` (`_send_meta`); switch the payload to `"type": "template"` with your template name.

## How sending works

Alerts are written to an outbox table in the same transaction as the event that caused them. A background worker sends them every few seconds and retries failures 3 times. A slow or broken SMS gateway never slows down the teacher publishing attendance. Failed messages show the provider's error in the outbox and can be retried. Phone numbers are masked in the admin list.
