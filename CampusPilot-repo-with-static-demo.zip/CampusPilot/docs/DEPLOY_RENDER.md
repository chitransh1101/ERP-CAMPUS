# Permanent public link (free): Render + Neon

Result: a link like **https://campuspilot-web.onrender.com** that works for anyone, any time, without your Codespace running.

- **Neon** (neon.tech) hosts the database: free forever, no card.
- **Render** (render.com) runs the app: free web services.
- Free services **sleep after 15 minutes without visitors**. The next visitor waits about 1 minute while it wakes up. If the first page shows an error, refresh after a minute.
- The local AI (Ollama) needs more memory than the free plan has, so the Copilot uses its built-in assistant. To get real AI answers, add a Claude key (see the end of this guide).

## 1. Database on Neon (3 minutes)
1. Go to https://neon.tech → **Sign up** → **Continue with GitHub**.
2. Create a project: name `campuspilot`, Postgres version as suggested, region **AWS Asia Pacific (Singapore)** (closest to India) → **Create**.
3. On the project dashboard click **Connect**. Copy the **connection string**. It looks like
   `postgresql://neondb_owner:xxxx@ep-xxxx.ap-southeast-1.aws.neon.tech/neondb?sslmode=require`
   Keep it private: it's the database password.

## 2. App on Render (10–15 minutes, mostly waiting)
1. Go to https://render.com → **Get Started** → **GitHub** and allow access to your **CampusPilot** repository.
2. Click **New +** → **Blueprint** → pick **CampusPilot** → **Connect**.
   Render reads `render.yaml` and shows two services: `campuspilot-api` and `campuspilot-web`.
3. Fill in the values it asks for:

   | Key | Value |
   |---|---|
   | `DATABASE_URL` | the Neon connection string from step 1 |
   | `PUBLIC_URL` | `https://campuspilot-web.onrender.com` |
   | `BACKEND_URL` | `https://campuspilot-api.onrender.com` |
   | `BACKEND_HOST_HEADER` | `campuspilot-api.onrender.com` |

4. Click **Apply** / **Deploy Blueprint**. Both services build (about 5–10 minutes). Wait until both show **Live**.
5. Open **https://campuspilot-web.onrender.com**. That's your permanent link.

### If Render gave your services different names
If someone already uses `campuspilot-web` or `campuspilot-api`, Render adds letters (e.g. `campuspilot-web-x7k2`). Check the real addresses at the top of each service page. Then:
- **campuspilot-api → Environment**: set `PUBLIC_URL` to the real website address → **Save, rebuild and deploy**.
- **campuspilot-web → Environment**: set `BACKEND_URL` and `BACKEND_HOST_HEADER` to the real API address → **Save, rebuild and deploy**.

## 3. Share it
Send the website link. Demo logins are shown under **Demo credentials** on the sign-in page. QR attendance, hall tickets, ID-card QR verification and parent alerts all use this address automatically.

Every `git push` to GitHub redeploys the app automatically.

## Optional
- **Real AI copilot:** campuspilot-api → Environment → set `COPILOT_PROVIDER=anthropic` and add `ANTHROPIC_API_KEY` (from console.anthropic.com).
- **Real SMS/WhatsApp:** add the `MESSAGING_*` / `TWILIO_*` keys from docs/ALERTS.md in the same place.
- **Real college (not demo):** set `SEED_DEMO=false`, `ADMIN_EMAIL`, `ADMIN_PASSWORD` (12+ characters) on a **fresh** Neon database, sign in, then remove `ADMIN_PASSWORD`. Also set `DEMO_MODE=false` on campuspilot-web to hide the demo logins.
- **No sleeping:** upgrade both Render services to a paid instance, or run `bash start.sh` on any always-on server (VPS / college server) instead.
- **Your own domain** (e.g. erp.yourcollege.edu): campuspilot-web → Settings → Custom Domains, then update `PUBLIC_URL`.
