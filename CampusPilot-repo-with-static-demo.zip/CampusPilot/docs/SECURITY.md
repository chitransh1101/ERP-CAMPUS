# Security model

Every item below has an automated test in `backend/tests/test_api.py` or the browser test.

## Authentication and sessions
- **Exact email matching.** The old login used `ILIKE` with raw input, so an email of `%` signed in as the first admin. Emails are now stored lower-case and compared exactly.
- **Passwords:** PBKDF2-HMAC-SHA256 with 600,000 iterations and a per-user salt, compared in constant time. Older hashes are upgraded automatically at the next login. Policy: 8+ characters, letters and numbers, not a common password, and not containing the user's email name.
- **No user enumeration:** an unknown email and a wrong password get the same message and take the same time (a dummy hash is checked).
- **Brute-force protection:** a per-account lockout (5 failures → 5 minutes, doubling on repeats) plus per-IP login and signup rate limits and a global per-IP request limit.
- **Revocable sessions:** each login creates a `user_sessions` row. Every request re-checks that row *and* the user's current status. Logging out, changing a password, a password reset or deactivation takes effect **immediately**; the old version kept deactivated users' tokens working. Deactivation also closes that user's live WebSocket connections.
- **Tokens the browser's JavaScript can't read:** the session lives in an `httpOnly`, `SameSite=Lax` cookie (`Secure` when on HTTPS), so an XSS bug can't steal it. The old version kept it in `localStorage`.
- **CSRF protection:** a double-submit token (`cp_csrf` cookie + `X-CSRF-Token` header) is required on every state-changing request that uses the cookie.
- **Admin-created accounts** get a unique random one-time password and must change it at first login. The old version gave everyone `changeme123`.
- **Self-signup** can't create admins, and in production can't create faculty either. Duplicate roll numbers are rejected, because roll numbers identify students on OCR sheets.

## Authorization (who can touch what)
- Roles are checked on every endpoint, and **ownership** is checked too:
  - Teachers can only mark attendance, publish grades, post assignments, materials and notices for **their own courses**, and only for students **enrolled** in them. The old version accepted any course.
  - Students only see their own records. Assignment submission is **per student**; the old version marked an assignment submitted for everyone.
  - Private notifications ("your application was rejected", "your grievance was resolved") go **only to that person**. The old version broadcast them to the whole role.
- **Placement eligibility** (CGPA and attendance) is enforced on the server from real records. The old version only greyed out a button.
- Admins can't deactivate themselves or the last active admin.

## Input and uploads
- Every request body goes through a strict schema: length limits, allowed values (`Literal`), numeric ranges (scores 0–100, CGPA 0–10), and unknown fields dropped, so there is no mass assignment. Malformed ids return 404, never 500.
- **Photo uploads:** checked by magic bytes (JPEG/PNG/WebP/BMP/TIFF only), 12 MB per photo, 10 photos per request, and a pixel limit against decompression bombs. Images are decoded in memory with no temp files named after user input. At most 2 OCR jobs run at once, and the per-user rate is capped.
- Request bodies over the size limit are refused before they're parsed.
- CSV import: 2 MB and 5,000 rows maximum, UTF-8 only, and each row is validated inside its own savepoint.

## HTTP hardening
- API responses: `X-Content-Type-Options`, `X-Frame-Options: DENY`, `Referrer-Policy: no-referrer`, a strict CSP, `Cache-Control: no-store`, and HSTS when on HTTPS.
- Web app (nginx): a strict **Content-Security-Policy** with `script-src 'self'` and no inline scripts (runtime config is served as `/config.js`), `frame-ancestors 'none'`, and an nginx-level rate limit.
- CORS is an explicit allow-list (`*` is refused in production). In the default setup the browser only ever talks to its own origin, because nginx proxies `/api`.
- The WebSocket checks the `Origin` header (against cross-site WebSocket hijacking), authenticates with the session cookie, and re-validates the session every few minutes.
- Unhandled errors return a generic message, and stack traces stay in the server log. `/docs` is disabled in production.
- Containers run as **non-root** users. The API and database aren't published to the internet; only nginx is.
- Production start-up **refuses** to run with a missing or short `SECRET_KEY` or `CORS_ORIGINS='*'`.

## AI Copilot
- The model never touches the database. It can only call **read-only tools** for the user's own role, and each tool runs the same checked code as the app's own screens, as the signed-in user. The tool list sent to the model contains only that role's tools. Calling any other tool returns "Unknown tool" (tested: a student's copilot can't reach fee dues or other students' data, and a teacher's can't read another teacher's course).
- **Actions are proposals only.** The server returns a confirm card; the browser runs the normal endpoint, with CSRF and validation, only when the user clicks Confirm. Prompt injection hidden in data (for example a grievance's text) therefore can't make it act. The system prompt also tells the model to treat tool results as data.
- Limits: 500-character questions, a 12-turn validated history (only `user`/`assistant` roles, so a client can't inject a `system` message), 12 messages a minute, a per-user daily cap, at most 5 tool rounds, and trimmed tool results.
- Privacy: with the default local AI (Ollama), questions and records never leave your server; the Ollama container isn't exposed outside the Docker network. With Claude or another cloud provider, the question and the records the copilot looks up are sent to that provider, and the chat window says which one. Chat text isn't stored on the server.

## Audit trail
Sign-ins, failed sign-ins, and every create, update, publish, approve or reset are written to the audit log with the actor and IP address. Admins see new entries live.

## Known limits / next steps
- Rate limits, lockouts and live connections are held in memory, which is right for the default single API process. To run several API processes, move them to Redis (see `app/realtime.py`).
- Study-material "upload" records the file's details, not the file itself. Add object storage (S3 or similar) before relying on it.
- Put the site behind **HTTPS** (e.g. Caddy, Cloudflare Tunnel, or your host's TLS) and set `COOKIE_SECURE=true`.

## New features (v3)

- **Parents** only ever see students an admin linked to them (every `/parent/children/{id}/…` call checks the link; other ids return 404). Parents can't self-register, can't use student/teacher/admin APIs, and have no copilot access.
- **QR attendance**: the QR token and the 6-digit code are HMAC-SHA256 of a per-session random secret and the current 15-second window, so they can't be predicted, and a forwarded photo expires within 45 s. Students can only check in to courses they're enrolled in, once per session. Code guessing is limited to 12 tries a minute per student. A random device id flags one phone checking in several students.
- **Document verification**: QR codes on ID cards, hall tickets, grade cards and certificates carry a token signed with `SECRET_KEY` (HMAC-SHA256). Edited or forged tokens are rejected. The public page shows only name, roll number, role and department, never email or marks, and it's rate-limited per IP. Bonafide certificates must also exist in the issued-documents register.
- **HOD analytics** are granted by an admin (`department_heads` table), not by the self-editable "designation" profile field, and are always pinned to the HOD's own department.
- **Parent alerts** are queued in the database and sent by a background worker. Provider keys stay in `.env`. Phone numbers are masked in the admin outbox.
- **Installable app**: the service worker caches only the app's own files and never `/api/*` or `/ws`, so personal data is never stored on the device by the service worker.
- **PDF downloads** require the signed-in session and only ever contain the caller's own data (or, for admins, aggregate reports).
